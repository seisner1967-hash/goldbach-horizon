FINITE IDENTITIES AND EXPLICIT ERROR BUDGETS IN A FRAMEWORK FOR BINARY GOLDBACH
Author: Durand Serge
Research synthesis and reproducibility report, version 1, 1 October 2026

DELIVERABLES
goldbach_synthesis.pdf: English research synthesis, abstract, tables,
proofs of finite identities and written analytic deductions, formal
statement appendix, bibliography and precise unresolved targets.
goldbach_synthesis.tex: one standalone LaTeX source; bibliography is inline.
goldbach_arxiv_source.zip: minimal manuscript source and build instructions.
goldbach_verification_bundle.zip: canonical Lean sources, retained evidence,
complete electronic declaration inventory and selected analytic provenance.

AUTHORSHIP AND SCOPE
This report is a synthesis of partial results, not a proof of binary
Goldbach and not a claim that the parity barrier has been overcome.
The 658 accumulated explicitly axiom-audited declarations, 852 lexical
declarations and 19 latest public conclusions are distinct counts.
The latest 19 statements are printed with hypotheses in the PDF; the
full 658-entry statement registry accompanies the verification bundle.
Analytic distribution, contour and sieve estimates are written arguments,
not Lean theorems. The primitive-character direct remainder is an explicit
reported input whose full substitution has not been reproduced in the PDF;
the universal gap and effective assembly depending on it are conditional.
The effective quarter profile and the qualitative
eighth profile remain separate. Global signed smallness and a complete
positive prime-pair margin remain open.

PREPARATION CHECKS
Current preparation rechecked 472 frozen archive payloads, source
bindings, declaration headers and retained compilation/axiom evidence.
It did not perform a new Lean compilation or rerun every historic test.
Targeted checks by separate AI agents are internal reviews, not external
peer review. No external mathematical validation or publication is claimed.

LATEX BUILD
The delivered PDF was compiled using the existing Tectonic XeTeX engine.
The native editor's compiler returned a platform-directory configuration
error; the source editor was preserved and the exported PDF was compiled
and inspected with the existing local compiler instead.
The standalone source uses ordinary TeX Live packages and Latin Modern
fonts, with no private fonts, external figures, shell escape or BibTeX.
Suggested TeX Live build (run twice for the contents and cross-references):
  pdflatex -interaction=nonstopmode -halt-on-error goldbach_synthesis.tex
  pdflatex -interaction=nonstopmode -halt-on-error goldbach_synthesis.tex
Alternatively use xelatex twice or tectonic --untrusted.
No submission has been made; arXiv source compatibility does not guarantee
arXiv acceptance or journal acceptance.

LEAN REPLAY
See reproducibility/lean/README_REPRODUCTION.txt and portable_replay.py.
Lean 4.15.0 and Mathlib revision
9837ca9d65d9de6fad1ef4381750ca688774e608 must be available.
The portable script defaults to checking a new build plan without compiling.
Actual source replay requires --execute and eight pinned dependency roots.
Existing .olean files are not included as substitutes for fresh compilation.

CORPUS AND PRIVACY
The report describes scoped local/Drive/GitHub coverage and selected reads.
Metadata triage is not proof validation. The bundle does not distribute
unrelated Drive metadata, third-party article PDFs, dependency caches,
private general-computer data or copies of the entire research archive.
Primary literature is linked in the bibliography, including version pins.

AI ASSISTANCE
AI assisted corpus retrieval, formal/analytic exploration, drafting and
internal checking. Durand Serge is the named human author; the report
discloses the assistance and states that human mathematical responsibility
and external review are required before making publication claims.
