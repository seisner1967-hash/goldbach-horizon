"""Render all final pages and record PDF structure; visual review is separate."""
from pathlib import Path
import argparse,json,re,hashlib,subprocess
from pypdf import PdfReader
from PIL import Image,ImageOps,ImageDraw
R=Path(__file__).resolve().parent.parent
ap=argparse.ArgumentParser();ap.add_argument('--render',action='store_true');a=ap.parse_args()
pdf=R/'goldbach_synthesis.pdf';out=R/'qa';out.mkdir(exist_ok=True)
reader=PdfReader(pdf);fonts={};texts=[]
def resolve(obj):return obj.get_object() if hasattr(obj,'get_object') else obj
def scan_fonts(resources):
    if not resources:return
    resources=resources.get_object()
    for key,ref in resolve(resources.get('/Font',{})).items():
        font=ref.get_object();name=str(font.get('/BaseFont',key))
        descendants=font.get('/DescendantFonts',[])
        fs=[x.get_object() for x in descendants] if descendants else [font]
        embedded=all(any(k in resolve(f.get('/FontDescriptor',{}))
                         for k in ('/FontFile','/FontFile2','/FontFile3')) for f in fs)
        fonts[name]={'type':str(font.get('/Subtype')),'embedded':embedded}
    for ref in resolve(resources.get('/XObject',{})).values():
        obj=ref.get_object()
        if obj.get('/Subtype')=='/Form':scan_fonts(obj.get('/Resources'))
for page in reader.pages:
    scan_fonts(page.get('/Resources'));texts.append(page.extract_text() or '')
(out/'extracted_text.txt').write_text('\n\n'.join(f'PAGE {i+1}\n{t}' for i,t in enumerate(texts)),encoding='utf-8')
log=(R/'goldbach_synthesis.log').read_text(encoding='utf-8',errors='replace')
receipt={'pdf':pdf.name,'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),
 'bytes':pdf.stat().st_size,'pages':len(reader.pages),'metadata':{str(k):str(v) for k,v in reader.metadata.items()},
 'fonts':fonts,'all_fonts_embedded':all(v['embedded'] for v in fonts.values()),
 'encrypted':reader.is_encrypted,'contains_javascript':'/JavaScript' in repr(reader.trailer),
 'missing_character_log_lines':[s for s in log.splitlines() if 'Missing character' in s],
 'overfull_log_lines':[s for s in log.splitlines() if 'Overfull' in s],
 'undefined_log_lines':[s for s in log.splitlines() if 'undefined' in s.lower()],
 'replacement_glyph_pages':[i+1 for i,t in enumerate(texts) if '\ufffd' in t],
 'visual_review':'pending human-visible inspection by root agent',
 'rendered_all_pages':False}
if a.render:
    pop=Path(r'C:\Users\Utilisateur\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe')
    subprocess.run([str(pop),'-r','90','-png',str(pdf),str(out/'page')],check=True,capture_output=True)
    pages=sorted(out.glob('page-*.png'),key=lambda p:int(p.stem.rsplit('-',1)[1]))
    assert len(pages)==len(reader.pages),(len(pages),len(reader.pages))
    contacts=[]
    for start in range(0,len(pages),12):
        sheet=Image.new('RGB',(1120,1710),'#e3e5e8');d=ImageDraw.Draw(sheet)
        for j,p in enumerate(pages[start:start+12]):
            im=Image.open(p).convert('RGB');im.thumbnail((350,525))
            x=15+(j%3)*370;y=24+(j//3)*420
            # 3 x 4 grid, width preserves full-page thumbnail readability.
            im.thumbnail((350,390));sheet.paste(im,(x+(350-im.width)//2,y))
            d.text((x+140,y+394),f'Page {start+j+1}',fill='black')
        dest=out/f'contact-{start//12+1:02}.png';sheet.save(dest);contacts.append(dest.name)
    receipt['rendered_all_pages']=True;receipt['contact_sheets']=contacts
(out/'pdf_qa_receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in receipt.items() if k!='fonts'},indent=2))
