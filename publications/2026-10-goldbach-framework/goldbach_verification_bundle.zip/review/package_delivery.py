"""Package scoped evidence without publishing or changing historical files."""
from pathlib import Path
import json,hashlib,zipfile,shutil
R=Path(__file__).resolve().parent.parent; old=R.parent/'Goldbach_Research_20260930'
assert not json.loads((R/'review'/'manuscript_assembly_receipt.json').read_text(encoding='utf-8'))['partial']
assert json.loads((R/'qa'/'pdf_qa_receipt.json').read_text(encoding='utf-8'))['visual_review']=='PASS; all final page contact sheets and selected full pages inspected'
analytic=R/'reproducibility'/'analytic';analytic.mkdir(parents=True,exist_ok=True)
selected=[
 'goldbach_research.tex',
 'scripts/verify_lemmas.py','scripts/validate_quadrature.py','scripts/cs21_reanalysis.py',
 'data/cs21_reanalysis.csv','data/cs21_summary.json','data/exact_checks.json','data/quadrature_checks.json',
 'sprint4/manuscript_scope.txt',
 'sprint17/Positive_Rough_Divisor_Addendum_Corrected.txt',
 'sprint17/agents/Rosser_Convention_Audit.txt',
 'sprint18/input/Cofacteur_Court_Original/Goldbach_Continuation_Cofacteur_Court_2026-10-01.txt',
 'sprint18/agents/Short_Cofactor_Audit_and_Positive_Dyadic_Refinements.txt',
 'sprint21/Checkpoint21_Final_Audit_and_Open_Signed_Target_2026-10-01.txt',
 'sprint21/Terminal_Vaughan_U_Invariant_And_Selector_Defect.txt',
 'sprint21/Actual_Weight_Second_Moment_And_AP_Transport.txt',
 'sprint21/Brun_Titchmarsh_Actual_Weight_Transport.txt',
 'sprint21/Small_Conductors_Uniform_Prefix_Budget_R_L16.txt',
 'sprint21/Actual_Mobius_AP_Rebalanced_Contour_Linear_Budget.txt',
 'sprint21/Whole_EJ_Shrinking_Universal_Reference_Assembly.txt',
 'sprint21/agents/Actual_Mobius_AP_Zero_Avoiding_Contour.txt',
 'sprint21/agents/formal_Growing_Unit_Mask_Near_One_Product.txt',
 'sprint21/agents/Centered_Type_I_Singular_Reduction_And_Real_AP_Head.txt',
 'sprint21/agents/Type_I_Principal_Character_Line_Explicit_Budget.txt',
 'sprint21/agents/Type_I_Divisible_U1_Explicit_Budget.txt',
 'sprint21/Universal_Budget_Adaptive_Page_Cutoff_10pow24.txt',
 'sprint21/agents/Primitive_Zero_Subtraction_Direct_Remainder_Budget.txt',
 'sprint21/agents/Universal_Missing_Prime_Square_Reference.txt',
 'sprint21/agents/Whole_Type_I_U1_Shrinking_Budget_With_Page_Projection.txt',
 'sprint21/agents/EZ_Whole_Shrinking_Budget_Large_Onset.txt',
 'sprint21/agents/Composite_Negative_Credit_At_Alpha_Eighth_Classical_Lower_Sieve_v2.txt',
 'sprint21/agents/Alpha_Eighth_All_Rough_Upper_And_Composite_Credit.txt',
 'sprint21/agents/Completed_Rough_Triple_Selberg_Aggregate_Budget.txt',
 'sprint21/agents/Fixed_Kernel_Direct_Net_Credit_Without_Covered_Excess.txt',
 'sprint21/agents/Exceptional_Conductor_Weighted_Projection.txt',
 'sprint21/agents/formal_R_Main_Euler_Mertens_Budget_v2.txt',
 'sprint21/check_universal_adaptive_page_cutoff.py',
 'sprint21/check_rebalanced_mobius_contour_linear_budget.py',
 'sprint21/check_actual_weight_transport_guards.py',
 'sprint21/check_terminal_U_invariant.py',
 'sprint21/agents/check_primitive_direct_remainder_guards.py',
 'sprint21/agents/check_universal_square_reference_guards.py',
 'sprint21/agents/check_EZ_shrinking_large_onset.py',
 'sprint21/agents/check_whole_type_i_shrinking_page_budget.py',
 'sprint21/agents/check_completed_rough_triple_selberg_budget.py',
 'sprint21/agents/check_alpha_eighth_composite_credit_v2_constants.py',
 'sprint21/root_universal_adaptive_page_cutoff_checks.json',
 'sprint21/root_actual_weight_transport_checks.json',
 'sprint21/root_rebalanced_mobius_contour_linear_budget_checks.json',
 'sprint21/root_alpha_eighth_composite_credit_v2_actual_replay.json',
 'sprint21/root_completed_rough_triple_selberg_replay.json',
]
bindings=[]
for rel in selected:
    src=old/rel
    if not src.is_file():raise FileNotFoundError(src)
    dest=analytic/rel;dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(src,dest)
    assert src.read_bytes()==dest.read_bytes()
    bindings.append({'path':rel,'origin':str(src),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),
                     'bytes':dest.stat().st_size})
(analytic/'SOURCE_BINDINGS.json').write_text(json.dumps({'files':bindings,'scope':'Selected retained written deductions and finite guard checks; not a fresh execution certificate.'},indent=2),encoding='utf-8')
(analytic/'README_ANALYTIC.txt').write_text(
 'Selected analytic provenance, not a complete historical archive.\n'
 'The final manuscript governs the claimed profiles and onsets.\n'
 'Older notes and the French first-phase source are historical context.\n'
 'The adaptive 10^24 onset supersedes looser earlier universal assemblies.\n'
 'Guard scripts verify arithmetic comparisons, not zero-free regions or sieve density.\n'
 'Scripts retain original paths/output behavior; inspect before running them and use a new directory.\n'
 'No retained test report is represented as a current execution.\n'
 'Third-party primary articles are supplied by bibliography links, not redistributed.\n',encoding='utf-8')
abstract_source=(R/'goldbach_synthesis.tex').read_text(encoding='utf-8')
import re
abstract=re.search(r'\\begin\{abstract\}(.*?)\\end\{abstract\}',abstract_source,re.S).group(1).strip()
(R/'arxiv_metadata.txt').write_text(
 'Title: Finite Identities and Explicit Error Budgets in a Framework for Binary Goldbach\n'
 'Author: Durand Serge\nLanguage: English\nSuggested subject: math.NT\n'
 'MSC: 11P32\nStatus: Research synthesis of partial results; no Goldbach proof.\n'
 'Abstract (LaTeX):\n'+abstract+'\n',encoding='utf-8')
def create_zip(path,files):
    payload=[]
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for src,name in sorted(files,key=lambda x:x[1]):
            b=src.read_bytes();z.writestr(name,b)
            payload.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
        z.writestr('MANIFEST.json',json.dumps({'payloads':payload},indent=2))
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        for p in payload:assert hashlib.sha256(z.read(p['path'])).hexdigest()==p['sha256']
    return {'file':path.name,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'payloads':len(payload),'crc_and_manifest':'PASS'}
source=create_zip(R/'goldbach_arxiv_source.zip',[(R/'goldbach_synthesis.tex','goldbach_synthesis.tex'),
 (R/'README.txt','README.txt'),(R/'arxiv_metadata.txt','arxiv_metadata.txt')])
evidence=[(p,p.relative_to(R).as_posix()) for p in (R/'reproducibility').rglob('*') if p.is_file()]
review_names=['lean_inventory.json','lean_inventory.md','lean_inventory_full_statement_appendix.txt',
 'lean_inventory_sprint21_appendix.txt','lean_inventory_module_table.tsv',
 'lean_header_completeness_correction_receipt.json','portable_replay_preparation_receipt.json',
 'Manuscript_Lean_And_Sector_Scope_Review.txt','Manuscript_Lean_And_Sector_Scope_Review.json',
 'Amended_Scope_And_Exterior_Guards_Review.txt','Amended_Scope_And_Exterior_Guards_Review.json',
 'lean_references_static_receipt.json',
 'analytic_sectors_and_prior_corpus.txt','Intro_Proxy_Ending_Targeted_Scope_Review.txt',
 'Intro_Proxy_Ending_Scope_Exact_Checks.json',
 'exterior_and_literature.txt','exterior_source_receipt.json',
 'Exterior_Source_Exact_Checks.json',
 'manuscript_assembly_receipt.json','build_manuscript.py','qa_pdf.py','package_delivery.py']
for n in review_names:
    p=R/'review'/n
    if p.is_file():evidence.append((p,'review/'+n))
for p in (R/'review').glob('*.tex'):evidence.append((p,'review/'+p.name))
evidence += [(R/'README.txt','README.txt'),(R/'arxiv_metadata.txt','arxiv_metadata.txt'),
 (R/'corpus'/'final_integrity_receipt.json','corpus/final_integrity_receipt.json'),
 (R/'corpus'/'github_audit_note.json','corpus/github_audit_note.json'),
 (R/'qa'/'pdf_qa_receipt.json','qa/pdf_qa_receipt.json')]
for n in ('coverage_summary.json','github_tree_metadata.json'):
    p=R/'corpus'/n
    if p.is_file():evidence.append((p,'corpus/'+n))
bundle=create_zip(R/'goldbach_verification_bundle.zip',evidence)
receipt={'source_package':source,'verification_bundle':bundle,
 'analytic_origin_bindings':len(bindings),'no_lean_compilation_performed':True,
 'no_submission_or_publication_performed':True}
(R/'DELIVERY_PACKAGES.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt,indent=2))
