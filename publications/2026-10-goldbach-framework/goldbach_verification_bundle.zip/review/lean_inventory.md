# Formal proof inventory for the Goldbach research corpus

Prepared on 1 October 2026 by an independent inventory/review agent. This report supplies the formal-evidence boundary for the English partial-results manuscript. It does not claim Goldbach, an unconditional global off-diagonal estimate, or a formalization of the classical analytic inputs.

## Scope and counting policy

The local search covered `Goldbach_Research_20260930` (the numbered research phases through sprint21, including the historical sprint2 repository) and `arbor-goldbach-native-main`. No applicable `AGENTS.md` was found in the workspace ancestry or these roots. Old research files and archives were read without modification. The output files of this inventory are confined to `Goldbach_Final_20261001/review`.

The scan found 894 physical Lean source files, with 502 distinct byte hashes across the two roots. Compilation copies, extracted archives, imported declarations and the two historical repository copies are explicitly separated from new results. The canonical sprint selection has 71 source files, including five audit/import/probe files with no theorem declarations; 66 files contain theorem or lemma declarations. It has 852 lexical theorem/lemma declarations, comprising 833 public declarations and 19 private helpers. Lexical presence is not, by itself, a claim of a successful compilation or an audited axiom footprint.

The registered, explicitly printed standard-axiom theorem subset contains **658 distinct fully qualified name/statement pairs** across the canonical sprint modules. This is an inventory of previously retained compilation evidence, not 658 new results from the final research phase. Source headers are matched against the names in the actual `#print axioms` logs; repeated imports and replay copies do not increase this count. The standard axiom vocabulary in the accepted subset is `propext`, `Classical.choice`, and `Quot.sound` (individual declarations may use a proper subset). No canonical sprint source contains a proof token `sorry`, `admit`, `native_decide`, or a custom `axiom` declaration after comments are stripped.

The count suitable for the latest-results abstract is **19 new, explicitly audited, finite public conclusions in sprint21**. It consists of 16 conclusions in the immutable audit snapshot and three later small-divisor-credit conclusions in the continuation addendum. Its six modules have actual production compilation and a separate fresh replay, with source/log/olean hashes and standard axiom reports retained. Private helper lemmas and recompiled old dependencies are not counted in these 19. This inventory did not run another Lean compilation; it verifies the evidence already produced by the research and independent replay agents.

`lean_inventory.json` is the electronic registry. It retains source paths and SHA256, exact theorem headers and hypotheses, public/private status, imports, receipt paths and SHA256, JSON record locations, log and compiled-artifact hashes, explicit axiom sets, source-copy groups, and the separately classified historical repository. `lean_inventory_sprint21_appendix.txt` gives the exact 19 latest theorem statements for the printed manuscript appendix. A full electronic statement appendix is supplied separately; printing every historical lemma would obscure the mathematical report.

## Audited families and exact counts

| Phase | Individually audited theorem statements | Formal content | Mathematical boundary |
|---|---:|---|---|
| 3 | 52 | Finite Fourier/Parseval and convolution identities, interval semantics, an explicit finite spectral example, exact arithmetic variance/Gram interfaces | A finite example and an error-reduction identity do not establish an asymptotic Goldbach estimate |
| 4 | 132 | Proxy coefficient energy and four-modulus combinatorics; anchor partitions, diagonal bounds, finite mass/simplex and cutoff geometry | Proxy/combinatorial majorants do not supply signed Möbius cancellation |
| 5 | 51 | Exact Ramanujan/Fourier formulas, folded windows, smoothing and signed cofactor kernels | A geometrically bounded or folded kernel is not a bound for the final arithmetic direction |
| 6 | 57 | Actual Vaughan identities, finite Heath-Brown-type identities, Type-II active rectangle assembly and weighted variance reduction | Type-I analytic estimates and the required Type-II cancellation remain written analytic inputs, not Lean conclusions |
| 7–9 | 25 | Four-sign pair structure; actual beta-weighted contractions and calibration/support geometry | Exact fibers and calibration provide no uniform cancellation merely from small finite energy ratios |
| 10–12 | 123 | Character splitting and nonunit correction, Kloosterman energy geometry, signed module transfer; literal conductor support, joint coprimality and shifted dispersion; two-index sector partitions | Exact orthogonality and support do not imply a spectral contraction or a small off-diagonal term |
| 13–15 | 135 | Multiplicity/diagonal and conditional off-diagonal budgets, finite Euler-factor bounds, prime-pair margin interfaces and proper-power reductions; scalar/cofactor boundary and Möbius short/long/cutoff identities | Effective margins require their stated arithmetic loss hypotheses; the infinite singular-product enclosure and analytic tails are written deductions |
| 16–18 | 58 | Ratio pushforward and finite Gauss factorization; literal Rosser boundary and signed sector assembly; actual parity masses and finite reference-gap inequalities | The model is subtracted once; a one-sided error budget alone does not prove a positive prime mass |
| 19 | 0 | Written explicit endpoint, mask and Mertens transport | No new Lean analytic theorem was created |
| 20 | 6 | Actual Möbius logarithmic divisor fibers and exact partial-prime-fiber branches | No complete lcm valuation classification or Bombieri–Vinogradov theorem in Lean is claimed |
| 21 | 19 | Actual Euler projection, literal-cut fiber bound, terminal cutoff invariant, full-H prime orbit, complete rough divisor kernel, and actual small-divisor credit | All are finite support/coefficient or accounting results; the global signed target and positive Goldbach margin remain open |
| **Total** | **658** | Individually printed, standard-axiom statements without repeated imports/replays | This total counts formal infrastructure and conditional interfaces, not solved analytic estimates |

Phases1 and2 are historical intake/repository stages without new canonical numbered-sprint modules in this selection. Sprint19 deliberately introduced no new Lean result. These absences are explicit inventory facts, not missing claims silently inferred from research prose.

## Latest six modules: what has actually been proved

| Module | Public audited results | Source SHA256 |
|---|---:|---|
| `GoldbachActualEulerProjection` | 1 | `7521a244da3f6000d4841156dee78f819bf9a1e075d6da127dacf6c0170520c0` |
| `GoldbachActualDivisorFibreBound` | 1 | `f9cdd1d266889b5f672ef76c35b845e51e1b81a6d3bedcd49737b01c26281e44` |
| `GoldbachActualTerminalCutoffInvariant` | 3 | `52a6a5b0d0f59879d2567df1415d8d4d9e2f5ff695a57421db18282a97a5c039` |
| `GoldbachCompleteHPrimeOrbit` | 5 | `df14ac670788ddbf2091cc62c41b93156267425ef937927f12945edf5f2ffa5e` |
| `GoldbachLiteralDivisorCompletion` | 6 | `fd3c4885ff79241c25b977af1954cbd8c1512e133dc4ccf9f391b6558c474fde` |
| `GoldbachActualSmallDivisorCredit` | 3 | `25feafb7ce3ce408ec76cd83e36682e947b508d0e580cd419ab6630c62c11a16` |

The local Euler projection is a genuine finite Möbius/totient coefficient calculation. For prime p it gives the actual selected/unselected factors `-1/p` and `1-1/[p(p-1)]`. It does not formalize an infinite Euler product, its convergence, a Mertens transport, or the numerical bound for `R_main`.

The literal-cut bound proves, for natural r,s,alpha all at least1, that the absolute actual truncated signed divisor coefficient is at most `s.divisors.card * log(alpha)`. It retains the original cutoff rather than replacing its coefficient by a free abstract sequence. It does not prove the classical AP distribution estimate to which the bound is later applied.

The terminal cutoff module uses the actual arithmetic row definitions and the exact Vaughan completion. It proves `fullRow+smallRow=primeRow`, the exact terminal defect with `e+|e|`, and the change-of-U identity. It does not make that excess term small and does not prove the covered bridge. Its hypotheses and definitions must be kept when the result is described as a terminal accounting identity.

The complete-H module defines the real arithmetic H by a finite convolution with Möbius coefficients beyond y. Its exact rough formula is `H_y(n)=mu(n)+1-2*1[n=1]`, including the exceptional value at1. It proves a literal divisor orbit and `H_y(p*e)=-H_y(e)` when p is prime at most y and e is y-rough and positive. The final finite orbit inequality retains the actual H coefficients, logarithms, low/high selectors and an explicit nonnegative low selector. It controls a completed pair and exposes the moving-boundary cost; it does not assert that arbitrary actual selectors satisfy a favorable closure inequality.

The divisor-completion module first proves the complete identity `sum_{k|m} mu(k)log(k/m)=-Lambda(m)` for nonzero m. It then proves literal proper-divisor admission and the original integer cap for rough m, and obtains the composite/prime specializations. The original Q and strict `alpha*k<m` face are present in the actual statements. The analytic sign of the harmonic W kernel is a separate written input, not a formal theorem in this module.

The small-divisor-credit module proves an arithmetic support theorem, rather than assuming the conclusion as an admission hypothesis: if alpha<P, L>0, all proper divisors of P are at most alpha, and every prime divisor of L is greater than alpha, then the small divisors of P*L are exactly all proper divisors of P. It obtains `j_alpha(P*L)=Lambda(P)+mu(P)log(P)`. With `not IsPrimePow(P)` and `mu(P)=-1`, this becomes `-log(P)`. These explicit assumptions imply the negative coefficient; they do not establish that its sector carries a sufficient mass of actual prime first-axis rows.

## Earlier results that warrant precise manuscript wording

The exact `R_k=B_k+C_k+E_k` character bookkeeping, nonunit corrections and finite energy identities are formal algebraic results. Their identities do not promote the analytic negligibility of B and E, or the cancellation of C, into a Lean theorem. In the Kloosterman geometry, an invertible-variable permutation can preserve energy. The finite Gauss factorization in sprint16 is stated for arbitrary E and F on a finite commutative group with a character into complex units; it uses inverses explicitly. No unit-norm hypothesis or nonunit-frequency exclusion is smuggled into that factorization.

The ratio-pushforward results certify a finite energy transfer, including injective support geometry under their hypotheses. A successful injection theorem gives an isometry of that packet; it does not give Möbius cancellation within its squared norm. Coupled character/histogram coefficients must remain coupled when these results are instantiated.

The signed-sector assembly in sprint17 explicitly subtracts the full main model once and keeps the complementary signed sector. Its theorem `signed_one_sided_transfer` proves only `S>=-reserve` from the stated identity and target inequality. `positive_margin_requires_reserved_gap` requires a separate strict positive margin and a reference large enough to pay loss+reserve+margin. An explicit zero-mass witness shows that the one-sided budget alone cannot establish positivity. This conditional status should survive every restatement in the manuscript.

The actual parity-mass module in sprint18 keeps positive finite discrete masses before subtracting a model. Weighted positive/negative allocations give exact sum and signed-difference identities. A discrepancy C-M can have either sign, and must not be used as a nonnegative counting measure. This is distinct from the reference-gap module: its compiled eight results give finite or conditional real inequalities with explicit input bounds. Later sharper numerical analytic reference constants were established only in writing; they were not retroactively formalized by the old source.

The prime-pair-margin code distinguishes a one-Mangoldt/squarefree representation quantity from the final detector with both axes prime. Proper prime powers and retained unit constraints are explicit owners. A rational positive margin on finitely many reference instances is not a proof for every sufficiently large even integer.

The written estimates for growing masks, conductor tails, Davenport inputs, ordinary Mertens transport, Akbary–Hambrook/Bordignon distribution, zero-avoiding Möbius contours, and classical lower/upper sieve remain analytic proofs outside Lean. This includes the alpha-eighth negative aggregate credits with an unevaluated/ineffective onset. Their exact finite coefficient ingredients are formalized; their prime density and global analytic summations are not. The same-profile exterior and the complementary signed deficit remain open.

## Historical Horizon repository and excluded assertions

The registry separately inventories 668 physical historical source copies across the sprint2 repository and `arbor-goldbach-native-main`; their byte-identical copies are grouped and never added to the new-sprint theorem count. This search did not establish a fresh successful source-bound compilation plus full standard-axiom audit for the historical repository as a whole. The presence of a local `.lake/build` directory is not such evidence, and its relevant matching oleans were not established in this source-level selection.

The local `AUDIT_NOTE.md` explicitly reports that four out of five old external predicates were trivially satisfiable or insufficiently tied to their intended arithmetic operators. `PCBAsymptotic` is defined as the eventual positivity of the Goldbach representation count for every even integer, and therefore already contains the asymptotic Goldbach assertion. The old conditional assembly must not be presented as an independent proof or as a reduction to four harmless inputs plus a newly solved fifth condition.

Historical source flags include `sorry` in `A2Certificate.lean` and in some `G26Verify` files, explicit custom axioms in `G26Verify/HorizonGoldbach.lean`, and `native_decide` in finite certificates or probes. These observations do not invalidate unrelated correctly checked finite theorems; they require a separate trust/scope classification and prevent an unqualified “entire historical repository compiled without sorry or nonstandard axioms” claim. Some historical native certificates establish finite numerical statements only.

The live GitHub tree retrieved by the coordinating agent is pinned to commit `979c05416140504f11c6e9ba6ad1dd565838bea1`. The local repository files were hashed as local evidence, without assuming that every file equals this remote commit. `Goldbach_Final_20261001/corpus/github_tree_metadata.json` records the independently obtained remote metadata. A local README or source file must not be represented as the live remote version merely because the project names agree.

## Reproduction and archive references

The accepted recent environment is Lean4.15.0, commit `11651562caae`, with Mathlib pinned to `9837ca9d65d9de6fad1ef4381750ca688774e608`. The eight imported dependency library roots in the actual fresh replays are aesop, batteries, importGraph, LeanSearchClient, mathlib, plausible, proofwidgets and Qq under `q356-canonical-binding-replay/.lake/packages`. Standard Lean system libraries are implicit. The independent fresh build directories are initially absent or olean-empty; old production module paths are excluded from the fresh proof replay.

The six latest modules have retained compile scripts. Examples use PowerShell `-File <compile_script> -BuildDirectory <new_absolute_empty_directory>`; the script establishes LEAN_PATH, copies the intended source, invokes the pinned Lean compiler, checks forbidden proof tokens and `#print axioms`, and writes source/log/olean hashes. The registry records the exact script paths and build receipts; appendices should refer to these scripts rather than invent a `lake build` command for a standalone module importing older project sources.

The immutable sprint21 base snapshot is `goldbach_sprint21_audit_snapshot_20261001.zip`, SHA256 `3b88e4f9367fb2b9718450df362149d1f4bcfa1fda886851e0db22091c35d720` (398 payloads plus manifest, 16 new conclusions). Its continuation addendum is `goldbach_sprint21_reviewed_continuation_addon_20261001.zip`, SHA256 `66dc5eecb878c78a260a469200bb6f81d48d8b14146b5fd4a06a357c7b1a5347` (67 payloads plus manifest, three new conclusions, combined count19). The final separate rough-sector supplement is `goldbach_sprint21_post_freeze_rough_supplement_20261001.zip`, SHA256 `9d44c84e76e78af0a0de3219881a821976f397688c5db271fa21b6034eff1442` (seven payloads plus manifest, zero new Lean results). The external independent receipts checked all CRC, SHA256, sizes and payload bytes, source/review bindings and the unchanged prior archives. Archive integrity verifies provenance; it is not a new analytic proof.

## Suggested manuscript appendices

1. Print the exact 19 sprint21 theorem statements, including all positivity, prime/roughness, support and cutoff assumptions, with six source hashes and the standard axiom footprint. Supply the local definitions needed to read the displayed Lean types, or the corresponding mathematical definitions earlier in the manuscript.
2. Print the compact family/count table above and provide `lean_inventory.json` plus the full electronic theorem-statement appendix as ancillary material. Keep historical imports and private helpers outside the “new results” count.
3. Give the toolchain/dependency pin, the original compile scripts, production and independent fresh replay receipt references, and the three immutable archive hashes. Reproducing a build in a new directory must not mutate the frozen package.
4. State the open hypotheses next to each conditional transfer: off-diagonal/signed deficit, covered support where that route is used, exact model ownership, sufficient reserve, proper-power/unit losses, and same-profile exterior estimates. Distinguish the direct fixed-kernel accounting route from a route that retains a covered excess term; do not add the two accounting conventions or spend the same negative credit twice.

This report deliberately ends with an evidence boundary: finite formal identities and conditional implications have been checked; the remaining arithmetic estimate and an unconditional positive prime-pair margin have not.
