"""Assemble one standalone TeX file for the native editor and arXiv."""
from pathlib import Path
import argparse,re,json,hashlib
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--partial',action='store_true');args=ap.parse_args()
names=['preamble.tex','intro.tex','proxy.tex','sectors.tex','exterior.tex','ending.tex']
missing=[n for n in names if not (R/n).exists()]
if missing and not args.partial:raise FileNotFoundError('Missing fragments: '+', '.join(missing))
pieces=[(R/n).read_text(encoding='utf-8') for n in names if (R/n).exists()]
pieces+=['\n\\appendix\n',(R/'lean_appendix.tex').read_text(encoding='utf-8'),
         '\n\\clearpage\n',(R/'bibliography.tex').read_text(encoding='utf-8'),'\n\\end{document}\n']
s='\n\n'.join(pieces)
# Narrow table cells are easier to read with normal word spacing.
s=re.sub(r'(\\begin\{(?:tabularx|tabular|longtable)\}[^\n]+)',
         lambda m:m.group(1).replace('p{','P{'),s)
# Print Lean Unicode with ordinary TeX math fonts.  The electronic headers
# and original Lean sources remain byte-exact; only the PDF listing rendering
# uses math escapes, avoiding unsupported Unicode in traditional typewriter fonts.
glyphs={'ℕ':r'\mathbb N','ℝ':r'\mathbb R','ℤ':r'\mathbb Z','ℂ':r'\mathbb C',
        '≤':r'\le','≥':r'\ge','≠':r'\ne','∀':r'\forall','∃':r'\exists',
        '→':r'\to','↔':r'\leftrightarrow','∧':r'\land','∨':r'\lor',
        '¬':r'\neg','∈':r'\in','∣':r'\mid','∑':r'\sum'}
def render_listing(match):
    body=match.group(2)
    for glyph,tex in glyphs.items():body=body.replace(glyph,'(*@$'+tex+'$@*)')
    return match.group(1)+body+match.group(3)
s=re.sub(r'(\\begin\{lstlisting\}[^\n]*\n)(.*?)(\\end\{lstlisting\})',
         render_listing,s,flags=re.S)
s=s.replace('showstringspaces=false,tabsize=2,',
            'showstringspaces=false,tabsize=2,escapeinside={(*@}{@*)},')
# All listing glyphs are now escaped; do not retain raw-Unicode literate keys.
s=re.sub(r'\n  literate=.*?(?=\n\})','',s,flags=re.S)
labels=re.findall(r'\\label\{([^}]+)\}',s)
assert len(labels)==len(set(labels)),[l for l in labels if labels.count(l)>1]
citations=set(k.strip() for c in re.findall(r'\\cite(?:\[[^]]*\])?\{([^}]+)\}',s) for k in c.split(','))
refs=set(re.findall(r'\\bibitem(?:\[[^]]*\])?\{([^}]+)\}',s))
assert citations<=refs,'Missing bibliography keys: '+repr(citations-refs)
path=R.parent/'goldbach_synthesis.tex';path.write_text(s,encoding='utf-8')
receipt={'source':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
         'characters':len(s),'fragments':names,'missing_fragments':missing,'partial':bool(missing),
         'fragment_hashes':{n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in names+['lean_appendix.tex','bibliography.tex'] if (R/n).exists()},
         'labels':len(labels),'citation_keys':sorted(citations),'bibliographic_items':len(refs)}
(R/'manuscript_assembly_receipt.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt,indent=2))
