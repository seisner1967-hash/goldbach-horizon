$ErrorActionPreference = 'Stop'
$taskRoot = 'D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930'
$taskOutput = Join-Path $taskRoot 'sprint15\agents\full_project_replayfresh'
$taskLean = 'C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskPackages = 'D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskOldCopies = Join-Path $taskRoot 'sprint15\agents\rough_cofactors_replay'
$taskProduction = Join-Path $taskRoot 'sprint15\lean'
$taskSpecs = @(
  @{name='GoldbachBridge'; origin=$taskOldCopies; expected='6d5cb30279cfd7c5eb46c7e1fde0d3616848b6eaae11a2d63a194422b8433ef5'; count=$null},
  @{name='GoldbachArithmetic'; origin=$taskOldCopies; expected='b83d5687844a96eef91b8129d0f95da7e04b54f678935693946cf0469bcc915c'; count=$null},
  @{name='GoldbachVaughan'; origin=$taskOldCopies; expected='f75239a846dcd13ca7f0bc39616998e31172b51ce4f98f0f55d498ef31953a99'; count=$null},
  @{name='GoldbachMoebiusComplement'; origin=$taskProduction; expected='25e3e0d9d80759d26ae860cbeca1d098eb027b2541547a8d32dcee6c2df712f4'; count=8},
  @{name='GoldbachMoebiusShortLong'; origin=$taskProduction; expected='e1ce90975a2db06478346fe47403f7a853fe2d5d316935ed5832964c493bf279'; count=15},
  @{name='GoldbachRoughCofactors'; origin=$taskProduction; expected='877bdfb0d135d9c2aa87455db055e26e0df46cf5fa0f78920278def41ebf3dbe'; count=13},
  @{name='GoldbachCutoffInvariance'; origin=$taskProduction; expected='546f9e328f7d4f880ecc078fd9605d9694ee15a10f94368ae0e524590727ee73'; count=6}
)
$taskLibraries = @('aesop','batteries','importGraph','LeanSearchClient','mathlib','plausible','proofwidgets','Qq') | ForEach-Object {
  Join-Path $taskPackages (Join-Path $_ '.lake\build\lib')
}
foreach ($taskLibrary in $taskLibraries) {
  if (-not (Test-Path -LiteralPath $taskLibrary -PathType Container)) { throw "Missing library: $taskLibrary" }
}
New-Item -ItemType Directory -Path $taskOutput -Force | Out-Null
$taskExistingOleanders = @(Get-ChildItem -LiteralPath $taskOutput -Filter '*.olean' -File)
if ($taskExistingOleanders.Count -ne 0) { throw 'Fresh replay output already contains oleans; do not overwrite an existing receipt.' }
$taskSourceRecords = @()
foreach ($taskSpec in $taskSpecs) {
  $taskSource = Join-Path $taskSpec.origin ($taskSpec.name + '.lean')
  $taskCopy = Join-Path $taskOutput ($taskSpec.name + '.lean')
  $taskOriginalHash = (Get-FileHash -LiteralPath $taskSource -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($taskOriginalHash -ne $taskSpec.expected) { throw "Frozen source hash mismatch: $($taskSpec.name)" }
  Copy-Item -LiteralPath $taskSource -Destination $taskCopy
  $taskCopyHash = (Get-FileHash -LiteralPath $taskCopy -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($taskOriginalHash -ne $taskCopyHash) { throw "Copied source hash mismatch: $($taskSpec.name)" }
  $taskImports = @(Get-Content -LiteralPath $taskCopy | Where-Object { $_ -match '^import ' })
  $taskSourceRecords += [ordered]@{name=$taskSpec.name; original=$taskSource; copy=$taskCopy; sha256=$taskCopyHash; imports=$taskImports; expected_new_reports=$taskSpec.count}
}
$taskPreviousLeanPath = $env:LEAN_PATH
$taskImportPaths = @($taskOutput) + $taskLibraries
$env:LEAN_PATH = $taskImportPaths -join ';'
$taskImportPaths | Set-Content -LiteralPath (Join-Path $taskOutput 'import_paths.txt') -Encoding utf8
$taskVersion = & $taskLean --version
$taskBuilds = @()
try {
  foreach ($taskRecord in $taskSourceRecords) {
    $taskOlean = Join-Path $taskOutput ($taskRecord.name + '.olean')
    $taskLog = Join-Path $taskOutput ($taskRecord.name + '.log')
    $taskBuildStart = [DateTime]::UtcNow
    & $taskLean -o $taskOlean $taskRecord.copy *> $taskLog
    $taskExit = $LASTEXITCODE
    $taskLogText = Get-Content -LiteralPath $taskLog -Raw
    $taskReports = @([regex]::Matches($taskLogText, "'[^']+' depends on axioms: \[[\s\S]*?\]") | ForEach-Object { $_.Value -replace '\s+', ' ' })
    $taskUnexpected = @($taskReports | ForEach-Object {
      [regex]::Match($_, '\[(.*?)\]').Groups[1].Value -split ',\s*' | Where-Object { $_ -and $_ -notin @('propext','Classical.choice','Quot.sound') }
    })
    $taskForbidden = @(Select-String -LiteralPath $taskRecord.copy -Pattern '\bsorry\b|\badmit\b|\bnative_decide\b|^\s*axiom\b')
    $taskDiagnostics = @($taskLogText -split "\r?\n" | Where-Object { $_ -match '(^|\W)(error|warning):' })
    $taskBuilds += [ordered]@{
      name=$taskRecord.name; compiler_exit=$taskExit; elapsed_seconds=([DateTime]::UtcNow-$taskBuildStart).TotalSeconds;
      axiom_reports=$taskReports; expected_new_reports=$taskRecord.expected_new_reports; unexpected_axioms=$taskUnexpected;
      forbidden_matches=$taskForbidden.Count; diagnostics=$taskDiagnostics;
      source_sha256=$taskRecord.sha256;
      olean_sha256=$(if (Test-Path -LiteralPath $taskOlean) {(Get-FileHash -LiteralPath $taskOlean -Algorithm SHA256).Hash.ToLowerInvariant()} else {$null});
      log_sha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant()
    }
    Write-Output ("Built {0}: exit={1}, reports={2}, diagnostics={3}" -f $taskRecord.name,$taskExit,$taskReports.Count,$taskDiagnostics.Count)
    if ($taskExit -ne 0) { break }
  }
} finally {
  $env:LEAN_PATH = $taskPreviousLeanPath
}
$taskFailures = @($taskBuilds | Where-Object {
  $_.compiler_exit -ne 0 -or $_.unexpected_axioms.Count -ne 0 -or $_.forbidden_matches -ne 0 -or $_.diagnostics.Count -ne 0 -or
  ($null -ne $_.expected_new_reports -and $_.axiom_reports.Count -ne $_.expected_new_reports)
})
$taskNewBuilds = @($taskBuilds | Where-Object { $null -ne $_.expected_new_reports })
$taskNewCount = ($taskNewBuilds | ForEach-Object { $_.axiom_reports.Count } | Measure-Object -Sum).Sum
$taskReceipt = [ordered]@{
  status=$(if ($taskBuilds.Count -eq 7 -and $taskFailures.Count -eq 0 -and $taskNewCount -eq 42) {'PASS'} else {'FAIL'});
  reviewer='/root/short_interval11'; independent_integrated_replay=$true; lean_version=$taskVersion;
  import_policy='Only this initially olean-empty fresh replay directory and eight Mathlib dependency libraries; standard Lean system libraries are implicit. No production or prior sprint/project olean path.';
  import_paths=$taskImportPaths; source_records=$taskSourceRecords; builds=$taskBuilds;
  new_theorem_count=$taskNewCount; expected_new_theorem_count=42;
  reason_for_recheck='The earlier Complement replay included cached project Arithmetic oleans, while the other newer replays compiled their source dependencies freshly. This integrated replay establishes the stronger fresh-dependency portability contract without contradicting the earlier valid finite proofs.';
  scope='Finite complementary Mobius signs and capped divisor/reference identities; actual short/long convolution and supports; rough beta/log support, coprime Mobius fusion and CRT discriminant; cutoff algebra. No distribution, smallness, variance bound, effective prime-pair margin, or Goldbach theorem.';
  replay_script_sha256=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()
}
$taskReceipt | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $taskOutput 'receipt.json') -Encoding utf8
Write-Output ("Integrated replay {0}: {1} new reports from {2} source builds." -f $taskReceipt.status,$taskNewCount,$taskBuilds.Count)
if ($taskReceipt.status -ne 'PASS') { exit 1 }
