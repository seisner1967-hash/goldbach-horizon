$ErrorActionPreference = 'Stop'
$taskResearchRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$taskPriorLibs = @('sprint12', 'sprint11', 'sprint10', 'sprint9', 'sprint8', 'sprint7', 'sprint6', 'sprint5', 'sprint4', 'sprint3') | ForEach-Object {
    Join-Path $taskResearchRoot ($_ + '\lean')
}
$taskCacheRoot = 'D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskLeanExe = 'C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskLibs = @(Get-ChildItem -LiteralPath $taskCacheRoot -Directory | ForEach-Object {
    $taskCandidate = Join-Path $_.FullName '.lake\build\lib'
    if (Test-Path -LiteralPath $taskCandidate) { $taskCandidate }
})
$env:LEAN_PATH = [string]::Join(';', @($PSScriptRoot) + $taskPriorLibs + $taskLibs)
$taskModule = 'GoldbachOffDiagonalBudget'
$taskSource = Join-Path $PSScriptRoot ($taskModule + '.lean')
& $taskLeanExe -o (Join-Path $PSScriptRoot ($taskModule + '.olean')) $taskSource *> (Join-Path $PSScriptRoot ($taskModule + '.log'))
$taskExit = $LASTEXITCODE
Get-Content -LiteralPath (Join-Path $PSScriptRoot ($taskModule + '.log'))
exit $taskExit
