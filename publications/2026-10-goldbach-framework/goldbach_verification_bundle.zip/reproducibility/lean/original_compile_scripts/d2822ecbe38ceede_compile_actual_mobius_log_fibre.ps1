param([string]$BuildDirectory = 'D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930\sprint20\agents\formal_mobius_log_productionfresh_v1')
$ErrorActionPreference = 'Stop'
$taskRoot = 'D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930\sprint20'
$taskBuild = [System.IO.Path]::GetFullPath($BuildDirectory)
if (-not $taskBuild.StartsWith($taskRoot + '\agents\formal_', [System.StringComparison]::OrdinalIgnoreCase)) {
    throw 'Build directory must remain in sprint20/agents/formal_*.'
}
if (Test-Path -LiteralPath $taskBuild) {
    throw 'This replay requires an initially absent fresh build directory.'
}
New-Item -ItemType Directory -Path $taskBuild | Out-Null
$taskOriginal = Join-Path $taskRoot 'lean\GoldbachActualMobiusLogFibre.lean'
$taskCopy = Join-Path $taskBuild 'GoldbachActualMobiusLogFibre.lean'
Copy-Item -LiteralPath $taskOriginal -Destination $taskCopy
$taskPackages = 'D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskLibraries = @('aesop','batteries','importGraph','LeanSearchClient','mathlib','plausible','proofwidgets','Qq') |
    ForEach-Object { Join-Path $taskPackages ($_ + '\.lake\build\lib') }
foreach ($taskLibrary in $taskLibraries) {
    if (-not (Test-Path -LiteralPath $taskLibrary)) { throw 'Missing Mathlib dependency library.' }
    if (Test-Path -LiteralPath (Join-Path $taskLibrary 'GoldbachActualMobiusLogFibre.olean')) {
        throw 'Unexpected project olean in an external dependency library.'
    }
}
$taskImports = @($taskBuild) + $taskLibraries
$env:LEAN_PATH = $taskImports -join ';'
$taskImports | Set-Content -LiteralPath (Join-Path $taskBuild 'import_paths.txt') -Encoding UTF8
$taskLean = 'C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskOlean = Join-Path $taskBuild 'GoldbachActualMobiusLogFibre.olean'
$taskLog = Join-Path $taskBuild 'GoldbachActualMobiusLogFibre.log'
$taskSourceText = Get-Content -LiteralPath $taskCopy -Raw
if ($taskSourceText -match '(?m)^\s*axiom\b|\b(sorry|admit|native_decide)\b') {
    throw 'Forbidden proof bypass in source.'
}
& $taskLean -o $taskOlean $taskCopy *> $taskLog
$taskExit = $LASTEXITCODE
if ($taskExit -ne 0) { Get-Content -LiteralPath $taskLog; throw 'Lean compilation failed.' }
$taskLogText = Get-Content -LiteralPath $taskLog -Raw
if ($taskLogText -match '(?i)error:|sorryAx|native_decide') { throw 'Forbidden diagnostic.' }
$taskAxioms = [regex]::Matches($taskLogText, "(?s)'([^']+)' depends on axioms:\s*\[([^\]]*)\]")
$taskReports = @()
foreach ($taskReport in $taskAxioms) {
    $taskNames = @($taskReport.Groups[2].Value.Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' })
    foreach ($taskName in $taskNames) {
        if ($taskName -notin @('propext','Classical.choice','Quot.sound')) { throw 'Unexpected theorem axiom.' }
    }
    $taskReports += @{ theorem = $taskReport.Groups[1].Value; axioms = $taskNames }
}
if ($taskReports.Count -ne 4) { throw 'Expected exactly four theorem reports.' }
$taskHash = { param($p) (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant() }
$taskReceipt = @{
    status = 'PASS'; compiler_exit = $taskExit; new_theorem_count = $taskReports.Count;
    lean_version = (& $taskLean --version | Out-String).Trim();
    source_original = $taskOriginal; source_copy = $taskCopy;
    source_sha256 = (& $taskHash $taskOriginal); copied_source_sha256 = (& $taskHash $taskCopy);
    olean_sha256 = (& $taskHash $taskOlean); log_sha256 = (& $taskHash $taskLog);
    compiler_script_sha256 = (& $taskHash $PSCommandPath);
    import_policy = 'Initially absent new sprint20/agents/formal_* build directory, and exactly eight Mathlib dependency libraries. No old production or frozen writes.';
    import_paths = $taskImports; axiom_reports = $taskReports;
    scope = 'Actual shifted Mobius-log divisor identity; original truncated signed coefficient collapses on full r*s<=alpha fibre, prime and nonprime cases. No lcm classification, AP budget or Goldbach conclusion.';
}
if ($taskReceipt.source_sha256 -ne $taskReceipt.copied_source_sha256) { throw 'Copy hash mismatch.' }
$taskReceipt | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath (Join-Path $taskBuild 'receipt.json') -Encoding UTF8
Write-Output ($taskReceipt | ConvertTo-Json -Depth 20)
