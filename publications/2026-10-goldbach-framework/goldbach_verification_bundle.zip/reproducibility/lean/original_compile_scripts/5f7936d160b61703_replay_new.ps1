$ErrorActionPreference='Stop'
$taskSprintRoot=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$taskResearchRoot=Split-Path $taskSprintRoot -Parent
$taskExpected=@{
    GoldbachOffDiagonalBudget='19c127ff1906bb991f5fea6aa8a06922289c4e67d5110461aae1d2e12a9693fe'
    GoldbachPrimePairMargin='74d3ccd9802464695c8008e00907be23c251ee12d681fc9d941b0cd65ec5982a'
}
$taskLeanExe='C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskCacheRoot='D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskPriorLibs=@('sprint12','sprint11','sprint10','sprint9','sprint8','sprint7','sprint6','sprint5','sprint4','sprint3') | ForEach-Object {
    Join-Path $taskResearchRoot ($_+'\lean')
}
$taskCacheLibs=@(Get-ChildItem -LiteralPath $taskCacheRoot -Directory | ForEach-Object {
    $taskCandidate=Join-Path $_.FullName '.lake\build\lib'
    if(Test-Path -LiteralPath $taskCandidate){$taskCandidate}
})
$taskPaths=@($PSScriptRoot)+$taskPriorLibs+$taskCacheLibs
$env:LEAN_PATH=[string]::Join(';',$taskPaths)
$taskReports=@()
foreach($taskModule in @('GoldbachOffDiagonalBudget','GoldbachPrimePairMargin')){
    $taskOriginal=Join-Path $taskSprintRoot ('lean\'+$taskModule+'.lean')
    $taskCopy=Join-Path $PSScriptRoot ($taskModule+'.lean')
    $taskOlean=Join-Path $PSScriptRoot ($taskModule+'.olean')
    $taskLog=Join-Path $PSScriptRoot ($taskModule+'.log')
    $taskBefore=(Get-FileHash -LiteralPath $taskOriginal -Algorithm SHA256).Hash.ToLowerInvariant()
    if($taskBefore -ne $taskExpected[$taskModule]){throw 'Frozen source hash mismatch'}
    Copy-Item -LiteralPath $taskOriginal -Destination $taskCopy
    & $taskLeanExe -o $taskOlean $taskCopy *> $taskLog
    $taskExit=$LASTEXITCODE
    $taskAfter=(Get-FileHash -LiteralPath $taskOriginal -Algorithm SHA256).Hash.ToLowerInvariant()
    $taskText=Get-Content -LiteralPath $taskLog -Raw
    $taskSourceText=Get-Content -LiteralPath $taskCopy -Raw
    $taskRequested=([regex]::Matches($taskSourceText,'(?m)^#print axioms ')).Count
    $taskReceived=([regex]::Matches($taskText,'depends on axioms:')).Count
    $taskAxiomSets=@([regex]::Matches($taskText,'depends on axioms:\s*\[([^\]]*)\]') | ForEach-Object {
        ,@($_.Groups[1].Value -split ',' | ForEach-Object {$_.Trim()})
    })
    $taskUnexpected=@($taskAxiomSets | ForEach-Object {$_} | Where-Object {$_ -notin @('propext','Classical.choice','Quot.sound')})
    $taskBad=([regex]::Matches($taskText,'(?mi)\berror:|\bwarning:|sorryAx')).Count
    $taskPass=($taskExit -eq 0)-and($taskBad -eq 0)-and($taskUnexpected.Count -eq 0)-and
        ($taskBefore -eq $taskAfter)-and($taskRequested -eq $taskReceived)
    $taskReports+=[ordered]@{
        module=$taskModule; status=$(if($taskPass){'PASS'}else{'FAIL'});
        compiler_exit_code=$taskExit; source_sha256=$taskBefore; source_after_sha256=$taskAfter;
        copied_source_sha256=(Get-FileHash -LiteralPath $taskCopy -Algorithm SHA256).Hash.ToLowerInvariant();
        olean_sha256=$(if(Test-Path -LiteralPath $taskOlean){(Get-FileHash -LiteralPath $taskOlean -Algorithm SHA256).Hash.ToLowerInvariant()}else{$null});
        log_sha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant();
        requested_axiom_reports=$taskRequested; received_axiom_reports=$taskReceived;
        errors_warnings_sorryAx=$taskBad; unexpected_axioms=$taskUnexpected;
        all_audit_axioms_allowed=($taskUnexpected.Count -eq 0); axiom_sets=$taskAxiomSets
    }
    Write-Output ($taskModule+': '+$(if($taskPass){'PASS'}else{'FAIL'})+' '+$taskReceived+' axiom reports')
}
$taskTotalReports=0
foreach($taskReportItem in $taskReports){$taskTotalReports += [int]$taskReportItem['received_axiom_reports']}
$taskReceipt=[ordered]@{
    status=$(if(@($taskReports | Where-Object {$_.status -ne 'PASS'}).Count -eq 0){'PASS'}else{'FAIL'});
    compiler=$taskLeanExe; original_current_sprint_import_path_excluded=$true;
    import_paths=$taskPaths; modules=$taskReports; total_axiom_reports=$taskTotalReports;
    literal_scope='Actual completed-C capped ordinary Cauchy mass and reflected cubic divisor moment ingredients; actual prime-support bridge and four finite positive margins. Full diagonal bound, central off-diagonal estimate and global transfer/error budgets remain explicit unproved premises.'
}
$taskReceipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'lean_replay_receipt.json') -Encoding utf8
if($taskReceipt.status -ne 'PASS'){throw 'Independent replay failed; artifacts preserved'}

