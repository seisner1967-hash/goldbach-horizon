$ErrorActionPreference='Stop'
$taskSprintRoot=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$taskResearchRoot=Split-Path $taskSprintRoot -Parent
$taskExpected=@{
    GoldbachShiftedDispersion='3c078ed7ad8f4832f94c6e31929d9a29bef90e23c7fce1755e93a9a2c22eb72a'
    GoldbachJointCoprimality='f894c372f9c7ad07b8f37bdf857783805e4e6c0f02bb2e5c277525a32cbc1df8'
}
$taskLeanExe='C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskCacheRoot='D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskPriorLibs=@('sprint11','sprint10','sprint9','sprint8','sprint7','sprint6','sprint5','sprint4','sprint3') | ForEach-Object {
    Join-Path $taskResearchRoot ($_+'\lean')
}
$taskCacheLibs=@(Get-ChildItem -LiteralPath $taskCacheRoot -Directory | ForEach-Object {
    $taskCandidate=Join-Path $_.FullName '.lake\build\lib'
    if(Test-Path -LiteralPath $taskCandidate){$taskCandidate}
})
$taskPaths=@($PSScriptRoot)+$taskPriorLibs+$taskCacheLibs
$env:LEAN_PATH=[string]::Join(';',$taskPaths)
$taskReports=@()
foreach($taskModule in @('GoldbachShiftedDispersion','GoldbachJointCoprimality')){
    $taskOriginal=Join-Path $taskSprintRoot ('lean\'+$taskModule+'.lean')
    $taskCopy=Join-Path $PSScriptRoot ($taskModule+'.lean')
    $taskOlean=Join-Path $PSScriptRoot ($taskModule+'.olean')
    $taskLog=Join-Path $PSScriptRoot ($taskModule+'.log')
    $taskBefore=(Get-FileHash -LiteralPath $taskOriginal -Algorithm SHA256).Hash.ToLowerInvariant()
    if($taskBefore -ne $taskExpected[$taskModule]){throw 'Frozen source hash mismatch'}
    Copy-Item -LiteralPath $taskOriginal -Destination $taskCopy
    & $taskLeanExe -o $taskOlean $taskCopy *> $taskLog
    $taskExit=$LASTEXITCODE
    $taskAfter=(Get-FileHash -LiteralPath $taskOriginal -Algorithm SHA256).Hash.ToLowerInvariant()
    $taskText=Get-Content -LiteralPath $taskLog -Raw
    $taskSourceText=Get-Content -LiteralPath $taskCopy -Raw
    $taskRequested=([regex]::Matches($taskSourceText,'(?m)^#print axioms ')).Count
    $taskReceived=([regex]::Matches($taskText,'depends on axioms:')).Count
    $taskAxiomSets=@([regex]::Matches($taskText,'depends on axioms:\s*\[([^\]]*)\]') | ForEach-Object {
        ,@($_.Groups[1].Value -split ',' | ForEach-Object {$_.Trim()})
    })
    $taskUnexpected=@($taskAxiomSets | ForEach-Object {$_} | Where-Object {$_ -notin @('propext','Classical.choice','Quot.sound')})
    $taskBad=([regex]::Matches($taskText,'(?mi)\berror:|\bwarning:|sorryAx')).Count
    $taskPass=($taskExit -eq 0)-and($taskBad -eq 0)-and($taskUnexpected.Count -eq 0)-and
        ($taskBefore -eq $taskAfter)-and($taskRequested -eq $taskReceived)
    $taskReports+=[ordered]@{
        module=$taskModule; status=$(if($taskPass){'PASS'}else{'FAIL'});
        compiler_exit_code=$taskExit; source_sha256=$taskBefore; source_after_sha256=$taskAfter;
        copied_source_sha256=(Get-FileHash -LiteralPath $taskCopy -Algorithm SHA256).Hash.ToLowerInvariant();
        olean_sha256=$(if(Test-Path -LiteralPath $taskOlean){(Get-FileHash -LiteralPath $taskOlean -Algorithm SHA256).Hash.ToLowerInvariant()}else{$null});
        log_sha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant();
        requested_axiom_reports=$taskRequested; received_axiom_reports=$taskReceived;
        errors_warnings_sorryAx=$taskBad; unexpected_axioms=$taskUnexpected;
        all_audit_axioms_allowed=($taskUnexpected.Count -eq 0); axiom_sets=$taskAxiomSets
    }
    Write-Output ($taskModule+': '+$(if($taskPass){'PASS'}else{'FAIL'})+' '+$taskReceived+' axiom reports')
}
$taskTotalReports=0
foreach($taskReportItem in $taskReports){$taskTotalReports += [int]$taskReportItem['received_axiom_reports']}
$taskReceipt=[ordered]@{
    status=$(if(@($taskReports | Where-Object {$_.status -ne 'PASS'}).Count -eq 0){'PASS'}else{'FAIL'});
    compiler=$taskLeanExe; original_current_sprint_import_path_excluded=$true;
    import_paths=$taskPaths; modules=$taskReports; total_axiom_reports=$taskTotalReports;
    literal_scope='ShiftedDispersion.fullSignedWeight links original full R rows; generic finite identities also apply to a separately instantiated completed-C kernel. JointCoprimality proves exact mask identities only.'
}
$taskReceipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'lean_replay_receipt.json') -Encoding utf8
if($taskReceipt.status -ne 'PASS'){throw 'Independent replay failed; artifacts preserved'}
