$ErrorActionPreference = 'Stop'
$taskRoot = 'D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930'
$taskOutput = Join-Path $taskRoot 'sprint15\agents\rough_cofactors_replay'
$taskLean = 'C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskPackages = 'D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskExpected = '877bdfb0d135d9c2aa87455db055e26e0df46cf5fa0f78920278def41ebf3dbe'
$taskSources = @(
  (Join-Path $taskRoot 'sprint3\lean\GoldbachBridge.lean'),
  (Join-Path $taskRoot 'sprint3\lean\GoldbachArithmetic.lean'),
  (Join-Path $taskRoot 'sprint6\lean\GoldbachVaughan.lean'),
  (Join-Path $taskRoot 'sprint15\lean\GoldbachRoughCofactors.lean')
)
$taskLibraries = @('aesop','batteries','importGraph','LeanSearchClient','mathlib','plausible','proofwidgets','Qq') | ForEach-Object {
  Join-Path $taskPackages (Join-Path $_ '.lake\build\lib')
}
foreach ($taskLibrary in $taskLibraries) {
  if (-not (Test-Path -LiteralPath $taskLibrary -PathType Container)) { throw "Missing library: $taskLibrary" }
}
New-Item -ItemType Directory -Path $taskOutput -Force | Out-Null
$taskMainHash = (Get-FileHash -LiteralPath $taskSources[3] -Algorithm SHA256).Hash.ToLowerInvariant()
if ($taskMainHash -ne $taskExpected) { throw 'Frozen source hash mismatch.' }
$taskSourceRecords = @()
foreach ($taskSource in $taskSources) {
  $taskName = [IO.Path]::GetFileNameWithoutExtension($taskSource)
  $taskCopy = Join-Path $taskOutput ($taskName + '.lean')
  $taskOriginalHash = (Get-FileHash -LiteralPath $taskSource -Algorithm SHA256).Hash.ToLowerInvariant()
  Copy-Item -LiteralPath $taskSource -Destination $taskCopy
  $taskCopyHash = (Get-FileHash -LiteralPath $taskCopy -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($taskOriginalHash -ne $taskCopyHash) { throw "Copied hash mismatch: $taskName" }
  $taskSourceRecords += [ordered]@{name=$taskName; original=$taskSource; copy=$taskCopy; sha256=$taskCopyHash}
}
$env:LEAN_PATH = (@($taskOutput) + $taskLibraries) -join ';'
(@($taskOutput) + $taskLibraries) | Set-Content -LiteralPath (Join-Path $taskOutput 'import_paths.txt') -Encoding utf8
$taskVersion = & $taskLean --version
$taskBuilds = @()
foreach ($taskRecord in $taskSourceRecords) {
  $taskOlean = Join-Path $taskOutput ($taskRecord.name + '.olean')
  $taskLog = Join-Path $taskOutput ($taskRecord.name + '.log')
  & $taskLean -o $taskOlean $taskRecord.copy *> $taskLog
  $taskExit = $LASTEXITCODE
  $taskLogText = Get-Content -LiteralPath $taskLog -Raw
  $taskReports = @([regex]::Matches($taskLogText, "'[^']+' depends on axioms: \[[\s\S]*?\]") | ForEach-Object { $_.Value -replace '\s+', ' ' })
  $taskUnexpected = @($taskReports | ForEach-Object {
    [regex]::Match($_, '\[(.*?)\]').Groups[1].Value -split ',\s*' | Where-Object { $_ -and $_ -notin @('propext','Classical.choice','Quot.sound') }
  })
  $taskForbidden = @(Select-String -LiteralPath $taskRecord.copy -Pattern '\bsorry\b|\badmit\b|\bnative_decide\b|^\s*axiom\b')
  $taskDiagnostics = @($taskLogText -split "\r?\n" | Where-Object { $_ -match '(^|\W)(error|warning):' })
  $taskBuilds += [ordered]@{
    name=$taskRecord.name; compiler_exit=$taskExit; axiom_reports=$taskReports; unexpected_axioms=$taskUnexpected;
    forbidden_matches=$taskForbidden.Count; diagnostics=$taskDiagnostics;
    source_sha256=$taskRecord.sha256; olean_sha256=$(if (Test-Path -LiteralPath $taskOlean) {(Get-FileHash -LiteralPath $taskOlean -Algorithm SHA256).Hash.ToLowerInvariant()} else {$null});
    log_sha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant()
  }
  if ($taskExit -ne 0) { break }
}
$taskMain = $taskBuilds | Where-Object { $_.name -eq 'GoldbachRoughCofactors' }
$taskFailures = @($taskBuilds | Where-Object { $_.compiler_exit -ne 0 -or $_.unexpected_axioms.Count -ne 0 -or $_.forbidden_matches -ne 0 -or $_.diagnostics.Count -ne 0 })
$taskReceipt = [ordered]@{
  status=$(if ($taskBuilds.Count -eq 4 -and $taskFailures.Count -eq 0 -and $taskMain.axiom_reports.Count -eq 13) {'PASS'} else {'FAIL'});
  reviewer='/root/short_interval11'; independent_replay=$true; lean_version=$taskVersion;
  import_policy='Only this fresh replay directory and bundled Mathlib dependency libraries. No project or old sprint olean path.';
  expected_main_source_sha256=$taskExpected; source_records=$taskSourceRecords; builds=$taskBuilds;
  theorem_count=13; scope='Finite exact rough beta support, cofactor sign fusion, integer discriminant and root divisibility only. No distribution or smallness theorem.';
  replay_script_sha256=(Get-FileHash -LiteralPath $PSCommandPath -Algorithm SHA256).Hash.ToLowerInvariant()
}
$taskReceipt | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $taskOutput 'receipt.json') -Encoding utf8
$taskReceipt | ConvertTo-Json -Depth 10
if ($taskReceipt.status -ne 'PASS') { exit 1 }

