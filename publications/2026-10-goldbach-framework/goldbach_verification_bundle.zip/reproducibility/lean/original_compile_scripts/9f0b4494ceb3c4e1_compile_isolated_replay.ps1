$ErrorActionPreference = 'Stop'
$taskResearchRoot = 'D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930'
$taskProductionRoot = Join-Path $taskResearchRoot 'sprint14\lean'
$taskCacheRoot = 'D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskLeanExe = 'C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskFrozenBoundaryHash = '1D0BDC0735CDC155B3CF0D30DC1A98EE2251327194FBB982125D02BAF177E420'
$taskSource = Join-Path $taskProductionRoot 'GoldbachCofactorBoundary.lean'
if ((Get-FileHash -LiteralPath $taskSource -Algorithm SHA256).Hash -ne $taskFrozenBoundaryHash) {
    throw 'Frozen cofactor source hash changed; stop before copying or compiling.'
}
$taskPriorLibs = @('sprint13','sprint12','sprint11','sprint10','sprint9','sprint8','sprint7','sprint6','sprint5','sprint4','sprint3') | ForEach-Object {
    Join-Path $taskResearchRoot ($_ + '\lean')
}
$taskPackageLibs = @(Get-ChildItem -LiteralPath $taskCacheRoot -Directory | ForEach-Object {
    $taskCandidate = Join-Path $_.FullName '.lake\build\lib'
    if (Test-Path -LiteralPath $taskCandidate) { $taskCandidate }
})
$taskImportPaths = @($PSScriptRoot) + $taskPriorLibs + $taskPackageLibs
$env:LEAN_PATH = [string]::Join(';', $taskImportPaths)
$taskImportPaths | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'import_paths.txt') -Encoding utf8
$taskModules = @('GoldbachScalarProjection','GoldbachCofactorBoundary')
foreach ($taskModule in $taskModules) {
    Copy-Item -LiteralPath (Join-Path $taskProductionRoot ($taskModule + '.lean')) -Destination (Join-Path $PSScriptRoot ($taskModule + '.lean'))
    & $taskLeanExe -o (Join-Path $PSScriptRoot ($taskModule + '.olean')) (Join-Path $PSScriptRoot ($taskModule + '.lean')) *> (Join-Path $PSScriptRoot ($taskModule + '.log'))
    $taskExit = $LASTEXITCODE
    Write-Output ($taskModule + ': exit ' + $taskExit)
    if ($taskExit -ne 0) {
        Get-Content -LiteralPath (Join-Path $PSScriptRoot ($taskModule + '.log'))
        exit $taskExit
    }
}
exit 0
