param([string]$BuildDirectory = 'D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930\sprint21\agents\literal_divisor_completion_productionfresh_v1')
$ErrorActionPreference='Stop'
$taskAgents='D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930\sprint21\agents'
$taskBuild=[System.IO.Path]::GetFullPath($BuildDirectory)
if (-not $taskBuild.StartsWith($taskAgents+'\literal_divisor_completion_', [System.StringComparison]::OrdinalIgnoreCase)) { throw 'Build outside own agents prefix.' }
if (Test-Path -LiteralPath $taskBuild) { throw 'Build must initially be absent.' }
New-Item -ItemType Directory -Path $taskBuild | Out-Null
$taskPackages='D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskLibraries=@('aesop','batteries','importGraph','LeanSearchClient','mathlib','plausible','proofwidgets','Qq') | ForEach-Object { Join-Path $taskPackages ($_+'\.lake\build\lib') }
foreach($taskLibrary in $taskLibraries){
  if(-not(Test-Path -LiteralPath $taskLibrary)){throw 'Missing library.'}
  foreach($taskModule in @('GoldbachBridge','GoldbachArithmetic','GoldbachLiteralDivisorCompletion')){
    if(Test-Path -LiteralPath (Join-Path $taskLibrary ($taskModule+'.olean'))){throw 'Unexpected project olean in library.'}
  }
}
$taskImports=@($taskBuild)+$taskLibraries
$env:LEAN_PATH=$taskImports -join ';'
$taskImports | Set-Content -LiteralPath (Join-Path $taskBuild 'import_paths.txt') -Encoding UTF8
$taskLean='C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskHash={param($p) (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}
$taskReports=@()
foreach($taskSpecification in @(
 @{name='GoldbachBridge';count=10;new=$false;path='D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930\sprint3\lean\GoldbachBridge.lean';hash='6d5cb30279cfd7c5eb46c7e1fde0d3616848b6eaae11a2d63a194422b8433ef5'},
 @{name='GoldbachArithmetic';count=15;new=$false;path='D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930\sprint3\lean\GoldbachArithmetic.lean';hash='b83d5687844a96eef91b8129d0f95da7e04b54f678935693946cf0469bcc915c'},
 @{name='GoldbachLiteralDivisorCompletion';count=6;new=$true;path=(Join-Path $taskAgents 'GoldbachLiteralDivisorCompletion.lean');hash=''}
)){
 $taskName=$taskSpecification.name
 $taskCopy=Join-Path $taskBuild ($taskName+'.lean')
 Copy-Item -LiteralPath $taskSpecification.path -Destination $taskCopy
 $taskSource=Get-Content -LiteralPath $taskCopy -Raw
 if($taskSource -match '(?m)^\s*axiom\b|\b(sorry|admit|native_decide)\b'){throw 'Proof bypass forbidden.'}
 $taskLog=Join-Path $taskBuild ($taskName+'.log')
 $taskOlean=Join-Path $taskBuild ($taskName+'.olean')
 & $taskLean -o $taskOlean $taskCopy *> $taskLog
 $taskExit=$LASTEXITCODE
 if($taskExit -ne 0){Get-Content -LiteralPath $taskLog;throw 'Compilation failed.'}
 $taskText=Get-Content -LiteralPath $taskLog -Raw
 if($taskText -match '(?i)error:|sorryAx|native_decide'){throw 'Forbidden diagnostic.'}
 $taskMatches=[regex]::Matches($taskText,"(?s)'([^']+)' depends on axioms:\s*\[([^\]]*)\]")
 if($taskMatches.Count -ne $taskSpecification.count){throw 'Axiom-report count differs.'}
 $taskProofs=@()
 foreach($taskMatch in $taskMatches){
   $taskAxioms=@($taskMatch.Groups[2].Value.Split(',')|ForEach-Object{$_.Trim()}|Where-Object{$_ -ne ''})
   foreach($taskAxiom in $taskAxioms){if($taskAxiom -notin @('propext','Classical.choice','Quot.sound')){throw 'Nonstandard axiom.'}}
   $taskProofs+=@{theorem=$taskMatch.Groups[1].Value;axioms=$taskAxioms}
 }
 $taskSourceHash=& $taskHash $taskSpecification.path
 if($taskSourceHash -ne (& $taskHash $taskCopy)){throw 'Source-copy mismatch.'}
 if($taskSpecification.hash -ne '' -and $taskSourceHash -ne $taskSpecification.hash){throw 'Frozen dependency changed.'}
 $taskReports+=@{module=$taskName;compiler_exit=0;newly_introduced=$taskSpecification.new;theorems=$taskProofs;source_sha256=$taskSourceHash;copied_source_sha256=(& $taskHash $taskCopy);log_sha256=(& $taskHash $taskLog);olean_sha256=(& $taskHash $taskOlean)}
}
$taskReceipt=@{status='PASS';compiler_exit=0;newly_introduced_theorem_count=6;dependency_theorems_recompiled_not_recounted=25;lean_version=(& $taskLean --version|Out-String).Trim();compiler_script_sha256=(& $taskHash $PSCommandPath);import_paths=$taskImports;reports=$taskReports;scope='Six finite literal divisor completion theorems: actual mu and log quotient, original floor Q and strict alpha*k<m, genuine prime-factor rough support. No W-sign, analytical sieve estimate, covered bridge or prime-pair positivity is formalized.'}
$taskReceipt|ConvertTo-Json -Depth 20|Set-Content -LiteralPath (Join-Path $taskBuild 'receipt.json') -Encoding UTF8
$taskReceipt|ConvertTo-Json -Depth 20
