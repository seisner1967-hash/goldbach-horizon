$ErrorActionPreference='Stop'
$taskSprintRoot=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$taskExpected=@{
    GoldbachProperPowerBudget='4a50445a2616f6e1ef62f9fdfb7d4677aab286605a83a75546e0ff154816ad64'
    GoldbachEulerLower='dd11c5575d8e4447bee42da40018875808f3dad8dc5272ac6a8487c55a1a8277'
}
$taskExpectedCounts=@{GoldbachProperPowerBudget=14; GoldbachEulerLower=6}
$taskLeanExe='C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskPriorReceiptNames=@('lean_replay_receipt.json','lean_multiplicity_replay_receipt.json')
$taskPriorReceipts=@()
$taskPriorReceiptHashes=@()
$taskPriorArtifactHashes=@()
foreach($taskReceiptName in $taskPriorReceiptNames){
    $taskReceiptPath=Join-Path $PSScriptRoot $taskReceiptName
    $taskReceipt=Get-Content -LiteralPath $taskReceiptPath -Raw | ConvertFrom-Json
    if($taskReceipt.status -ne 'PASS'){throw 'Prior independent replay is not PASS'}
    $taskPriorReceipts+=$taskReceipt
    $taskPriorReceiptHashes+=[ordered]@{
        file=$taskReceiptName;
        sha256=(Get-FileHash -LiteralPath $taskReceiptPath -Algorithm SHA256).Hash.ToLowerInvariant()
    }
    foreach($taskPriorModule in $taskReceipt.modules){
        foreach($taskExtension in @('lean','olean','log')){
            $taskPriorPath=Join-Path $PSScriptRoot ($taskPriorModule.module+'.'+$taskExtension)
            $taskRecordedHash=switch($taskExtension){
                'lean' {$taskPriorModule.copied_source_sha256}
                'olean' {$taskPriorModule.olean_sha256}
                'log' {$taskPriorModule.log_sha256}
            }
            $taskActualHash=(Get-FileHash -LiteralPath $taskPriorPath -Algorithm SHA256).Hash.ToLowerInvariant()
            if($taskActualHash -ne $taskRecordedHash){throw 'Prior replay artifact differs from frozen receipt'}
            $taskPriorArtifactHashes+=[ordered]@{file=($taskPriorModule.module+'.'+$taskExtension); sha256=$taskActualHash}
        }
    }
}
$taskPaths=@($taskPriorReceipts[0].import_paths)
$taskProductionPath=Join-Path $taskSprintRoot 'lean'
if($taskProductionPath -in $taskPaths){throw 'Production sprint13 imports are forbidden'}
if($taskPaths[0] -ne $PSScriptRoot){throw 'Independent dependency path must be first'}
$env:LEAN_PATH=[string]::Join(';',$taskPaths)
$taskReports=@()
foreach($taskModule in @('GoldbachProperPowerBudget','GoldbachEulerLower')){
    $taskOriginal=Join-Path $taskSprintRoot ('lean\'+$taskModule+'.lean')
    $taskCopy=Join-Path $PSScriptRoot ($taskModule+'.lean')
    $taskOlean=Join-Path $PSScriptRoot ($taskModule+'.olean')
    $taskLog=Join-Path $PSScriptRoot ($taskModule+'.log')
    $taskBefore=(Get-FileHash -LiteralPath $taskOriginal -Algorithm SHA256).Hash.ToLowerInvariant()
    if($taskBefore -ne $taskExpected[$taskModule]){throw 'Frozen source hash mismatch'}
    Copy-Item -LiteralPath $taskOriginal -Destination $taskCopy
    & $taskLeanExe -o $taskOlean $taskCopy *> $taskLog
    $taskExit=$LASTEXITCODE
    $taskAfter=(Get-FileHash -LiteralPath $taskOriginal -Algorithm SHA256).Hash.ToLowerInvariant()
    $taskText=Get-Content -LiteralPath $taskLog -Raw
    $taskSourceText=Get-Content -LiteralPath $taskCopy -Raw
    $taskRequested=([regex]::Matches($taskSourceText,'(?m)^#print axioms ')).Count
    $taskReceived=([regex]::Matches($taskText,'depends on axioms:')).Count
    $taskAxiomSets=@([regex]::Matches($taskText,'depends on axioms:\s*\[([^\]]*)\]') | ForEach-Object {
        ,@($_.Groups[1].Value -split ',' | ForEach-Object {$_.Trim()})
    })
    $taskUnexpected=@($taskAxiomSets | ForEach-Object {$_} | Where-Object {$_ -notin @('propext','Classical.choice','Quot.sound')})
    $taskBad=([regex]::Matches($taskText,'(?mi)\berror:|\bwarning:|sorryAx')).Count
    $taskCopiedHash=(Get-FileHash -LiteralPath $taskCopy -Algorithm SHA256).Hash.ToLowerInvariant()
    $taskPass=($taskExit -eq 0)-and($taskBad -eq 0)-and($taskUnexpected.Count -eq 0)-and
        ($taskBefore -eq $taskAfter)-and($taskCopiedHash -eq $taskBefore)-and
        ($taskRequested -eq $taskExpectedCounts[$taskModule])-and($taskReceived -eq $taskRequested)
    $taskReports+=[ordered]@{
        module=$taskModule; status=$(if($taskPass){'PASS'}else{'FAIL'});
        compiler_exit_code=$taskExit; source_sha256=$taskBefore; source_after_sha256=$taskAfter;
        copied_source_sha256=$taskCopiedHash;
        olean_sha256=$(if(Test-Path -LiteralPath $taskOlean){(Get-FileHash -LiteralPath $taskOlean -Algorithm SHA256).Hash.ToLowerInvariant()}else{$null});
        log_sha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant();
        requested_axiom_reports=$taskRequested; received_axiom_reports=$taskReceived;
        errors_warnings_sorryAx=$taskBad; unexpected_axioms=$taskUnexpected;
        all_audit_axioms_allowed=($taskUnexpected.Count -eq 0); axiom_sets=$taskAxiomSets
    }
    Write-Output ($taskModule+': '+$(if($taskPass){'PASS'}else{'FAIL'})+' '+$taskReceived+' axiom reports')
}
foreach($taskFrozenArtifact in @($taskPriorReceiptHashes)+@($taskPriorArtifactHashes)){
    $taskPath=Join-Path $PSScriptRoot $taskFrozenArtifact.file
    if((Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskFrozenArtifact.sha256){
        throw 'Prior independent artifacts changed during supplemental replay'
    }
}
$taskTotalReports=0
foreach($taskReportItem in $taskReports){$taskTotalReports += [int]$taskReportItem['received_axiom_reports']}
$taskReceipt=[ordered]@{
    status=$(if(@($taskReports | Where-Object {$_.status -ne 'PASS'}).Count -eq 0){'PASS'}else{'FAIL'});
    compiler=$taskLeanExe; original_current_sprint_import_path_excluded=$true;
    import_paths=$taskPaths; modules=$taskReports; total_axiom_reports=$taskTotalReports;
    previous_receipts=$taskPriorReceiptHashes; previous_artifacts=$taskPriorArtifactHashes;
    prior_independent_proofs_not_recompiled=$true; prior_independent_artifacts_unchanged=$true;
    literal_scope='Unconditional proper-prime-power contamination bound at every natural N and finite Euler-product lower bound 1/2 for any finite family of distinct integers at least 3. The terminal prime-pair corollary retains the actual transfer identity, reference and remaining error/margin hypotheses. No infinite Euler-product passage, central off-diagonal cancellation or general Goldbach margin is formalized.'
}
$taskReceipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'lean_terminal_extra_replay_receipt.json') -Encoding utf8
if($taskReceipt.status -ne 'PASS'){throw 'Independent supplemental replay failed; artifacts preserved'}
