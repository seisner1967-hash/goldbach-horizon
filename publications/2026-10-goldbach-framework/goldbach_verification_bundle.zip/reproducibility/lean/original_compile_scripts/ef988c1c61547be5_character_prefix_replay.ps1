param(
    [Parameter(Mandatory=$true)]
    [string]$ExpectedSourceSha
)
$ErrorActionPreference = 'Stop'
$taskSprintRoot = Split-Path $PSScriptRoot -Parent
$taskResearchRoot = Split-Path $taskSprintRoot -Parent
$taskReplayRoot = Join-Path $PSScriptRoot 'character_prefix_independent_replay'
$taskOriginalSource = Join-Path $taskSprintRoot 'lean\GoldbachCharacterPrefix.lean'
$taskCopiedSource = Join-Path $taskReplayRoot 'GoldbachCharacterPrefix.lean'
$taskOlean = Join-Path $taskReplayRoot 'GoldbachCharacterPrefix.olean'
$taskLog = Join-Path $taskReplayRoot 'GoldbachCharacterPrefix.log'
$taskOriginalHash = (Get-FileHash -LiteralPath $taskOriginalSource -Algorithm SHA256).Hash.ToLowerInvariant()
if ($taskOriginalHash -ne $ExpectedSourceSha.ToLowerInvariant()) {
    throw 'Frozen source hash does not match requested replay.'
}
New-Item -Path $taskReplayRoot -ItemType Directory -Force | Out-Null
Copy-Item -LiteralPath $taskOriginalSource -Destination $taskCopiedSource
$taskPriorLibs = @('sprint10','sprint9','sprint8','sprint7','sprint6','sprint5','sprint4','sprint3') | ForEach-Object {
    Join-Path $taskResearchRoot ($_ + '\lean')
}
$taskCacheRoot = 'D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskLeanExe = 'C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskLibs = @(Get-ChildItem -LiteralPath $taskCacheRoot -Directory | ForEach-Object {
    $taskCandidate = Join-Path $_.FullName '.lake\build\lib'
    if (Test-Path -LiteralPath $taskCandidate) { $taskCandidate }
})
$taskPaths = @($taskReplayRoot) + $taskPriorLibs + $taskLibs
$env:LEAN_PATH = [string]::Join(';', $taskPaths)
& $taskLeanExe -o $taskOlean $taskCopiedSource *> $taskLog
$taskExit = $LASTEXITCODE
$taskText = Get-Content -LiteralPath $taskLog -Raw
$taskFrozenAfter = (Get-FileHash -LiteralPath $taskOriginalSource -Algorithm SHA256).Hash.ToLowerInvariant()
$taskAuditCount = ([regex]::Matches($taskText, 'depends on axioms:')).Count
$taskSourceText = Get-Content -LiteralPath $taskCopiedSource -Raw
$taskRequestedCount = ([regex]::Matches($taskSourceText, '(?m)^#print axioms ')).Count
$taskErrorCount = ([regex]::Matches($taskText, '(?mi)\berror:|\bwarning:|sorryAx')).Count
$taskAxiomSets = @([regex]::Matches($taskText, 'depends on axioms:\s*\[([^\]]*)\]') | ForEach-Object {
    ,@($_.Groups[1].Value -split ',' | ForEach-Object { $_.Trim() })
})
$taskAllowedAxioms = @('propext','Classical.choice','Quot.sound')
$taskUnexpectedAxioms = @($taskAxiomSets | ForEach-Object { $_ } | Where-Object { $_ -notin $taskAllowedAxioms })
$taskPass = ($taskExit -eq 0) -and ($taskErrorCount -eq 0) -and
    ($taskAuditCount -eq $taskRequestedCount) -and ($taskFrozenAfter -eq $taskOriginalHash) -and
    ($taskUnexpectedAxioms.Count -eq 0)
$taskReceipt = [ordered]@{
    status = $(if ($taskPass) { 'PASS' } else { 'FAIL' })
    compiler_exit_code = $taskExit
    source_sha256 = $taskOriginalHash
    source_after_sha256 = $taskFrozenAfter
    copied_source_sha256 = (Get-FileHash -LiteralPath $taskCopiedSource -Algorithm SHA256).Hash.ToLowerInvariant()
    olean_sha256 = $(if (Test-Path -LiteralPath $taskOlean) { (Get-FileHash -LiteralPath $taskOlean -Algorithm SHA256).Hash.ToLowerInvariant() } else { $null })
    log_sha256 = (Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant()
    requested_axiom_reports = $taskRequestedCount
    received_axiom_reports = $taskAuditCount
    errors_warnings_or_sorryAx = $taskErrorCount
    all_audit_axioms_allowed = ($taskUnexpectedAxioms.Count -eq 0)
    unexpected_axioms = $taskUnexpectedAxioms
    axiom_sets = $taskAxiomSets
    import_paths = $taskPaths
    current_sprint_original_import_path_excluded = $true
    compiler = $taskLeanExe
    audit_reports = @($taskText -split "\r?\n" | Where-Object { $_ -match 'depends on axioms:' })
}
$taskReceiptPath = Join-Path $taskReplayRoot 'replay_receipt.json'
$taskReceipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $taskReceiptPath -Encoding utf8
$taskReceipt | ConvertTo-Json -Depth 5
if (-not $taskPass) { throw 'Independent replay failed; inspect preserved log and receipt.' }
