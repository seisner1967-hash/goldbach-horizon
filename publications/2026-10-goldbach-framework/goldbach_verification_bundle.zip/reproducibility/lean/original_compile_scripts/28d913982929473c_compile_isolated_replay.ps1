$ErrorActionPreference = 'Stop'
$taskResearchRoot = 'D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930'
$taskProductionDir = Join-Path $taskResearchRoot 'sprint14\lean'
$taskPriorLibs = @('sprint13', 'sprint12', 'sprint11', 'sprint10', 'sprint9', 'sprint8', 'sprint7', 'sprint6', 'sprint5', 'sprint4', 'sprint3') | ForEach-Object {
    Join-Path $taskResearchRoot ($_ + '\lean')
}
$taskCacheRoot = 'D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskLeanExe = 'C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskLibs = @(Get-ChildItem -LiteralPath $taskCacheRoot -Directory | ForEach-Object {
    $taskCandidate = Join-Path $_.FullName '.lake\build\lib'
    if (Test-Path -LiteralPath $taskCandidate) { $taskCandidate }
})
$taskImportDirs = @($PSScriptRoot) + $taskPriorLibs + $taskLibs
if ($taskImportDirs -contains $taskProductionDir) { throw 'Production sprint14/lean is excluded from replay import paths.' }
$env:LEAN_PATH = [string]::Join(';', $taskImportDirs)
$taskImportDirs | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'import_paths.txt') -Encoding utf8
$taskModule = 'GoldbachScalarProjection'
$taskSource = Join-Path $PSScriptRoot ($taskModule + '.lean')
& $taskLeanExe -o (Join-Path $PSScriptRoot ($taskModule + '.olean')) $taskSource *> (Join-Path $PSScriptRoot ($taskModule + '.log'))
$taskExit = $LASTEXITCODE
Get-Content -LiteralPath (Join-Path $PSScriptRoot ($taskModule + '.log'))
exit $taskExit
