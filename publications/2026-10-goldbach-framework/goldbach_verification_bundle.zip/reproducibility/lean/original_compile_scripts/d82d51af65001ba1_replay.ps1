$ErrorActionPreference = 'Stop'
$taskRoot = 'D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930'
$taskOutput = $PSScriptRoot
$taskLean = 'C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskPackages = 'D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskLibraries = @('aesop','batteries','importGraph','LeanSearchClient','mathlib','plausible','proofwidgets','Qq') | ForEach-Object {
    Join-Path $taskPackages (Join-Path $_ '.lake\build\lib')
}
foreach ($taskLibrary in $taskLibraries) {
    if (-not (Test-Path -LiteralPath $taskLibrary -PathType Container)) { throw "Missing dependency: $taskLibrary" }
}
$taskModules = @(
    @{ name='GoldbachMoebiusShortLong'; expected='e1ce90975a2db06478346fe47403f7a853fe2d5d316935ed5832964c493bf279'; expected_reports=15; role='fresh dependency replay, previously audited public statements' },
    @{ name='GoldbachCutoffInvariance'; expected='546f9e328f7d4f880ecc078fd9605d9694ee15a10f94368ae0e524590727ee73'; expected_reports=6; role='new independently replayed public statements' }
)
$taskVersion = & $taskLean --version
$env:LEAN_PATH = (@($taskOutput) + $taskLibraries) -join ';'
(@($taskOutput) + $taskLibraries) | Set-Content -LiteralPath (Join-Path $taskOutput 'import_paths.txt') -Encoding utf8
$taskResults = @()
foreach ($taskModule in $taskModules) {
    $taskSource = Join-Path $taskRoot "sprint15\lean\$($taskModule.name).lean"
    $taskSourceHash = (Get-FileHash -LiteralPath $taskSource -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($taskSourceHash -ne $taskModule.expected) { throw "Frozen hash mismatch: $($taskModule.name)" }
    $taskCopy = Join-Path $taskOutput "$($taskModule.name).lean"
    Copy-Item -LiteralPath $taskSource -Destination $taskCopy
    $taskCopyHash = (Get-FileHash -LiteralPath $taskCopy -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($taskCopyHash -ne $taskSourceHash) { throw 'Copied bytes mismatch.' }
    $taskOlean = Join-Path $taskOutput "$($taskModule.name).olean"
    $taskLog = Join-Path $taskOutput "$($taskModule.name).log"
    & $taskLean -o $taskOlean $taskCopy *> $taskLog
    $taskExit = $LASTEXITCODE
    $taskLogText = Get-Content -LiteralPath $taskLog -Raw
    $taskAxiomReports = @([regex]::Matches($taskLogText, "'[^']+' depends on axioms: \[[\s\S]*?\]") | ForEach-Object { $_.Value -replace '\s+', ' ' })
    $taskUnexpectedAxioms = @($taskAxiomReports | ForEach-Object {
        $taskAxiomList = [regex]::Match($_, '\[(.*?)\]').Groups[1].Value
        $taskAxiomList -split ',\s*' | Where-Object { $_ -and $_ -notin @('propext','Classical.choice','Quot.sound') }
    })
    $taskForbidden = @(Select-String -LiteralPath $taskCopy -Pattern '\bsorry\b|\badmit\b|\bnative_decide\b|^\s*axiom\b')
    $taskDiagnostics = @($taskLogText -split "`r?`n" | Where-Object { $_ -match '(^|\W)(error|warning):' })
    $taskResults += [ordered]@{
        name=$taskModule.name
        role=$taskModule.role
        status=$(if ($taskExit -eq 0 -and $taskAxiomReports.Count -eq $taskModule.expected_reports -and $taskUnexpectedAxioms.Count -eq 0 -and $taskForbidden.Count -eq 0 -and $taskDiagnostics.Count -eq 0) { 'PASS' } else { 'FAIL' })
        compiler_exit=$taskExit
        source=$taskSource
        source_sha256=$taskSourceHash
        copied_source=$taskCopy
        copied_source_sha256=$taskCopyHash
        log=$taskLog
        log_sha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant()
        olean=$taskOlean
        olean_sha256=$(if (Test-Path -LiteralPath $taskOlean) { (Get-FileHash -LiteralPath $taskOlean -Algorithm SHA256).Hash.ToLowerInvariant() } else { $null })
        axiom_report_count=$taskAxiomReports.Count
        axiom_reports=$taskAxiomReports
        unexpected_axioms=$taskUnexpectedAxioms
        forbidden_source_matches=$taskForbidden.Count
        compiler_diagnostics=$taskDiagnostics
    }
    if ($taskExit -ne 0) { break }
}
$taskFiles = @($PSCommandPath,(Join-Path $taskOutput 'import_paths.txt')) | ForEach-Object {
    $taskItem = Get-Item -LiteralPath $_
    [ordered]@{path=$taskItem.FullName; bytes=$taskItem.Length; sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash.ToLowerInvariant()}
}
$taskReportTotal = 0
foreach ($taskResult in $taskResults) { $taskReportTotal += [int]$taskResult.axiom_report_count }
$taskReceipt = [ordered]@{
    status=$(if ($taskResults.Count -eq 2 -and @($taskResults | Where-Object {$_.status -ne 'PASS'}).Count -eq 0) {'PASS'} else {'FAIL'})
    replay_agent='/root/large_sieve11'
    independent_replay=$true
    lean_version=$taskVersion
    import_policy='Fresh copied sources and fresh oleans in this directory, plus exactly eight cached Mathlib dependency libraries; no production sprint15 or earlier project oleans.'
    modules=$taskResults
    total_replayed_axiom_reports=$taskReportTotal
    newly_independently_replayed_axiom_reports=6
    prior_dependency_reports_not_new_claims=15
    files=$taskFiles
    scope='Exact integer-weight finite identities on explicit common long support; mass-one retains HH, mass-zero leaves mixed differences. No real beta-log linkage or analytic smallness is formalized by this module.'
}
$taskReceipt | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $taskOutput 'receipt.json') -Encoding utf8
Write-Output "$($taskReceipt.status): $($taskReceipt.total_replayed_axiom_reports) replay reports, six new public identities."
if ($taskReceipt.status -ne 'PASS') { exit 1 }
