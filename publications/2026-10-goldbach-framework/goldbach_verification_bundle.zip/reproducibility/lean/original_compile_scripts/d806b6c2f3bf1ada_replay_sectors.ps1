$ErrorActionPreference='Stop'
$taskSprintRoot=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$taskPriorReceiptNames=@('lean_replay_receipt.json','lean_extra_replay_receipt.json')
$taskReceipts=@()
foreach($taskName in $taskPriorReceiptNames){
    $taskReceipt=Get-Content -LiteralPath (Join-Path $PSScriptRoot $taskName) -Raw | ConvertFrom-Json
    if($taskReceipt.status -ne 'PASS' -or $taskReceipt.total_axiom_reports -ne 25){throw 'Prior independent receipt is not accepted'}
    $taskReceipts+=$taskReceipt
    foreach($taskDependency in $taskReceipt.modules){
        foreach($taskPair in @(@('lean','copied_source_sha256'),@('olean','olean_sha256'),@('log','log_sha256'))){
            $taskFile=Join-Path $PSScriptRoot ($taskDependency.module+'.'+$taskPair[0])
            if((Get-FileHash -LiteralPath $taskFile -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskDependency.($taskPair[1])){throw 'Isolated dependency changed'}
        }
    }
}
$taskModule='GoldbachTwoIndexSectors'
$taskExpected='11d31b29565c67503f550fab36de727966e909543d7f832b3a45d62752f5f02c'
$taskLeanExe='C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskPaths=@($taskReceipts[0].import_paths)
$env:LEAN_PATH=[string]::Join(';',$taskPaths)
$taskOriginal=Join-Path $taskSprintRoot ('lean\'+$taskModule+'.lean')
$taskCopy=Join-Path $PSScriptRoot ($taskModule+'.lean')
$taskOlean=Join-Path $PSScriptRoot ($taskModule+'.olean')
$taskLog=Join-Path $PSScriptRoot ($taskModule+'.log')
$taskBefore=(Get-FileHash -LiteralPath $taskOriginal -Algorithm SHA256).Hash.ToLowerInvariant()
if($taskBefore -ne $taskExpected){throw 'Frozen sector source hash mismatch'}
Copy-Item -LiteralPath $taskOriginal -Destination $taskCopy
& $taskLeanExe -o $taskOlean $taskCopy *> $taskLog
$taskExit=$LASTEXITCODE
$taskAfter=(Get-FileHash -LiteralPath $taskOriginal -Algorithm SHA256).Hash.ToLowerInvariant()
$taskText=Get-Content -LiteralPath $taskLog -Raw
$taskSourceText=Get-Content -LiteralPath $taskCopy -Raw
$taskRequested=([regex]::Matches($taskSourceText,'(?m)^#print axioms ')).Count
$taskReceived=([regex]::Matches($taskText,'depends on axioms:')).Count
$taskAxiomSets=@([regex]::Matches($taskText,'depends on axioms:\s*\[([^\]]*)\]') | ForEach-Object {
    ,@($_.Groups[1].Value -split ',' | ForEach-Object {$_.Trim()})
})
$taskUnexpected=@($taskAxiomSets | ForEach-Object {$_} | Where-Object {$_ -notin @('propext','Classical.choice','Quot.sound')})
$taskBad=([regex]::Matches($taskText,'(?mi)\berror:|\bwarning:|sorryAx')).Count
$taskPass=($taskExit -eq 0)-and($taskBad -eq 0)-and($taskUnexpected.Count -eq 0)-and
    ($taskBefore -eq $taskAfter)-and($taskRequested -eq $taskReceived)
$taskReport=[ordered]@{
    module=$taskModule; status=$(if($taskPass){'PASS'}else{'FAIL'});
    compiler_exit_code=$taskExit; source_sha256=$taskBefore; source_after_sha256=$taskAfter;
    copied_source_sha256=(Get-FileHash -LiteralPath $taskCopy -Algorithm SHA256).Hash.ToLowerInvariant();
    olean_sha256=$(if(Test-Path -LiteralPath $taskOlean){(Get-FileHash -LiteralPath $taskOlean -Algorithm SHA256).Hash.ToLowerInvariant()}else{$null});
    log_sha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant();
    requested_axiom_reports=$taskRequested; received_axiom_reports=$taskReceived;
    errors_warnings_sorryAx=$taskBad; unexpected_axioms=$taskUnexpected;
    all_audit_axioms_allowed=($taskUnexpected.Count -eq 0); axiom_sets=$taskAxiomSets
}
$taskReceipt=[ordered]@{
    status=$taskReport.status; compiler=$taskLeanExe; original_current_sprint_import_path_excluded=$true;
    import_paths=$taskPaths; modules=@($taskReport); total_axiom_reports=$taskReceived;
    initial_independent_dependency_receipt_sha256=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'lean_replay_receipt.json') -Algorithm SHA256).Hash.ToLowerInvariant();
    extra_independent_dependency_receipt_sha256=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'lean_extra_replay_receipt.json') -Algorithm SHA256).Hash.ToLowerInvariant();
    prior_independent_proofs_not_recompiled=$true;
    literal_scope='Exact signed four-sector finite partition and actualCEntry semantic energy bridge, valid for arbitrary real column weight. Nonnegativity requires nonnegative weight; no cancellation or asymptotic bound.'
}
$taskReceipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'lean_sectors_replay_receipt.json') -Encoding utf8
Write-Output ($taskModule+': '+$taskReport.status+' '+$taskReceived+' axiom reports')
if(-not $taskPass){throw 'Independent sector replay failed; artifacts preserved'}
