$ErrorActionPreference = 'Stop'
$taskRoot = 'D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930'
$taskSource = Join-Path $taskRoot 'sprint15\lean\GoldbachMoebiusShortLong.lean'
$taskOutput = Join-Path $taskRoot 'sprint15\agents\short_long_independent_replay'
$taskLean = 'C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskPackages = 'D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskExpected = 'e1ce90975a2db06478346fe47403f7a853fe2d5d316935ed5832964c493bf279'
$taskLibraries = @('aesop','batteries','importGraph','LeanSearchClient','mathlib','plausible','proofwidgets','Qq') | ForEach-Object {
    Join-Path $taskPackages (Join-Path $_ '.lake\build\lib')
}
foreach ($taskLibrary in $taskLibraries) {
    if (-not (Test-Path -LiteralPath $taskLibrary -PathType Container)) { throw "Missing package library: $taskLibrary" }
}
New-Item -ItemType Directory -Path $taskOutput -Force | Out-Null
$taskSourceHash = (Get-FileHash -LiteralPath $taskSource -Algorithm SHA256).Hash.ToLowerInvariant()
if ($taskSourceHash -ne $taskExpected) { throw 'Frozen source hash mismatch.' }
$taskCopy = Join-Path $taskOutput 'GoldbachMoebiusShortLong.lean'
Copy-Item -LiteralPath $taskSource -Destination $taskCopy
$taskCopyHash = (Get-FileHash -LiteralPath $taskCopy -Algorithm SHA256).Hash.ToLowerInvariant()
if ($taskCopyHash -ne $taskExpected) { throw 'Copied source hash mismatch.' }
$env:LEAN_PATH = $taskLibraries -join ';'
$taskLibraries | Set-Content -LiteralPath (Join-Path $taskOutput 'import_paths.txt') -Encoding utf8
$taskVersion = & $taskLean --version
$taskOlean = Join-Path $taskOutput 'GoldbachMoebiusShortLong.olean'
$taskLog = Join-Path $taskOutput 'GoldbachMoebiusShortLong.log'
& $taskLean -o $taskOlean $taskCopy *> $taskLog
$taskExit = $LASTEXITCODE
$taskLogText = Get-Content -LiteralPath $taskLog -Raw
$taskAxiomReports = @([regex]::Matches($taskLogText, "'[^']+' depends on axioms: \[[\s\S]*?\]") | ForEach-Object { $_.Value -replace '\s+', ' ' })
$taskUnexpectedAxioms = @($taskAxiomReports | ForEach-Object {
    $taskAxiomList = [regex]::Match($_, '\[(.*?)\]').Groups[1].Value
    $taskAxiomList -split ',\s*' | Where-Object { $_ -and $_ -notin @('propext','Classical.choice','Quot.sound') }
})
$taskForbidden = @(Select-String -LiteralPath $taskCopy -Pattern '\bsorry\b|\badmit\b|\bnative_decide\b|^\s*axiom\b')
$taskDiagnostics = @($taskLogText -split "`r?`n" | Where-Object { $_ -match '(^|\W)(error|warning):' })
$taskNames = @('short_apply','short_apply_of_le','short_apply_of_gt','long_apply_of_le','long_apply_of_gt','convolution_vanishes_below','convolution_with_arbitrary_preserves_vanishing','long_double_support','algebraic_short_long_identity','moebius_short_long','moebius_long_region','long_double_of_no_long_divisor','long_double_prime','short_double_prime','long_region_product')
$taskFiles = @($taskSource,$taskCopy,$taskOlean,$taskLog,(Join-Path $taskOutput 'import_paths.txt'),$PSCommandPath) | ForEach-Object {
    $taskItem = Get-Item -LiteralPath $_
    [ordered]@{ path=$taskItem.FullName; bytes=$taskItem.Length; sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash.ToLowerInvariant() }
}
$taskReceipt = [ordered]@{
    status=$(if ($taskExit -eq 0 -and $taskAxiomReports.Count -eq 15 -and $taskUnexpectedAxioms.Count -eq 0 -and $taskForbidden.Count -eq 0 -and $taskDiagnostics.Count -eq 0) { 'PASS' } else { 'FAIL' })
    replay_agent='/root/high_product_core_audit14'
    independent_replay=$true
    compiler_exit=$taskExit
    lean_version=$taskVersion
    expected_frozen_source_sha256=$taskExpected
    copied_source_sha256=$taskCopyHash
    import_policy='Only existing bundled Mathlib package dependency libraries; no project, sprint15 production, or previous sprint import/output directory.'
    theorem_count=15
    theorem_names=$taskNames
    axiom_reports=$taskAxiomReports
    unexpected_axioms=$taskUnexpectedAxioms
    forbidden_source_matches=$taskForbidden.Count
    compiler_diagnostics=$taskDiagnostics
    files=$taskFiles
    scope='Finite exact short/long Mobius convolution identities and support; no analytic smallness, effective threshold, or Goldbach theorem.'
}
$taskReceipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $taskOutput 'receipt.json') -Encoding utf8
$taskReceipt | ConvertTo-Json -Depth 8
if ($taskExit -ne 0) { exit $taskExit }
if ($taskReceipt.status -ne 'PASS') { exit 1 }
