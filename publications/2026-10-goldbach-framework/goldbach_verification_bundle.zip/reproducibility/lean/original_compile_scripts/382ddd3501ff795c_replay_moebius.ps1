$ErrorActionPreference = 'Stop'
$taskResearchRoot = 'D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930'
$taskCacheRoot = 'D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskLeanExe = 'C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskSource = Join-Path $taskResearchRoot 'sprint15\lean\GoldbachMoebiusComplement.lean'
$taskCopiedSource = Join-Path $PSScriptRoot 'GoldbachMoebiusComplement.lean'
Copy-Item -LiteralPath $taskSource -Destination $taskCopiedSource
$taskPriorLibs = @('sprint14','sprint13','sprint12','sprint11','sprint10','sprint9','sprint8','sprint7','sprint6','sprint5','sprint4','sprint3') | ForEach-Object {
    Join-Path $taskResearchRoot ($_ + '\lean')
}
$taskPackageLibs = @(Get-ChildItem -LiteralPath $taskCacheRoot -Directory | ForEach-Object {
    $taskCandidate = Join-Path $_.FullName '.lake\build\lib'
    if (Test-Path -LiteralPath $taskCandidate) { $taskCandidate }
})
$taskImportPaths = @($PSScriptRoot) + $taskPriorLibs + $taskPackageLibs
$env:LEAN_PATH = [string]::Join(';', $taskImportPaths)
$taskLog = Join-Path $PSScriptRoot 'GoldbachMoebiusComplement.log'
$taskOlean = Join-Path $PSScriptRoot 'GoldbachMoebiusComplement.olean'
& $taskLeanExe -o $taskOlean $taskCopiedSource *> $taskLog
$taskExit = $LASTEXITCODE
$taskReceipt = [ordered]@{
    reviewer = '/root'
    sourceAuthor = '/root/high_product_core_audit14'
    isolatedFromProductionSprint15 = $true
    originalSourceSha256 = (Get-FileHash -LiteralPath $taskSource -Algorithm SHA256).Hash.ToLower()
    copiedSourceSha256 = (Get-FileHash -LiteralPath $taskCopiedSource -Algorithm SHA256).Hash.ToLower()
    logSha256 = (Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLower()
    leanExitCode = $taskExit
    importPaths = $taskImportPaths
    analyticCancellationProved = $false
    goldbachProved = $false
}
if (Test-Path -LiteralPath $taskOlean) {
    $taskReceipt.oleanSha256 = (Get-FileHash -LiteralPath $taskOlean -Algorithm SHA256).Hash.ToLower()
}
$taskReceipt | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'receipt.json') -Encoding utf8
Get-Content -LiteralPath $taskLog
exit $taskExit
