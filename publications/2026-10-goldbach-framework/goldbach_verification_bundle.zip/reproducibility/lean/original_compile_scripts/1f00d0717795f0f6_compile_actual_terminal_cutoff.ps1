param([string]$BuildDirectory = 'D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930\sprint21\agents\root_terminal_cutoff_productionfresh_v1')
$ErrorActionPreference = 'Stop'
$taskRoot = 'D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930\sprint21'
$taskBuild = [System.IO.Path]::GetFullPath($BuildDirectory)
if (-not $taskBuild.StartsWith($taskRoot + '\agents\root_terminal_cutoff', [System.StringComparison]::OrdinalIgnoreCase)) {
    throw 'Build must remain within sprint21/agents/root_terminal_cutoff*.'
}
if (Test-Path -LiteralPath $taskBuild) { throw 'Build directory must initially be absent.' }
New-Item -ItemType Directory -Path $taskBuild | Out-Null
$taskPackages = 'D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskLibraries = @('aesop','batteries','importGraph','LeanSearchClient','mathlib','plausible','proofwidgets','Qq') |
    ForEach-Object { Join-Path $taskPackages ($_ + '\.lake\build\lib') }
foreach ($taskLibrary in $taskLibraries) {
    if (-not (Test-Path -LiteralPath $taskLibrary)) { throw 'Missing dependency library.' }
    foreach ($taskModule in @('GoldbachBridge','GoldbachArithmetic','GoldbachVaughan','GoldbachActualTerminalCutoffInvariant')) {
        if (Test-Path -LiteralPath (Join-Path $taskLibrary ($taskModule + '.olean'))) {
            throw 'Unexpected cached project olean in dependency library.'
        }
    }
}
$taskImports = @($taskBuild) + $taskLibraries
$env:LEAN_PATH = $taskImports -join ';'
$taskImports | Set-Content -LiteralPath (Join-Path $taskBuild 'import_paths.txt') -Encoding UTF8
$taskLean = 'C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskReports = @()
foreach ($taskSpecification in @(
    @{ name='GoldbachBridge'; count=10; new=$false; sprint='sprint3'; hash='6d5cb30279cfd7c5eb46c7e1fde0d3616848b6eaae11a2d63a194422b8433ef5' },
    @{ name='GoldbachArithmetic'; count=15; new=$false; sprint='sprint3'; hash='b83d5687844a96eef91b8129d0f95da7e04b54f678935693946cf0469bcc915c' },
    @{ name='GoldbachVaughan'; count=19; new=$false; sprint='sprint6'; hash='f75239a846dcd13ca7f0bc39616998e31172b51ce4f98f0f55d498ef31953a99' },
    @{ name='GoldbachActualTerminalCutoffInvariant'; count=3; new=$true; sprint='sprint21'; hash='' }
)) {
    $taskName = $taskSpecification.name
    $taskOriginal = Join-Path ('D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930\' + $taskSpecification.sprint) ('lean\' + $taskName + '.lean')
    $taskCopy = Join-Path $taskBuild ($taskName + '.lean')
    Copy-Item -LiteralPath $taskOriginal -Destination $taskCopy
    $taskSourceText = Get-Content -LiteralPath $taskCopy -Raw
    if ($taskSourceText -match '(?m)^\s*axiom\b|\b(sorry|admit|native_decide)\b') { throw 'Forbidden proof bypass.' }
    $taskLog = Join-Path $taskBuild ($taskName + '.log')
    $taskOlean = Join-Path $taskBuild ($taskName + '.olean')
    & $taskLean -o $taskOlean $taskCopy *> $taskLog
    $taskExit = $LASTEXITCODE
    if ($taskExit -ne 0) { Get-Content -LiteralPath $taskLog; throw ('Compilation failed: ' + $taskName) }
    $taskText = Get-Content -LiteralPath $taskLog -Raw
    if ($taskText -match '(?i)error:|sorryAx|native_decide') { throw 'Forbidden diagnostic.' }
    $taskMatches = [regex]::Matches($taskText, "(?s)'([^']+)' depends on axioms:\s*\[([^\]]*)\]")
    $taskAxiomReports = @()
    foreach ($taskMatch in $taskMatches) {
        $taskAxioms = @($taskMatch.Groups[2].Value.Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne '' })
        foreach ($taskAxiom in $taskAxioms) {
            if ($taskAxiom -notin @('propext','Classical.choice','Quot.sound')) { throw 'Nonstandard axiom.' }
        }
        $taskAxiomReports += @{ theorem=$taskMatch.Groups[1].Value; axioms=$taskAxioms }
    }
    if ($taskAxiomReports.Count -ne $taskSpecification.count) { throw 'Unexpected axiom report count.' }
    $taskHash = { param($p) (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant() }
    $taskSourceHash = & $taskHash $taskOriginal
    $taskCopyHash = & $taskHash $taskCopy
    if ($taskSourceHash -ne $taskCopyHash) { throw 'Source-copy mismatch.' }
    if ($taskSpecification.hash -ne '' -and $taskSourceHash -ne $taskSpecification.hash) {
        throw 'Previously accepted dependency source changed.'
    }
    $taskReports += @{ module=$taskName; compiler_exit=$taskExit; newly_introduced=$taskSpecification.new;
        theorem_reports=$taskAxiomReports; source_sha256=$taskSourceHash; copied_source_sha256=$taskCopyHash;
        olean_sha256=(& $taskHash $taskOlean); log_sha256=(& $taskHash $taskLog) }
}
$taskReceipt = @{ status='PASS'; compiler_exit=0; newly_introduced_theorem_count=3;
    dependency_theorems_recompiled_not_recounted=44; reports=$taskReports;
    lean_version=(& $taskLean --version | Out-String).Trim(); import_paths=$taskImports;
    compiler_script_sha256=(& $taskHash $PSCommandPath);
    scope='Three actual finite terminal-cutoff identities preserving true Vaughan coefficients, modulus cap, cofactor boundary and unit masks. Forty-four frozen dependency proofs freshly compiled, not recounted. No cancellation estimate, covered bridge, positive margin or analytic AP theorem.' }
$taskReceipt | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath (Join-Path $taskBuild 'receipt.json') -Encoding UTF8
Write-Output ($taskReceipt | ConvertTo-Json -Depth 20)
