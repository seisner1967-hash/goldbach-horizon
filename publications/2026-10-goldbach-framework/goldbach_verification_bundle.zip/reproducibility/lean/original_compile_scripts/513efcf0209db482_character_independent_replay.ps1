param(
    [ValidateSet('GoldbachKloostermanGeometry', 'GoldbachCharacterSplit', 'GoldbachSignedModulusTransfer')]
    [string[]]$Modules = @('GoldbachKloostermanGeometry', 'GoldbachCharacterSplit', 'GoldbachSignedModulusTransfer')
)
$ErrorActionPreference = 'Stop'
$taskSprintRoot = Split-Path $PSScriptRoot -Parent
$taskResearchRoot = Split-Path $taskSprintRoot -Parent
$taskSourceRoot = Join-Path $taskSprintRoot 'lean'
$taskReplayRoot = Join-Path $PSScriptRoot 'character_independent_replay'
$taskLeanExe = 'C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskCacheRoot = 'D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskPriorLibs = @('sprint9', 'sprint8', 'sprint7', 'sprint6', 'sprint5', 'sprint4', 'sprint3') | ForEach-Object {
    Join-Path $taskResearchRoot ($_ + '\lean')
}
$taskCacheLibs = @(Get-ChildItem -LiteralPath $taskCacheRoot -Directory | ForEach-Object {
    $taskCandidate = Join-Path $_.FullName '.lake\build\lib'
    if (Test-Path -LiteralPath $taskCandidate) { $taskCandidate }
})
New-Item -ItemType Directory -Path $taskReplayRoot -Force | Out-Null
# The current production sprint10/lean directory is deliberately excluded.
$env:LEAN_PATH = [string]::Join(';', @($taskReplayRoot) + $taskPriorLibs + $taskCacheLibs)
$taskLeanVersion = (& $taskLeanExe --version | Out-String).Trim()
foreach ($taskModule in $Modules) {
    $taskOriginal = Join-Path $taskSourceRoot ($taskModule + '.lean')
    $taskCopied = Join-Path $taskReplayRoot ($taskModule + '.lean')
    $taskLog = Join-Path $taskReplayRoot ($taskModule + '.replay.log')
    $taskOlean = Join-Path $taskReplayRoot ($taskModule + '.olean')
    $taskSourceHash = (Get-FileHash -LiteralPath $taskOriginal -Algorithm SHA256).Hash.ToLowerInvariant()
    Copy-Item -LiteralPath $taskOriginal -Destination $taskCopied -Force
    $taskCopyHash = (Get-FileHash -LiteralPath $taskCopied -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($taskCopyHash -ne $taskSourceHash) { throw 'Source changed during replay copy.' }
    & $taskLeanExe -o $taskOlean $taskCopied *> $taskLog
    $taskExit = $LASTEXITCODE
    $taskLogText = Get-Content -LiteralPath $taskLog -Raw
    $taskAudits = [regex]::Matches($taskLogText, 'depends on axioms:\s*\[([^\]]*)\]')
    $taskAllowed = @('propext', 'Classical.choice', 'Quot.sound')
    $taskAuditValid = $true
    foreach ($taskAudit in $taskAudits) {
        foreach ($taskAxiom in ($taskAudit.Groups[1].Value -split ',')) {
            if (($taskAxiom.Trim().Length -gt 0) -and ($taskAxiom.Trim() -notin $taskAllowed)) {
                $taskAuditValid = $false
            }
        }
    }
    $taskExpected = switch ($taskModule) {
        'GoldbachKloostermanGeometry' { 10 }
        'GoldbachCharacterSplit' { 14 }
        'GoldbachSignedModulusTransfer' { 6 }
    }
    $taskCurrentHash = (Get-FileHash -LiteralPath $taskOriginal -Algorithm SHA256).Hash.ToLowerInvariant()
    $taskPass = ($taskExit -eq 0) -and ($taskAudits.Count -eq $taskExpected) -and
        $taskAuditValid -and ($taskLogText -notmatch '(?im)\berror:|\bwarning:') -and
        ($taskCurrentHash -eq $taskSourceHash)
    $taskReceipt = [ordered]@{
        module = $taskModule
        checked_utc = [DateTime]::UtcNow.ToString('o')
        lean_version = $taskLeanVersion
        source_original = $taskOriginal
        source_copy = $taskCopied
        source_sha256 = $taskSourceHash
        copied_source_sha256 = $taskCopyHash
        original_source_unchanged_during_replay = ($taskCurrentHash -eq $taskSourceHash)
        replay_log = $taskLog
        replay_log_sha256 = (Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant()
        replay_olean_sha256 = if (Test-Path -LiteralPath $taskOlean) {
            (Get-FileHash -LiteralPath $taskOlean -Algorithm SHA256).Hash.ToLowerInvariant()
        } else { $null }
        lean_exit_code = $taskExit
        printed_axiom_audits = $taskAudits.Count
        expected_printed_axiom_audits = $taskExpected
        standard_axioms_only = $taskAuditValid
        production_sprint10_library_excluded = $true
        old_modules_rebuilt = $false
        pass = $taskPass
    }
    $taskJson = $taskReceipt | ConvertTo-Json -Depth 5
    $taskJson | Set-Content -LiteralPath (Join-Path $taskReplayRoot ($taskModule + '.receipt.json')) -Encoding utf8
    $taskJson
    if (-not $taskPass) {
        Get-Content -LiteralPath $taskLog
        throw ('Independent replay failed for ' + $taskModule)
    }
}
