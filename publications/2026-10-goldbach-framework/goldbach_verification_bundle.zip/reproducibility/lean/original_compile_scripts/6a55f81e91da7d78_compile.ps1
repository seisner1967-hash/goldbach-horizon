param([string[]]$Modules = @('GoldbachVariance', 'GoldbachQuartic', 'GoldbachBridge',
    'GoldbachFourier', 'GoldbachIntervals', 'GoldbachArithmetic', 'GoldbachHundred',
    'GoldbachAudit'))
$ErrorActionPreference = 'Stop'
$taskLeanRoot = $PSScriptRoot
$taskCacheRoot = 'D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskLeanExe = 'C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskLibs = @(Get-ChildItem -LiteralPath $taskCacheRoot -Directory | ForEach-Object {
    $taskCandidate = Join-Path $_.FullName '.lake\build\lib'
    if (Test-Path -LiteralPath $taskCandidate) { $taskCandidate }
})
$env:LEAN_PATH = [string]::Join(';', @($taskLeanRoot) + $taskLibs)
foreach ($taskModule in $Modules) {
    $taskSource = Join-Path $taskLeanRoot ($taskModule + '.lean')
    $taskOutput = Join-Path $taskLeanRoot ($taskModule + '.olean')
    $taskLog = Join-Path $taskLeanRoot ($taskModule + '.log')
    & $taskLeanExe -o $taskOutput $taskSource *> $taskLog
    $taskExit = $LASTEXITCODE
    Get-Content -LiteralPath $taskLog
    if ($taskExit -ne 0) { exit $taskExit }
}
