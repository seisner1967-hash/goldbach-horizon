param([Parameter(Mandatory=$true)][string]$CharacterSourceSha256)
$ErrorActionPreference='Stop'
$taskSprintRoot=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$taskResearchRoot=Split-Path $taskSprintRoot -Parent
$taskInitial=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'lean_replay_receipt.json') -Raw | ConvertFrom-Json
if($taskInitial.status -ne 'PASS' -or $taskInitial.total_axiom_reports -ne 25){throw 'Initial independent receipt is not the accepted 25 audits'}
foreach($taskDependency in $taskInitial.modules){
    foreach($taskPair in @(@('lean','copied_source_sha256'),@('olean','olean_sha256'),@('log','log_sha256'))){
        $taskFile=Join-Path $PSScriptRoot ($taskDependency.module+'.'+$taskPair[0])
        $taskHash=(Get-FileHash -LiteralPath $taskFile -Algorithm SHA256).Hash.ToLowerInvariant()
        if($taskHash -ne $taskDependency.($taskPair[1])){throw 'Initial isolated dependency changed'}
    }
}
$taskExpected=@{
    GoldbachCharacterDispersion=$CharacterSourceSha256.ToLowerInvariant()
    GoldbachConductorPrefix='56fe21ac42e3be97a8e63a80bcd077b4b79159a2adcc263a9cab7c4beee66564'
}
$taskLeanExe='C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskPaths=@($taskInitial.import_paths)
$env:LEAN_PATH=[string]::Join(';',$taskPaths)
$taskReports=@()
foreach($taskModule in @('GoldbachCharacterDispersion','GoldbachConductorPrefix')){
    $taskOriginal=Join-Path $taskSprintRoot ('lean\'+$taskModule+'.lean')
    $taskCopy=Join-Path $PSScriptRoot ($taskModule+'.lean')
    $taskOlean=Join-Path $PSScriptRoot ($taskModule+'.olean')
    $taskLog=Join-Path $PSScriptRoot ($taskModule+'.log')
    $taskBefore=(Get-FileHash -LiteralPath $taskOriginal -Algorithm SHA256).Hash.ToLowerInvariant()
    if($taskBefore -ne $taskExpected[$taskModule]){throw 'Frozen extra source hash mismatch'}
    Copy-Item -LiteralPath $taskOriginal -Destination $taskCopy
    & $taskLeanExe -o $taskOlean $taskCopy *> $taskLog
    $taskExit=$LASTEXITCODE
    $taskAfter=(Get-FileHash -LiteralPath $taskOriginal -Algorithm SHA256).Hash.ToLowerInvariant()
    $taskText=Get-Content -LiteralPath $taskLog -Raw
    $taskSourceText=Get-Content -LiteralPath $taskCopy -Raw
    $taskRequested=([regex]::Matches($taskSourceText,'(?m)^#print axioms ')).Count
    $taskReceived=([regex]::Matches($taskText,'depends on axioms:')).Count
    $taskAxiomSets=@([regex]::Matches($taskText,'depends on axioms:\s*\[([^\]]*)\]') | ForEach-Object {
        ,@($_.Groups[1].Value -split ',' | ForEach-Object {$_.Trim()})
    })
    $taskUnexpected=@($taskAxiomSets | ForEach-Object {$_} | Where-Object {$_ -notin @('propext','Classical.choice','Quot.sound')})
    $taskBad=([regex]::Matches($taskText,'(?mi)\berror:|\bwarning:|sorryAx')).Count
    $taskPass=($taskExit -eq 0)-and($taskBad -eq 0)-and($taskUnexpected.Count -eq 0)-and
        ($taskBefore -eq $taskAfter)-and($taskRequested -eq $taskReceived)
    $taskReports+=[ordered]@{
        module=$taskModule; status=$(if($taskPass){'PASS'}else{'FAIL'});
        compiler_exit_code=$taskExit; source_sha256=$taskBefore; source_after_sha256=$taskAfter;
        copied_source_sha256=(Get-FileHash -LiteralPath $taskCopy -Algorithm SHA256).Hash.ToLowerInvariant();
        olean_sha256=$(if(Test-Path -LiteralPath $taskOlean){(Get-FileHash -LiteralPath $taskOlean -Algorithm SHA256).Hash.ToLowerInvariant()}else{$null});
        log_sha256=(Get-FileHash -LiteralPath $taskLog -Algorithm SHA256).Hash.ToLowerInvariant();
        requested_axiom_reports=$taskRequested; received_axiom_reports=$taskReceived;
        errors_warnings_sorryAx=$taskBad; unexpected_axioms=$taskUnexpected;
        all_audit_axioms_allowed=($taskUnexpected.Count -eq 0); axiom_sets=$taskAxiomSets
    }
    Write-Output ($taskModule+': '+$(if($taskPass){'PASS'}else{'FAIL'})+' '+$taskReceived+' axiom reports')
}
$taskTotalReports=0
foreach($taskReportItem in $taskReports){$taskTotalReports += [int]$taskReportItem['received_axiom_reports']}
$taskReceipt=[ordered]@{
    status=$(if(@($taskReports | Where-Object {$_.status -ne 'PASS'}).Count -eq 0){'PASS'}else{'FAIL'});
    compiler=$taskLeanExe; original_current_sprint_import_path_excluded=$true;
    import_paths=$taskPaths; modules=$taskReports; total_axiom_reports=$taskTotalReports;
    initial_independent_dependency_receipt_sha256=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot 'lean_replay_receipt.json') -Algorithm SHA256).Hash.ToLowerInvariant();
    initial_independent_proofs_not_recompiled=$true;
    literal_scope='Completed-C character selector and signed bilinear linkage; finite conductor-prefix endpoint algebra only. No arithmetic cancellation or asymptotic estimate.'
}
$taskReceipt | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'lean_extra_replay_receipt.json') -Encoding utf8
if($taskReceipt.status -ne 'PASS'){throw 'Independent extra replay failed; artifacts preserved'}
