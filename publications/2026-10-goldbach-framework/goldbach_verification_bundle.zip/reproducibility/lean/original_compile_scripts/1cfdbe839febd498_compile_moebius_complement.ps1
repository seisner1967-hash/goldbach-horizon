$ErrorActionPreference = 'Stop'
$taskResearchRoot = 'D:\Users\Utilisateur\Desktop\Maths\Goldbach_Research_20260930'
$taskCacheRoot = 'D:\Users\Utilisateur\Desktop\Maths\q356-canonical-binding-replay\.lake\packages'
$taskLeanExe = 'C:\Users\Utilisateur\.elan\toolchains\leanprover--lean4---v4.15.0\bin\lean.exe'
$taskPriorLibs = @('sprint14','sprint13','sprint12','sprint11','sprint10','sprint9','sprint8','sprint7','sprint6','sprint5','sprint4','sprint3') | ForEach-Object {
    Join-Path $taskResearchRoot ($_ + '\lean')
}
$taskPackageLibs = @(Get-ChildItem -LiteralPath $taskCacheRoot -Directory | ForEach-Object {
    $taskCandidate = Join-Path $_.FullName '.lake\build\lib'
    if (Test-Path -LiteralPath $taskCandidate) { $taskCandidate }
})
$taskImportPaths = @($PSScriptRoot) + $taskPriorLibs + $taskPackageLibs
$env:LEAN_PATH = [string]::Join(';', $taskImportPaths)
$taskImportPaths | Set-Content -LiteralPath (Join-Path $PSScriptRoot 'moebius_import_paths.txt') -Encoding utf8
$taskModule = 'GoldbachMoebiusComplement'
& $taskLeanExe -o (Join-Path $PSScriptRoot ($taskModule + '.olean')) (Join-Path $PSScriptRoot ($taskModule + '.lean')) *> (Join-Path $PSScriptRoot ($taskModule + '.log'))
$taskExit = $LASTEXITCODE
Write-Output ($taskModule + ': exit ' + $taskExit)
Get-Content -LiteralPath (Join-Path $PSScriptRoot ($taskModule + '.log'))
exit $taskExit
