"""Replay copied Lean sources in a new directory, without shell commands.

The default --check-only plan calls no process, including no compiler version
probe. A real replay needs --execute. No dependency is installed or downloaded.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

LIBRARIES = (
    "aesop", "batteries", "importGraph", "LeanSearchClient",
    "mathlib", "plausible", "proofwidgets", "Qq",
)
STANDARD_AXIOMS = {"propext", "Classical.choice", "Quot.sound"}
LEAN_VERSION = "4.15.0"
LEAN_COMMIT = "11651562caae"
MATHLIB_COMMIT = "9837ca9d65d9de6fad1ef4381750ca688774e608"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def evidence_folder() -> Path:
    here = Path(__file__).resolve().parent
    if (here / "MANIFEST_REPRODUCTION.json").is_file():
        return here
    return here.parent / "reproducibility" / "lean"


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--lean-exe", required=True, type=Path,
                   help="absolute path to the pinned Lean 4.15.0 executable")
    p.add_argument("--dependency-lib-dir", action="append", required=True,
                   type=Path, metavar="DIRECTORY",
                   help="repeat exactly eight times, ordered: " + ", ".join(LIBRARIES))
    p.add_argument("--build-dir", required=True, type=Path,
                   help="absolute directory that does not yet exist")
    p.add_argument("--evidence-dir", type=Path, default=evidence_folder(),
                   help="copied collection containing sources, order and manifest")
    modes = p.add_mutually_exclusive_group()
    modes.add_argument("--check-only", action="store_true",
                       help="validate the plan without any subprocess or file creation (default)")
    modes.add_argument("--execute", action="store_true",
                       help="actually run the compiler; creates only the new build directory")
    p.add_argument("--module-timeout", type=int, default=600,
                   help="maximum seconds per compiler process (default: 600)")
    return p


def absolute_path(p: Path, label: str) -> Path:
    if not p.is_absolute():
        raise ValueError(label + " must be absolute: " + str(p))
    return p.resolve()


def validate(args: argparse.Namespace) -> dict:
    exe = absolute_path(args.lean_exe, "--lean-exe")
    if not exe.is_file():
        raise ValueError("Lean executable does not exist: " + str(exe))
    if len(args.dependency_lib_dir) != 8:
        raise ValueError("Exactly eight --dependency-lib-dir arguments are required")
    libs = [absolute_path(p, "--dependency-lib-dir") for p in args.dependency_lib_dir]
    if len(set(libs)) != 8 or not all(p.is_dir() for p in libs):
        raise ValueError("The eight library directories must exist and be distinct")
    build = absolute_path(args.build_dir, "--build-dir")
    if build.exists():
        raise ValueError("Refuse to use an existing build directory: " + str(build))
    evidence = absolute_path(args.evidence_dir, "--evidence-dir")
    if not evidence.is_dir():
        raise ValueError("Evidence directory does not exist: " + str(evidence))
    for protected in [evidence, *libs]:
        if build == protected or build.is_relative_to(protected):
            raise ValueError("Build directory must be outside sources and dependency libraries")
    if args.module_timeout <= 0:
        raise ValueError("--module-timeout must be positive")
    manifest_bytes = (evidence / "MANIFEST_REPRODUCTION.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    entries = {}
    for entry in manifest["files"]:
        rel = Path(entry["path"])
        if rel.is_absolute() or ".." in rel.parts:
            raise ValueError("Unsafe relative manifest path: " + str(rel))
        if entry["path"] in entries:
            raise ValueError("Duplicate manifest path: " + entry["path"])
        entries[entry["path"]] = entry
    order_bytes = (evidence / "compile_order.json").read_bytes()
    order_entry = entries["compile_order.json"]
    if (sha256(order_bytes) != order_entry["sha256"] or
            len(order_bytes) != order_entry["bytes"]):
        raise ValueError("compile_order.json differs from the copied manifest")
    order_document = json.loads(order_bytes)
    if order_document["dependency_pin"] != MATHLIB_COMMIT:
        raise ValueError("Unexpected Mathlib revision in compile_order.json")
    modules = order_document["module_order"]
    imports = order_document["local_imports"]
    if len(modules) != 71 or len(set(modules)) != 71 or set(modules) != set(imports):
        raise ValueError("Expected exactly 71 distinct canonical modules")
    seen = set()
    sources = {}
    for module in modules:
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", module):
            raise ValueError("Unsafe module name: " + str(module))
        if not set(imports[module]).issubset(seen):
            raise ValueError("Module order is not topological: " + module)
        rel = "sources/" + module + ".lean"
        entry = entries[rel]
        source = evidence / rel
        source_bytes = source.read_bytes()
        if sha256(source_bytes) != entry["sha256"] or len(source_bytes) != entry["bytes"]:
            raise ValueError("Copied source hash/size mismatch: " + str(source))
        sources[module] = {"source": str(source), "sha256": entry["sha256"],
                           "bytes": entry["bytes"]}
        seen.add(module)
    if sum(k.startswith("sources/") for k in entries) != 71:
        raise ValueError("Manifest has an unexpected canonical source count")
    return {
        "status": "PLAN_VALIDATED_NO_PROCESS_CALLED", "compilation_performed": False,
        "build_directory_created": False, "lean_exe": str(exe),
        "lean_pin": {"version": LEAN_VERSION, "commit": LEAN_COMMIT},
        "mathlib_pin": MATHLIB_COMMIT,
        "dependency_directories": [
            {"expected_package": n, "directory": str(p)} for n, p in zip(LIBRARIES, libs)],
        "dependency_revisions_verified_by_this_plan": False,
        "build_dir": str(build), "evidence_dir": str(evidence),
        "manifest_sha256": sha256(manifest_bytes),
        "compile_order_sha256": sha256(order_bytes), "module_order": modules,
        "sources": sources,
        "expected_audited_statements": order_document.get("expected_audited_statements", []),
        "scope": "Fresh source replay is available but has not been executed by plan validation.",
    }


def parse_axioms(raw: bytes) -> dict[str, list[str]]:
    output = raw.decode("utf-8", errors="replace")
    found = {}
    for name, body in re.findall(r"'([^']+)'\s+depends on axioms:\s*\[([^\]]*)\]", output):
        axioms = sorted({a.strip() for a in body.split(",") if a.strip()})
        if not set(axioms).issubset(STANDARD_AXIOMS):
            raise ValueError("Nonstandard axiom footprint for " + name + ": " + str(axioms))
        found[name] = axioms
    for name in re.findall(r"'([^']+)'\s+does not depend on any axioms", output):
        found[name] = []
    return found


def execute(args: argparse.Namespace, plan: dict) -> dict:
    build = Path(plan["build_dir"])
    # mkdir refuses an existing path. No delete, move or recursive cleanup is used.
    build.mkdir(parents=True, exist_ok=False)
    logs = build / "fresh_logs"
    logs.mkdir()
    result = {**plan, "status": "RUNNING", "build_directory_created": True,
              "started_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
              "script_sha256": sha256(Path(__file__).read_bytes()), "compiler_invocations": [],
              "all_printed_axiom_footprints": {},
              "analytic_theorem_claimed": False}
    receipt = build / "FRESH_REPLAY_RECEIPT.json"

    def save() -> None:
        receipt.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")

    try:
        for module in plan["module_order"]:
            source = Path(plan["sources"][module]["source"])
            copied = build / (module + ".lean")
            shutil.copyfile(source, copied)
            if sha256(copied.read_bytes()) != plan["sources"][module]["sha256"]:
                raise ValueError("Source changed during copy: " + module)
        environment = os.environ.copy()
        environment["LEAN_PATH"] = os.pathsep.join(
            [str(build), *[d["directory"] for d in plan["dependency_directories"]]])
        result["LEAN_PATH"] = environment["LEAN_PATH"]
        version = subprocess.run([plan["lean_exe"], "--version"], cwd=build,
                                 env=environment, stdout=subprocess.PIPE,
                                 stderr=subprocess.STDOUT, timeout=30, shell=False)
        version_path = logs / "lean_version.log"
        version_path.write_bytes(version.stdout)
        result["version_log_sha256"] = sha256(version.stdout)
        result["version_exit_code"] = version.returncode
        version_text = version.stdout.decode("utf-8", errors="replace")
        result["actual_lean_version"] = version_text.strip()
        if (version.returncode != 0 or LEAN_VERSION not in version_text or
                LEAN_COMMIT not in version_text):
            raise ValueError("Compiler version/commit does not match the retained pin")
        for module in plan["module_order"]:
            source = build / (module + ".lean")
            olean = build / (module + ".olean")
            log = logs / (module + ".log")
            command = [plan["lean_exe"], "-o", str(olean), str(source)]
            started = time.monotonic()
            try:
                compiled = subprocess.run(command, cwd=build, env=environment,
                                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                          timeout=args.module_timeout, shell=False)
                raw, exit_code, timed_out = compiled.stdout, compiled.returncode, False
            except subprocess.TimeoutExpired as error:
                raw, exit_code, timed_out = error.stdout or b"", None, True
            log.write_bytes(raw)
            record = {"module": module, "argv": command, "exit_code": exit_code,
                      "timed_out": timed_out, "elapsed_seconds": time.monotonic() - started,
                      "source_sha256": sha256(source.read_bytes()),
                      "log": str(log), "log_sha256": sha256(raw),
                      "olean_sha256": sha256(olean.read_bytes()) if olean.is_file() else None}
            result["compiler_invocations"].append(record)
            result["compilation_performed"] = True
            save()
            if exit_code != 0 or not olean.is_file():
                raise RuntimeError("Compilation failed or timed out for " + module)
            if record["source_sha256"] != plan["sources"][module]["sha256"]:
                raise ValueError("Copied source changed during compilation: " + module)
            audits = parse_axioms(raw)
            result["all_printed_axiom_footprints"].update(audits)
            record["printed_axiom_objects"] = len(audits)
            save()
        expected = {s["name"] for s in plan["expected_audited_statements"]}
        missing = sorted(expected - set(result["all_printed_axiom_footprints"]))
        result["expected_audited_name_count"] = len(expected)
        result["missing_expected_printed_objects"] = missing
        if missing:
            raise ValueError("Fresh outputs omit expected axiom-audited names; inspect the receipt")
        result["status"] = "FRESH_REPLAY_PASS"
        result["scope"] = ("All 71 copied canonical modules compiled in topological order; "
                           "printed axiom objects use only standard axioms. This is not an "
                           "analytic-input proof or Goldbach theorem.")
    except Exception as error:
        result["status"] = "FRESH_REPLAY_FAIL"
        result["error"] = type(error).__name__ + ": " + str(error)
    result["finished_utc"] = dt.datetime.now(dt.timezone.utc).isoformat()
    save()
    return result


def main() -> int:
    args = parser().parse_args()
    try:
        plan = validate(args)
    except (OSError, ValueError, KeyError, TypeError, json.JSONDecodeError) as error:
        print(json.dumps({"status": "PLAN_REJECTED_NO_PROCESS_CALLED", "error": str(error)}, indent=2))
        return 2
    if not args.execute:
        print(json.dumps(plan, indent=2))
        return 0
    result = execute(args, plan)
    print(json.dumps({"status": result["status"], "build_dir": result["build_dir"],
                      "receipt": str(Path(result["build_dir"]) / "FRESH_REPLAY_RECEIPT.json"),
                      "compiled_modules": len(result["compiler_invocations"]),
                      "error": result.get("error")}, indent=2))
    return 0 if result["status"] == "FRESH_REPLAY_PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
