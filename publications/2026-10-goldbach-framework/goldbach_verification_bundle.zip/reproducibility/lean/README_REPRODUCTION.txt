READ-ONLY LEAN SOURCE AND CERTIFICATE REPRODUCTION FOLDER

This folder contains 71 canonical source files, original retained compile
scripts, successful source-bound receipts/axiom logs and older checkpoint
metadata. It contains no copied olean, dependency cache, PDF or ZIP. The
manifest hashes every payload and binds it to its original read-only path.
Imported local modules form a closed graph; compile_order.json records a
topological order. Dependencies and proof names are not counted again.

TRUST AND SCOPE
Use Lean 4.15.0, commit 11651562caae and Mathlib revision
9837ca9d65d9de6fad1ef4381750ca688774e608. Required cached library roots are
aesop, batteries, importGraph, LeanSearchClient, mathlib, plausible,
proofwidgets and Qq (in that order for portable_replay.py).
The copied lake-manifest.json records pins. An existing .olean is not a
fresh source replay. The current inventory verified prior evidence and
performed no new compilation. The latest 19 finite conclusions are separate
from 658 accumulated explicitly axiom-audited statements; lexical declaration
counts, private helpers, repeated imports and old copies are not new results.

PORTABLE REPLAY (not executed during preparation of this folder)
Run python portable_replay.py --help to inspect its arguments. Supply an
absolute --lean-exe, exactly eight --dependency-lib-dir arguments in the
order above, and a NEW absolute --build-dir. --check-only (also the default)
checks paths, source hashes and the closed topological plan without calling
any process or creating the build directory. Actual compilation requires the
separate explicit --execute option. Dependencies must already be available;
the script neither downloads nor installs them. Library revision identity
must be verified on the replay host; a directory existing is not such a check.
It records compiler argv arrays, version, exit codes, source/log/olean hashes
and printed axiom footprints in FRESH_REPLAY_RECEIPT.json in the new directory.
The included five wrappers/probes are not counted as new theorem declarations.
Their inclusion in this replay plan is not a claim that this new plan ran.

MANUAL FRESH REPLAY PROCEDURE
1. Resolve the pinned Lean executable and the eight matching dependency
   library directories on the replay host. Check actual versions/revisions.
2. Choose a NEW absolute build directory that does not contain an old
   project olean. Copy all sources/*.lean into that directory without edits.
3. Set LEAN_PATH to that new directory followed by only the eight pinned
   dependency library roots; standard Lean system libraries are implicit.
4. In compile_order.json order, invoke the pinned compiler with arguments
   ["-o", "<new>/<Module>.olean", "<new>/<Module>.lean"]. Capture stdout and
   stderr to a per-module fresh log and require compiler exit 0.
5. Parse #print axioms outputs against the retained expected statements;
   permit only propext, Classical.choice and Quot.sound. Hash copied source, log
   and olean. Some source/helper declarations are not individually printed.
   Use inventory headers and old receipts to distinguish that scope.

ORIGINAL SCRIPTS
Original scripts retain exact bytes and often authoring-host absolute
paths or PSScriptRoot-relative source layouts. They are templates/evidence,
not automatically portable commands from this flattened evidence folder.
Use the original source layout or resolve equivalent pinned paths before
invocation. Recent supported examples use -BuildDirectory <newAbsolute>.
No original script is executed, silently modified or wrapped by this
gatherer. No network/update/install command is needed for this inventory.

LIMITATIONS
This artifact does not prove a classical analytic input in Lean, a covered
bridge, an effective global signed deficit, a sufficient prime-pair margin
or Goldbach. Historical Horizon predicates and files with gaps/custom
axioms/native certificates are excluded from these 71 canonical sources.
The complete machine registry remains in review/lean_inventory.json; its
absolute origin paths document provenance rather than a portable URL.
