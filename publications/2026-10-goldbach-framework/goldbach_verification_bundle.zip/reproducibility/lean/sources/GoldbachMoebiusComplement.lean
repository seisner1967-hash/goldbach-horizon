import GoldbachArithmetic
import Mathlib.NumberTheory.VonMangoldt

/-!
Exact complementary Moebius signs and the literal capped divisor switch.
These finite identities prove no analytic cancellation or Goldbach margin.
-/

namespace GoldbachResearch.MoebiusComplement

open scoped BigOperators
open Finset ActualArithmetic

theorem moebius_complement_int (k r : ℕ) :
    ArithmeticFunction.moebius k * ArithmeticFunction.moebius (k * r) =
      ArithmeticFunction.moebius r * ArithmeticFunction.moebius (k * r) ^ 2 := by
  by_cases hsq : Squarefree (k * r)
  · have hk : Squarefree k := hsq.squarefree_of_dvd (dvd_mul_right k r)
    have hcop : k.Coprime r := Nat.coprime_of_squarefree_mul hsq
    have hmul := ArithmeticFunction.isMultiplicative_moebius.map_mul_of_coprime hcop
    rw [ArithmeticFunction.moebius_sq_eq_one_of_squarefree hsq, mul_one, hmul]
    calc
      ArithmeticFunction.moebius k *
          (ArithmeticFunction.moebius k * ArithmeticFunction.moebius r) =
          ArithmeticFunction.moebius k ^ 2 * ArithmeticFunction.moebius r := by ring
      _ = ArithmeticFunction.moebius r := by
        rw [ArithmeticFunction.moebius_sq_eq_one_of_squarefree hk, one_mul]
  · simp [ArithmeticFunction.moebius_eq_zero_of_not_squarefree hsq]

theorem muReal_complement (k r : ℕ) :
    muReal k * muReal (k * r) = muReal r * muReal (k * r) ^ 2 := by
  unfold muReal
  exact_mod_cast moebius_complement_int k r

theorem muReal_complement_of_product {k r m : ℕ} (h : k * r = m) :
    muReal k * muReal m = muReal r * muReal m ^ 2 := by
  simpa only [h] using muReal_complement k r

theorem log_ratio_of_product {k r m : ℕ} (hk : 0 < k) (hr : 0 < r)
    (h : k * r = m) :
    Real.log ((k : ℝ) / (m : ℝ)) = -Real.log (r : ℝ) := by
  have hk0 : (k : ℝ) ≠ 0 := by exact_mod_cast hk.ne'
  have hr0 : (r : ℝ) ≠ 0 := by exact_mod_cast hr.ne'
  rw [← h, Nat.cast_mul, Real.log_div hk0 (mul_ne_zero hk0 hr0),
    Real.log_mul hk0 hr0]
  ring

theorem capped_cut_iff {k r m alpha Q : ℕ} (hk : 0 < k) (hr : 0 < r)
    (h : k * r = m) :
    (k ≤ Q ∧ alpha * k < m) ↔ (alpha < r ∧ m ≤ Q * r) := by
  constructor
  · rintro ⟨hQ, ha⟩
    have ha' : alpha < r := by
      apply (Nat.mul_lt_mul_left hk).mp
      simpa [h, Nat.mul_comm] using ha
    exact ⟨ha', by simpa [h] using Nat.mul_le_mul_right r hQ⟩
  · rintro ⟨ha, hQ⟩
    have hkQ : k ≤ Q := by
      by_contra hnot
      have hlt := Nat.mul_lt_mul_of_pos_right (Nat.lt_of_not_ge hnot) hr
      rw [h] at hlt
      omega
    refine ⟨hkQ, ?_⟩
    simpa [h, Nat.mul_comm] using (Nat.mul_lt_mul_left hk).mpr ha

theorem signed_log_complement {k r m : ℕ} (hk : 0 < k) (hr : 0 < r)
    (h : k * r = m) :
    muReal m * (muReal k * Real.log ((k : ℝ) / (m : ℝ))) =
      muReal m ^ 2 * (-muReal r * Real.log (r : ℝ)) := by
  rw [log_ratio_of_product hk hr h]
  calc
    muReal m * (muReal k * -Real.log (r : ℝ)) =
        -(muReal k * muReal m) * Real.log (r : ℝ) := by ring
    _ = muReal m ^ 2 * (-muReal r * Real.log (r : ℝ)) := by
      rw [muReal_complement_of_product h]
      ring

noncomputable def cappedDivisorWeight (m alpha Q : ℕ) : ℝ :=
  ∑ k ∈ m.divisors,
    if k ≤ Q ∧ alpha * k < m then
      muReal k * Real.log ((k : ℝ) / (m : ℝ)) else 0

noncomputable def cappedShortDivisor (m alpha Q : ℕ) : ℝ :=
  -(∑ d ∈ m.divisors,
    if d ≤ alpha ∨ m > Q * d then muReal d * Real.log (d : ℝ) else 0)

theorem capped_divisor_switch (m alpha Q : ℕ) :
    muReal m * cappedDivisorWeight m alpha Q =
      -(muReal m ^ 2) * (∑ d ∈ m.divisors,
        if alpha < d ∧ m ≤ Q * d then muReal d * Real.log (d : ℝ) else 0) := by
  classical
  unfold cappedDivisorWeight
  rw [← Nat.sum_divisorsAntidiagonal
    (fun k (_ : ℕ) => if k ≤ Q ∧ alpha * k < m then
      muReal k * Real.log ((k : ℝ) / (m : ℝ)) else 0)]
  rw [Finset.mul_sum]
  have hpoint :
      (∑ p ∈ m.divisorsAntidiagonal, muReal m *
        (if p.1 ≤ Q ∧ alpha * p.1 < m then
          muReal p.1 * Real.log ((p.1 : ℝ) / (m : ℝ)) else 0)) =
      ∑ p ∈ m.divisorsAntidiagonal, muReal m ^ 2 *
        (if alpha < p.2 ∧ m ≤ Q * p.2 then
          -muReal p.2 * Real.log (p.2 : ℝ) else 0) := by
    apply Finset.sum_congr rfl
    intro p hp
    have hm := (Nat.mem_divisorsAntidiagonal.mp hp).1
    have hk : 0 < p.1 := Nat.pos_of_ne_zero (Nat.left_ne_zero_of_mem_divisorsAntidiagonal hp)
    have hr : 0 < p.2 := Nat.pos_of_ne_zero (Nat.right_ne_zero_of_mem_divisorsAntidiagonal hp)
    have hcut := capped_cut_iff hk hr hm (alpha := alpha) (Q := Q)
    by_cases hc : p.1 ≤ Q ∧ alpha * p.1 < m
    · have hc' := hcut.mp hc
      simp only [if_pos hc, if_pos hc']
      exact signed_log_complement hk hr hm
    · have hc' : ¬ (alpha < p.2 ∧ m ≤ Q * p.2) := by
        intro hc'
        exact hc (hcut.mpr hc')
      simp only [if_neg hc, if_neg hc', mul_zero]
  rw [hpoint, ← Finset.mul_sum, Nat.sum_divisorsAntidiagonal'
    (fun (_ : ℕ) d => if alpha < d ∧ m ≤ Q * d then
      -muReal d * Real.log (d : ℝ) else 0)]
  have hneg :
      (∑ d ∈ m.divisors, if alpha < d ∧ m ≤ Q * d then
        -muReal d * Real.log (d : ℝ) else 0) =
      -(∑ d ∈ m.divisors, if alpha < d ∧ m ≤ Q * d then
        muReal d * Real.log (d : ℝ) else 0) := by
    rw [← Finset.sum_neg_distrib]
    apply Finset.sum_congr rfl
    intro d hd
    split_ifs <;> ring
  rw [hneg]
  ring

theorem capped_reference_identity (m alpha Q : ℕ) :
    muReal m * cappedDivisorWeight m alpha Q =
      muReal m ^ 2 *
        (ArithmeticFunction.vonMangoldt m - cappedShortDivisor m alpha Q) := by
  classical
  have hsplit :
      (∑ d ∈ m.divisors, muReal d * Real.log (d : ℝ)) =
      (∑ d ∈ m.divisors, if alpha < d ∧ m ≤ Q * d then
        muReal d * Real.log (d : ℝ) else 0) +
      (∑ d ∈ m.divisors, if d ≤ alpha ∨ m > Q * d then
        muReal d * Real.log (d : ℝ) else 0) := by
    rw [← Finset.sum_add_distrib]
    apply Finset.sum_congr rfl
    intro d hd
    by_cases hc : alpha < d ∧ m ≤ Q * d
    · have hc' : ¬ (d ≤ alpha ∨ m > Q * d) := by omega
      simp [hc, hc']
    · have hc' : d ≤ alpha ∨ m > Q * d := by omega
      simp [hc, hc']
  have hvm : (∑ d ∈ m.divisors, muReal d * Real.log (d : ℝ)) =
      -ArithmeticFunction.vonMangoldt m := by
    simpa only [muReal] using ArithmeticFunction.sum_moebius_mul_log_eq (n := m)
  have hselected :
      (∑ d ∈ m.divisors, if alpha < d ∧ m ≤ Q * d then
        muReal d * Real.log (d : ℝ) else 0) =
      -ArithmeticFunction.vonMangoldt m -
        (∑ d ∈ m.divisors, if d ≤ alpha ∨ m > Q * d then
          muReal d * Real.log (d : ℝ) else 0) := by linarith
  rw [capped_divisor_switch, hselected]
  unfold cappedShortDivisor
  ring

#print axioms moebius_complement_int
#print axioms muReal_complement
#print axioms muReal_complement_of_product
#print axioms log_ratio_of_product
#print axioms capped_cut_iff
#print axioms signed_log_complement
#print axioms capped_divisor_switch
#print axioms capped_reference_identity

end GoldbachResearch.MoebiusComplement
