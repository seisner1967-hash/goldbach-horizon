import GoldbachCharacterDispersion

/-!
The literal completed C scalar is the weighted constant-direction projection
of its capped columns. The orthogonal residual is retained exactly and need
not be small when the scalar is small. No arithmetic projection bound is proved.
-/

namespace GoldbachResearch.ScalarProjection

open scoped BigOperators
open Finset ActualArithmetic TypeIIAssembly ShiftedDispersion CharacterDispersion

noncomputable section

def weightMass (J : Finset ℕ) (w : ℕ → ℝ) : ℝ := ∑ b ∈ J, w b

def weightedContraction (J : Finset ℕ) (w u : ℕ → ℝ) : ℝ :=
  ∑ b ∈ J, w b * u b

def weightedEnergy (J : Finset ℕ) (w u : ℕ → ℝ) : ℝ :=
  ∑ b ∈ J, w b * u b ^ 2

def residualColumn (J : Finset ℕ) (w u : ℕ → ℝ) (b : ℕ) : ℝ :=
  u b - weightedContraction J w u / weightMass J w

def residualEnergy (J : Finset ℕ) (w u : ℕ → ℝ) : ℝ :=
  weightedEnergy J w (residualColumn J w u)

def projectedEnergy (J : Finset ℕ) (w u : ℕ → ℝ) : ℝ :=
  weightedContraction J w u ^ 2 / weightMass J w

theorem weightMass_nonneg (J : Finset ℕ) (w : ℕ → ℝ)
    (hw : ∀ b ∈ J, 0 ≤ w b) : 0 ≤ weightMass J w := sum_nonneg hw

theorem weightedEnergy_nonneg (J : Finset ℕ) (w u : ℕ → ℝ)
    (hw : ∀ b ∈ J, 0 ≤ w b) : 0 ≤ weightedEnergy J w u :=
  sum_nonneg (fun b hb => mul_nonneg (hw b hb) (sq_nonneg _))

theorem weightedContraction_translate (J : Finset ℕ) (w u : ℕ → ℝ) (t : ℝ) :
    weightedContraction J w (fun b => u b - t) =
      weightedContraction J w u - t * weightMass J w := by
  unfold weightedContraction weightMass
  simp_rw [mul_sub, Finset.sum_sub_distrib, ← Finset.sum_mul]
  ring

theorem weightedEnergy_translate (J : Finset ℕ) (w u : ℕ → ℝ) (t : ℝ) :
    weightedEnergy J w (fun b => u b - t) =
      weightedEnergy J w u - 2 * t * weightedContraction J w u +
        t ^ 2 * weightMass J w := by
  unfold weightedEnergy weightedContraction weightMass
  calc
    (∑ b ∈ J, w b * (u b - t) ^ 2) =
        ∑ b ∈ J, (w b * u b ^ 2 - 2 * t * (w b * u b) + t ^ 2 * w b) := by
      apply sum_congr rfl
      intro b hb
      ring
    _ = _ := by
      simp_rw [Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum]

theorem residual_weighted_contraction_zero (J : Finset ℕ) (w u : ℕ → ℝ)
    (hB : weightMass J w ≠ 0) :
    weightedContraction J w (residualColumn J w u) = 0 := by
  unfold residualColumn
  rw [weightedContraction_translate]
  field_simp

theorem weighted_projection_decomposition (J : Finset ℕ) (w u : ℕ → ℝ)
    (hB : weightMass J w ≠ 0) :
    weightedEnergy J w u = projectedEnergy J w u + residualEnergy J w u := by
  unfold residualEnergy residualColumn projectedEnergy
  rw [weightedEnergy_translate]
  field_simp
  ring

theorem residualEnergy_nonneg (J : Finset ℕ) (w u : ℕ → ℝ)
    (hw : ∀ b ∈ J, 0 ≤ w b) : 0 ≤ residualEnergy J w u :=
  weightedEnergy_nonneg J w _ hw

theorem weights_zero_of_mass_zero (J : Finset ℕ) (w : ℕ → ℝ)
    (hw : ∀ b ∈ J, 0 ≤ w b) (hB : weightMass J w = 0) :
    ∀ b ∈ J, w b = 0 :=
  (Finset.sum_eq_zero_iff_of_nonneg hw).mp hB

theorem weighted_quantities_zero_of_mass_zero (J : Finset ℕ) (w u : ℕ → ℝ)
    (hw : ∀ b ∈ J, 0 ≤ w b) (hB : weightMass J w = 0) :
    weightedContraction J w u = 0 ∧ weightedEnergy J w u = 0 ∧
      residualEnergy J w u = 0 := by
  have hz := weights_zero_of_mass_zero J w hw hB
  constructor
  · apply sum_eq_zero
    intro b hb
    rw [hz b hb, zero_mul]
  constructor
  · apply sum_eq_zero
    intro b hb
    rw [hz b hb, zero_mul]
  · apply sum_eq_zero
    intro b hb
    rw [hz b hb, zero_mul]

theorem scalar_square_eq_mass_energy_minus_residual (J : Finset ℕ) (w u : ℕ → ℝ)
    (hB : weightMass J w ≠ 0) :
    weightedContraction J w u ^ 2 =
      weightMass J w * (weightedEnergy J w u - residualEnergy J w u) := by
  have hd := weighted_projection_decomposition J w u hB
  unfold projectedEnergy at hd
  have heq : weightedEnergy J w u - residualEnergy J w u =
      weightedContraction J w u ^ 2 / weightMass J w := by linarith
  rw [heq]
  field_simp

/- This is a sufficient scalar criterion with a projection-budget premise;
   it makes no requirement on the orthogonal residual or the entire energy. -/
theorem scalar_square_le_of_projectedEnergy_bound (J : Finset ℕ) (w u : ℕ → ℝ)
    (hB : 0 < weightMass J w) (T : ℝ) (hproj : projectedEnergy J w u ≤ T) :
    weightedContraction J w u ^ 2 ≤ weightMass J w * T := by
  unfold projectedEnergy at hproj
  have h := (div_le_iff₀ hB).mp hproj
  simpa only [mul_comm] using h

def actualColumn (N cutoff Q U b : ℕ) : ℝ :=
  column (activeFirst N U) muReal
    (arithmeticKernel N (fullCharacterWeight N cutoff Q)) b

def actualScalar (N cutoff Q U V : ℕ) : ℝ :=
  SignedModulusTransfer.signedApproximation N Q
    (SignedModulusTransfer.actualCharacterReal N cutoff U V)

def actualMass (N U V : ℕ) : ℝ :=
  weightMass (cappedSecond N U V) (Vaughan.beta V)

def actualEnergy (N cutoff Q U V : ℕ) : ℝ :=
  weightedEnergy (cappedSecond N U V) (Vaughan.beta V) (actualColumn N cutoff Q U)

def actualResidual (N cutoff Q U V : ℕ) : ℝ :=
  residualEnergy (cappedSecond N U V) (Vaughan.beta V) (actualColumn N cutoff Q U)

theorem actualScalar_eq_weightedContraction (N cutoff Q U V : ℕ) :
    actualScalar N cutoff Q U V =
      weightedContraction (cappedSecond N U V) (Vaughan.beta V) (actualColumn N cutoff Q U) :=
  signed_character_eq_capped_column N cutoff Q U V

theorem actualEnergy_eq_capped_dispersion (N cutoff Q U V : ℕ) :
    actualEnergy N cutoff Q U V =
      dispersion (activeFirst N U) (cappedSecond N U V) muReal (Vaughan.beta V)
        (arithmeticKernel N (fullCharacterWeight N cutoff Q)) := rfl

theorem actualMass_nonneg (N U V : ℕ) : 0 ≤ actualMass N U V :=
  weightMass_nonneg _ _ (fun b _ => Vaughan.beta_nonneg V b)

theorem actual_scalar_projection_decomposition (N cutoff Q U V : ℕ)
    (hB : 0 < actualMass N U V) :
    actualEnergy N cutoff Q U V =
      actualScalar N cutoff Q U V ^ 2 / actualMass N U V + actualResidual N cutoff Q U V := by
  rw [actualScalar_eq_weightedContraction]
  exact weighted_projection_decomposition _ _ _ hB.ne'

theorem actual_residual_orthogonal (N cutoff Q U V : ℕ) (hB : 0 < actualMass N U V) :
    (∑ b ∈ cappedSecond N U V, Vaughan.beta V b *
      (actualColumn N cutoff Q U b - actualScalar N cutoff Q U V / actualMass N U V)) = 0 := by
  rw [actualScalar_eq_weightedContraction]
  exact residual_weighted_contraction_zero _ _ _ hB.ne'

theorem actual_weighted_quantities_zero_of_mass_zero (N cutoff Q U V : ℕ)
    (hB : actualMass N U V = 0) :
    actualScalar N cutoff Q U V = 0 ∧ actualEnergy N cutoff Q U V = 0 ∧
      actualResidual N cutoff Q U V = 0 := by
  rw [actualScalar_eq_weightedContraction]
  exact weighted_quantities_zero_of_mass_zero _ _ _ (fun b _ => Vaughan.beta_nonneg V b) hB

theorem actual_scalar_square_eq_mass_energy_minus_residual (N cutoff Q U V : ℕ)
    (hB : 0 < actualMass N U V) :
    actualScalar N cutoff Q U V ^ 2 =
      actualMass N U V * (actualEnergy N cutoff Q U V - actualResidual N cutoff Q U V) := by
  rw [actualScalar_eq_weightedContraction]
  exact scalar_square_eq_mass_energy_minus_residual _ _ _ hB.ne'

theorem actual_scalar_square_le_of_projection_bound (N cutoff Q U V : ℕ)
    (hB : 0 < actualMass N U V) (T : ℝ)
    (hproj : actualScalar N cutoff Q U V ^ 2 / actualMass N U V ≤ T) :
    actualScalar N cutoff Q U V ^ 2 ≤ actualMass N U V * T := by
  have h := (div_le_iff₀ hB).mp hproj
  simpa only [mul_comm] using h

#print axioms weightMass_nonneg
#print axioms weightedEnergy_nonneg
#print axioms weightedContraction_translate
#print axioms weightedEnergy_translate
#print axioms residual_weighted_contraction_zero
#print axioms weighted_projection_decomposition
#print axioms residualEnergy_nonneg
#print axioms weights_zero_of_mass_zero
#print axioms weighted_quantities_zero_of_mass_zero
#print axioms scalar_square_eq_mass_energy_minus_residual
#print axioms scalar_square_le_of_projectedEnergy_bound
#print axioms actualScalar_eq_weightedContraction
#print axioms actualEnergy_eq_capped_dispersion
#print axioms actualMass_nonneg
#print axioms actual_scalar_projection_decomposition
#print axioms actual_residual_orthogonal
#print axioms actual_weighted_quantities_zero_of_mass_zero
#print axioms actual_scalar_square_eq_mass_energy_minus_residual
#print axioms actual_scalar_square_le_of_projection_bound

end
end GoldbachResearch.ScalarProjection
