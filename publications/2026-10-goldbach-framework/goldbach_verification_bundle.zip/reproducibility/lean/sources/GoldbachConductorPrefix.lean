import GoldbachJointCoprimality
import Mathlib.Algebra.BigOperators.Intervals
import Mathlib.Analysis.SpecialFunctions.Log.Basic

/-!
# Finite conductor-prefix endpoints

Exact integer cutoffs and finite logarithmic identities only. In particular,
there is no infinite sum, growing-mask uniform estimate or asymptotic axiom.
-/

namespace GoldbachResearch.ConductorPrefix

open scoped BigOperators
open Finset ActualArithmetic JointCoprimality

noncomputable def maskedCoefficient (r K : ℕ) : ℝ :=
  muReal r / (Nat.totient r : ℝ) * coprimeIndicator r K

noncomputable def A (K R : ℕ) : ℝ :=
  ∑ r ∈ Icc 1 R, maskedCoefficient r K

noncomputable def W (K R : ℕ) : ℝ :=
  ∑ r ∈ Icc 1 R, maskedCoefficient r K * Real.log ((r : ℝ) / (R : ℝ))

noncomputable def actualPrefix (K R q m : ℕ) : ℝ :=
  ∑ r ∈ Icc 1 R, maskedCoefficient r K *
    Real.log ((q : ℝ) * (r : ℝ) / (m : ℝ))

theorem cutoff_le_iff (q T H : ℕ) (hq : 0 < q) :
    T ≤ H / q ↔ q * T ≤ H := by
  simpa only [Nat.mul_comm] using (Nat.le_div_iff_mul_le hq : T ≤ H / q ↔ T * q ≤ H)

theorem mem_cutoff_iff (q r H : ℕ) (hq : 0 < q) :
    r ∈ Icc 1 (H / q) ↔ 1 ≤ r ∧ q * r ≤ H := by
  rw [Finset.mem_Icc, cutoff_le_iff q r H hq]

theorem log_endpoint_split (r R q m : ℕ)
    (hr : 0 < r) (hR : 0 < R) (hq : 0 < q) (hm : 0 < m) :
    Real.log ((q : ℝ) * (r : ℝ) / (m : ℝ)) =
      Real.log ((r : ℝ) / (R : ℝ)) +
        Real.log ((q : ℝ) * (R : ℝ) / (m : ℝ)) := by
  have hr0 : (r : ℝ) ≠ 0 := by exact_mod_cast hr.ne'
  have hR0 : (R : ℝ) ≠ 0 := by exact_mod_cast hR.ne'
  have hq0 : (q : ℝ) ≠ 0 := by exact_mod_cast hq.ne'
  have hm0 : (m : ℝ) ≠ 0 := by exact_mod_cast hm.ne'
  rw [Real.log_div (mul_ne_zero hq0 hr0) hm0, Real.log_mul hq0 hr0,
    Real.log_div hr0 hR0, Real.log_div (mul_ne_zero hq0 hR0) hm0,
    Real.log_mul hq0 hR0]
  ring

theorem actualPrefix_endpoint_decomposition (K R q m : ℕ)
    (hR : 0 < R) (hq : 0 < q) (hm : 0 < m) :
    actualPrefix K R q m =
      W K R + Real.log ((q : ℝ) * (R : ℝ) / (m : ℝ)) * A K R := by
  unfold actualPrefix W A
  calc
    (∑ r ∈ Icc 1 R, maskedCoefficient r K *
        Real.log ((q : ℝ) * (r : ℝ) / (m : ℝ))) =
        ∑ r ∈ Icc 1 R, maskedCoefficient r K *
          (Real.log ((r : ℝ) / (R : ℝ)) +
            Real.log ((q : ℝ) * (R : ℝ) / (m : ℝ))) := by
      apply Finset.sum_congr rfl
      intro r hr
      rw [log_endpoint_split r R q m
        (Nat.lt_of_lt_of_le Nat.zero_lt_one (Finset.mem_Icc.mp hr).1) hR hq hm]
    _ = _ := by
      simp only [mul_add, Finset.sum_add_distrib, ← Finset.sum_mul]
      rw [mul_comm (∑ r ∈ Icc 1 R, maskedCoefficient r K)]

theorem finite_prefix_difference (f : ℕ → ℝ) (T R : ℕ) (hTR : T ≤ R) :
    (∑ r ∈ Icc 1 R, f r) - (∑ r ∈ Icc 1 T, f r) =
      ∑ r ∈ Ioc T R, f r := by
  have hu : Icc 1 R = Icc 1 T ∪ Ioc T R := by
    ext r
    simp only [Finset.mem_Icc, Finset.mem_union, Finset.mem_Ioc]
    omega
  have hd : Disjoint (Icc 1 T) (Ioc T R) := by
    apply Finset.disjoint_left.mpr
    intro r hr ht
    have hrT := (Finset.mem_Icc.mp hr).2
    have hTr := (Finset.mem_Ioc.mp ht).1
    omega
  rw [hu, Finset.sum_union hd]
  ring

theorem A_prefix_difference (K T R : ℕ) (hTR : T ≤ R) :
    A K R - A K T = ∑ r ∈ Ioc T R, maskedCoefficient r K := by
  exact finite_prefix_difference (fun r => maskedCoefficient r K) T R hTR

theorem actualPrefix_difference (K T R q m : ℕ) (hTR : T ≤ R) :
    actualPrefix K R q m - actualPrefix K T q m =
      ∑ r ∈ Ioc T R, maskedCoefficient r K *
        Real.log ((q : ℝ) * (r : ℝ) / (m : ℝ)) := by
  exact finite_prefix_difference
    (fun r => maskedCoefficient r K * Real.log ((q : ℝ) * (r : ℝ) / (m : ℝ))) T R hTR

theorem endpoint_difference_decomposition (K T R q m : ℕ)
    (hT : 0 < T) (hR : 0 < R) (hq : 0 < q) (hm : 0 < m) :
    actualPrefix K R q m - actualPrefix K T q m =
      (W K R - W K T) +
        Real.log ((q : ℝ) * (R : ℝ) / (m : ℝ)) * A K R -
        Real.log ((q : ℝ) * (T : ℝ) / (m : ℝ)) * A K T := by
  rw [actualPrefix_endpoint_decomposition K R q m hR hq hm,
    actualPrefix_endpoint_decomposition K T q m hT hq hm]
  ring

theorem subtract_common_constant (x y c : ℝ) :
    (x + c) - (y + c) = x - y := by
  ring

#print axioms cutoff_le_iff
#print axioms mem_cutoff_iff
#print axioms log_endpoint_split
#print axioms actualPrefix_endpoint_decomposition
#print axioms finite_prefix_difference
#print axioms A_prefix_difference
#print axioms actualPrefix_difference
#print axioms endpoint_difference_decomposition
#print axioms subtract_common_constant

end GoldbachResearch.ConductorPrefix
