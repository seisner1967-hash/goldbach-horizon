import GoldbachArithmetic

/-! Literal interval completion for the actual divisor kernel.
The admission premise is finite and explicit; no analytical smallness,
prime-pair margin or centered-prefix sign is assumed in this module. -/
namespace GoldbachResearch.LiteralDivisorCompletion

open scoped BigOperators
open ActualArithmetic

noncomputable def divisorKernel (alpha Q m : ℕ) : ℝ :=
  ∑ k ∈ m.divisors,
    if k ≤ Q ∧ alpha * k < m then
      muReal k * Real.log ((k : ℝ) / (m : ℝ))
    else 0

private theorem full_quotient_convolution (m : ℕ) :
    (∑ k ∈ m.divisors, muReal k * Real.log (m / k : ℕ)) =
      ArithmeticFunction.vonMangoldt m := by
  have h := congrArg (fun f : ArithmeticFunction ℝ => f m)
    ArithmeticFunction.moebius_mul_log_eq_vonMangoldt
  change ((ArithmeticFunction.moebius : ArithmeticFunction ℝ) *
    ArithmeticFunction.log) m = ArithmeticFunction.vonMangoldt m at h
  rw [ArithmeticFunction.mul_apply] at h
  simp only [ArithmeticFunction.log_apply, ArithmeticFunction.intCoe_apply] at h
  rw [Nat.sum_divisorsAntidiagonal
    (fun i j => (ArithmeticFunction.moebius i : ℝ) * Real.log (j : ℝ))] at h
  simpa only [muReal] using h

/-- Full real quotient-log sum, before any cutoff or analytic estimate. -/
theorem full_literal_divisor_sum (m : ℕ) (hm : m ≠ 0) :
    (∑ k ∈ m.divisors, muReal k * Real.log ((k : ℝ) / (m : ℝ))) =
      -ArithmeticFunction.vonMangoldt m := by
  have hterm : ∀ k ∈ m.divisors,
      Real.log ((k : ℝ) / (m : ℝ)) = -Real.log (m / k : ℕ) := by
    intro k hk
    have hdiv : k ∣ m := (Nat.mem_divisors.mp hk).1
    have hkn : k ≠ 0 := by
      intro hz
      subst k
      exact hm (by simpa using hdiv)
    have hkr : (k : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr hkn
    have hmr : (m : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr hm
    rw [Nat.cast_div hdiv hkr, Real.log_div hkr hmr,
      Real.log_div hmr hkr]
    ring
  calc
    _ = ∑ k ∈ m.divisors, -(muReal k * Real.log (m / k : ℕ)) := by
      apply Finset.sum_congr rfl
      intro k hk
      rw [hterm k hk]
      ring
    _ = -(∑ k ∈ m.divisors, muReal k * Real.log (m / k : ℕ)) := by
      rw [Finset.sum_neg_distrib]
    _ = _ := by rw [full_quotient_convolution]

/-- The original strict face and modulus cap include every proper divisor. -/
theorem literal_completion_of_proper_admission (alpha Q m : ℕ) (hm : m ≠ 0)
    (hadmit : ∀ k ∈ m.divisors, k ≠ m → k ≤ Q ∧ alpha * k < m) :
    divisorKernel alpha Q m = -ArithmeticFunction.vonMangoldt m := by
  rw [← full_literal_divisor_sum m hm]
  unfold divisorKernel
  apply Finset.sum_congr rfl
  intro k hk
  by_cases hkm : k = m
  · subst k
    have hmr : (m : ℝ) ≠ 0 := Nat.cast_ne_zero.mpr hm
    simp [div_self hmr]
  · simp only [if_pos (hadmit k hk hkm)]

/-- Proper cofactors above alpha imply the original floor cap and strict face. -/
theorem actual_floor_cap_admits_proper_divisors (N alpha m : ℕ)
    (hm : m ≠ 0) (hN : m ≤ N - 1) (ha : 0 < alpha)
    (hcofactor : ∀ c ∈ m.divisors, c ≠ 1 → alpha < c) :
    ∀ k ∈ m.divisors, k ≠ m →
      k ≤ (N - 1) / alpha ∧ alpha * k < m := by
  intro k hk hkm
  have hdiv : k ∣ m := (Nat.mem_divisors.mp hk).1
  have hk0 : k ≠ 0 := by
    intro hz
    subst k
    exact hm (by simpa using hdiv)
  have hkpos : 0 < k := Nat.pos_of_ne_zero hk0
  have hcdiv : m / k ∣ m := Nat.div_dvd_of_dvd hdiv
  have hcmem : m / k ∈ m.divisors := Nat.mem_divisors.mpr ⟨hcdiv, hm⟩
  have hceq : m / k * k = m := Nat.div_mul_cancel hdiv
  have hcne : m / k ≠ 1 := by
    intro hc
    rw [hc, one_mul] at hceq
    exact hkm hceq
  have hface : alpha * k < m := by
    have hlt := Nat.mul_lt_mul_of_pos_right (hcofactor (m / k) hcmem hcne) hkpos
    simpa only [hceq] using hlt
  refine ⟨?_, hface⟩
  apply (Nat.le_div_iff_mul_le ha).mpr
  nlinarith

/-- Literal completed kernel at the original Q=floor((N-1)/alpha). -/
theorem literal_completion_at_original_floor (N alpha m : ℕ)
    (hm : m ≠ 0) (hN : m ≤ N - 1) (ha : 0 < alpha)
    (hcofactor : ∀ c ∈ m.divisors, c ≠ 1 → alpha < c) :
    divisorKernel alpha ((N - 1) / alpha) m =
      -ArithmeticFunction.vonMangoldt m := by
  exact literal_completion_of_proper_admission alpha ((N - 1) / alpha) m hm
    (actual_floor_cap_admits_proper_divisors N alpha m hm hN ha hcofactor)

/-- The literal prime-factor roughness condition controls every proper cofactor. -/
theorem rough_prime_factors_control_cofactors (alpha m : ℕ) (hm : m ≠ 0)
    (hrough : ∀ p : ℕ, Nat.Prime p → p ∣ m → alpha < p) :
    ∀ c ∈ m.divisors, c ≠ 1 → alpha < c := by
  intro c hc hcne
  have hcdiv : c ∣ m := (Nat.mem_divisors.mp hc).1
  have hc0 : c ≠ 0 := by
    intro hz
    subst c
    exact hm (by simpa using hcdiv)
  have hcpos : 0 < c := Nat.pos_of_ne_zero hc0
  have hp : Nat.Prime c.minFac := Nat.minFac_prime hcne
  have hpdiv : c.minFac ∣ c := Nat.minFac_dvd c
  have hpc : c.minFac ≤ c := Nat.le_of_dvd hcpos hpdiv
  exact lt_of_lt_of_le (hrough c.minFac hp (hpdiv.trans hcdiv)) hpc

/-- Actual alpha-roughness completes the strict divisor kernel at the original cap. -/
theorem rough_literal_completion_at_original_floor (N alpha m : ℕ)
    (hm : m ≠ 0) (hN : m ≤ N - 1) (ha : 0 < alpha)
    (hrough : ∀ p : ℕ, Nat.Prime p → p ∣ m → alpha < p) :
    divisorKernel alpha ((N - 1) / alpha) m =
      -ArithmeticFunction.vonMangoldt m := by
  exact literal_completion_at_original_floor N alpha m hm hN ha
    (rough_prime_factors_control_cofactors alpha m hm hrough)

#print axioms full_literal_divisor_sum
#print axioms literal_completion_of_proper_admission
#print axioms actual_floor_cap_admits_proper_divisors
#print axioms literal_completion_at_original_floor
#print axioms rough_prime_factors_control_cofactors
#print axioms rough_literal_completion_at_original_floor

end GoldbachResearch.LiteralDivisorCompletion
