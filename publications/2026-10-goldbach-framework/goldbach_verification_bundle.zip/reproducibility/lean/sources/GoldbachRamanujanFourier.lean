import GoldbachFourier
import GoldbachCoefficientEnergy
import Mathlib.Algebra.GroupWithZero.Units.Equiv
import Mathlib.Data.Nat.ChineseRemainder

/-!
# Actual additive-character realization of the prime-local proxy

The first bridge identifies the literal divisor factor with the sum over
nonzero additive frequencies on `ZMod p`. All character orthogonality inputs
are proved from Mathlib's primitive standard additive character.
-/

namespace GoldbachResearch.RamanujanFourier

open scoped BigOperators
open Finset AddChar Patterns CoefficientEnergy

variable {p : ℕ} [NeZero p]

noncomputable def nonzeroCharacterSum (p : ℕ) [NeZero p] (x : ZMod p) : ℂ :=
  ∑ a ∈ (Finset.univ : Finset (ZMod p)).erase 0, ZMod.stdAddChar (a * x)

theorem full_character_sum (x : ZMod p) :
    ∑ a : ZMod p, ZMod.stdAddChar (a * x) = if x = 0 then (p : ℂ) else 0 := by
  simpa only [ZMod.card, Nat.cast_ite, Nat.cast_zero] using
    AddChar.sum_mulShift x (ZMod.isPrimitive_stdAddChar p)

theorem nonzeroCharacterSum_values (x : ZMod p) :
    nonzeroCharacterSum p x = if x = 0 then (p : ℂ) - 1 else -1 := by
  have he := Finset.sum_erase_add (Finset.univ : Finset (ZMod p))
    (fun a => ZMod.stdAddChar (a * x)) (Finset.mem_univ 0)
  simp only [zero_mul, AddChar.map_zero_eq_one] at he
  change nonzeroCharacterSum p x + 1 = _ at he
  rw [full_character_sum] at he
  split_ifs at he ⊢ <;> linear_combination he

/-- For a prime modulus, the sum is the classical Ramanujan sum, since
every nonzero residue is a unit. The equality below is valid for every
positive modulus with the explicitly stated nonzero-frequency convention. -/
theorem primeRamanujan_eq_character_sum (n : ℕ) :
    (primeRamanujan p n : ℂ) = nonzeroCharacterSum p (n : ZMod p) := by
  rw [nonzeroCharacterSum_values]
  simp only [ZMod.natCast_zmod_eq_zero_iff_dvd, primeRamanujan]
  split_ifs <;> push_cast <;> rfl

noncomputable def primeLocal (p : ℕ) [NeZero p] (x : ZMod p) : ℝ :=
  primeRamanujan p x.val

theorem primeLocal_values (x : ZMod p) :
    primeLocal p x = if x = 0 then (p : ℝ) - 1 else -1 := by
  simp only [primeLocal, primeRamanujan, ← ZMod.natCast_zmod_eq_zero_iff_dvd,
    ZMod.natCast_zmod_val]

theorem primeLocal_eq_character_sum (x : ZMod p) :
    (primeLocal p x : ℂ) = nonzeroCharacterSum p x := by
  rw [primeLocal_values, nonzeroCharacterSum_values]
  split_ifs <;> push_cast <;> rfl

theorem primeLocal_dft (k : ZMod p) :
    ZMod.dft (fun x => (primeLocal p x : ℂ)) k =
      if k = 0 then 0 else (p : ℂ) := by
  have hx (x : ZMod p) : (primeLocal p x : ℂ) =
      (if x = 0 then (p : ℂ) else 0) - 1 := by
    rw [primeLocal_values]
    split_ifs <;> push_cast <;> ring
  simp only [ZMod.dft_apply, smul_eq_mul, hx, mul_sub, Finset.sum_sub_distrib]
  have hd : (∑ x : ZMod p, ZMod.stdAddChar (-(x * k)) *
      (if x = 0 then (p : ℂ) else 0)) = p := by
    simp [mul_ite]
  rw [hd]
  have hc : (∑ x : ZMod p, ZMod.stdAddChar (-(x * k)) * 1) =
      if k = 0 then (p : ℂ) else 0 := by
    simpa only [mul_one, ← mul_neg, neg_eq_zero] using full_character_sum (-k)
  rw [hc]
  split_ifs <;> ring

/-- At a prime modulus the nonzero frequencies are exactly the unit
frequencies of the usual Ramanujan sum. -/
theorem primeRamanujan_eq_unit_character_sum (hp : p.Prime) (n : ℕ) :
    (primeRamanujan p n : ℂ) =
      ∑ a : (ZMod p)ˣ, ZMod.stdAddChar (a.val * (n : ZMod p)) := by
  letI : Fact p.Prime := ⟨hp⟩
  rw [primeRamanujan_eq_character_sum]
  symm
  unfold nonzeroCharacterSum
  refine Finset.sum_bij (fun a _ => a.val) ?_ ?_ ?_ ?_
  · intro a ha
    exact Finset.mem_erase.mpr ⟨a.ne_zero, Finset.mem_univ _⟩
  · intro a ha b hb hab
    exact Units.ext hab
  · intro a ha
    refine ⟨Units.mk0 a (Finset.mem_erase.mp ha).1, Finset.mem_univ _, rfl⟩
  · intro a ha
    rfl

theorem primeLocal_mean_zero : ∑ x : ZMod p, primeLocal p x = 0 := by
  have h := primeLocal_dft (p := p) 0
  rw [ZMod.dft_apply_zero] at h
  simpa only [ite_true, ← Complex.ofReal_sum, Complex.ofReal_eq_zero] using h

theorem primeLocal_sum_squares :
    ∑ x : ZMod p, (primeLocal p x) ^ 2 = (p : ℝ) * ((p : ℝ) - 1) := by
  have hx (x : ZMod p) : (primeLocal p x) ^ 2 =
      (p : ℝ) - 1 + ((p : ℝ) - 2) * primeLocal p x := by
    exact primeRamanujan_square p x.val
  simp only [hx, Finset.sum_add_distrib, ← Finset.mul_sum, primeLocal_mean_zero,
    mul_zero, add_zero, Finset.sum_const, Finset.card_univ, ZMod.card, nsmul_eq_mul]

noncomputable def residueFactor (p : ℕ) (x : ZMod p) : ℝ :=
  if x = 0 then (p : ℝ) - 1 else -1

theorem residueFactor_eq_primeLocal (x : ZMod p) :
    residueFactor p x = primeLocal p x := (primeLocal_values x).symm

omit [NeZero p] in
theorem residueFactor_natCast (n : ℕ) :
    residueFactor p (n : ZMod p) = primeRamanujan p n := by
  simp only [residueFactor, primeRamanujan, ZMod.natCast_zmod_eq_zero_iff_dvd]

abbrev ResidueTorus (U : Finset ℕ) := (p : U) → ZMod (p : ℕ)

noncomputable def torusBasis (U g : Finset ℕ) (x : ResidueTorus U) : ℝ :=
  ∏ p : U, if (p : ℕ) ∈ g then residueFactor p (x p) else 1

noncomputable def periodSize (U : Finset ℕ) : ℝ := ∏ p ∈ U, (p : ℝ)

theorem periodSize_eq_natCast (U : Finset ℕ) :
    periodSize U = ((∏ p ∈ U, p : ℕ) : ℝ) := by
  simp only [periodSize, Nat.cast_prod]

noncomputable def trueShellWeight (g : Finset ℕ) : ℝ := ∏ p ∈ g, ((p : ℝ) - 1)

section Torus

variable (U : Finset ℕ) [∀ p : U, NeZero (p : ℕ)]

theorem torusBasis_inner (g h : Finset ℕ) (hg : g ⊆ U) (hh : h ⊆ U) :
    ∑ x : ResidueTorus U, torusBasis U g x * torusBasis U h x =
      if g = h then periodSize U * trueShellWeight g else 0 := by
  classical
  simp only [torusBasis, ← Finset.prod_mul_distrib]
  rw [← Fintype.prod_sum (fun (p : U) (x : ZMod (p : ℕ)) =>
    (if (p : ℕ) ∈ g then residueFactor p x else 1) *
    (if (p : ℕ) ∈ h then residueFactor p x else 1))]
  by_cases heq : g = h
  · subst h
    simp only [ite_true]
    have he (p : U) :
        (∑ x : ZMod (p : ℕ), (if (p : ℕ) ∈ g then residueFactor p x else 1) *
          (if (p : ℕ) ∈ g then residueFactor p x else 1)) =
          (p : ℝ) * (if (p : ℕ) ∈ g then (p : ℝ) - 1 else 1) := by
      by_cases hp : (p : ℕ) ∈ g
      · simp only [hp, ite_true, residueFactor_eq_primeLocal, ← pow_two]
        exact primeLocal_sum_squares
      · simp [hp, ZMod.card]
    simp only [he, Finset.prod_mul_distrib]
    rw [Finset.prod_coe_sort U (fun p => (p : ℝ)),
      Finset.prod_coe_sort U (fun p => if p ∈ g then (p : ℝ) - 1 else 1),
      Finset.prod_ite_mem, Finset.inter_eq_right.mpr hg]
    rfl
  · simp only [heq, ite_false]
    obtain ⟨p, hp⟩ : ∃ p, ¬(p ∈ g ↔ p ∈ h) := by
      by_contra hn
      apply heq
      apply Finset.ext
      intro p
      exact not_not.mp ((not_exists.mp hn) p)
    have hpU : p ∈ U := by
      by_cases hpg : p ∈ g
      · exact hg hpg
      · have hph : p ∈ h := by tauto
        exact hh hph
    letI : NeZero p := inferInstanceAs (NeZero ((⟨p, hpU⟩ : U) : ℕ))
    apply Finset.prod_eq_zero (Finset.mem_univ (⟨p, hpU⟩ : U))
    by_cases hpg : p ∈ g
    · have hph : p ∉ h := by tauto
      simp only [hpg, hph, ite_true, ite_false, mul_one, residueFactor_eq_primeLocal]
      exact primeLocal_mean_zero
    · have hph : p ∈ h := by tauto
      simp only [hpg, hph, ite_true, ite_false, one_mul, residueFactor_eq_primeLocal]
      exact primeLocal_mean_zero

theorem torus_combination_energy (T : Finset (Finset ℕ))
    (hT : ∀ g ∈ T, g ⊆ U) (c : Finset ℕ → ℝ) :
    (∑ x : ResidueTorus U, (∑ g ∈ T, c g * torusBasis U g x) ^ 2) =
      periodSize U * ∑ g ∈ T, trueShellWeight g * (c g) ^ 2 := by
  classical
  calc
    _ = ∑ x : ResidueTorus U, ∑ g ∈ T, ∑ h ∈ T,
        (c g * c h) * (torusBasis U g x * torusBasis U h x) := by
      apply Finset.sum_congr rfl
      intro x hx
      rw [pow_two, Finset.sum_mul_sum]
      apply Finset.sum_congr rfl
      intro g hg
      apply Finset.sum_congr rfl
      intro h hh
      ring
    _ = ∑ g ∈ T, ∑ h ∈ T, (c g * c h) *
        ∑ x : ResidueTorus U, torusBasis U g x * torusBasis U h x := by
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro g hg
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro h hh
      rw [Finset.mul_sum]
    _ = _ := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro g hg
      have he : (∑ h ∈ T, (c g * c h) *
          ∑ x : ResidueTorus U, torusBasis U g x * torusBasis U h x) =
          ∑ h ∈ T, if h = g then periodSize U *
            (trueShellWeight g * (c g) ^ 2) else 0 := by
        apply Finset.sum_congr rfl
        intro h hh
        rw [torusBasis_inner U g h (hT g hg) (hT h hh)]
        by_cases heq : g = h
        · subst h
          simp only [ite_true]
          ring
        · simp [heq, Ne.symm heq]
      rw [he]
      simp [hg]

theorem torusBasis_sum (g : Finset ℕ) (hg : g ⊆ U) :
    ∑ x : ResidueTorus U, torusBasis U g x =
      if g = ∅ then periodSize U else 0 := by
  have h := torusBasis_inner U g ∅ hg (Finset.empty_subset U)
  by_cases he : g = ∅
  · subst g
    simpa [torusBasis, trueShellWeight] using h
  · simpa [he, torusBasis, trueShellWeight] using h

omit [∀ p : U, NeZero (p : ℕ)] in
theorem torusBasis_natural (g : Finset ℕ) (hg : g ⊆ U) (n : ℕ) :
    torusBasis U g (fun p => (n : ZMod (p : ℕ))) =
      ∏ p ∈ g, primeRamanujan p n := by
  classical
  unfold torusBasis
  simp only [residueFactor_natCast]
  rw [Finset.prod_coe_sort U (fun p => if p ∈ g then primeRamanujan p n else 1),
    Finset.prod_ite_mem, Finset.inter_eq_right.mpr hg]

noncomputable def torusSquare (S : Finset ℕ) (x : ResidueTorus U) : ℝ :=
  ∑ g ∈ U.powerset, squareCoefficient U S g * torusBasis U g x

noncomputable def torusCenteredSquare (S : Finset ℕ) (x : ResidueTorus U) : ℝ :=
  ∑ g ∈ U.powerset.filter (fun g => g ≠ ∅),
    squareCoefficient U S g * torusBasis U g x

omit [∀ p : U, NeZero (p : ℕ)] in
theorem torusCenteredSquare_eq_sub (S : Finset ℕ) (x : ResidueTorus U) :
    torusCenteredSquare U S x = torusSquare U S x - squareCoefficient U S ∅ := by
  classical
  have he : U.powerset.filter (fun g => g ≠ ∅) = U.powerset.erase ∅ := by
    ext g
    simp [and_comm]
  unfold torusCenteredSquare torusSquare
  rw [he, Finset.sum_erase_eq_sub (Finset.mem_powerset.mpr (Finset.empty_subset U))]
  simp [torusBasis]

theorem torusSquare_sum (S : Finset ℕ) :
    ∑ x : ResidueTorus U, torusSquare U S x =
      periodSize U * squareCoefficient U S ∅ := by
  classical
  unfold torusSquare
  rw [Finset.sum_comm]
  have he : (∑ g ∈ U.powerset, ∑ x : ResidueTorus U,
      squareCoefficient U S g * torusBasis U g x) =
      ∑ g ∈ U.powerset, if g = ∅ then periodSize U * squareCoefficient U S ∅ else 0 := by
    apply Finset.sum_congr rfl
    intro g hg
    rw [← Finset.mul_sum, torusBasis_sum U g (Finset.mem_powerset.mp hg)]
    by_cases heq : g = ∅
    · subst g
      simp [mul_comm]
    · simp [heq]
  rw [he]
  simp

omit [∀ p : U, NeZero (p : ℕ)] in
theorem torusSquare_natural (S : Finset ℕ) (n : ℕ) :
    torusSquare U S (fun p => (n : ZMod (p : ℕ))) = divisorProxy U S n ^ 2 := by
  unfold torusSquare
  rw [divisorProxy_square_expansion]
  apply Finset.sum_congr rfl
  intro g hg
  rw [torusBasis_natural U g (Finset.mem_powerset.mp hg)]

omit [∀ p : U, NeZero (p : ℕ)] in
theorem torusCenteredSquare_natural (S : Finset ℕ) (n : ℕ) :
    torusCenteredSquare U S (fun p => (n : ZMod (p : ℕ))) =
      divisorProxy U S n ^ 2 - squareCoefficient U S ∅ := by
  rw [torusCenteredSquare_eq_sub, torusSquare_natural]

theorem periodSize_pos : 0 < periodSize U := by
  unfold periodSize
  apply Finset.prod_pos
  intro p hp
  letI : NeZero p := inferInstanceAs (NeZero ((⟨p, hp⟩ : U) : ℕ))
  exact_mod_cast NeZero.pos p

theorem trueShellWeight_le (g : Finset ℕ) (hg : g ⊆ U) :
    trueShellWeight g ≤ subsetPrimeProduct g := by
  unfold trueShellWeight subsetPrimeProduct
  apply Finset.prod_le_prod
  · intro p hp
    letI : NeZero p := inferInstanceAs (NeZero ((⟨p, hg hp⟩ : U) : ℕ))
    have hp1 : (1 : ℝ) ≤ p := by
      exact_mod_cast (Nat.one_le_iff_ne_zero.mpr (NeZero.ne p))
    linarith
  · intro p hp
    linarith

theorem torusSquare_energy (S : Finset ℕ) :
    (∑ x : ResidueTorus U, (torusSquare U S x) ^ 2) =
      periodSize U * ∑ g ∈ U.powerset,
        trueShellWeight g * (squareCoefficient U S g) ^ 2 := by
  exact torus_combination_energy U U.powerset
    (fun g hg => Finset.mem_powerset.mp hg) (squareCoefficient U S)

theorem torusCenteredSquare_energy (S : Finset ℕ) :
    (∑ x : ResidueTorus U, (torusCenteredSquare U S x) ^ 2) =
      periodSize U * ∑ g ∈ U.powerset.filter (fun g => g ≠ ∅),
        trueShellWeight g * (squareCoefficient U S g) ^ 2 := by
  exact torus_combination_energy U (U.powerset.filter (fun g => g ≠ ∅))
    (fun g hg => Finset.mem_powerset.mp (Finset.mem_filter.mp hg).1)
    (squareCoefficient U S)

theorem torusSquare_energy_le_coefficientEnergy (S : Finset ℕ) :
    (∑ x : ResidueTorus U, (torusSquare U S x) ^ 2) ≤
      periodSize U * coefficientEnergy U S := by
  rw [torusSquare_energy]
  apply mul_le_mul_of_nonneg_left _ (le_of_lt (periodSize_pos U))
  unfold coefficientEnergy
  apply Finset.sum_le_sum
  intro g hg
  exact mul_le_mul_of_nonneg_right (trueShellWeight_le U g (Finset.mem_powerset.mp hg))
    (sq_nonneg _)

theorem torusCenteredSquare_variance_le_coefficientEnergy (S : Finset ℕ) :
    (∑ x : ResidueTorus U, (torusCenteredSquare U S x) ^ 2) / periodSize U ≤
      centeredCoefficientEnergy U S := by
  apply (div_le_iff₀ (periodSize_pos U)).mpr
  rw [torusCenteredSquare_energy, mul_comm (centeredCoefficientEnergy U S)]
  apply mul_le_mul_of_nonneg_left _ (le_of_lt (periodSize_pos U))
  unfold centeredCoefficientEnergy
  apply Finset.sum_le_sum
  intro g hg
  exact mul_le_mul_of_nonneg_right
    (trueShellWeight_le U g (Finset.mem_powerset.mp (Finset.mem_filter.mp hg).1))
    (sq_nonneg _)

noncomputable def naturalResidues (n : Fin (∏ p ∈ U, p)) : ResidueTorus U :=
  fun p => (n.val : ZMod (p : ℕ))

theorem naturalResidues_surjective (hU : ∀ p ∈ U, p.Prime) :
    Function.Surjective (naturalResidues U) := by
  classical
  intro x
  let a : U → ℕ := fun p => (x p).val
  let s : U → ℕ := fun p => (p : ℕ)
  have hs : ∀ p ∈ (Finset.univ : Finset U), s p ≠ 0 := by
    intro p hp
    exact NeZero.ne (p : ℕ)
  have hpair : Set.Pairwise (Finset.univ : Finset U) (Nat.Coprime on s) := by
    intro p hp q hq hpq
    apply (Nat.coprime_primes (hU p p.property) (hU q q.property)).mpr
    intro hpqval
    exact hpq (Subtype.ext hpqval)
  let z := Nat.chineseRemainderOfFinset a s Finset.univ hs hpair
  have hzlt : z.val < ∏ p ∈ U, p := by
    have h := Nat.chineseRemainderOfFinset_lt_prod a s hs hpair
    change z.val < ∏ p : U, (p : ℕ) at h
    rw [Finset.prod_coe_sort U (fun p => p)] at h
    exact h
  refine ⟨⟨z.val, hzlt⟩, ?_⟩
  funext p
  apply ZMod.val_injective
  change ((z.val : ℕ) : ZMod (p : ℕ)).val = (x p).val
  rw [ZMod.val_natCast]
  have he := z.property p (Finset.mem_univ p)
  change z.val % (p : ℕ) = (x p).val % (p : ℕ) at he
  exact he.trans (Nat.mod_eq_of_lt (ZMod.val_lt (x p)))

theorem naturalResidues_bijective (hU : ∀ p ∈ U, p.Prime) :
    Function.Bijective (naturalResidues U) := by
  apply (Fintype.bijective_iff_surjective_and_card (naturalResidues U)).mpr
  refine ⟨naturalResidues_surjective U hU, ?_⟩
  simp only [Fintype.card_fin, ResidueTorus, Fintype.card_pi, ZMod.card]
  exact (Finset.prod_coe_sort U (fun p => p)).symm

theorem natural_period_sum_eq_torus (hU : ∀ p ∈ U, p.Prime)
    (f : ResidueTorus U → ℝ) :
    (∑ n : Fin (∏ p ∈ U, p), f (naturalResidues U n)) =
      ∑ x : ResidueTorus U, f x := by
  exact Fintype.sum_bijective (naturalResidues U) (naturalResidues_bijective U hU)
    _ _ (fun n => rfl)

end Torus

/-- The constant channel is the literal mean of the squared divisor proxy
over a complete period. Pairwise coprimality is supplied by prime support. -/
theorem complete_period_mean (U S : Finset ℕ) (hU : ∀ p ∈ U, p.Prime) :
    (∑ n : Fin (∏ p ∈ U, p), divisorProxy U S n.val ^ 2) / periodSize U =
      squareCoefficient U S ∅ := by
  letI : ∀ p : U, NeZero (p : ℕ) := fun p => ⟨(hU p p.property).ne_zero⟩
  have he : (∑ n : Fin (∏ p ∈ U, p), divisorProxy U S n.val ^ 2) =
      ∑ x : ResidueTorus U, torusSquare U S x := by
    rw [← natural_period_sum_eq_torus U hU (torusSquare U S)]
    apply Finset.sum_congr rfl
    intro n hn
    exact (torusSquare_natural U S n.val).symm
  rw [he, torusSquare_sum]
  exact mul_div_cancel_left₀ _ (ne_of_gt (periodSize_pos U))

/-- Exact Parseval for the actual arithmetic proxy on a complete natural
period. The exact shell weight is `∏(p-1)`, distinct from the cap `∏p`. -/
theorem complete_period_variance_eq (U S : Finset ℕ) (hU : ∀ p ∈ U, p.Prime) :
    (∑ n : Fin (∏ p ∈ U, p),
      (divisorProxy U S n.val ^ 2 - squareCoefficient U S ∅) ^ 2) / periodSize U =
      ∑ g ∈ U.powerset.filter (fun g => g ≠ ∅),
        trueShellWeight g * (squareCoefficient U S g) ^ 2 := by
  letI : ∀ p : U, NeZero (p : ℕ) := fun p => ⟨(hU p p.property).ne_zero⟩
  have he : (∑ n : Fin (∏ p ∈ U, p),
      (divisorProxy U S n.val ^ 2 - squareCoefficient U S ∅) ^ 2) =
      ∑ x : ResidueTorus U, (torusCenteredSquare U S x) ^ 2 := by
    rw [← natural_period_sum_eq_torus U hU (fun x => (torusCenteredSquare U S x) ^ 2)]
    apply Finset.sum_congr rfl
    intro n hn
    exact congrArg (fun r : ℝ => r ^ 2) (torusCenteredSquare_natural U S n.val).symm
  rw [he, torusCenteredSquare_energy]
  exact mul_div_cancel_left₀ _ (ne_of_gt (periodSize_pos U))

/-- The certified quartic coefficient cap controls literal period variance;
the Fourier bridge is proved and is not a premise of this theorem. -/
theorem complete_period_variance_le (U S : Finset ℕ) (hU : ∀ p ∈ U, p.Prime) :
    (∑ n : Fin (∏ p ∈ U, p),
      (divisorProxy U S n.val ^ 2 - squareCoefficient U S ∅) ^ 2) / periodSize U ≤
      centeredCoefficientEnergy U S := by
  letI : ∀ p : U, NeZero (p : ℕ) := fun p => ⟨(hU p p.property).ne_zero⟩
  rw [complete_period_variance_eq U S hU]
  unfold centeredCoefficientEnergy
  apply Finset.sum_le_sum
  intro g hg
  exact mul_le_mul_of_nonneg_right
    (trueShellWeight_le U g (Finset.mem_powerset.mp (Finset.mem_filter.mp hg).1))
    (sq_nonneg _)

theorem sum_zmod_val_eq_fin (N : ℕ) [NeZero N] (f : ℕ → ℝ) :
    (∑ x : ZMod N, f x.val) = ∑ n : Fin N, f n.val := by
  cases N with
  | zero => exact (NeZero.ne 0 rfl).elim
  | succ N => rfl

/-- Direct interface to the `ZMod` DFT and smoothing API. -/
theorem complete_zmod_period_variance_le (U S : Finset ℕ)
    [NeZero (∏ p ∈ U, p)] (hU : ∀ p ∈ U, p.Prime) :
    (∑ x : ZMod (∏ p ∈ U, p),
      (divisorProxy U S x.val ^ 2 - squareCoefficient U S ∅) ^ 2) / periodSize U ≤
      centeredCoefficientEnergy U S := by
  rw [sum_zmod_val_eq_fin (∏ p ∈ U, p)
    (fun n => (divisorProxy U S n ^ 2 - squareCoefficient U S ∅) ^ 2)]
  exact complete_period_variance_le U S hU

theorem complete_zmod_period_mean (U S : Finset ℕ)
    [NeZero (∏ p ∈ U, p)] (hU : ∀ p ∈ U, p.Prime) :
    (∑ x : ZMod (∏ p ∈ U, p), divisorProxy U S x.val ^ 2) / periodSize U =
      squareCoefficient U S ∅ := by
  rw [sum_zmod_val_eq_fin (∏ p ∈ U, p) (fun n => divisorProxy U S n ^ 2)]
  exact complete_period_mean U S hU

theorem terminal_complete_period_variance_polynomial_bound (Q : ℕ) (hQ : 0 < Q) :
    (∑ n : Fin (∏ p ∈ Mass.oddPrimes Q, p),
      (divisorProxy (Mass.oddPrimes Q) (terminalSupport Q) n.val ^ 2 -
        squareCoefficient (Mass.oddPrimes Q) (terminalSupport Q) ∅) ^ 2) /
          periodSize (Mass.oddPrimes Q) ≤
      8 * Mass.oddEulerMass Q ^ 11 * min (Mass.oddHarmonic Q ^ 7)
        (goldbachSimplexPolynomial (2 * Real.log (Q : ℝ))) := by
  exact (complete_period_variance_le (Mass.oddPrimes Q) (terminalSupport Q)
    (fun p hp => (Mass.mem_oddPrimes.mp hp).2.1)).trans
      (terminal_centered_coefficient_energy_polynomial_bound Q hQ)

#print axioms primeRamanujan_eq_character_sum
#print axioms primeLocal_eq_character_sum
#print axioms primeLocal_dft
#print axioms primeRamanujan_eq_unit_character_sum
#print axioms primeLocal_mean_zero
#print axioms primeLocal_sum_squares
#print axioms torusBasis_inner
#print axioms torus_combination_energy
#print axioms torusSquare_energy
#print axioms torusCenteredSquare_energy
#print axioms torusCenteredSquare_eq_sub
#print axioms torusSquare_sum
#print axioms torusSquare_energy_le_coefficientEnergy
#print axioms torusCenteredSquare_variance_le_coefficientEnergy
#print axioms naturalResidues_bijective
#print axioms complete_period_mean
#print axioms complete_period_variance_eq
#print axioms complete_period_variance_le
#print axioms complete_zmod_period_variance_le
#print axioms complete_zmod_period_mean
#print axioms terminal_complete_period_variance_polynomial_bound

end GoldbachResearch.RamanujanFourier
