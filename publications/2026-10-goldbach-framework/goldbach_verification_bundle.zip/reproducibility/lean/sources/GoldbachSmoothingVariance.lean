import GoldbachFourier

/-!
# Concrete finite cyclic smoothing and its Fourier energy

All sums below are actual sums on `ZMod M`, rather than symbolic energy
variables. An indicator window of cardinality A gives its normalized
autocorrelation (a finite Fejer window). The full frequency energy is at
most M*A, without a Fourier-cap hypothesis.
-/

namespace GoldbachResearch.SmoothingVariance

open scoped BigOperators
open Finset AddChar

variable {M : ℕ} [NeZero M]

noncomputable def cyclicConvolution (b f : ZMod M → ℂ) (t : ZMod M) : ℂ :=
  ∑ x, b x * f (t - x)

theorem dft_cyclicConvolution (b f : ZMod M → ℂ) (k : ZMod M) :
    ZMod.dft (cyclicConvolution b f) k = ZMod.dft b k * ZMod.dft f k := by
  rw [ZMod.dft_apply]
  simp only [smul_eq_mul, cyclicConvolution, Finset.mul_sum]
  rw [Finset.sum_comm]
  have hs (x : ZMod M) :
      (∑ t, ZMod.stdAddChar (-(t * k)) * (b x * f (t - x))) =
        ZMod.stdAddChar (-(x * k)) * b x * ZMod.dft f k := by
    rw [ZMod.dft_apply]
    simp only [smul_eq_mul, Finset.mul_sum]
    symm
    refine Fintype.sum_equiv (Equiv.addLeft x) _ _ (fun y => ?_)
    change ZMod.stdAddChar (-(x * k)) * b x *
        (ZMod.stdAddChar (-(y * k)) * f y) =
      ZMod.stdAddChar (-((x + y) * k)) * (b x * f ((x + y) - x))
    rw [add_sub_cancel_left, add_mul, neg_add, AddChar.map_add_eq_mul]
    ring
  simp_rw [hs]
  rw [← Finset.sum_mul]
  rfl

theorem smoothing_parseval (b f : ZMod M → ℂ) :
    (M : ℝ) * ∑ t, Complex.normSq (cyclicConvolution b f t) =
      ∑ k, Complex.normSq (ZMod.dft b k) * Complex.normSq (ZMod.dft f k) := by
  rw [← GoldbachResearch.dft_parseval]
  apply Finset.sum_congr rfl
  intro k hk
  rw [dft_cyclicConvolution, Complex.normSq_mul]

noncomputable def periodMean (f : ZMod M → ℂ) : ℂ :=
  (∑ x, f x) / (M : ℂ)

noncomputable def removeMean (f : ZMod M → ℂ) (x : ZMod M) : ℂ :=
  f x - periodMean f

theorem dft_constant (c : ℂ) (k : ZMod M) :
    ZMod.dft (fun _ : ZMod M => c) k = if k = 0 then (M : ℂ) * c else 0 := by
  have hc : (∑ x : ZMod M, ZMod.stdAddChar (-(x * k))) =
      if k = 0 then (M : ℂ) else 0 := by
    simpa only [← mul_neg, neg_eq_zero, ZMod.card, Nat.cast_ite, Nat.cast_zero]
      using AddChar.sum_mulShift (-k) (ZMod.isPrimitive_stdAddChar M)
  simp only [ZMod.dft_apply, smul_eq_mul, ← Finset.sum_mul, hc]
  split_ifs <;> simp

theorem dft_removeMean (f : ZMod M → ℂ) (k : ZMod M) :
    ZMod.dft (removeMean f) k = if k = 0 then 0 else ZMod.dft f k := by
  have he : ZMod.dft (removeMean f) k =
      ZMod.dft f k - ZMod.dft (fun _ : ZMod M => periodMean f) k := by
    simp only [ZMod.dft_apply, smul_eq_mul, removeMean, mul_sub,
      Finset.sum_sub_distrib]
  rw [he, dft_constant]
  by_cases hk : k = 0
  · subst k
    simp only [ite_true, ZMod.dft_apply_zero, periodMean]
    have hm : (M : ℂ) ≠ 0 := NeZero.ne _
    field_simp
  · simp [hk]

noncomputable def periodSmoothingVariance (b f : ZMod M → ℂ) : ℝ :=
  (∑ t, Complex.normSq (cyclicConvolution b (removeMean f) t)) / (M : ℝ)

/-- The exact complete-period smoothing variance. Zero-frequency removal
is proved by subtracting the actual mean, not postulated as an energy cap. -/
theorem periodSmoothingVariance_eq_frequency_sum (b f : ZMod M → ℂ) :
    periodSmoothingVariance b f =
      (∑ k ∈ (Finset.univ : Finset (ZMod M)).erase 0,
        Complex.normSq (ZMod.dft b k) * Complex.normSq (ZMod.dft f k)) /
          (M : ℝ) ^ 2 := by
  have he : (∑ k, Complex.normSq (ZMod.dft b k) *
      Complex.normSq (ZMod.dft (removeMean f) k)) =
      ∑ k ∈ (Finset.univ : Finset (ZMod M)).erase 0,
        Complex.normSq (ZMod.dft b k) * Complex.normSq (ZMod.dft f k) := by
    have hz := Finset.sum_erase_add (Finset.univ : Finset (ZMod M))
      (fun k => Complex.normSq (ZMod.dft b k) *
        Complex.normSq (ZMod.dft (removeMean f) k)) (Finset.mem_univ 0)
    simp only [dft_removeMean, ite_true, Complex.normSq_zero, mul_zero, add_zero] at hz
    simp only [dft_removeMean]
    rw [← hz]
    apply Finset.sum_congr rfl
    intro k hk
    simp [dft_removeMean, (Finset.mem_erase.mp hk).1]
  have hp := smoothing_parseval b (removeMean f)
  rw [he] at hp
  unfold periodSmoothingVariance
  have hm : (M : ℝ) ≠ 0 := NeZero.ne _
  rw [← hp]
  field_simp
  ring

noncomputable def window (P : ZMod M → Prop) [DecidablePred P] (x : ZMod M) : ℝ :=
  if P x then 1 else 0

def windowCard (P : ZMod M → Prop) [DecidablePred P] : ℕ :=
  ((Finset.univ : Finset (ZMod M)).filter P).card

noncomputable def autocorrelation (P : ZMod M → Prop) [DecidablePred P]
    (t : ZMod M) : ℝ := ∑ x, window P x * window P (x - t)

noncomputable def fejerWindow (P : ZMod M → Prop) [DecidablePred P]
    (t : ZMod M) : ℝ := autocorrelation P t / (windowCard P : ℝ)

omit [NeZero M] in
theorem window_nonneg (P : ZMod M → Prop) [DecidablePred P] (x : ZMod M) :
    0 ≤ window P x := by
  unfold window
  split_ifs <;> norm_num

omit [NeZero M] in
theorem window_le_one (P : ZMod M → Prop) [DecidablePred P] (x : ZMod M) :
    window P x ≤ 1 := by
  unfold window
  split_ifs <;> norm_num

theorem sum_window (P : ZMod M → Prop) [DecidablePred P] :
    ∑ x, window P x = (windowCard P : ℝ) := by
  simp [window, windowCard, Finset.sum_boole]

theorem autocorrelation_nonneg (P : ZMod M → Prop) [DecidablePred P]
    (t : ZMod M) : 0 ≤ autocorrelation P t := by
  exact Finset.sum_nonneg (fun x hx => mul_nonneg (window_nonneg P x)
    (window_nonneg P (x - t)))

theorem autocorrelation_le_card (P : ZMod M → Prop) [DecidablePred P]
    (t : ZMod M) : autocorrelation P t ≤ (windowCard P : ℝ) := by
  rw [← sum_window P]
  apply Finset.sum_le_sum
  intro x hx
  simpa using mul_le_mul_of_nonneg_left (window_le_one P (x - t))
    (window_nonneg P x)

theorem sum_autocorrelation (P : ZMod M → Prop) [DecidablePred P] :
    ∑ t, autocorrelation P t = (windowCard P : ℝ) ^ 2 := by
  unfold autocorrelation
  rw [Finset.sum_comm]
  have he (x : ZMod M) : ∑ t, window P (x - t) = ∑ t, window P t := by
    exact Fintype.sum_equiv (Equiv.subLeft x) _ _ (fun t => rfl)
  simp only [← Finset.mul_sum, he, sum_window, ← Finset.sum_mul]
  ring

theorem autocorrelation_square_sum_le (P : ZMod M → Prop) [DecidablePred P] :
    ∑ t, (autocorrelation P t) ^ 2 ≤ (windowCard P : ℝ) ^ 3 := by
  calc
    ∑ t, (autocorrelation P t) ^ 2 ≤
        ∑ t, (windowCard P : ℝ) * autocorrelation P t := by
      apply Finset.sum_le_sum
      intro t ht
      have h0 := autocorrelation_nonneg P t
      have h1 := autocorrelation_le_card P t
      nlinarith
    _ = (windowCard P : ℝ) ^ 3 := by
      rw [← Finset.mul_sum, sum_autocorrelation]
      ring

theorem fejerWindow_dft (P : ZMod M → Prop) [DecidablePred P]
    (k : ZMod M) :
    ZMod.dft (fun t => (fejerWindow P t : ℂ)) k =
      (Complex.normSq (ZMod.dft (fun x => (window P x : ℂ)) k) : ℂ) /
        (windowCard P : ℂ) := by
  have ha : (fun t => (autocorrelation P t : ℂ)) =
      cyclicConvolution (fun x => (window P x : ℂ))
        (fun x => star (window P (-x) : ℂ)) := by
    funext t
    simp only [autocorrelation, cyclicConvolution, Complex.ofReal_sum,
      Complex.ofReal_mul, Complex.star_def, Complex.conj_ofReal]
    congr 1
    funext x
    congr 2
    ring
  have hf : (fun t => (fejerWindow P t : ℂ)) =
      fun t => (autocorrelation P t : ℂ) * (windowCard P : ℂ)⁻¹ := by
    funext t
    simp [fejerWindow, div_eq_mul_inv]
  rw [hf, ZMod.dft_mul_const]
  change ZMod.dft (fun t => (autocorrelation P t : ℂ)) k *
    (windowCard P : ℂ)⁻¹ = _
  rw [ha, dft_cyclicConvolution]
  have hstar := GoldbachResearch.dft_star_reflect (fun x => (window P x : ℂ)) k
  rw [hstar, Complex.star_def, Complex.mul_conj]
  rfl

theorem fejerWindow_frequency_energy_le (P : ZMod M → Prop) [DecidablePred P] :
    ∑ k, Complex.normSq (ZMod.dft (fun t => (fejerWindow P t : ℂ)) k) ≤
      (M : ℝ) * (windowCard P : ℝ) := by
  rw [GoldbachResearch.dft_parseval]
  simp only [Complex.normSq_ofReal, ← pow_two, fejerWindow, div_pow, ← Finset.sum_div]
  by_cases hA : windowCard P = 0
  · simp [hA]
  · have hA0 : 0 < (windowCard P : ℝ) := by
      exact_mod_cast Nat.pos_of_ne_zero hA
    have hc := autocorrelation_square_sum_le P
    have hs : (∑ t, (autocorrelation P t) ^ 2) / (windowCard P : ℝ) ^ 2 ≤
        (windowCard P : ℝ) := by
      apply (div_le_iff₀ (sq_pos_of_pos hA0)).mpr
      nlinarith
    exact mul_le_mul_of_nonneg_left hs (Nat.cast_nonneg M)

/-- A literal interval with no wraparound has precisely H points. -/
theorem initialInterval_card (H : ℕ) (hH : H ≤ M) :
    windowCard (fun x : ZMod M => x.val < H) = H := by
  have hc : ((Finset.univ : Finset (ZMod M)).filter (fun x => x.val < H)).card =
      (Finset.range H).card := by
    refine Finset.card_bij (fun x _ => x.val) ?_ ?_ ?_
    · intro x hx
      exact Finset.mem_range.mpr (Finset.mem_filter.mp hx).2
    · intro x hx y hy he
      exact ZMod.val_injective M he
    · intro n hn
      have hnM : n < M := (Finset.mem_range.mp hn).trans_le hH
      refine ⟨(n : ZMod M), ?_, ?_⟩
      · simp [ZMod.val_natCast, Nat.mod_eq_of_lt hnM, Finset.mem_range.mp hn]
      · exact ZMod.val_natCast_of_lt hnM
  simpa [windowCard] using hc

theorem initialInterval_fejer_frequency_energy_le (H : ℕ) (hH : H ≤ M) :
    ∑ k, Complex.normSq (ZMod.dft
      (fun t => (fejerWindow (fun x : ZMod M => x.val < H) t : ℂ)) k) ≤
        (M : ℝ) * (H : ℝ) := by
  simpa only [initialInterval_card H hH] using
    fejerWindow_frequency_energy_le (fun x : ZMod M => x.val < H)

#print axioms dft_cyclicConvolution
#print axioms smoothing_parseval
#print axioms dft_removeMean
#print axioms periodSmoothingVariance_eq_frequency_sum
#print axioms sum_autocorrelation
#print axioms autocorrelation_square_sum_le
#print axioms fejerWindow_dft
#print axioms fejerWindow_frequency_energy_le
#print axioms initialInterval_card
#print axioms initialInterval_fejer_frequency_energy_le

end GoldbachResearch.SmoothingVariance
