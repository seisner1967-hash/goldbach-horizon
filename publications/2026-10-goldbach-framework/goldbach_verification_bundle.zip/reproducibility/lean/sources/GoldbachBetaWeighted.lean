import GoldbachTypeIIVariance

/-!
# Positive beta weights inside the signed dispersion

Weighted Cauchy retains beta in the energy, including its exact zero
support. No comparison with the unweighted bound, and no cancellation
estimate, is asserted. The kernel and outer Moebius coefficients are signed.
-/

namespace GoldbachResearch.BetaWeighted

open scoped BigOperators
open Finset ActualArithmetic TypeIIAssembly TypeIIVariance

theorem weighted_sum_sq_le_mass_energy {I : Type*} (s : Finset I)
    (w f : I → ℝ) (hw : ∀ i ∈ s, 0 ≤ w i) :
    (∑ i ∈ s, w i * f i) ^ 2 ≤
      (∑ i ∈ s, w i) * ∑ i ∈ s, w i * f i ^ 2 := by
  have h := Finset.sum_mul_sq_le_sq_mul_sq s
    (fun i => Real.sqrt (w i)) (fun i => Real.sqrt (w i) * f i)
  have hleft : (∑ i ∈ s, Real.sqrt (w i) * (Real.sqrt (w i) * f i)) =
      ∑ i ∈ s, w i * f i := by
    apply Finset.sum_congr rfl
    intro i hi
    rw [← mul_assoc, Real.mul_self_sqrt (hw i hi)]
  have hmass : (∑ i ∈ s, Real.sqrt (w i) ^ 2) = ∑ i ∈ s, w i := by
    apply Finset.sum_congr rfl
    intro i hi
    exact Real.sq_sqrt (hw i hi)
  have henergy : (∑ i ∈ s, (Real.sqrt (w i) * f i) ^ 2) =
      ∑ i ∈ s, w i * f i ^ 2 := by
    apply Finset.sum_congr rfl
    intro i hi
    rw [mul_pow, Real.sq_sqrt (hw i hi)]
  rwa [hleft, hmass, henergy] at h

noncomputable def betaMass (N V : ℕ) : ℝ :=
  ∑ b ∈ activeSecond N V, Vaughan.beta V b

noncomputable def betaDispersion (N cutoff k U V : ℕ) : ℝ :=
  ∑ b ∈ activeSecond N V, Vaughan.beta V b *
    (∑ a ∈ activeFirst N U, muReal a *
      Bilinear.actualTypeIIKernel N cutoff k a b) ^ 2

noncomputable def betaModulusBudget (N cutoff Q U V : ℕ) : ℝ :=
  ∑ k ∈ actualModuli N Q, (k : ℝ) * muReal k ^ 2 *
    betaDispersion N cutoff k U V

theorem actual_typeII_sq_le_beta_mass_dispersion (N cutoff k U V : ℕ) :
    typeIIRow N cutoff k U V ^ 2 ≤
      betaMass N V * betaDispersion N cutoff k U V := by
  unfold typeIIRow
  rw [actual_signedRow_typeTwo_eq_active_bilinear,
    Bilinear.bilinearSum_eq_transpose]
  exact weighted_sum_sq_le_mass_energy (activeSecond N V) (Vaughan.beta V)
    (fun b => ∑ a ∈ activeFirst N U, muReal a *
      Bilinear.actualTypeIIKernel N cutoff k a b)
    (fun b _ => Vaughan.beta_nonneg V b)

/-- Four signed Moebius factors remain under the actual positive beta weight. -/
theorem betaDispersion_eq_four_signed_factors (N cutoff k U V : ℕ) :
    betaDispersion N cutoff k U V =
      ∑ b ∈ activeSecond N V, Vaughan.beta V b *
        ∑ a ∈ activeFirst N U, ∑ c ∈ activeFirst N U,
          muReal a * muReal c * muReal (N - a * b) * muReal (N - c * b) *
            actualRow N cutoff k (a * b) * actualRow N cutoff k (c * b) := by
  unfold betaDispersion
  simp_rw [pow_two, Finset.sum_mul_sum]
  apply Finset.sum_congr rfl
  intro b hb
  congr 1
  apply Finset.sum_congr rfl
  intro a ha
  apply Finset.sum_congr rfl
  intro c hc
  unfold Bilinear.actualTypeIIKernel
  ring

theorem typeII_variance_le_beta_modulus_budget (N cutoff Q U V : ℕ) :
    typeIIVariance N cutoff Q U V ≤
      betaMass N V * betaModulusBudget N cutoff Q U V := by
  unfold typeIIVariance betaModulusBudget
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro k hk
  have hh := mul_le_mul_of_nonneg_left
    (actual_typeII_sq_le_beta_mass_dispersion N cutoff k U V)
    (mul_nonneg (Nat.cast_nonneg k) (sq_nonneg (muReal k)))
  simpa only [mul_left_comm, mul_assoc] using hh

theorem actualVariance_le_beta_weighted_target (N cutoff Q U V : ℕ) :
    actualVariance N cutoff Q ≤
      2 * typeIVariance N cutoff Q U V +
        2 * betaMass N V * betaModulusBudget N cutoff Q U V := by
  have h1 := actualVariance_le_two_typeI_add_two_typeII N cutoff Q U V
  have h2 := typeII_variance_le_beta_modulus_budget N cutoff Q U V
  linarith

#print axioms weighted_sum_sq_le_mass_energy
#print axioms actual_typeII_sq_le_beta_mass_dispersion
#print axioms betaDispersion_eq_four_signed_factors
#print axioms typeII_variance_le_beta_modulus_budget
#print axioms actualVariance_le_beta_weighted_target

end GoldbachResearch.BetaWeighted
