import Mathlib.NumberTheory.VonMangoldt
import Mathlib.Tactic

/-!
The actual finite Mobius-log divisor fibre. Mathlib already proves the
unshifted logarithmic identity. This module derives its shifted version
and the signed coefficient with the original truncation rt <= alpha.
The full-fibre guard is explicit. No AP estimate or lcm classification
is asserted here.
-/

namespace GoldbachResearch.ActualMobiusLogFibre

open scoped BigOperators

noncomputable def signedDivisorCoefficient (r s alpha : ℕ) : ℝ :=
  (ArithmeticFunction.moebius s : ℝ) *
    (ArithmeticFunction.moebius r : ℝ) *
    ∑ t ∈ s.divisors,
      if r * t ≤ alpha then
        (ArithmeticFunction.moebius t : ℝ) * Real.log ((r * t : ℕ) : ℝ)
      else 0

private theorem moebius_divisor_sum_zero {s : ℕ} (hs : 1 < s) :
    (∑ t ∈ s.divisors, (ArithmeticFunction.moebius t : ℝ)) = 0 := by
  have h := congrArg (fun f : ArithmeticFunction ℤ => f s)
    ArithmeticFunction.moebius_mul_coe_zeta
  dsimp only at h
  rw [ArithmeticFunction.coe_mul_zeta_apply,
    ArithmeticFunction.one_apply_ne (by omega : s ≠ 1)] at h
  exact_mod_cast h

theorem actual_log_divisor_identity {r s : ℕ} (hr : 0 < r) (hs : 1 < s) :
    (∑ t ∈ s.divisors, (ArithmeticFunction.moebius t : ℝ) *
      Real.log ((r * t : ℕ) : ℝ)) = -ArithmeticFunction.vonMangoldt s := by
  have hsplit :
      (∑ t ∈ s.divisors, (ArithmeticFunction.moebius t : ℝ) *
        Real.log ((r * t : ℕ) : ℝ)) =
      ∑ t ∈ s.divisors, (ArithmeticFunction.moebius t : ℝ) *
        (Real.log (r : ℝ) + Real.log (t : ℝ)) := by
    apply Finset.sum_congr rfl
    intro t ht
    have ht0 : t ≠ 0 := by
      intro hzero
      subst t
      have hd := (Nat.mem_divisors.mp ht).1
      simp only [zero_dvd_iff] at hd
      omega
    rw [Nat.cast_mul, Real.log_mul (by exact_mod_cast hr.ne')
      (by exact_mod_cast ht0)]
  rw [hsplit]
  simp_rw [mul_add]
  rw [Finset.sum_add_distrib, ← Finset.sum_mul,
    moebius_divisor_sum_zero hs, zero_mul, zero_add]
  simpa only [ArithmeticFunction.log_apply] using
    (ArithmeticFunction.sum_moebius_mul_log_eq (n := s))

theorem signed_coefficient_full_fibre {r s alpha : ℕ}
    (hr : 0 < r) (hs : 1 < s) (hfull : r * s ≤ alpha) :
    signedDivisorCoefficient r s alpha =
      -(ArithmeticFunction.moebius s : ℝ) *
        (ArithmeticFunction.moebius r : ℝ) * ArithmeticFunction.vonMangoldt s := by
  have hsum :
      (∑ t ∈ s.divisors,
        if r * t ≤ alpha then
          (ArithmeticFunction.moebius t : ℝ) * Real.log ((r * t : ℕ) : ℝ)
        else 0) =
      ∑ t ∈ s.divisors, (ArithmeticFunction.moebius t : ℝ) *
        Real.log ((r * t : ℕ) : ℝ) := by
    apply Finset.sum_congr rfl
    intro t ht
    have ht_le : t ≤ s := Nat.le_of_dvd (by omega) (Nat.mem_divisors.mp ht).1
    rw [if_pos ((Nat.mul_le_mul_left r ht_le).trans hfull)]
  unfold signedDivisorCoefficient
  rw [hsum, actual_log_divisor_identity hr hs]
  ring

theorem signed_coefficient_prime {r p alpha : ℕ}
    (hr : 0 < r) (hp : p.Prime) (hfull : r * p ≤ alpha) :
    signedDivisorCoefficient r p alpha =
      (ArithmeticFunction.moebius r : ℝ) * Real.log (p : ℝ) := by
  rw [signed_coefficient_full_fibre hr hp.one_lt hfull,
    ArithmeticFunction.moebius_apply_prime hp,
    ArithmeticFunction.vonMangoldt_apply_prime hp]
  simp

theorem signed_coefficient_nonprime_zero {r s alpha : ℕ}
    (hr : 0 < r) (hs : 1 < s) (hnot : ¬s.Prime) (hfull : r * s ≤ alpha) :
    signedDivisorCoefficient r s alpha = 0 := by
  rw [signed_coefficient_full_fibre hr hs hfull]
  by_cases hpow : IsPrimePow s
  · rw [ArithmeticFunction.moebius_apply_isPrimePow_not_prime hpow hnot]
    simp
  · rw [ArithmeticFunction.vonMangoldt_eq_zero_iff.mpr hpow]
    simp

#print axioms actual_log_divisor_identity
#print axioms signed_coefficient_full_fibre
#print axioms signed_coefficient_prime
#print axioms signed_coefficient_nonprime_zero

end GoldbachResearch.ActualMobiusLogFibre
