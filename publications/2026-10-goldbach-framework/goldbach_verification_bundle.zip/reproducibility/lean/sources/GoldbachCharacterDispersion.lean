import GoldbachShiftedDispersion
import GoldbachSignedModulusTransfer

/-!
The literal completed character C weight, distinguished from the Type II R
weight in GoldbachShiftedDispersion. All module contributions remain inside W.
-/

namespace GoldbachResearch.CharacterDispersion

open scoped BigOperators
open Finset ActualArithmetic TypeIIAssembly ShiftedDispersion

noncomputable section

def completedWeight (N cutoff k n : ℕ) : ℝ :=
  if hk : k = 0 then 0 else
    letI : NeZero k := ⟨hk⟩
    if n.Coprime N then CharacterSplit.rowAmplitude N cutoff k n *
      (CharacterSplit.spectrum (N : ZMod k) (n : ZMod k)).re else 0

def fullCharacterWeight (N cutoff Q n : ℕ) : ℝ :=
  ∑ k ∈ actualModuli N Q, muReal k * completedWeight N cutoff k n

theorem completedWeight_zero (N cutoff k : ℕ) : completedWeight N cutoff k 0 = 0 := by
  classical
  by_cases hk : k = 0
  · simp [completedWeight, hk]
  · simp [completedWeight, hk, CharacterSplit.rowAmplitude]

theorem completedWeight_outside {N cutoff k n : ℕ} (hn : N ≤ n) :
    completedWeight N cutoff k n = 0 := by
  classical
  by_cases hk : k = 0
  · simp [completedWeight, hk]
  · have hs : ¬(1 ≤ n ∧ n < N ∧ n < N - cutoff * k) := by omega
    simp [completedWeight, hk, CharacterSplit.rowAmplitude, hs]

theorem spectrum_real_selector {k : ℕ} [NeZero k] (N n : ℕ)
    (hNk : N.Coprime k) (hn : n ≤ N) :
    (CharacterSplit.spectrum (N : ZMod k) (n : ZMod k)).re =
      (if k ∣ N - n then 1 else 0) -
        (if n.Coprime k then 1 else 0) / (k.totient : ℝ) := by
  classical
  have hN : IsUnit (N : ZMod k) := (ZMod.isUnit_iff_coprime N k).mpr hNk
  have hs : CharacterSplit.spectrum (N : ZMod k) (n : ZMod k) =
      CharacterSplit.centered (N : ZMod k) (n : ZMod k) +
        CharacterSplit.nonunitCorrection (n : ZMod k) :=
    sub_eq_iff_eq_add.mp (CharacterSplit.centered_eq_spectrum_sub_nonunit hN _).symm
  rw [hs, CharacterSplit.centered_natCast N n hn,
    CharacterSplit.nonunitCorrection_natCast n]
  split_ifs <;> simp_all

theorem completedWeight_explicit_selector {N cutoff k n : ℕ}
    (hk : 0 < k) (hNk : N.Coprime k) (hn : n ≤ N) :
    completedWeight N cutoff k n = if n.Coprime N then
      CharacterSplit.rowAmplitude N cutoff k n *
        ((if k ∣ N - n then 1 else 0) -
          (if n.Coprime k then 1 else 0) / (k.totient : ℝ)) else 0 := by
  classical
  letI : NeZero k := ⟨hk.ne'⟩
  simp only [completedWeight, dif_neg hk.ne']
  rw [spectrum_real_selector N n hNk hn]

theorem fullCharacterWeight_explicit_selector (N cutoff Q n : ℕ) (hn : n ≤ N) :
    fullCharacterWeight N cutoff Q n =
      ∑ k ∈ actualModuli N Q, muReal k * (if n.Coprime N then
        CharacterSplit.rowAmplitude N cutoff k n *
          ((if k ∣ N - n then 1 else 0) -
            (if n.Coprime k then 1 else 0) / (k.totient : ℝ)) else 0) := by
  unfold fullCharacterWeight
  apply Finset.sum_congr rfl
  intro k hk
  have hmem := actualModuli_membership.mp hk
  rw [completedWeight_explicit_selector (by omega : 0 < k) hmem.2.2.1.symm hn]

theorem characterRow_real_eq_weighted_sequence {k : ℕ} [NeZero k]
    (N cutoff : ℕ) (f : ArithmeticFunction ℝ) :
    (CharacterSplit.characterRow (k := k) N cutoff f).re =
      ∑ n ∈ range N, f n * muReal (N - n) * completedWeight N cutoff k n := by
  classical
  unfold CharacterSplit.characterRow
  change Complex.reAddGroupHom (∑ n ∈ range N, _) = _
  rw [map_sum]
  apply Finset.sum_congr rfl
  intro n hn
  change (if n.Coprime N then
      (f n * muReal (N - n) * CharacterSplit.rowAmplitude N cutoff k n : ℝ) *
        CharacterSplit.spectrum (N : ZMod k) (n : ZMod k) else (0 : ℂ)).re = _
  by_cases hc : n.Coprime N
  · simp only [if_pos hc, completedWeight, dif_neg (NeZero.ne k), if_pos hc]
    simp only [Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im,
      mul_zero, zero_mul, sub_zero]
    ring
  · simp only [if_neg hc, completedWeight, dif_neg (NeZero.ne k), if_neg hc,
      Complex.zero_re, mul_zero]

theorem actualCharacterReal_eq_weighted_sequence (N cutoff U V k : ℕ) :
    SignedModulusTransfer.actualCharacterReal N cutoff U V k =
      ∑ n ∈ range N, Vaughan.typeTwo U V n * muReal (N - n) *
        completedWeight N cutoff k n := by
  classical
  by_cases hk : k = 0
  · simp [SignedModulusTransfer.actualCharacterReal, completedWeight, hk]
  · letI : NeZero k := ⟨hk⟩
    simp only [SignedModulusTransfer.actualCharacterReal, dif_neg hk]
    exact characterRow_real_eq_weighted_sequence N cutoff (Vaughan.typeTwo U V)

theorem typeTwo_weighted_eq_active_bilinear (N U V : ℕ) (W : ℕ → ℝ)
    (hzero : W 0 = 0) (hout : ∀ n, N ≤ n → W n = 0) :
    (∑ n ∈ range N, Vaughan.typeTwo U V n * muReal (N - n) * W n) =
      Bilinear.bilinearSum (activeFirst N U) (activeSecond N V) muReal
        (Vaughan.beta V) (arithmeticKernel N W) := by
  classical
  let F : ℕ × ℕ → ℝ := fun p =>
    (if U < p.1 then Vaughan.mu p.1 else 0) * Vaughan.beta V p.2 *
      muReal (N - p.1 * p.2) * W (p.1 * p.2)
  have hexpand : (∑ n ∈ range N, Vaughan.typeTwo U V n * muReal (N - n) * W n) =
      ∑ n ∈ range N, ∑ p ∈ n.divisorsAntidiagonal, F p := by
    apply Finset.sum_congr rfl
    intro n hn
    rw [Vaughan.typeTwo_bilinear, Finset.sum_mul, Finset.sum_mul]
    apply Finset.sum_congr rfl
    intro p hp
    dsimp [F]
    rw [(Nat.mem_divisorsAntidiagonal.mp hp).1]
  have hz : ∀ p, p.1 * p.2 = 0 → F p = 0 := by
    intro p hp
    simp [F, hp, hzero]
  have ho : ∀ p, N ≤ p.1 * p.2 → F p = 0 := by
    intro p hp
    simp [F, hout _ hp]
  rw [hexpand, divisor_sum_eq_rectangle N F hz ho]
  have hprod : (∑ p ∈ (range N).product (range N), F p) =
      ∑ a ∈ range N, ∑ b ∈ range N, F (a, b) :=
    Finset.sum_product (range N) (range N) F
  rw [hprod]
  unfold Bilinear.bilinearSum activeFirst activeSecond arithmeticKernel
  simp only [Finset.sum_filter]
  apply Finset.sum_congr rfl
  intro a ha
  by_cases hu : U < a
  · simp only [if_pos hu]
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro b hb
    by_cases hv : V < b
    · simp only [if_pos hv]
      dsimp [F]
      simp only [if_pos hu]
      change muReal a * Vaughan.beta V b * muReal (N - a * b) * W (a * b) = _
      ring
    · have hbzero := Vaughan.beta_zero_of_le (Nat.le_of_not_gt hv)
      simp [F, hu, hv, hbzero]
  · simp [F, hu]

theorem actualCharacterReal_eq_column (N cutoff U V k : ℕ) :
    SignedModulusTransfer.actualCharacterReal N cutoff U V k =
      ∑ b ∈ activeSecond N V, Vaughan.beta V b *
        column (activeFirst N U) muReal
          (arithmeticKernel N (completedWeight N cutoff k)) b := by
  rw [actualCharacterReal_eq_weighted_sequence,
    typeTwo_weighted_eq_active_bilinear N U V (completedWeight N cutoff k)
      (completedWeight_zero N cutoff k) (fun n hn => completedWeight_outside hn),
    Bilinear.bilinearSum_eq_transpose]
  rfl

theorem arithmeticKernel_fullCharacterWeight (N cutoff Q a b : ℕ) :
    arithmeticKernel N (fullCharacterWeight N cutoff Q) a b =
      ∑ k ∈ actualModuli N Q, muReal k *
        arithmeticKernel N (completedWeight N cutoff k) a b := by
  unfold arithmeticKernel fullCharacterWeight
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k hk
  ring

theorem signed_character_eq_aggregated_column (N cutoff Q U V : ℕ) :
    SignedModulusTransfer.signedApproximation N Q
      (SignedModulusTransfer.actualCharacterReal N cutoff U V) =
      ∑ b ∈ activeSecond N V, Vaughan.beta V b *
        column (activeFirst N U) muReal
          (arithmeticKernel N (fullCharacterWeight N cutoff Q)) b := by
  unfold SignedModulusTransfer.signedApproximation
  simp_rw [actualCharacterReal_eq_column]
  unfold column
  simp_rw [arithmeticKernel_fullCharacterWeight, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro b hb
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a ha
  apply Finset.sum_congr rfl
  intro k hk
  ring

theorem signed_character_sq_le_dispersion (N cutoff Q U V : ℕ) :
    SignedModulusTransfer.signedApproximation N Q
      (SignedModulusTransfer.actualCharacterReal N cutoff U V) ^ 2 ≤
      (∑ b ∈ activeSecond N V, Vaughan.beta V b) *
        dispersion (activeFirst N U) (activeSecond N V) muReal (Vaughan.beta V)
          (arithmeticKernel N (fullCharacterWeight N cutoff Q)) := by
  rw [signed_character_eq_aggregated_column]
  exact weighted_contraction_sq_le _ _ _ _ _ (fun b _ => Vaughan.beta_nonneg V b)

def cappedSecond (N U V : ℕ) : Finset ℕ :=
  (activeSecond N V).filter fun b => b ≤ (N - 1) / (U + 1)

theorem fullCharacterWeight_outside {N cutoff Q n : ℕ} (hn : N ≤ n) :
    fullCharacterWeight N cutoff Q n = 0 := by
  unfold fullCharacterWeight
  apply Finset.sum_eq_zero
  intro k hk
  rw [completedWeight_outside hn, mul_zero]

theorem character_column_zero_above_cap {N cutoff Q U b : ℕ}
    (hb : (N - 1) / (U + 1) < b) :
    column (activeFirst N U) muReal
      (arithmeticKernel N (fullCharacterWeight N cutoff Q)) b = 0 := by
  unfold column
  apply Finset.sum_eq_zero
  intro a ha
  have hau : U < a := (Finset.mem_filter.mp ha).2
  have hab : N ≤ a * b := by
    by_contra hn
    have hab' : a * b ≤ N - 1 := by omega
    have hprod : b * (U + 1) ≤ N - 1 := by
      have h := Nat.mul_le_mul_right b (by omega : U + 1 ≤ a)
      nlinarith
    have hble : b ≤ (N - 1) / (U + 1) :=
      (Nat.le_div_iff_mul_le (by omega : 0 < U + 1)).mpr hprod
    omega
  simp [arithmeticKernel, fullCharacterWeight_outside hab]

theorem signed_character_eq_capped_column (N cutoff Q U V : ℕ) :
    SignedModulusTransfer.signedApproximation N Q
      (SignedModulusTransfer.actualCharacterReal N cutoff U V) =
      ∑ b ∈ cappedSecond N U V, Vaughan.beta V b *
        column (activeFirst N U) muReal
          (arithmeticKernel N (fullCharacterWeight N cutoff Q)) b := by
  rw [signed_character_eq_aggregated_column]
  unfold cappedSecond
  symm
  apply Finset.sum_subset (Finset.filter_subset _ _)
  intro b hb hout
  have hcap : (N - 1) / (U + 1) < b := by
    have hnot : ¬b ≤ (N - 1) / (U + 1) := by
      intro h
      exact hout (Finset.mem_filter.mpr ⟨hb, h⟩)
    omega
  rw [character_column_zero_above_cap hcap, mul_zero]

theorem signed_character_sq_le_capped_dispersion (N cutoff Q U V : ℕ) :
    SignedModulusTransfer.signedApproximation N Q
      (SignedModulusTransfer.actualCharacterReal N cutoff U V) ^ 2 ≤
      (∑ b ∈ cappedSecond N U V, Vaughan.beta V b) *
        dispersion (activeFirst N U) (cappedSecond N U V) muReal (Vaughan.beta V)
          (arithmeticKernel N (fullCharacterWeight N cutoff Q)) := by
  rw [signed_character_eq_capped_column]
  exact weighted_contraction_sq_le _ _ _ _ _ (fun b _ => Vaughan.beta_nonneg V b)

#print axioms completedWeight_zero
#print axioms completedWeight_outside
#print axioms spectrum_real_selector
#print axioms completedWeight_explicit_selector
#print axioms fullCharacterWeight_explicit_selector
#print axioms characterRow_real_eq_weighted_sequence
#print axioms actualCharacterReal_eq_weighted_sequence
#print axioms typeTwo_weighted_eq_active_bilinear
#print axioms actualCharacterReal_eq_column
#print axioms arithmeticKernel_fullCharacterWeight
#print axioms signed_character_eq_aggregated_column
#print axioms signed_character_sq_le_dispersion
#print axioms fullCharacterWeight_outside
#print axioms character_column_zero_above_cap
#print axioms signed_character_eq_capped_column
#print axioms signed_character_sq_le_capped_dispersion

end
end GoldbachResearch.CharacterDispersion
