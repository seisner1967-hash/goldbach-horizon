import GoldbachOffDiagonalBudget

/-!
An unconditional finite upper bound for the actual C-energy. The cost is
the number of active first-variable entries in each column, not an
arithmetic cancellation estimate. All signed module contributions remain
inside fullCharacterWeight. The bound is too large for the Goldbach target.
-/

namespace GoldbachResearch.ColumnMultiplicity

open scoped BigOperators
open Finset ActualArithmetic TypeIIAssembly ShiftedDispersion CharacterDispersion
open OffDiagonalBudget

noncomputable section

def columnSupport (N U b : ℕ) : Finset ℕ :=
  (activeFirst N U).filter fun a => a * b < N

def columnMultiplicity (N U V : ℕ) : ℕ := (N - 1) / (V + 1) - U

def cEntry (N cutoff Q a b : ℕ) : ℝ :=
  muReal a * arithmeticKernel N (fullCharacterWeight N cutoff Q) a b

theorem cEntry_outside {N cutoff Q a b : ℕ} (hab : N ≤ a * b) :
    cEntry N cutoff Q a b = 0 := by
  simp [cEntry, arithmeticKernel, fullCharacterWeight_outside hab]

theorem columnSupport_card_le {N U V b : ℕ} (hb : V < b) :
    (columnSupport N U b).card ≤ columnMultiplicity N U V := by
  have hbpos : 0 < b := by omega
  have hs : columnSupport N U b ⊆ Ioc U ((N - 1) / b) := by
    intro a ha
    rcases mem_filter.mp ha with ⟨ha, hab⟩
    have hau : U < a := (mem_filter.mp ha).2
    exact mem_Ioc.mpr ⟨hau, (Nat.le_div_iff_mul_le hbpos).mpr (by omega)⟩
  have hc := card_le_card hs
  rw [Nat.card_Ioc] at hc
  have hdiv : (N - 1) / b ≤ (N - 1) / (V + 1) :=
    Nat.div_le_div_left (by omega) (by omega)
  exact hc.trans (Nat.sub_le_sub_right hdiv U)

theorem column_eq_supported_sum (N cutoff Q U b : ℕ) :
    column (activeFirst N U) muReal
      (arithmeticKernel N (fullCharacterWeight N cutoff Q)) b =
      ∑ a ∈ columnSupport N U b, cEntry N cutoff Q a b := by
  classical
  unfold column columnSupport
  rw [sum_filter]
  apply sum_congr rfl
  intro a ha
  by_cases hab : a * b < N
  · simp [hab, cEntry]
  · have hz := cEntry_outside (N := N) (cutoff := cutoff) (Q := Q)
      (a := a) (b := b) (by omega)
    simpa only [if_neg hab, cEntry] using hz

theorem square_sum_eq_supported_sum (N cutoff Q U b : ℕ) :
    (∑ a ∈ activeFirst N U, cEntry N cutoff Q a b ^ 2) =
      ∑ a ∈ columnSupport N U b, cEntry N cutoff Q a b ^ 2 := by
  classical
  unfold columnSupport
  rw [sum_filter]
  apply sum_congr rfl
  intro a ha
  by_cases hab : a * b < N
  · simp [hab]
  · simp [hab, cEntry_outside (by omega : N ≤ a * b)]

theorem column_sq_le_support_diagonal (N cutoff Q U b : ℕ) :
    column (activeFirst N U) muReal
        (arithmeticKernel N (fullCharacterWeight N cutoff Q)) b ^ 2 ≤
      ((columnSupport N U b).card : ℝ) *
        ∑ a ∈ activeFirst N U, cEntry N cutoff Q a b ^ 2 := by
  rw [column_eq_supported_sum, square_sum_eq_supported_sum]
  simpa using Finset.sum_mul_sq_le_sq_mul_sq (columnSupport N U b)
    (fun _ => (1 : ℝ)) (fun a => cEntry N cutoff Q a b)

theorem coherentDiagonal_eq_entry_squares (N cutoff Q U V : ℕ) :
    coherentDiagonal N cutoff Q U V =
      ∑ b ∈ cappedSecond N U V, ∑ a ∈ activeFirst N U,
        cEntry N cutoff Q a b ^ 2 := by
  unfold coherentDiagonal diagonal cEntry
  simp only [one_mul, mul_pow]
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]

theorem coherentDiagonal_nonneg (N cutoff Q U V : ℕ) :
    0 ≤ coherentDiagonal N cutoff Q U V := by
  rw [coherentDiagonal_eq_entry_squares]
  exact sum_nonneg (fun b hb => sum_nonneg (fun a ha => sq_nonneg _))

theorem characterEnergy_le_multiplicity_diagonal (N cutoff Q U V : ℕ) :
    characterEnergy N cutoff Q U V ≤
      (columnMultiplicity N U V : ℝ) * coherentDiagonal N cutoff Q U V := by
  rw [coherentDiagonal_eq_entry_squares, Finset.mul_sum]
  unfold characterEnergy dispersion
  simp only [one_mul]
  apply sum_le_sum
  intro b hb
  have hbV : V < b := (mem_filter.mp (mem_filter.mp hb).1).2
  refine (column_sq_le_support_diagonal N cutoff Q U b).trans ?_
  apply mul_le_mul_of_nonneg_right
    (by exact_mod_cast columnSupport_card_le (N := N) (U := U) hbV)
  exact sum_nonneg (fun a ha => sq_nonneg _)

theorem positive_off_le_multiplicity {E D M : ℝ}
    (hD : 0 ≤ D) (hE : E ≤ M * D) :
    max (E - D) 0 ≤ max (M - 1) 0 * D := by
  apply max_le
  · calc
      E - D ≤ (M - 1) * D := by nlinarith
      _ ≤ max (M - 1) 0 * D := mul_le_mul_of_nonneg_right (le_max_left _ _) hD
  · exact mul_nonneg (le_max_right _ _) hD

theorem actual_positive_off_le_multiplicity_diagonal (N cutoff Q U V : ℕ) :
    max (offDiagonal N cutoff Q U V) 0 ≤
      max ((columnMultiplicity N U V : ℝ) - 1) 0 *
        coherentDiagonal N cutoff Q U V := by
  unfold offDiagonal
  exact positive_off_le_multiplicity (coherentDiagonal_nonneg N cutoff Q U V)
    (characterEnergy_le_multiplicity_diagonal N cutoff Q U V)

theorem actual_column_sq_le_energy {N cutoff Q U V b : ℕ}
    (hb : b ∈ cappedSecond N U V) :
    column (activeFirst N U) muReal
        (arithmeticKernel N (fullCharacterWeight N cutoff Q)) b ^ 2 ≤
      characterEnergy N cutoff Q U V := by
  unfold characterEnergy dispersion
  simp only [one_mul]
  exact Finset.single_le_sum
    (f := fun c : ℕ => column (activeFirst N U) muReal
      (arithmeticKernel N (fullCharacterWeight N cutoff Q)) c ^ 2)
    (fun c hc => sq_nonneg _) hb

#print axioms cEntry_outside
#print axioms columnSupport_card_le
#print axioms column_eq_supported_sum
#print axioms square_sum_eq_supported_sum
#print axioms column_sq_le_support_diagonal
#print axioms coherentDiagonal_eq_entry_squares
#print axioms coherentDiagonal_nonneg
#print axioms characterEnergy_le_multiplicity_diagonal
#print axioms positive_off_le_multiplicity
#print axioms actual_positive_off_le_multiplicity_diagonal
#print axioms actual_column_sq_le_energy

end
end GoldbachResearch.ColumnMultiplicity
