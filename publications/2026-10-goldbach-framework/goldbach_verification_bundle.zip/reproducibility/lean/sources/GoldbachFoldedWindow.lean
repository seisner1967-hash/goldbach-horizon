import GoldbachSmoothingVariance
import Mathlib.Data.Nat.Periodic

/-!
# Literal interval folding on a finite cyclic group

The quotient/remainder formula for counting all H interval points is proved,
including H larger than the modulus. The interval is not assumed to remain
an indicator after folding.
-/

namespace GoldbachResearch.FoldedWindow

open scoped BigOperators
open Finset SmoothingVariance

variable {M : ℕ} [NeZero M]

omit [NeZero M] in
theorem periodic_count_blocks (P : ℕ → Prop) [DecidablePred P]
    (hP : Function.Periodic P M) (q r : ℕ) :
    Nat.count P (q * M + r) = q * Nat.count P M + Nat.count P r := by
  induction q with
  | zero => simp
  | succ q ih =>
    have he (j : ℕ) : P (M + j) = P j := by simpa [Nat.add_comm] using hP j
    rw [Nat.succ_mul]
    have ht : q * M + M + r = M + (q * M + r) := by omega
    rw [ht, Nat.count_add]
    simp only [he]
    rw [ih]
    ring

theorem initial_residue_count (H : ℕ) (hH : H ≤ M) (x : ZMod M) :
    Nat.count (fun j : ℕ => (j : ZMod M) = x) H = if x.val < H then 1 else 0 := by
  rw [Nat.count_eq_card_filter_range]
  have he : (Finset.range H).filter (fun j : ℕ => (j : ZMod M) = x) =
      if x.val < H then {x.val} else ∅ := by
    by_cases hx : x.val < H
    · rw [if_pos hx]
      ext j
      simp only [Finset.mem_filter, Finset.mem_range, Finset.mem_singleton]
      constructor
      · intro hj
        have hjM : j < M := hj.1.trans_le hH
        have hh := congrArg ZMod.val hj.2
        simpa only [ZMod.val_natCast, Nat.mod_eq_of_lt hjM] using hh
      · intro hj
        subst j
        exact ⟨hx, ZMod.natCast_zmod_val x⟩
    · rw [if_neg hx]
      apply Finset.eq_empty_iff_forall_not_mem.mpr
      intro j hj
      have hm := Finset.mem_filter.mp hj
      have hjM : j < M := (Finset.mem_range.mp hm.1).trans_le hH
      have hh := congrArg ZMod.val hm.2
      have hval : j = x.val := by
        simpa only [ZMod.val_natCast, Nat.mod_eq_of_lt hjM] using hh
      exact hx (hval ▸ Finset.mem_range.mp hm.1)
  rw [he]
  split_ifs <;> simp

noncomputable def foldedBox (H : ℕ) (x : ZMod M) : ℝ :=
  Nat.count (fun j : ℕ => (j : ZMod M) = x) H

/-- A full block contributes one point to each residue. This identity uses
the literal cardinality of interval points, not a replacement definition. -/
theorem foldedBox_eq_quotient_remainder (H : ℕ) (x : ZMod M) :
    foldedBox H x = (H / M : ℕ) +
      window (fun y : ZMod M => y.val < H % M) x := by
  have hM : 0 < M := Nat.pos_of_ne_zero (NeZero.ne M)
  have hp : Function.Periodic (fun j : ℕ => (j : ZMod M) = x) M := by
    intro j
    simp
  have he : H = H / M * M + H % M := by
    simpa [Nat.mul_comm] using (Nat.div_add_mod H M).symm
  unfold foldedBox
  conv_lhs => rw [he]
  rw [periodic_count_blocks _ hp]
  rw [initial_residue_count M le_rfl x,
    initial_residue_count (H % M) (Nat.mod_lt H hM).le x]
  simp only [ZMod.val_lt, if_true, mul_one, Nat.cast_add, window,
    Nat.cast_ite, Nat.cast_one, Nat.cast_zero]

noncomputable def foldedAutocorrelation (H : ℕ) (t : ZMod M) : ℝ :=
  ∑ x, foldedBox H x * foldedBox H (x - t)

noncomputable def foldedFejer (H : ℕ) (t : ZMod M) : ℝ :=
  foldedAutocorrelation H t / (H : ℝ)

theorem foldedAutocorrelation_eq (H : ℕ) (t : ZMod M) :
    foldedAutocorrelation H t =
      (M : ℝ) * (H / M : ℕ) ^ 2 +
        2 * (H / M : ℕ) * (H % M : ℕ) +
          autocorrelation (fun x : ZMod M => x.val < H % M) t := by
  let P : ZMod M → Prop := fun x => x.val < H % M
  have hr : H % M ≤ M := (Nat.mod_lt H (Nat.pos_of_ne_zero (NeZero.ne M))).le
  have hs : ∑ x, window P x = ((H % M : ℕ) : ℝ) := by
    rw [sum_window, initialInterval_card _ hr]
  have ht : ∑ x, window P (x - t) = ((H % M : ℕ) : ℝ) := by
    rw [← hs]
    exact Fintype.sum_equiv (Equiv.addRight (-t)) _ _ (fun x => by
      simp only [sub_eq_add_neg]; rfl)
  have he (x : ZMod M) : foldedBox H x * foldedBox H (x - t) =
      ((H / M : ℕ) : ℝ) ^ 2 + ((H / M : ℕ) : ℝ) * window P x +
        ((H / M : ℕ) : ℝ) * window P (x - t) + window P x * window P (x - t) := by
    rw [foldedBox_eq_quotient_remainder, foldedBox_eq_quotient_remainder]
    change ((H / M : ℕ) + window P x) * ((H / M : ℕ) + window P (x - t)) = _
    ring
  unfold foldedAutocorrelation
  simp_rw [he]
  simp only [Finset.sum_add_distrib, ← Finset.mul_sum, hs, ht,
    Finset.sum_const, Finset.card_univ, ZMod.card, nsmul_eq_mul]
  change _ = _ + _ + ∑ x, window P x * window P (x - t)
  ring

/-- Away from zero frequency, whole blocks contribute only a constant.
The folded Fejer window is exactly a rescaled residual Fejer window. -/
theorem foldedFejer_dft_nonzero (H : ℕ) (k : ZMod M) (hk : k ≠ 0) :
    ZMod.dft (fun t => (foldedFejer H t : ℂ)) k =
      ((H % M : ℕ) : ℂ) / (H : ℂ) *
        ZMod.dft (fun t =>
          (fejerWindow (fun x : ZMod M => x.val < H % M) t : ℂ)) k := by
  let P : ZMod M → Prop := fun x => x.val < H % M
  let C : ℝ := (M : ℝ) * (H / M : ℕ) ^ 2 + 2 * (H / M : ℕ) * (H % M : ℕ)
  have hr : H % M ≤ M := (Nat.mod_lt H (Nat.pos_of_ne_zero (NeZero.ne M))).le
  have he (t : ZMod M) : foldedFejer H t =
      C / (H : ℝ) + ((H % M : ℕ) : ℝ) / (H : ℝ) * fejerWindow P t := by
    unfold foldedFejer
    rw [foldedAutocorrelation_eq]
    change (C + autocorrelation P t) / (H : ℝ) = _
    unfold fejerWindow
    rw [initialInterval_card _ hr]
    by_cases hz : H % M = 0
    · have ha : autocorrelation P t = 0 := by
        simp [P, hz, autocorrelation, window]
      simp [hz, ha]
    · have hzR : ((H % M : ℕ) : ℝ) ≠ 0 := by exact_mod_cast hz
      have hH : H ≠ 0 := by intro h; exact hz (by simp [h])
      have hHR : (H : ℝ) ≠ 0 := by exact_mod_cast hH
      field_simp [hzR, hHR]
      ring
  have hf : (fun t => (foldedFejer H t : ℂ)) =
      (fun _ : ZMod M => (C : ℂ) / (H : ℂ)) +
        fun t => (((H % M : ℕ) : ℂ) / (H : ℂ)) * (fejerWindow P t : ℂ) := by
    funext t
    simpa only [Pi.add_apply, Complex.ofReal_add, Complex.ofReal_div,
      Complex.ofReal_mul, Complex.ofReal_natCast] using congrArg Complex.ofReal (he t)
  rw [hf, map_add]
  change ZMod.dft (fun _ : ZMod M => (C : ℂ) / (H : ℂ)) k +
    ZMod.dft (fun t => (((H % M : ℕ) : ℂ) / (H : ℂ)) * (fejerWindow P t : ℂ)) k = _
  rw [dft_constant, if_neg hk, zero_add, ZMod.dft_const_mul]

/-- The g*H cap now covers arbitrary H, including folded intervals longer
than the modulus. Only the zero frequency is excluded, as in the variance. -/
theorem foldedFejer_nonzero_frequency_energy_le (H : ℕ) :
    ∑ k ∈ (Finset.univ : Finset (ZMod M)).erase 0,
      Complex.normSq (ZMod.dft (fun t => (foldedFejer H t : ℂ)) k) ≤
        (M : ℝ) * (H : ℝ) := by
  let P : ZMod M → Prop := fun x => x.val < H % M
  have hr : H % M ≤ M := (Nat.mod_lt H (Nat.pos_of_ne_zero (NeZero.ne M))).le
  have he : (∑ k ∈ (Finset.univ : Finset (ZMod M)).erase 0,
      Complex.normSq (ZMod.dft (fun t => (foldedFejer H t : ℂ)) k)) =
      (((H % M : ℕ) : ℝ) / (H : ℝ)) ^ 2 *
        ∑ k ∈ (Finset.univ : Finset (ZMod M)).erase 0,
          Complex.normSq (ZMod.dft (fun t => (fejerWindow P t : ℂ)) k) := by
    rw [Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro k hk
    rw [foldedFejer_dft_nonzero H k (Finset.mem_erase.mp hk).1,
      Complex.normSq_mul]
    simp [Complex.normSq_div, Complex.normSq_natCast, div_pow, pow_two, P]
    left
    ring
  rw [he]
  have hs : (∑ k ∈ (Finset.univ : Finset (ZMod M)).erase 0,
      Complex.normSq (ZMod.dft (fun t => (fejerWindow P t : ℂ)) k)) ≤
        (M : ℝ) * ((H % M : ℕ) : ℝ) := by
    exact (Finset.sum_le_sum_of_subset_of_nonneg (Finset.erase_subset _ _)
      (fun k hk hkn => Complex.normSq_nonneg _)).trans
        (by simpa [P, initialInterval_card _ hr] using fejerWindow_frequency_energy_le P)
  have h0 : 0 ≤ ((H % M : ℕ) : ℝ) := Nat.cast_nonneg _
  have hle : ((H % M : ℕ) : ℝ) ≤ (H : ℝ) := by exact_mod_cast Nat.mod_le H M
  have hc := mul_le_mul_of_nonneg_left hs (sq_nonneg (((H % M : ℕ) : ℝ) / (H : ℝ)))
  by_cases hH : H = 0
  · simp [hH]
  · have hHR : 0 < (H : ℝ) := by exact_mod_cast Nat.pos_of_ne_zero hH
    have hratio : ((H % M : ℕ) : ℝ) / (H : ℝ) ≤ 1 := (div_le_one hHR).mpr hle
    have hratio0 : 0 ≤ ((H % M : ℕ) : ℝ) / (H : ℝ) := div_nonneg h0 hHR.le
    have hsq : (((H % M : ℕ) : ℝ) / (H : ℝ)) ^ 2 ≤ 1 := by nlinarith
    calc
      _ ≤ (((H % M : ℕ) : ℝ) / (H : ℝ)) ^ 2 * ((M : ℝ) * ((H % M : ℕ) : ℝ)) := hc
      _ ≤ (M : ℝ) * ((H % M : ℕ) : ℝ) := by
        nlinarith [mul_le_mul_of_nonneg_right hsq
          (mul_nonneg (Nat.cast_nonneg M) h0)]
      _ ≤ (M : ℝ) * (H : ℝ) := mul_le_mul_of_nonneg_left hle (Nat.cast_nonneg M)

#print axioms periodic_count_blocks
#print axioms initial_residue_count
#print axioms foldedBox_eq_quotient_remainder
#print axioms foldedAutocorrelation_eq
#print axioms foldedFejer_dft_nonzero
#print axioms foldedFejer_nonzero_frequency_energy_le

end GoldbachResearch.FoldedWindow
