import Mathlib.Analysis.Fourier.ZMod
import Mathlib.Tactic

/-!
# Finite Fourier identities used by the Goldbach certificates

This module uses Mathlib's actual discrete Fourier transform on `ZMod N`.
The identities are finite and unconditional; estimates for prime correlations
are not assumptions or conclusions of this file.
-/

namespace GoldbachResearch

open Finset AddChar

variable {N : ℕ} [NeZero N]

theorem dft_transpose (f g : ZMod N → ℂ) :
    ∑ k, ZMod.dft f k * g k = ∑ x, f x * ZMod.dft g x := by
  simp only [ZMod.dft_apply, smul_eq_mul, Finset.sum_mul, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro x hx
  apply Finset.sum_congr rfl
  intro k hk
  rw [mul_comm x k]
  ring

theorem dft_bilinear (f g : ZMod N → ℂ) :
    ∑ k, ZMod.dft f k * ZMod.dft g k =
      (N : ℂ) * ∑ x, f x * g (-x) := by
  rw [dft_transpose, ZMod.dft_dft]
  simp only [smul_eq_mul, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro x hx
  ring

theorem stdAddChar_conj (x : ZMod N) :
    star (ZMod.stdAddChar x) = ZMod.stdAddChar (-x) := by
  simp only [ZMod.stdAddChar_apply]
  rw [AddChar.map_neg_eq_inv]
  exact (Circle.coe_inv_eq_conj (ZMod.toCircle x)).symm

theorem dft_star (f : ZMod N → ℂ) (k : ZMod N) :
    ZMod.dft (fun x => star (f x)) k = star (ZMod.dft f (-k)) := by
  simp only [ZMod.dft_apply, smul_eq_mul, star_sum, star_mul',
    stdAddChar_conj, mul_neg, neg_neg]

theorem dft_star_reflect (f : ZMod N → ℂ) (k : ZMod N) :
    ZMod.dft (fun x => star (f (-x))) k = star (ZMod.dft f k) := by
  rw [congr_fun (ZMod.dft_comp_neg (fun x => star (f x))) k]
  simpa using dft_star f (-k)

theorem dft_parseval_complex (f : ZMod N → ℂ) :
    ∑ k, ZMod.dft f k * star (ZMod.dft f k) =
      (N : ℂ) * ∑ x, f x * star (f x) := by
  simpa only [dft_star_reflect, neg_neg] using
    dft_bilinear f (fun x => star (f (-x)))

theorem dft_parseval (f : ZMod N → ℂ) :
    ∑ k, Complex.normSq (ZMod.dft f k) =
      (N : ℝ) * ∑ x, Complex.normSq (f x) := by
  have h := dft_parseval_complex f
  simp only [Complex.star_def, Complex.mul_conj, ← Complex.ofReal_sum,
    ← Complex.ofReal_natCast, ← Complex.ofReal_mul] at h
  exact Complex.ofReal_injective h

theorem dft_shift (f : ZMod N → ℂ) (t k : ZMod N) :
    ZMod.dft (fun x => f (t + x)) k =
      ZMod.stdAddChar (t * k) * ZMod.dft f k := by
  simp only [ZMod.dft_apply, smul_eq_mul, Finset.mul_sum]
  refine Fintype.sum_equiv (Equiv.addLeft t) _ _ (fun x => ?_)
  change ZMod.stdAddChar (-(x * k)) * f (t + x) =
    ZMod.stdAddChar (t * k) * (ZMod.stdAddChar (-((t + x) * k)) * f (t + x))
  rw [← mul_assoc, ← AddChar.map_add_eq_mul]
  congr 2
  ring

theorem dft_square_convolution (f : ZMod N → ℂ) (t : ZMod N) :
    ∑ k, ZMod.stdAddChar (t * k) * (ZMod.dft f k) ^ 2 =
      (N : ℂ) * ∑ x, f x * f (t - x) := by
  have h := dft_bilinear f (fun x => f (t + x))
  simp only [dft_shift, ← sub_eq_add_neg] at h
  convert h using 1
  apply Finset.sum_congr rfl
  intro k hk
  ring

noncomputable def centeredDFT (f : ZMod N → ℝ) (t k : ZMod N) : ℂ :=
  ZMod.stdAddChar (t * k) * ZMod.dft (fun x => (f x : ℂ)) k

theorem centered_parseval (f : ZMod N → ℝ) (t : ZMod N) :
    ∑ k, Complex.normSq (centeredDFT f t k) = (N : ℝ) * ∑ x, (f x) ^ 2 := by
  have hc (k : ZMod N) : Complex.normSq (ZMod.stdAddChar (t * k)) = 1 := by
    exact Circle.normSq_coe _
  simp only [centeredDFT, Complex.normSq_mul, hc, one_mul]
  convert dft_parseval (fun x => (f x : ℂ)) using 1
  congr 1
  apply Finset.sum_congr rfl
  intro x hx
  simp [Complex.normSq_apply, pow_two]

theorem centered_square (f : ZMod N → ℝ) (t : ZMod N) :
    ∑ k, (centeredDFT f t k) ^ 2 =
      (N : ℂ) * ∑ x, (f x : ℂ) * (f (2 * t - x) : ℂ) := by
  have h := dft_square_convolution (fun x => (f x : ℂ)) (2 * t)
  convert h using 1
  apply Finset.sum_congr rfl
  intro k hk
  have hc : (ZMod.stdAddChar (t * k)) ^ 2 = ZMod.stdAddChar (2 * t * k) := by
    rw [pow_two, ← AddChar.map_add_eq_mul]
    congr 1
    ring
  simp only [centeredDFT, mul_pow, hc]

theorem centered_real_identity (f : ZMod N → ℝ) (t : ZMod N) :
    (N : ℝ) * ((∑ x, f x * f (2 * t - x)) + ∑ x, (f x) ^ 2) =
      2 * ∑ k, ((centeredDFT f t k).re) ^ 2 := by
  have hs := congrArg Complex.re (centered_square f t)
  have hp := centered_parseval f t
  have hpoint (z : ℂ) : (z ^ 2).re = 2 * z.re ^ 2 - Complex.normSq z := by
    simp only [pow_two, Complex.mul_re, Complex.normSq_apply]
    ring
  simp only [Complex.re_sum, hpoint, Finset.sum_sub_distrib,
    ← Finset.mul_sum, Complex.mul_re, Complex.ofReal_re, Complex.ofReal_im,
    mul_zero, sub_zero, Complex.natCast_re, Complex.natCast_im] at hs
  linarith

/-- An unconditional lower bound from any chosen set of Fourier modes. -/
theorem partial_modes_lower_bound (f : ZMod N → ℝ) (t : ZMod N)
    (modes : Finset (ZMod N)) :
    2 * (∑ k ∈ modes, ((centeredDFT f t k).re) ^ 2) -
      (N : ℝ) * ∑ x, (f x) ^ 2 ≤
        (N : ℝ) * ∑ x, f x * f (2 * t - x) := by
  have hsub : (∑ k ∈ modes, ((centeredDFT f t k).re) ^ 2) ≤
      ∑ k, ((centeredDFT f t k).re) ^ 2 := by
    apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _)
    intro k hk hkm
    exact sq_nonneg _
  have h := centered_real_identity f t
  nlinarith

theorem positive_partial_modes_implies_positive_convolution
    (f : ZMod N → ℝ) (t : ZMod N) (modes : Finset (ZMod N))
    (h : (N : ℝ) * ∑ x, (f x) ^ 2 <
      2 * (∑ k ∈ modes, ((centeredDFT f t k).re) ^ 2)) :
    0 < ∑ x, f x * f (2 * t - x) := by
  have hn : 0 < (N : ℝ) := by exact_mod_cast (NeZero.pos N)
  have hl := partial_modes_lower_bound f t modes
  nlinarith

theorem stdAddChar_re (x : ZMod N) :
    (ZMod.stdAddChar x).re = Real.cos (2 * Real.pi * (x.val : ℝ) / (N : ℝ)) := by
  have hre : (2 : ℂ).re = 2 := by norm_num
  have him : (2 : ℂ).im = 0 := by norm_num
  rw [ZMod.stdAddChar_apply, ZMod.toCircle_apply, Complex.exp_re]
  simp only [Complex.mul_re, Complex.mul_im, Complex.div_natCast_re,
    Complex.div_natCast_im, Complex.ofReal_re, Complex.ofReal_im,
    Complex.natCast_re, Complex.natCast_im, hre, him,
    Complex.I_re, Complex.I_im, mul_zero, zero_mul, mul_one, one_mul,
    add_zero, zero_add, sub_zero, zero_sub, div_zero, zero_div,
    neg_zero, Real.exp_zero]

theorem centered_cosine (f : ZMod N → ℝ) (t k : ZMod N) :
    (centeredDFT f t k).re =
      ∑ x, f x * Real.cos (2 * Real.pi * ((k * (x - t)).val : ℝ) / (N : ℝ)) := by
  have hc : centeredDFT f t k =
      ∑ x, star (ZMod.stdAddChar (k * (x - t))) * (f x : ℂ) := by
    simp only [centeredDFT, ZMod.dft_apply, smul_eq_mul, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro x hx
    rw [← mul_assoc, ← AddChar.map_add_eq_mul, stdAddChar_conj]
    congr 2
    ring
  rw [hc, Complex.re_sum]
  apply Finset.sum_congr rfl
  intro x hx
  simp only [Complex.mul_re, Complex.star_def, Complex.conj_re,
    Complex.ofReal_re, Complex.ofReal_im, mul_zero, sub_zero, stdAddChar_re]
  ring

noncomputable def supportIndicator (P : ZMod N → Prop) [DecidablePred P]
    (x : ZMod N) : ℝ := if P x then 1 else 0

/-- Positivity of the actual Fourier certificate forces a cyclic pair in
the specified support. No distribution hypothesis is required. -/
theorem cyclic_indicator_pair (P : ZMod N → Prop) [DecidablePred P]
    (t : ZMod N) (modes : Finset (ZMod N))
    (h : (N : ℝ) * ∑ x, (supportIndicator P x) ^ 2 <
      2 * (∑ k ∈ modes, ((centeredDFT (supportIndicator P) t k).re) ^ 2)) :
    ∃ x, P x ∧ P (2 * t - x) := by
  have hc := positive_partial_modes_implies_positive_convolution
    (supportIndicator P) t modes h
  by_contra hno
  have hz : ∑ x, supportIndicator P x * supportIndicator P (2 * t - x) = 0 := by
    apply Finset.sum_eq_zero
    intro x hx
    by_cases hp : P x
    · have hq : ¬ P (2 * t - x) := by
        intro hq
        exact hno ⟨x, hp, hq⟩
      simp [supportIndicator, hq]
    · simp [supportIndicator, hp]
  rw [hz] at hc
  exact (lt_irrefl 0) hc

/-- A size condition removes modular wraparound, giving an ordinary
Goldbach pair from a cyclic prime support pair. -/
theorem natural_prime_pair_of_cyclic_small (A : ℕ) (P : ZMod N → Prop)
    (t : ZMod N)
    (hsupport : ∀ x, P x → Nat.Prime x.val ∧ x.val ≤ A - 2)
    (htarget : (A : ZMod N) = 2 * t)
    (hsize : 2 * (A - 2) < N) (hA : A < N)
    (hpair : ∃ x, P x ∧ P (2 * t - x)) :
    ∃ p q : ℕ, Nat.Prime p ∧ Nat.Prime q ∧ A = p + q := by
  obtain ⟨x, hx, hy⟩ := hpair
  have hp := hsupport x hx
  have hq := hsupport (2 * t - x) hy
  have hsmall : x.val + (2 * t - x).val < N := by omega
  have hz : ((x.val + (2 * t - x).val : ℕ) : ZMod N) = (A : ZMod N) := by
    simp only [Nat.cast_add, ZMod.natCast_zmod_val]
    rw [htarget]
    ring
  have heq := congrArg ZMod.val hz
  simp only [ZMod.val_natCast, Nat.mod_eq_of_lt hsmall, Nat.mod_eq_of_lt hA] at heq
  exact ⟨x.val, (2 * t - x).val, hp.1, hq.1, heq.symm⟩

#print axioms dft_bilinear
#print axioms dft_parseval
#print axioms dft_square_convolution
#print axioms centered_real_identity
#print axioms positive_partial_modes_implies_positive_convolution
#print axioms centered_cosine
#print axioms cyclic_indicator_pair
#print axioms natural_prime_pair_of_cyclic_small

end GoldbachResearch
