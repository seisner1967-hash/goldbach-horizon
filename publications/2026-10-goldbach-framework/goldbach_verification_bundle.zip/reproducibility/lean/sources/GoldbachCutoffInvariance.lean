import GoldbachMoebiusShortLong
import Mathlib.Tactic

/-!
Exact dependence of the actual long-long coefficients on their cutoff.
These are finite algebraic identities. No smallness or analytic estimate
is assumed, and the weights below do not hide a Goldbach hypothesis.
-/

namespace GoldbachResearch.CutoffInvariance

open scoped BigOperators
open GoldbachResearch.MoebiusShortLong

theorem long_double_cutoff_difference {y z n : ℕ}
    (hy : y < n) (hz : z < n) :
    longDouble y n - longDouble z n = shortDouble y n - shortDouble z n := by
  have h₁ := moebius_long_region hy
  have h₂ := moebius_long_region hz
  linarith

def mixedDifference (y z a r : ℕ) : ℤ :=
  (shortDouble y a - shortDouble z a) * longDouble y r +
    longDouble z a * (shortDouble y r - shortDouble z r)

theorem long_product_cutoff_difference {y z a r : ℕ}
    (hya : y < a) (hza : z < a) (hyr : y < r) (hzr : z < r) :
    longDouble y a * longDouble y r - longDouble z a * longDouble z r =
      mixedDifference y z a r := by
  unfold mixedDifference
  rw [← long_double_cutoff_difference hya hza,
      ← long_double_cutoff_difference hyr hzr]
  ring

theorem weighted_cutoff_difference {ι : Type*} (s : Finset ι)
    (a r : ι → ℕ) (w : ι → ℤ) (y z : ℕ)
    (ha : ∀ i ∈ s, y < a i ∧ z < a i)
    (hr : ∀ i ∈ s, y < r i ∧ z < r i) :
    (∑ i ∈ s, w i * (longDouble y (a i) * longDouble y (r i))) -
      (∑ i ∈ s, w i * (longDouble z (a i) * longDouble z (r i))) =
      ∑ i ∈ s, w i * mixedDifference y z (a i) (r i) := by
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro i hi
  rw [← mul_sub, long_product_cutoff_difference
    (ha i hi).1 (ha i hi).2 (hr i hi).1 (hr i hi).2]

theorem cutoff_combination {ι : Type*} (s : Finset ι)
    (y : ι → ℕ) (w : ι → ℤ) (z a r : ℕ)
    (hy : ∀ i ∈ s, y i < a ∧ y i < r) (hza : z < a) (hzr : z < r) :
    (∑ i ∈ s, w i * (longDouble (y i) a * longDouble (y i) r)) =
      (∑ i ∈ s, w i) * (longDouble z a * longDouble z r) +
      ∑ i ∈ s, w i * mixedDifference (y i) z a r := by
  rw [Finset.sum_mul, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i hi
  have h := long_product_cutoff_difference
    (hy i hi).1 hza (hy i hi).2 hzr
  rw [← mul_add]
  congr 1
  linarith

theorem cutoff_combination_mass_one {ι : Type*} (s : Finset ι)
    (y : ι → ℕ) (w : ι → ℤ) (z a r : ℕ)
    (hy : ∀ i ∈ s, y i < a ∧ y i < r) (hza : z < a) (hzr : z < r)
    (hw : ∑ i ∈ s, w i = 1) :
    (∑ i ∈ s, w i * (longDouble (y i) a * longDouble (y i) r)) =
      longDouble z a * longDouble z r +
      ∑ i ∈ s, w i * mixedDifference (y i) z a r := by
  rw [cutoff_combination s y w z a r hy hza hzr, hw, one_mul]

theorem cutoff_combination_mass_zero {ι : Type*} (s : Finset ι)
    (y : ι → ℕ) (w : ι → ℤ) (z a r : ℕ)
    (hy : ∀ i ∈ s, y i < a ∧ y i < r) (hza : z < a) (hzr : z < r)
    (hw : ∑ i ∈ s, w i = 0) :
    (∑ i ∈ s, w i * (longDouble (y i) a * longDouble (y i) r)) =
      ∑ i ∈ s, w i * mixedDifference (y i) z a r := by
  rw [cutoff_combination s y w z a r hy hza hzr, hw, zero_mul, zero_add]

#print axioms long_double_cutoff_difference
#print axioms long_product_cutoff_difference
#print axioms weighted_cutoff_difference
#print axioms cutoff_combination
#print axioms cutoff_combination_mass_one
#print axioms cutoff_combination_mass_zero

end GoldbachResearch.CutoffInvariance
