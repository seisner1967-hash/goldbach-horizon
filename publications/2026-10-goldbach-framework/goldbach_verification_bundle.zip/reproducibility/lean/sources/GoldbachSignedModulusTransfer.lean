import GoldbachCharacterSplit

/-!
# Retain the outer Mobius signs when transferring an arithmetic row

The approximating row c may be the real nonprincipal-character row.
No smallness premise is introduced: a literal weighted error budget
controls the transfer, and inter-modulus cross signs remain explicit.
-/

namespace GoldbachResearch.SignedModulusTransfer

open scoped BigOperators
open Finset ActualArithmetic ArithmeticBridge

noncomputable def signedApproximation (N Q : ℕ) (c : ℕ → ℝ) : ℝ :=
  ∑ k ∈ actualModuli N Q, muReal k * c k

noncomputable def reciprocalMass (N Q : ℕ) : ℝ :=
  ∑ k ∈ actualModuli N Q, 1 / (k : ℝ)

noncomputable def approximationEnergy (N cutoff Q : ℕ) (c : ℕ → ℝ) : ℝ :=
  ∑ k ∈ actualModuli N Q,
    (k : ℝ) * muReal k ^ 2 * (actualEpsilon N cutoff k - c k) ^ 2

/-- The literal completed nonprincipal-character row; modulus zero is inactive. -/
noncomputable def actualCharacterReal (N cutoff U V k : ℕ) : ℝ :=
  if hk : k = 0 then 0 else
    letI : NeZero k := ⟨hk⟩
    (CharacterSplit.characterRow (k := k) N cutoff (Vaughan.typeTwo U V)).re

theorem signed_difference (N cutoff Q : ℕ) (c : ℕ → ℝ) :
    actualSignedError N cutoff Q - signedApproximation N Q c =
      ∑ k ∈ actualModuli N Q, muReal k * (actualEpsilon N cutoff k - c k) := by
  simp only [actualSignedError, signedApproximation, mul_sub, Finset.sum_sub_distrib]

theorem signed_transfer_sq (N cutoff Q : ℕ) (c : ℕ → ℝ) :
    (actualSignedError N cutoff Q - signedApproximation N Q c) ^ 2 ≤
      reciprocalMass N Q * approximationEnergy N cutoff Q c := by
  rw [signed_difference]
  exact weighted_signed_cauchy (actualModuli N Q) (fun k : ℕ => (k : ℝ))
    muReal (fun k => actualEpsilon N cutoff k - c k)
    (fun k hk => actual_modulus_positive hk)

theorem signedApproximation_sq_eq_cross_moduli (N Q : ℕ) (c : ℕ → ℝ) :
    signedApproximation N Q c ^ 2 =
      ∑ k ∈ actualModuli N Q, ∑ j ∈ actualModuli N Q,
        muReal k * muReal j * c k * c j := by
  unfold signedApproximation
  rw [pow_two, Finset.sum_mul_sum]
  apply Finset.sum_congr rfl
  intro k hk
  apply Finset.sum_congr rfl
  intro j hj
  ring

theorem signedApproximation_sq_le_weighted_energy (N Q : ℕ) (c : ℕ → ℝ) :
    signedApproximation N Q c ^ 2 ≤ reciprocalMass N Q *
      ∑ k ∈ actualModuli N Q, (k : ℝ) * muReal k ^ 2 * c k ^ 2 := by
  exact weighted_signed_cauchy (actualModuli N Q) (fun k : ℕ => (k : ℝ))
    muReal c (fun k hk => actual_modulus_positive hk)

theorem approximationEnergy_zero_eq_actualVariance (N cutoff Q : ℕ) :
    approximationEnergy N cutoff Q (fun _ => 0) = actualVariance N cutoff Q := by
  simp [approximationEnergy, actualVariance]

/-- Exact finite transfer to the genuine character row, with its full error budget. -/
theorem actual_signed_character_transfer (N cutoff Q U V : ℕ) :
    (actualSignedError N cutoff Q -
      signedApproximation N Q (actualCharacterReal N cutoff U V)) ^ 2 ≤
      reciprocalMass N Q *
        approximationEnergy N cutoff Q (actualCharacterReal N cutoff U V) :=
  signed_transfer_sq N cutoff Q (actualCharacterReal N cutoff U V)

#print axioms signed_difference
#print axioms signed_transfer_sq
#print axioms signedApproximation_sq_eq_cross_moduli
#print axioms signedApproximation_sq_le_weighted_energy
#print axioms approximationEnergy_zero_eq_actualVariance
#print axioms actual_signed_character_transfer

end GoldbachResearch.SignedModulusTransfer
