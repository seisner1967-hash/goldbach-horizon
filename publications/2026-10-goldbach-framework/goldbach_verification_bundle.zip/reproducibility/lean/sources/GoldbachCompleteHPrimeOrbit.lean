import Mathlib.Tactic
import Mathlib.NumberTheory.ArithmeticFunction

/-! Actual complete Mobius cofactor coefficients and a single-prime orbit.
Every cofactor is retained. No asymptotic hypothesis or analytical bound.
-/
namespace GoldbachResearch.CompleteHPrimeOrbit

open scoped BigOperators
open ArithmeticFunction

noncomputable section

def longMu (y : ℕ) : ArithmeticFunction ℤ :=
  ⟨fun n => if y < n then ArithmeticFunction.moebius n else 0, by simp⟩

def H (y n : ℕ) : ℤ :=
  ((longMu y * longMu y) * (ArithmeticFunction.zeta : ArithmeticFunction ℤ)) n

def rough (y n : ℕ) : Prop := ∀ d, d ∣ n → d ≤ y → d = 1

private theorem af_sub_apply (f g : ArithmeticFunction ℤ) (n : ℕ) :
    (f-g) n = f n-g n := rfl

private theorem longMu_apply (y n : ℕ) :
    longMu y n = if y<n then ArithmeticFunction.moebius n else 0 := rfl

private def atom (p : ℕ) : ArithmeticFunction ℤ :=
  ⟨fun n => if n = 0 then 0 else if n = p then 1 else 0, by simp⟩

private theorem atom_apply {p : ℕ} (hp : p ≠ 0) (n : ℕ) :
    atom p n = if n = p then 1 else 0 := by
  by_cases hn : n = 0
  · subst n
    simp [atom, hp.symm]
  · simp [atom, hn]

private theorem mul_congr_divisors {n : ℕ}
    {f f' g g' : ArithmeticFunction ℤ}
    (hf : ∀ d, d ∣ n → f d = f' d)
    (hg : ∀ d, d ∣ n → g d = g' d) :
    (f * g) n = (f' * g') n := by
  simp only [ArithmeticFunction.mul_apply]
  apply Finset.sum_congr rfl
  intro d hd
  have hprod := (Nat.mem_divisorsAntidiagonal.mp hd).1
  have hd1 : d.1 ∣ n := ⟨d.2, hprod.symm⟩
  have hd2 : d.2 ∣ n := ⟨d.1, by simpa [Nat.mul_comm] using hprod.symm⟩
  rw [hf d.1 hd1, hg d.2 hd2]

private theorem H_congr_divisors {y n : ℕ} (f : ArithmeticFunction ℤ)
    (hf : ∀ d, d ∣ n → longMu y d = f d) :
    H y n = ((f * f) * (ArithmeticFunction.zeta : ArithmeticFunction ℤ)) n := by
  unfold H
  apply mul_congr_divisors
  · intro d hd
    apply mul_congr_divisors
    · intro t ht
      exact hf t (dvd_trans ht hd)
    · intro t ht
      exact hf t (dvd_trans ht hd)
  · intro d hd
    rfl

theorem H_literal_finite_sum (y n : ℕ) :
    H y n = ∑ d ∈ n.divisors, ∑ uv ∈ d.divisorsAntidiagonal,
      (if y < uv.1 then ArithmeticFunction.moebius uv.1 else 0) *
      (if y < uv.2 then ArithmeticFunction.moebius uv.2 else 0) := by
  unfold H
  rw [ArithmeticFunction.coe_mul_zeta_apply]
  simp only [ArithmeticFunction.mul_apply, longMu_apply]

theorem H_rough_formula {y n : ℕ} (hy : 1 ≤ y) (hn : 0 < n)
    (hr : rough y n) :
    H y n = ArithmeticFunction.moebius n + 1 - 2 * (if n = 1 then 1 else 0) := by
  have hf : ∀ d, d ∣ n → longMu y d =
      (ArithmeticFunction.moebius - (1 : ArithmeticFunction ℤ)) d := by
    intro d hd
    by_cases hd1 : d = 1
    · subst d
      simp [longMu_apply, af_sub_apply, not_lt.mpr hy,
        ArithmeticFunction.moebius_apply_one]
    · have hgt : y < d := by
        by_contra hh
        exact hd1 (hr d hd (not_lt.mp hh))
      simp [longMu_apply, hgt, af_sub_apply,
        ArithmeticFunction.one_apply_ne hd1]
  have hc :
      ((ArithmeticFunction.moebius - (1 : ArithmeticFunction ℤ)) *
        (ArithmeticFunction.moebius - 1) *
        (ArithmeticFunction.zeta : ArithmeticFunction ℤ)) =
      ArithmeticFunction.moebius + ArithmeticFunction.zeta - (1 + 1) := by
    calc
      _ = ArithmeticFunction.moebius *
          (ArithmeticFunction.moebius * ArithmeticFunction.zeta) -
          (ArithmeticFunction.moebius * ArithmeticFunction.zeta) -
          (ArithmeticFunction.moebius * ArithmeticFunction.zeta) +
          ArithmeticFunction.zeta := by ring
      _ = _ := by rw [ArithmeticFunction.moebius_mul_coe_zeta]; ring
  rw [H_congr_divisors _ hf, hc]
  simp only [af_sub_apply, ArithmeticFunction.add_apply,
    ArithmeticFunction.natCoe_apply, ArithmeticFunction.zeta_apply_ne hn.ne',
    Nat.cast_one, ArithmeticFunction.one_apply]
  ring

theorem prime_divisor_orbit_partition {p L k : ℕ} (hp : p.Prime)
    (hk : k ∣ p * L) :
    (k ∣ L ∧ ¬p ∣ k) ∨ ∃ x, x ∣ L ∧ k = p * x := by
  by_cases hpk : p ∣ k
  · rcases hpk with ⟨x, rfl⟩
    right
    exact ⟨x, (Nat.mul_dvd_mul_iff_left hp.pos).mp hk, rfl⟩
  · left
    have hcop : k.Coprime p := (hp.coprime_iff_not_dvd.mpr hpk).symm
    exact ⟨hcop.dvd_mul_left.mp hk, hpk⟩

private theorem small_divisors_pe {y p e : ℕ} (hp : p.Prime)
    (hr : rough y e) : ∀ d, d ∣ p * e → d ≤ y → d = 1 ∨ d = p := by
  intro d hd hdy
  rcases prime_divisor_orbit_partition hp hd with h | ⟨x,hxe,hdx⟩
  · exact Or.inl (hr d h.1 hdy)
  · have hxd : x ≤ d := by
      rw [hdx]
      exact Nat.le_mul_of_pos_left x hp.pos
    have hx1 := hr x hxe (hxd.trans hdy)
    right
    simpa [hx1] using hdx

private theorem atom_convolve {p e : ℕ} (hp : p ≠ 0) (he : e ≠ 0)
    (f : ArithmeticFunction ℤ) : (atom p * f) (p * e) = f e := by
  rw [ArithmeticFunction.mul_apply, Finset.sum_eq_single (p,e)]
  · simp [atom_apply hp]
  · intro d hd hne
    have hprod := (Nat.mem_divisorsAntidiagonal.mp hd).1
    have hd1 : d.1 ≠ p := by
      intro hh
      have hd2 : d.2 = e := Nat.eq_of_mul_eq_mul_left (Nat.pos_of_ne_zero hp)
        (by simpa [hh] using hprod)
      exact hne (Prod.ext hh hd2)
    simp [atom_apply hp, hd1]
  · intro hh
    exact False.elim (hh (Nat.mem_divisorsAntidiagonal.mpr
      ⟨rfl, Nat.mul_ne_zero hp he⟩))

private theorem atom_zeta_of_not_dvd {p n : ℕ} (hp : p ≠ 0)
    (hpn : ¬p ∣ n) :
    (atom p * (ArithmeticFunction.zeta : ArithmeticFunction ℤ)) n = 0 := by
  rw [ArithmeticFunction.coe_mul_zeta_apply]
  apply Finset.sum_eq_zero
  intro d hd
  have hdp : d ≠ p := by
    intro hh
    exact hpn (hh ▸ Nat.dvd_of_mem_divisors hd)
  simp [atom_apply hp, hdp]

private theorem H_one_small_prime_gt_one {y p e : ℕ} (hy : 1 ≤ y) (hp : p.Prime)
    (hpy : p ≤ y) (he : 1 < e) (hr : rough y e) :
    H y (p * e) = -H y e := by
  have hp0 := hp.ne_zero
  have he0 : e ≠ 0 := by omega
  have hpe0 := Nat.mul_ne_zero hp0 he0
  have hpe1 : p * e ≠ 1 := by nlinarith [hp.two_le]
  have hpep : p * e ≠ p := by nlinarith [hp.pos]
  have hpn : ¬p ∣ e := by
    intro hh
    exact hp.ne_one (hr p hh hpy)
  let A := atom p
  have hf : ∀ d, d ∣ p * e → longMu y d =
      (ArithmeticFunction.moebius - (1 : ArithmeticFunction ℤ) + A) d := by
    intro d hd
    by_cases hd1 : d = 1
    · subst d
      simp [longMu_apply, A, atom_apply hp0, ArithmeticFunction.add_apply,
        af_sub_apply, not_lt.mpr hy,
        ArithmeticFunction.moebius_apply_one, hp.ne_one.symm]
    · by_cases hdp : d = p
      · subst d
        simp [longMu_apply, A, atom_apply hp0, ArithmeticFunction.add_apply,
          af_sub_apply, not_lt.mpr hpy,
          ArithmeticFunction.moebius_apply_prime hp,
          ArithmeticFunction.one_apply_ne hp.ne_one]
      · have hgt : y < d := by
          by_contra hh
          rcases small_divisors_pe hp hr d hd (not_lt.mp hh) with hh | hh
          · exact hd1 hh
          · exact hdp hh
        simp [longMu_apply, A, atom_apply hp0, hgt, ArithmeticFunction.add_apply,
          af_sub_apply, ArithmeticFunction.one_apply_ne hd1, hdp]
  have hc :
      ((ArithmeticFunction.moebius - (1 : ArithmeticFunction ℤ) + A) *
       (ArithmeticFunction.moebius - 1 + A) *
       (ArithmeticFunction.zeta : ArithmeticFunction ℤ)) =
      ArithmeticFunction.moebius - 1 - 1 + ArithmeticFunction.zeta + A + A -
      (A * ArithmeticFunction.zeta) - (A * ArithmeticFunction.zeta) +
      (A * A * ArithmeticFunction.zeta) := by
    calc
      _ = ArithmeticFunction.moebius *
          (ArithmeticFunction.moebius * ArithmeticFunction.zeta) -
          (ArithmeticFunction.moebius * ArithmeticFunction.zeta) -
          (ArithmeticFunction.moebius * ArithmeticFunction.zeta) +
          ArithmeticFunction.zeta + A *
          (ArithmeticFunction.moebius * ArithmeticFunction.zeta) + A *
          (ArithmeticFunction.moebius * ArithmeticFunction.zeta) -
          (A * ArithmeticFunction.zeta) - (A * ArithmeticFunction.zeta) +
          (A * A * ArithmeticFunction.zeta) := by ring
      _ = _ := by rw [ArithmeticFunction.moebius_mul_coe_zeta]; simp
  have hm : ArithmeticFunction.moebius (p * e) = -ArithmeticFunction.moebius e := by
    rw [ArithmeticFunction.isMultiplicative_moebius.map_mul_of_coprime
      (hp.coprime_iff_not_dvd.mpr hpn), ArithmeticFunction.moebius_apply_prime hp]
    ring
  have ha : A (p*e) = 0 := by simp [A, atom_apply hp0, hpep]
  have haz : (A * (ArithmeticFunction.zeta : ArithmeticFunction ℤ)) (p*e) = 1 := by
    change (atom p * (ArithmeticFunction.zeta : ArithmeticFunction ℤ)) (p*e) = 1
    rw [atom_convolve hp0 he0]
    simp [ArithmeticFunction.zeta_apply_ne he0]
  have haaz : (A * A * (ArithmeticFunction.zeta : ArithmeticFunction ℤ)) (p*e) = 0 := by
    change (atom p * atom p * (ArithmeticFunction.zeta : ArithmeticFunction ℤ)) (p*e) = 0
    rw [mul_assoc, atom_convolve hp0 he0, atom_zeta_of_not_dvd hp0 hpn]
  rw [H_congr_divisors _ hf, hc]
  simp only [ArithmeticFunction.add_apply, af_sub_apply]
  rw [hm, ArithmeticFunction.one_apply_ne hpe1,
    ArithmeticFunction.natCoe_apply, ArithmeticFunction.zeta_apply_ne hpe0,
    Nat.cast_one, ha, haz, haaz,
    H_rough_formula hy (by omega : 0<e) hr, if_neg (by omega : e≠1)]
  ring

private theorem H_below_cutoff {y n : ℕ} (hn : n ≤ y) : H y n = 0 := by
  by_cases hn0 : n = 0
  · subst n
    simp [H]
  · have hf : ∀ d, d ∣ n → longMu y d = (0 : ArithmeticFunction ℤ) d := by
      intro d hd
      have hdy := (Nat.le_of_dvd (Nat.pos_of_ne_zero hn0) hd).trans hn
      simp [longMu_apply, not_lt.mpr hdy]
    rw [H_congr_divisors _ hf]
    simp

theorem H_one_small_prime {y p e : ℕ} (hy : 1 ≤ y) (hp : p.Prime)
    (hpy : p ≤ y) (he : 0 < e) (hr : rough y e) :
    H y (p * e) = -H y e := by
  by_cases he1 : e = 1
  · subst e
    simp only [Nat.mul_one, H_below_cutoff hpy, H_below_cutoff hy,
      neg_zero]
  · exact H_one_small_prime_gt_one hy hp hpy (by omega) hr

private theorem H_rough_nonnegative {y n : ℕ} (hy : 1 ≤ y) (hn : 0 < n)
    (hr : rough y n) : 0 ≤ H y n := by
  rw [H_rough_formula hy hn hr]
  by_cases hn1 : n = 1
  · simp [hn1, ArithmeticFunction.moebius_apply_one]
  · simp only [if_neg hn1, mul_zero, sub_zero]
    rcases ArithmeticFunction.moebius_eq_or n with h | h | h <;> simp [h]

theorem actual_complete_orbit_upper {y p a e b : ℕ}
    (hy : 1 ≤ y) (hp : p.Prime) (hpy : p ≤ y)
    (ha : 0 < a) (hra : rough y a) (he : 0 < e) (hre : rough y e)
    (hb : 1 ≤ b) (low high : ℝ) (hlow : 0 ≤ low) :
    0 ≤ (H y a : ℝ) * Real.log b * (H y e : ℝ) * low * Real.log p ∧
    (H y a : ℝ) * Real.log b *
      ((H y e : ℝ) * high * Real.log e +
       (H y (p*e) : ℝ) * low * Real.log (p*e))
      ≤ (H y a : ℝ) * Real.log b * (H y e : ℝ) *
        (max (high-low) 0 * Real.log e - low * Real.log p) := by
  have hA : 0 ≤ (H y a : ℝ) := by
    exact_mod_cast H_rough_nonnegative hy ha hra
  have hE : 0 ≤ (H y e : ℝ) := by
    exact_mod_cast H_rough_nonnegative hy he hre
  have hB : 0 ≤ Real.log (b : ℝ) := Real.log_nonneg (by exact_mod_cast hb)
  have hL : 0 ≤ Real.log (e : ℝ) := Real.log_nonneg (by exact_mod_cast he)
  have hG : 0 ≤ (H y a : ℝ) * Real.log b * (H y e : ℝ) :=
    mul_nonneg (mul_nonneg hA hB) hE
  have hcomp : (high-low)*Real.log e ≤ max (high-low) 0 * Real.log e :=
    mul_le_mul_of_nonneg_right (le_max_left _ _) hL
  have hlpe : Real.log ((p : ℝ)*(e : ℝ)) = Real.log (p : ℝ) + Real.log (e : ℝ) :=
    Real.log_mul (by exact_mod_cast hp.ne_zero) (by exact_mod_cast he.ne')
  constructor
  · exact mul_nonneg (mul_nonneg hG hlow)
      (Real.log_nonneg (by exact_mod_cast hp.one_le))
  · rw [H_one_small_prime hy hp hpy he hre, Int.cast_neg, hlpe]
    calc
      _ = ((H y a : ℝ) * Real.log b * (H y e : ℝ)) *
          ((high-low)*Real.log e-low*Real.log p) := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_left (by linarith) hG

end
end GoldbachResearch.CompleteHPrimeOrbit

#print axioms GoldbachResearch.CompleteHPrimeOrbit.H_literal_finite_sum
#print axioms GoldbachResearch.CompleteHPrimeOrbit.H_rough_formula
#print axioms GoldbachResearch.CompleteHPrimeOrbit.prime_divisor_orbit_partition
#print axioms GoldbachResearch.CompleteHPrimeOrbit.H_one_small_prime
#print axioms GoldbachResearch.CompleteHPrimeOrbit.actual_complete_orbit_upper
