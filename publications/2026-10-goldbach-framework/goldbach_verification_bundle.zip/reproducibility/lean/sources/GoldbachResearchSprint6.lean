import GoldbachResearchSprint5
import GoldbachVaughan
import GoldbachHeathBrown
import GoldbachBilinear
import GoldbachTypeIIAssembly
import GoldbachTypeIIVariance

/-!
# Goldbach checkpoint 6: the signed arithmetic bilinear structure

Vaughan's identity and the J=2 Heath--Brown identities are derived for
Mathlib's actual arithmetic functions. The literal Type II row is reindexed
onto its active rectangle. A one-Cauchy dispersion preserves all four
Möbius signs and is connected to the actual modulus-weighted variance.

The Type I arbitrary-logarithmic-saving estimate is independently reviewed
in written notes, using classical Davenport. It is not formalized in Lean.
No small bound for the signed Type II dispersion is proved or postulated.
No proof of Goldbach or major external mathematical breakthrough is claimed.
-/

#print axioms GoldbachResearch.Vaughan.vaughan_identity
#print axioms GoldbachResearch.HeathBrown.vonMangoldt_heath_brown_two
#print axioms GoldbachResearch.TypeIIAssembly.actual_signedRow_typeTwo_eq_active_bilinear
#print axioms GoldbachResearch.TypeIIAssembly.actualSignedDispersion_eq_four_moebius_signs
#print axioms GoldbachResearch.TypeIIVariance.actualVariance_le_typeI_and_signed_dispersion
#print axioms GoldbachResearch.Bilinear.complement_rectangle_determinant
