import GoldbachScalarProjection

/-!
Exact disjoint large-factor boundaries for the literal completed C scalar.
The cofactor budget below takes an explicit pointwise kernel majorant; it
does not posit or prove a signed cancellation estimate.
-/

namespace GoldbachResearch.CofactorBoundary

open scoped BigOperators
open Finset ActualArithmetic TypeIIAssembly ShiftedDispersion CharacterDispersion ScalarProjection

noncomputable section

def boundaryAP (N a b : ℕ) : Prop := a * b < N ∧ N - a * b < a

def boundaryBP (N a b : ℕ) : Prop :=
  a * b < N ∧ a ≤ N - a * b ∧ N - a * b < b

def coreP (N a b : ℕ) : Prop :=
  a * b < N ∧ a ≤ N - a * b ∧ b ≤ N - a * b

def regionSum (I J : Finset ℕ) (w : ℕ → ℝ) (x : ℕ → ℕ → ℝ)
    (P : ℕ → ℕ → Prop) : ℝ := by
  classical
  exact ∑ b ∈ J, w b * ∑ a ∈ I, if P a b then x a b else 0

def actualEntry (N cutoff Q a b : ℕ) : ℝ :=
  muReal a * arithmeticKernel N (fullCharacterWeight N cutoff Q) a b

def actualBoundaryA (N cutoff Q U V : ℕ) : ℝ :=
  regionSum (activeFirst N U) (cappedSecond N U V) (Vaughan.beta V)
    (actualEntry N cutoff Q) (boundaryAP N)

def actualBoundaryB (N cutoff Q U V : ℕ) : ℝ :=
  regionSum (activeFirst N U) (cappedSecond N U V) (Vaughan.beta V)
    (actualEntry N cutoff Q) (boundaryBP N)

def actualCore (N cutoff Q U V : ℕ) : ℝ :=
  regionSum (activeFirst N U) (cappedSecond N U V) (Vaughan.beta V)
    (actualEntry N cutoff Q) (coreP N)

def boundaryColumn (I : Finset ℕ) (N b : ℕ) (x : ℕ → ℝ) : ℝ := by
  classical
  exact ∑ a ∈ I, if boundaryAP N a b then x a else 0

def cofactorWindow (N b : ℕ) : Finset ℕ :=
  (Icc 1 ((N - 1) / (b + 1))).filter fun m => m % b = N % b

theorem large_factor_iff_cofactor_cap {N a b : ℕ} (hb : 0 < b) (hab : a * b < N) :
    (N - a * b < a ↔ (b + 1) * (N - a * b) < N) ∧
    (N - a * b < a ↔ N - a * b ≤ (N - 1) / (b + 1)) := by
  have hsum : N - a * b + a * b = N := Nat.sub_add_cancel hab.le
  have hiff : N - a * b < a ↔ (b + 1) * (N - a * b) < N := by
    constructor
    · intro ha
      nlinarith
    · intro hm
      by_contra ha
      have ha' : a ≤ N - a * b := Nat.le_of_not_gt ha
      nlinarith
  refine ⟨hiff, hiff.trans ?_⟩
  rw [Nat.le_div_iff_mul_le (by omega : 0 < b + 1)]
  have hNpos : 1 ≤ N := by omega
  have hsub : N - 1 + 1 = N := Nat.sub_add_cancel hNpos
  constructor <;> intro h <;> nlinarith

theorem reflection_injective {N n n' : ℕ} (hn : n ≤ N) (hn' : n' ≤ N)
    (heq : N - n = N - n') : n = n' := by omega

theorem affine_cofactor_injective {N a a' b : ℕ} (hb : 0 < b)
    (ha : a * b < N) (ha' : a' * b < N)
    (heq : N - a * b = N - a' * b) : a = a' := by
  have hprod : a * b = a' * b := reflection_injective ha.le ha'.le heq
  exact Nat.eq_of_mul_eq_mul_right hb hprod

theorem cofactor_residue {N a b : ℕ} (hab : a * b < N) :
    (N - a * b) % b = N % b := by
  have hsum := Nat.sub_add_cancel hab.le
  have hm := congrArg (fun x : ℕ => x % b) hsum
  simpa [Nat.add_mod] using hm

theorem cofactorWindow_coprime {N b m : ℕ} (hNb : N.Coprime b)
    (hm : m ∈ cofactorWindow N b) : m.Coprime b := by
  have hmod := (mem_filter.mp hm).2
  have hgcd : Nat.gcd b m = Nat.gcd b N := by
    rw [Nat.gcd_rec b m, Nat.gcd_rec b N, hmod]
  show Nat.gcd m b = 1
  rw [Nat.gcd_comm m b, hgcd]
  exact hNb.symm

theorem core_complement_quadratic {N a b : ℕ} (hcore : coreP N a b) :
    N ≤ (N - a * b) * (N - a * b + 1) := by
  have hsum := Nat.sub_add_cancel hcore.1.le
  have hprod := Nat.mul_le_mul hcore.2.1 hcore.2.2
  nlinarith

theorem three_region_partition (I J : Finset ℕ) (N : ℕ) (w : ℕ → ℝ)
    (x : ℕ → ℕ → ℝ) (hout : ∀ a ∈ I, ∀ b ∈ J, N ≤ a * b → x a b = 0) :
    weightedContraction J w (fun b => ∑ a ∈ I, x a b) =
      regionSum I J w x (boundaryAP N) + regionSum I J w x (boundaryBP N) +
        regionSum I J w x (coreP N) := by
  classical
  have hpoint (a : ℕ) (ha : a ∈ I) (b : ℕ) (hb : b ∈ J) :
      x a b = (if boundaryAP N a b then x a b else 0) +
        (if boundaryBP N a b then x a b else 0) + (if coreP N a b then x a b else 0) := by
    by_cases hab : a * b < N
    · by_cases ham : N - a * b < a
      · have hma : ¬a ≤ N - a * b := by omega
        simp [boundaryAP, boundaryBP, coreP, hab, ham, hma]
      · have hma : a ≤ N - a * b := by omega
        by_cases hbm : N - a * b < b
        · have hmb : ¬b ≤ N - a * b := by omega
          simp [boundaryAP, boundaryBP, coreP, hab, ham, hma, hbm, hmb]
        · have hmb : b ≤ N - a * b := by omega
          simp [boundaryAP, boundaryBP, coreP, hab, ham, hma, hbm, hmb]
    · have hz := hout a ha b hb (by omega)
      simp [boundaryAP, boundaryBP, coreP, hab, hz]
  unfold weightedContraction regionSum
  calc
    (∑ b ∈ J, w b * ∑ a ∈ I, x a b) =
        ∑ b ∈ J, w b * ∑ a ∈ I,
          ((if boundaryAP N a b then x a b else 0) +
           (if boundaryBP N a b then x a b else 0) +
           (if coreP N a b then x a b else 0)) := by
      apply sum_congr rfl
      intro b hb
      congr 1
      apply sum_congr rfl
      intro a ha
      exact hpoint a ha b hb
    _ = _ := by
      simp_rw [Finset.sum_add_distrib, mul_add, Finset.sum_add_distrib]

theorem boundary_column_abs_le_cofactor_budget (I : Finset ℕ) (N b : ℕ)
    (hb : 0 < b) (x H : ℕ → ℝ)
    (hH : ∀ m ∈ cofactorWindow N b, 0 ≤ H m)
    (hx : ∀ a ∈ I, boundaryAP N a b → |x a| ≤ H (N - a * b)) :
    |boundaryColumn I N b x| ≤
      ∑ m ∈ cofactorWindow N b, H m := by
  classical
  unfold boundaryColumn
  let S := I.filter fun a => boundaryAP N a b
  have hsum : (∑ a ∈ I, if boundaryAP N a b then x a else 0) = ∑ a ∈ S, x a := by
    dsimp [S]
    rw [sum_filter]
  have hinj : Set.InjOn (fun a => N - a * b) S := by
    intro a ha a' ha' heq
    have haB := (mem_filter.mp ha).2
    have ha'B := (mem_filter.mp ha').2
    exact affine_cofactor_injective hb haB.1 ha'B.1 heq
  have hsubset : S.image (fun a => N - a * b) ⊆ cofactorWindow N b := by
    intro m hm
    rcases mem_image.mp hm with ⟨a, ha, rfl⟩
    have haB := (mem_filter.mp ha).2
    have hab := haB.1
    exact mem_filter.mpr ⟨mem_Icc.mpr
      ⟨by omega, (large_factor_iff_cofactor_cap hb haB.1).2.mp haB.2⟩, cofactor_residue hab⟩
  rw [hsum]
  calc
    |∑ a ∈ S, x a| ≤ ∑ a ∈ S, |x a| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ a ∈ S, H (N - a * b) := by
      apply sum_le_sum
      intro a ha
      exact hx a (mem_filter.mp ha).1 (mem_filter.mp ha).2
    _ = ∑ m ∈ S.image (fun a => N - a * b), H m := (Finset.sum_image hinj).symm
    _ ≤ ∑ m ∈ cofactorWindow N b, H m :=
      Finset.sum_le_sum_of_subset_of_nonneg hsubset (fun m hm _ => hH m hm)

theorem actualScalar_three_regions (N cutoff Q U V : ℕ) :
    actualScalar N cutoff Q U V = actualBoundaryA N cutoff Q U V +
      actualBoundaryB N cutoff Q U V + actualCore N cutoff Q U V := by
  rw [actualScalar_eq_weightedContraction]
  apply three_region_partition (activeFirst N U) (cappedSecond N U V) N
    (Vaughan.beta V) (actualEntry N cutoff Q)
  intro a ha b hb hab
  simp [actualEntry, arithmeticKernel, fullCharacterWeight_outside hab]

theorem actualEntry_abs_le_kernel (N cutoff Q a b : ℕ) :
    |actualEntry N cutoff Q a b| ≤ |fullCharacterWeight N cutoff Q (a * b)| := by
  have hmu (n : ℕ) : |muReal n| ≤ 1 := by
    unfold muReal
    exact_mod_cast (ArithmeticFunction.abs_moebius_le_one (n := n))
  unfold actualEntry arithmeticKernel
  rw [abs_mul, abs_mul]
  have hprod : |muReal a| * |muReal (N - a * b)| ≤ 1 := by
    nlinarith [abs_nonneg (muReal a), abs_nonneg (muReal (N - a * b)), hmu a, hmu (N - a * b)]
  calc
    |muReal a| * (|muReal (N - a * b)| * |fullCharacterWeight N cutoff Q (a * b)|) =
        (|muReal a| * |muReal (N - a * b)|) * |fullCharacterWeight N cutoff Q (a * b)| := by ring
    _ ≤ 1 * |fullCharacterWeight N cutoff Q (a * b)| :=
      mul_le_mul_of_nonneg_right hprod (abs_nonneg _)
    _ = _ := one_mul _

/- The pointwise kernel majorant and its nonnegativity are explicit premises.
   No unknown signed correlation estimate is encoded in this implication. -/
theorem actualBoundaryA_abs_le_cofactor_budget (N cutoff Q U V : ℕ) (H : ℕ → ℕ → ℝ)
    (hH : ∀ b ∈ cappedSecond N U V, ∀ m ∈ cofactorWindow N b, 0 ≤ H b m)
    (hG : ∀ b ∈ cappedSecond N U V, ∀ a ∈ activeFirst N U,
      boundaryAP N a b → |fullCharacterWeight N cutoff Q (a * b)| ≤ H b (N - a * b)) :
    |actualBoundaryA N cutoff Q U V| ≤
      ∑ b ∈ cappedSecond N U V, Vaughan.beta V b *
        ∑ m ∈ cofactorWindow N b, H b m := by
  classical
  unfold actualBoundaryA regionSum
  calc
    |∑ b ∈ cappedSecond N U V, Vaughan.beta V b * ∑ a ∈ activeFirst N U,
        if boundaryAP N a b then actualEntry N cutoff Q a b else 0| ≤
        ∑ b ∈ cappedSecond N U V, |Vaughan.beta V b * ∑ a ∈ activeFirst N U,
          if boundaryAP N a b then actualEntry N cutoff Q a b else 0| :=
      Finset.abs_sum_le_sum_abs _ _
    _ ≤ _ := by
      apply sum_le_sum
      intro b hb
      rw [abs_mul, abs_of_nonneg (Vaughan.beta_nonneg V b)]
      apply mul_le_mul_of_nonneg_left _ (Vaughan.beta_nonneg V b)
      have hbV : V < b := (mem_filter.mp (mem_filter.mp hb).1).2
      apply boundary_column_abs_le_cofactor_budget (activeFirst N U) N b
        (by omega : 0 < b) (fun a => actualEntry N cutoff Q a b) (H b) (hH b hb)
      intro a ha hboundary
      exact (actualEntry_abs_le_kernel N cutoff Q a b).trans (hG b hb a ha hboundary)

#print axioms large_factor_iff_cofactor_cap
#print axioms reflection_injective
#print axioms affine_cofactor_injective
#print axioms cofactor_residue
#print axioms cofactorWindow_coprime
#print axioms core_complement_quadratic
#print axioms three_region_partition
#print axioms boundary_column_abs_le_cofactor_budget
#print axioms actualScalar_three_regions
#print axioms actualEntry_abs_le_kernel
#print axioms actualBoundaryA_abs_le_cofactor_budget

end
end GoldbachResearch.CofactorBoundary
