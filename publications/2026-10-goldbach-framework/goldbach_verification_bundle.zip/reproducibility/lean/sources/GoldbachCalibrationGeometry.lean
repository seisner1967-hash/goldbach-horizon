import GoldbachTypeIIAssembly
import Mathlib.Order.Interval.Finset.Nat
import Mathlib.Data.Nat.Sqrt

/-!
# Exact balanced-window coverage after a cutoff

The geometry is fixed before evaluating arithmetic correlations. Cardinal
thresholds certify coverage only, never statistical significance or an
asymptotic cancellation estimate. H is the chosen upper endpoint; an actual
application takes H=floor(sqrt(N-cutoff*k-1)).
-/

namespace GoldbachResearch.CalibrationGeometry

open Finset

def liveWindow (H U : ℕ) : Finset ℕ := Ioc (max (H / 2) U) H

theorem liveWindow_membership (H U a : ℕ) :
    a ∈ liveWindow H U ↔ H / 2 < a ∧ a ≤ H ∧ U < a := by
  simp only [liveWindow, Finset.mem_Ioc, max_lt_iff]
  omega

theorem liveWindow_card (H U : ℕ) :
    (liveWindow H U).card = H - max (H / 2) U := by
  simp [liveWindow]

/-- A positive prescribed row count has an exact natural-number criterion. -/
theorem liveWindow_card_ge_iff (H U r : ℕ) (hr : 0 < r) :
    r ≤ (liveWindow H U).card ↔ max (H / 2) U + r ≤ H := by
  rw [liveWindow_card]
  omega

theorem liveWindow_empty_of_cutoff (H U : ℕ) (hU : H ≤ U) :
    liveWindow H U = ∅ := by
  apply Finset.card_eq_zero.mp
  rw [liveWindow_card]
  have hu : U ≤ max (H / 2) U := le_max_right _ _
  omega

theorem liveRectangle_card (H U V : ℕ) :
    ((liveWindow H U).product (liveWindow H V)).card =
      (H - max (H / 2) U) * (H - max (H / 2) V) := by
  have hp : ((liveWindow H U).product (liveWindow H V)).card =
      (liveWindow H U).card * (liveWindow H V).card :=
    Finset.card_product (liveWindow H U) (liveWindow H V)
  rw [hp, liveWindow_card, liveWindow_card]

/-- Geometric support is independent of whether mu or the centered row vanishes. -/
theorem liveRectangle_strict_support (N cutoff k H U V a b : ℕ)
    (hcap : H * H + cutoff * k < N)
    (ha : a ∈ liveWindow H U) (hb : b ∈ liveWindow H V) :
    U < a ∧ V < b ∧ 1 ≤ a * b ∧ a * b + cutoff * k < N := by
  have ha' := (liveWindow_membership H U a).mp ha
  have hb' := (liveWindow_membership H V b).mp hb
  have ha0 : 0 < a := by omega
  have hb0 : 0 < b := by omega
  have hp := Nat.mul_pos ha0 hb0
  have hab : a * b ≤ H * H := Nat.mul_le_mul ha'.2.1 hb'.2.1
  exact ⟨ha'.2.2, hb'.2.2, by omega, by omega⟩

/-- The integer square-root endpoint gives the strict complement cutoff. -/
theorem canonical_sqrt_cap (N cutoff k : ℕ) (hcut : cutoff * k < N) :
    Nat.sqrt (N - cutoff * k - 1) * Nat.sqrt (N - cutoff * k - 1) +
      cutoff * k < N := by
  have hs := Nat.sqrt_le (N - cutoff * k - 1)
  omega

/-- Support for the literal canonical cell used by the numerical script. -/
theorem canonicalRectangle_strict_support (N cutoff k U V a b : ℕ)
    (hcut : cutoff * k < N)
    (ha : a ∈ liveWindow (Nat.sqrt (N - cutoff * k - 1)) U)
    (hb : b ∈ liveWindow (Nat.sqrt (N - cutoff * k - 1)) V) :
    U < a ∧ V < b ∧ 1 ≤ a * b ∧ a * b + cutoff * k < N := by
  exact liveRectangle_strict_support N cutoff k _ U V a b
    (canonical_sqrt_cap N cutoff k hcut) ha hb

#print axioms liveWindow_membership
#print axioms liveWindow_card
#print axioms liveWindow_card_ge_iff
#print axioms liveWindow_empty_of_cutoff
#print axioms liveRectangle_card
#print axioms liveRectangle_strict_support
#print axioms canonical_sqrt_cap
#print axioms canonicalRectangle_strict_support

end GoldbachResearch.CalibrationGeometry
