import GoldbachResearchRoot
import GoldbachRamanujanFourier
import GoldbachSignedKernel
import GoldbachSmoothingVariance
import GoldbachFoldedWindow

/-!
# Goldbach research checkpoint 5

The literal unsmoothed complete-period proxy variance, the folded interval
kernel, and the actual signed arithmetic cofactor identities are proved.
These modules do not assemble the per-conductor smoothed proxy inequality,
the short-average large sieve, or signed shifted-prime cancellation.
The Brun--Titchmarsh log-cubed diagonal refinement is a separate written
analytic proof; the available Lean arithmetic diagonal cap remains log-fourth.
No proof of Goldbach or external novelty is claimed.
-/

#print axioms GoldbachResearch.RamanujanFourier.terminal_complete_period_variance_polynomial_bound
#print axioms GoldbachResearch.SignedKernel.actualSignedError_cofactor_decomposition
#print axioms GoldbachResearch.SmoothingVariance.periodSmoothingVariance_eq_frequency_sum
#print axioms GoldbachResearch.FoldedWindow.foldedFejer_nonzero_frequency_energy_le
#print axioms GoldbachResearch.Diagonal.actualDiagonal_le_two_N_Q_log_four
