import GoldbachKloostermanGeometry

/-! Exact co-modulus support in the high-conductor region. No cancellation. -/

namespace GoldbachResearch.ConductorSupport

theorem high_conductor_forces_one {N alpha Q q n r : ℕ}
    (hr : 1 ≤ r) (hcap : q * r ≤ Q) (hstrict : n + alpha * (q * r) < N)
    (hhigh : Q < 2 * q ∨ N ≤ n + 2 * alpha * q) : r = 1 := by
  by_contra hne
  have hr2 : 2 ≤ r := by omega
  have hqr : 2 * q ≤ q * r := by nlinarith [Nat.mul_le_mul_left q hr2]
  rcases hhigh with hQ | hN
  · omega
  · have halpha : alpha * (2 * q) ≤ alpha * (q * r) :=
      Nat.mul_le_mul_left alpha hqr
    nlinarith

theorem high_conductor_admissible_iff {N alpha Q q n r : ℕ}
    (hr : 1 ≤ r) (hqcap : q ≤ Q) (hfirst : n + alpha * q < N)
    (hhigh : Q < 2 * q ∨ N ≤ n + 2 * alpha * q) :
    (q * r ≤ Q ∧ n + alpha * (q * r) < N) ↔ r = 1 := by
  constructor
  · intro h
    exact high_conductor_forces_one hr h.1 h.2 hhigh
  · intro h
    subst r
    simpa only [Nat.mul_one] using And.intro hqcap hfirst

def coModulusSupport (N alpha Q q n : ℕ) : Finset ℕ :=
  (Finset.range (Q + 1)).filter fun r =>
    1 ≤ r ∧ q * r ≤ Q ∧ n + alpha * (q * r) < N

theorem high_conductor_support_singleton {N alpha Q q n : ℕ}
    (hq : 0 < q) (hqcap : q ≤ Q) (hfirst : n + alpha * q < N)
    (hhigh : Q < 2 * q ∨ N ≤ n + 2 * alpha * q) :
    coModulusSupport N alpha Q q n = {1} := by
  ext r
  simp only [coModulusSupport, Finset.mem_filter, Finset.mem_range,
    Finset.mem_singleton]
  constructor
  · intro h
    exact high_conductor_forces_one h.2.1 h.2.2.1 h.2.2.2 hhigh
  · intro h
    subst r
    have hQ : 1 ≤ Q := by omega
    simp only [Nat.mul_one]
    exact ⟨by omega, le_rfl, hqcap, hfirst⟩

#print axioms high_conductor_forces_one
#print axioms high_conductor_admissible_iff
#print axioms high_conductor_support_singleton

end GoldbachResearch.ConductorSupport
