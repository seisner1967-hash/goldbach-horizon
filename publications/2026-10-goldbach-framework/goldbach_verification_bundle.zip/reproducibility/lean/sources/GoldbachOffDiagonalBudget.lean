import GoldbachCharacterDispersion
import GoldbachTwoIndexSectors
import Mathlib.Data.Nat.Choose.Basic

/-!
Finite unweighted C-energy and its quantitative off-diagonal obligation.
The coherent diagonal budget is a PREMISE in the terminal bound below.
The central positive off-diagonal estimate is neither assumed implicitly nor proved.
-/

namespace GoldbachResearch.OffDiagonalBudget

open scoped BigOperators
open Finset ActualArithmetic TypeIIAssembly ShiftedDispersion CharacterDispersion

noncomputable section

def logBudget (N : ℕ) : ℝ := 1 + Real.log N

def betaSquareMass (N U V : ℕ) : ℝ :=
  ∑ b ∈ cappedSecond N U V, Vaughan.beta V b ^ 2

def characterEnergy (N cutoff Q U V : ℕ) : ℝ :=
  dispersion (activeFirst N U) (cappedSecond N U V) muReal (fun _ => 1)
    (arithmeticKernel N (fullCharacterWeight N cutoff Q))

def coherentDiagonal (N cutoff Q U V : ℕ) : ℝ :=
  diagonal (activeFirst N U) (cappedSecond N U V) muReal (fun _ => 1)
    (arithmeticKernel N (fullCharacterWeight N cutoff Q))

def offDiagonal (N cutoff Q U V : ℕ) : ℝ :=
  characterEnergy N cutoff Q U V - coherentDiagonal N cutoff Q U V

def outerBudget (N U : ℕ) (L : ℝ) : ℝ := (N : ℝ) * L ^ 2 / (U + 1 : ℝ)

theorem logBudget_nonneg {N : ℕ} (hN : 1 ≤ N) : 0 ≤ logBudget N := by
  have hlog : 0 ≤ Real.log (N : ℝ) := Real.log_nonneg (by exact_mod_cast hN)
  unfold logBudget
  linarith

theorem cappedSecond_card_le (N U V : ℕ) :
    (cappedSecond N U V).card ≤ (N - 1) / (U + 1) := by
  have hs : cappedSecond N U V ⊆ Icc 1 ((N - 1) / (U + 1)) := by
    intro b hb
    rcases mem_filter.mp hb with ⟨hb, hcap⟩
    have hV : V < b := (mem_filter.mp hb).2
    exact mem_Icc.mpr ⟨by omega, hcap⟩
  have hc := card_le_card hs
  simpa only [Nat.card_Icc, Nat.add_sub_cancel] using hc

theorem betaSquareMass_le_outerBudget {N : ℕ} (hN : 1 ≤ N) (U V : ℕ) :
    betaSquareMass N U V ≤ outerBudget N U (logBudget N) := by
  have hL := logBudget_nonneg hN
  have hp (b : ℕ) (hb : b ∈ cappedSecond N U V) :
      Vaughan.beta V b ^ 2 ≤ logBudget N ^ 2 := by
    have hactive := (mem_filter.mp hb).1
    have hV : V < b := (mem_filter.mp hactive).2
    have hbN : b < N := mem_range.mp (mem_filter.mp hactive).1
    have hbpos : 0 < (b : ℝ) := by exact_mod_cast (by omega : 0 < b)
    have hlog : Real.log (b : ℝ) ≤ Real.log (N : ℝ) :=
      Real.log_le_log hbpos (by exact_mod_cast hbN.le)
    have hbeta := Vaughan.beta_le_log V b
    have hnonneg := Vaughan.beta_nonneg V b
    have hbL : Vaughan.beta V b ≤ logBudget N := by unfold logBudget; linarith
    nlinarith
  have hmass : betaSquareMass N U V ≤
      ((N - 1) / (U + 1) : ℕ) * logBudget N ^ 2 := by
    unfold betaSquareMass
    calc
      _ ≤ ∑ b ∈ cappedSecond N U V, logBudget N ^ 2 := sum_le_sum hp
      _ = ((cappedSecond N U V).card : ℝ) * logBudget N ^ 2 := by simp
      _ ≤ ((N - 1) / (U + 1) : ℕ) * logBudget N ^ 2 :=
        mul_le_mul_of_nonneg_right (by exact_mod_cast cappedSecond_card_le N U V)
          (sq_nonneg _)
  have hcapNat : ((N - 1) / (U + 1)) * (U + 1) ≤ N :=
    (Nat.div_mul_le_self (N - 1) (U + 1)).trans (Nat.sub_le N 1)
  have hcap : (((N - 1) / (U + 1) : ℕ) : ℝ) ≤ (N : ℝ) / (U + 1 : ℝ) := by
    apply (le_div_iff₀ (by positivity : 0 < (U + 1 : ℝ))).mpr
    exact_mod_cast hcapNat
  calc
    betaSquareMass N U V ≤ _ := hmass
    _ ≤ ((N : ℝ) / (U + 1 : ℝ)) * logBudget N ^ 2 :=
      mul_le_mul_of_nonneg_right hcap (sq_nonneg _)
    _ = outerBudget N U (logBudget N) := by unfold outerBudget; ring

theorem signed_character_sq_le_unweighted_energy (N cutoff Q U V : ℕ) :
    SignedModulusTransfer.signedApproximation N Q
      (SignedModulusTransfer.actualCharacterReal N cutoff U V) ^ 2 ≤
      betaSquareMass N U V * characterEnergy N cutoff Q U V := by
  rw [signed_character_eq_capped_column]
  unfold betaSquareMass characterEnergy dispersion
  simpa only [one_mul] using
    Finset.sum_mul_sq_le_sq_mul_sq (cappedSecond N U V) (Vaughan.beta V)
      (column (activeFirst N U) muReal
        (arithmeticKernel N (fullCharacterWeight N cutoff Q)))

theorem characterEnergy_nonneg (N cutoff Q U V : ℕ) :
    0 ≤ characterEnergy N cutoff Q U V :=
  dispersion_nonneg _ _ _ _ _ (fun _ _ => by norm_num)

theorem characterEnergy_eq_diagonal_add_off (N cutoff Q U V : ℕ) :
    characterEnergy N cutoff Q U V = coherentDiagonal N cutoff Q U V +
      offDiagonal N cutoff Q U V := by
  unfold offDiagonal
  ring

theorem quantitative_budget_of_diagonal_bound
    {S B E D O n L d : ℝ} (hn : 0 ≤ n) (hd : 0 < d)
    (hE : 0 ≤ E) (hCS : S ^ 2 ≤ B * E) (hBO : B ≤ n * L ^ 2 / d)
    (hDO : D ≤ 20 * n * L ^ 9) (hdecomp : E = D + O) :
    S ^ 2 ≤ (n * L ^ 2 / d) * (20 * n * L ^ 9 + max O 0) := by
  have hbudget : 0 ≤ n * L ^ 2 / d := div_nonneg (mul_nonneg hn (sq_nonneg _)) hd.le
  have hEO : E ≤ 20 * n * L ^ 9 + max O 0 := by
    rw [hdecomp]
    exact add_le_add hDO (le_max_left O 0)
  calc
    S ^ 2 ≤ B * E := hCS
    _ ≤ (n * L ^ 2 / d) * E := mul_le_mul_of_nonneg_right hBO hE
    _ ≤ (n * L ^ 2 / d) * (20 * n * L ^ 9 + max O 0) :=
      mul_le_mul_of_nonneg_left hEO hbudget

/- The only arithmetic premise below is the coherent diagonal estimate.
   The outer beta-square budget is proved above for the actual coefficients. -/
theorem signed_character_sq_le_diagonal_budget {N : ℕ} (hN : 1 ≤ N)
    (cutoff Q U V : ℕ)
    (hD : coherentDiagonal N cutoff Q U V ≤ 20 * (N : ℝ) * logBudget N ^ 9) :
    SignedModulusTransfer.signedApproximation N Q
      (SignedModulusTransfer.actualCharacterReal N cutoff U V) ^ 2 ≤
      outerBudget N U (logBudget N) *
        (20 * (N : ℝ) * logBudget N ^ 9 + max (offDiagonal N cutoff Q U V) 0) := by
  exact quantitative_budget_of_diagonal_bound (by positivity)
    (by positivity : 0 < (U + 1 : ℝ)) (characterEnergy_nonneg N cutoff Q U V)
    (signed_character_sq_le_unweighted_energy N cutoff Q U V)
    (betaSquareMass_le_outerBudget hN U V) hD
    (characterEnergy_eq_diagonal_add_off N cutoff Q U V)

theorem signed_character_sq_le_with_off_budget {N : ℕ} (hN : 1 ≤ N)
    (cutoff Q U V : ℕ) (T : ℝ)
    (hD : coherentDiagonal N cutoff Q U V ≤ 20 * (N : ℝ) * logBudget N ^ 9)
    (hO : max (offDiagonal N cutoff Q U V) 0 ≤ T) :
    SignedModulusTransfer.signedApproximation N Q
      (SignedModulusTransfer.actualCharacterReal N cutoff U V) ^ 2 ≤
      outerBudget N U (logBudget N) * (20 * (N : ℝ) * logBudget N ^ 9 + T) := by
  refine (signed_character_sq_le_diagonal_budget hN cutoff Q U V hD).trans ?_
  apply mul_le_mul_of_nonneg_left (add_le_add_left hO _) ?_
  unfold outerBudget
  positivity

theorem cubic_young_identity (x y : ℝ) :
    x ^ 3 + 2 * y ^ 3 - 3 * x * y ^ 2 = (x - y) ^ 2 * (x + 2 * y) := by ring

theorem cubic_young {x y : ℝ} (hx : 0 ≤ x) (hy : 0 ≤ y) :
    3 * x * y ^ 2 ≤ x ^ 3 + 2 * y ^ 3 := by
  have hprod := mul_nonneg (sq_nonneg (x - y)) (by linarith : 0 ≤ x + 2 * y)
  rw [← cubic_young_identity] at hprod
  linarith

theorem reflected_cubic_moment (N : ℕ) (f : ℕ → ℝ)
    (hf : ∀ n ∈ Ico 1 N, 0 ≤ f n) :
    (∑ n ∈ Ico 1 N, f n * f (N - n) ^ 2) ≤ ∑ n ∈ Ico 1 N, f n ^ 3 := by
  by_cases hN : 1 ≤ N
  · have hreflect : (∑ n ∈ Ico 1 N, f (N - n) ^ 3) =
        ∑ n ∈ Ico 1 N, f n ^ 3 := by
      have hs := Finset.sum_Ico_reflect (fun n => f n ^ 3) 1 (Nat.le_succ N)
      simpa only [Nat.add_sub_cancel, Nat.add_sub_cancel_left] using hs
    have hsum : 3 * (∑ n ∈ Ico 1 N, f n * f (N - n) ^ 2) ≤
        (∑ n ∈ Ico 1 N, f n ^ 3) + 2 * (∑ n ∈ Ico 1 N, f (N - n) ^ 3) := by
      have hp : (∑ n ∈ Ico 1 N, 3 * f n * f (N - n) ^ 2) ≤
          ∑ n ∈ Ico 1 N, (f n ^ 3 + 2 * f (N - n) ^ 3) := by
        apply sum_le_sum
        intro n hn
        have hn' := mem_Ico.mp hn
        have hm : N - n ∈ Ico 1 N := mem_Ico.mpr ⟨by omega, by omega⟩
        exact cubic_young (hf n hn) (hf (N - n) hm)
      simpa only [mul_assoc, ← Finset.mul_sum, Finset.sum_add_distrib] using hp
    rw [hreflect] at hsum
    linarith
  · have hN0 : N = 0 := by omega
    subst N
    simp

theorem reflected_divisor_cubic_moment (N : ℕ) :
    (∑ n ∈ Ico 1 N, (n.divisors.card : ℝ) * ((N - n).divisors.card : ℝ) ^ 2) ≤
      ∑ n ∈ Ico 1 N, (n.divisors.card : ℝ) ^ 3 :=
  reflected_cubic_moment N (fun n => (n.divisors.card : ℝ)) (fun _ _ => by positivity)

theorem prime_power_cubic_growth (e : ℕ) :
    (e + 2) ^ 3 ≤ (e + 8) * (e + 1) ^ 2 := by
  nlinarith [sq_nonneg (e : ℤ)]

theorem prime_power_cubic_le_choose (e : ℕ) :
    (e + 1) ^ 3 ≤ (e + 7).choose 7 := by
  induction e with
  | zero => norm_num
  | succ e ih =>
    have hchoose := Nat.choose_mul_succ_eq (e + 7) 7
    have hmul := Nat.mul_le_mul_right (e + 8) ih
    have hg := Nat.mul_le_mul_right (e + 1) (prime_power_cubic_growth e)
    have hc : (e + 2) ^ 3 * (e + 1) ≤ (e + 8).choose 7 * (e + 1) := by
      have hchoose' : (e + 7).choose 7 * (e + 8) =
          (e + 8).choose 7 * (e + 1) := by simpa using hchoose
      nlinarith
    have hepos : 0 < e + 1 := by omega
    have hres : (e + 2) ^ 3 ≤ (e + 8).choose 7 :=
      (mul_le_mul_right hepos).mp hc
    simpa only [Nat.succ_eq_add_one, Nat.add_assoc] using hres

#print axioms logBudget_nonneg
#print axioms cappedSecond_card_le
#print axioms betaSquareMass_le_outerBudget
#print axioms signed_character_sq_le_unweighted_energy
#print axioms characterEnergy_nonneg
#print axioms characterEnergy_eq_diagonal_add_off
#print axioms quantitative_budget_of_diagonal_bound
#print axioms signed_character_sq_le_diagonal_budget
#print axioms signed_character_sq_le_with_off_budget
#print axioms cubic_young_identity
#print axioms cubic_young
#print axioms reflected_cubic_moment
#print axioms reflected_divisor_cubic_moment
#print axioms prime_power_cubic_growth
#print axioms prime_power_cubic_le_choose

end
end GoldbachResearch.OffDiagonalBudget
