import GoldbachVaughan
import Mathlib.Tactic

/-!
Exact rough-fibre support, genuine Vaughan beta, and cofactor sign fusion.
No analytic estimate or cancellation assumption is introduced here.
-/

namespace GoldbachResearch.RoughCofactors

open scoped BigOperators
open Finset ActualArithmetic

/-- No nontrivial divisor at most V; equivalent to absence of primes <= V. -/
def Rough (V n : ℕ) : Prop := ∀ d : ℕ, d ∣ n → d ≤ V → d = 1

theorem rough_one (V : ℕ) : Rough V 1 := by
  intro d hd _
  exact Nat.eq_one_of_dvd_one hd

theorem rough_of_dvd {V n b : ℕ} (hn : Rough V n) (hb : b ∣ n) :
    Rough V b := by
  intro d hd hV
  exact hn d (dvd_trans hd hb) hV

theorem rough_right_factor {V a b : ℕ} (h : Rough V (a * b)) :
    Rough V b := rough_of_dvd h (dvd_mul_left b a)

theorem rough_left_factor {V a b : ℕ} (h : Rough V (a * b)) :
    Rough V a := rough_of_dvd h (dvd_mul_right a b)

theorem beta_eq_log_of_rough {V b : ℕ} (hb : Rough V b) :
    Vaughan.beta V b = Real.log (b : ℝ) := by
  rw [Vaughan.beta_divisor_sum, ← ArithmeticFunction.vonMangoldt_sum]
  apply Finset.sum_congr rfl
  intro d hd
  by_cases hV : V < d
  · simp [hV]
  · have hd1 := hb d (Nat.mem_divisors.mp hd).1 (Nat.le_of_not_gt hV)
    simp [hV, hd1, ArithmeticFunction.vonMangoldt_apply_one]

theorem beta_eq_log_on_rough_fibre {V a b n : ℕ}
    (hn : Rough V n) (hab : a * b = n) :
    Vaughan.beta V b = Real.log (b : ℝ) := by
  apply beta_eq_log_of_rough
  apply rough_of_dvd hn
  rw [← hab]
  exact dvd_mul_left b a

theorem coprime_cofactors {N a b k r : ℕ}
    (hN : N = a * b + k * r) (hu : (a * b).Coprime N) :
    a.Coprime r := by
  have haN : a.Coprime N := hu.of_dvd_left (dvd_mul_right a b)
  rw [hN] at haN
  have hakr : a.Coprime (k * r) :=
    (Nat.coprime_mul_left_add_right a (k * r) b).mp haN
  exact hakr.of_dvd_right (dvd_mul_left r k)

theorem coprime_short_factors {N a b k r : ℕ}
    (hN : N = a * b + k * r) (hu : (a * b).Coprime N) :
    b.Coprime k := by
  have hbN : b.Coprime N := hu.of_dvd_left (dvd_mul_left b a)
  have hN' : N = b * a + k * r := by simpa [Nat.mul_comm a b] using hN
  rw [hN'] at hbN
  have hbkr : b.Coprime (k * r) :=
    (Nat.coprime_mul_left_add_right b (k * r) a).mp hbN
  exact hbkr.of_dvd_right (dvd_mul_right k r)

theorem moebius_cofactor_fusion {N a b k r : ℕ}
    (hN : N = a * b + k * r) (hu : (a * b).Coprime N) :
    ArithmeticFunction.moebius a * ArithmeticFunction.moebius r =
      ArithmeticFunction.moebius (a * r) := by
  exact (ArithmeticFunction.isMultiplicative_moebius.map_mul_of_coprime
    (coprime_cofactors hN hu)).symm

theorem muReal_cofactor_fusion {N a b k r : ℕ}
    (hN : N = a * b + k * r) (hu : (a * b).Coprime N) :
    muReal a * muReal r = muReal (a * r) := by
  unfold muReal
  exact_mod_cast moebius_cofactor_fusion hN hu

theorem exact_divisible_weight_on_rough_fibre {N a b k r V : ℕ}
    (hN : N = a * b + k * r) (hu : (a * b).Coprime N)
    (hn : Rough V (a * b)) :
    -(muReal a * muReal r * Vaughan.beta V b *
      muReal (k * r) ^ 2 * Real.log (r : ℝ)) =
    -(muReal (a * r) * Real.log (b : ℝ) *
      muReal (k * r) ^ 2 * Real.log (r : ℝ)) := by
  rw [muReal_cofactor_fusion hN hu, beta_eq_log_of_rough (rough_right_factor hn)]

theorem cofactor_quadratic_discriminant {N a b k r : ℕ}
    (hN : N = a * b + k * r) :
    ((N : ℤ) - 2 * (a : ℤ) * (b : ℤ)) ^ 2 +
      4 * ((a : ℤ) * (r : ℤ)) * ((b : ℤ) * (k : ℤ)) = (N : ℤ) ^ 2 := by
  have h : (N : ℤ) = (a : ℤ) * (b : ℤ) + (k : ℤ) * (r : ℤ) := by
    exact_mod_cast hN
  rw [h]
  ring

theorem root_product_divisibility {N a b k r : ℕ}
    (hN : N = a * b + k * r) :
    ((a : ℤ) * (r : ℤ)) ∣ ((a : ℤ) * (b : ℤ)) *
      ((a : ℤ) * (b : ℤ) - (N : ℤ)) := by
  refine ⟨-((b : ℤ) * (k : ℤ)), ?_⟩
  have h : (N : ℤ) = (a : ℤ) * (b : ℤ) + (k : ℤ) * (r : ℤ) := by
    exact_mod_cast hN
  rw [h]
  ring

#print axioms rough_one
#print axioms rough_of_dvd
#print axioms rough_right_factor
#print axioms rough_left_factor
#print axioms beta_eq_log_of_rough
#print axioms beta_eq_log_on_rough_fibre
#print axioms coprime_cofactors
#print axioms coprime_short_factors
#print axioms moebius_cofactor_fusion
#print axioms muReal_cofactor_fusion
#print axioms exact_divisible_weight_on_rough_fibre
#print axioms cofactor_quadratic_discriminant
#print axioms root_product_divisibility

end GoldbachResearch.RoughCofactors
