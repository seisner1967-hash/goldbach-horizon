import GoldbachArithmetic

/-!
# Finite exceptional-set transfers

The counting arguments are kernel checked. The arithmetic main-term lower bound
and a small averaged positive off-diagonal budget remain explicit assumptions.
No Goldbach conclusion is supplied as an input and no asymptotic is asserted.
-/

namespace GoldbachResearch.Exceptional

open scoped BigOperators
open ActualArithmetic

theorem card_large_le_secondMoment {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (f : ι → ℝ) (t : ℝ) (ht : 0 < t) :
    t ^ 2 * ((s.filter (fun i => t ≤ |f i|)).card : ℝ) ≤ ∑ i ∈ s, (f i) ^ 2 := by
  classical
  have hp : ∀ i ∈ s.filter (fun i => t ≤ |f i|), t ^ 2 ≤ (f i) ^ 2 := by
    intro i hi
    have hi' := (Finset.mem_filter.mp hi).2
    nlinarith [abs_nonneg (f i), sq_abs (f i)]
  calc
    t ^ 2 * ((s.filter (fun i => t ≤ |f i|)).card : ℝ) =
        ∑ i ∈ s.filter (fun i => t ≤ |f i|), t ^ 2 := by simp; ring
    _ ≤ ∑ i ∈ s.filter (fun i => t ≤ |f i|), (f i) ^ 2 := Finset.sum_le_sum hp
    _ ≤ ∑ i ∈ s, (f i) ^ 2 :=
      Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _)
        (fun i hi hni => sq_nonneg (f i))

theorem card_large_le_secondMoment_div {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (f : ι → ℝ) (t B : ℝ) (ht : 0 < t)
    (hB : ∑ i ∈ s, (f i) ^ 2 ≤ B) :
    ((s.filter (fun i => t ≤ |f i|)).card : ℝ) ≤ B / t ^ 2 := by
  have h := (card_large_le_secondMoment s f t ht).trans hB
  apply (le_div_iff₀ (sq_pos_of_pos ht)).2
  simpa only [mul_comm] using h

/-- A relative-defect threshold with the Fejer width paid only once. The
second-moment estimate is an explicit input, rather than an assumed count. -/
theorem card_relative_defect_le {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (f : ι → ℝ) (delta h G B : ℝ)
    (hd : 0 < delta) (hh : 0 < h) (hG : 0 < G)
    (hB : ∑ i ∈ s, (f i) ^ 2 ≤ h * B) :
    ((s.filter (fun i => delta * h * G ≤ |f i|)).card : ℝ) ≤
      B / (delta ^ 2 * h * G ^ 2) := by
  have ht : 0 < delta * h * G := mul_pos (mul_pos hd hh) hG
  have hc := card_large_le_secondMoment_div s f (delta * h * G) (h * B) ht hB
  have heq : h * B / (delta * h * G) ^ 2 = B / (delta ^ 2 * h * G ^ 2) := by
    field_simp [ne_of_gt hd, ne_of_gt hh, ne_of_gt hG]
    ring
  simpa only [heq] using hc

theorem card_large_le_nonneg_sum {ι : Type*} [DecidableEq ι]
    (s : Finset ι) (f : ι → ℝ) (t : ℝ)
    (hf : ∀ i ∈ s, 0 ≤ f i) :
    t * ((s.filter (fun i => t ≤ f i)).card : ℝ) ≤ ∑ i ∈ s, f i := by
  classical
  calc
    t * ((s.filter (fun i => t ≤ f i)).card : ℝ) =
        ∑ i ∈ s.filter (fun i => t ≤ f i), t := by simp; ring
    _ ≤ ∑ i ∈ s.filter (fun i => t ≤ f i), f i :=
      Finset.sum_le_sum (fun i hi => (Finset.mem_filter.mp hi).2)
    _ ≤ ∑ i ∈ s, f i :=
      Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _)
        (fun i hi hni => hf i hi)

def Goldbach (N : ℕ) : Prop :=
  ∃ p q : ℕ, Nat.Prime p ∧ Nat.Prime q ∧ p + q = N

noncomputable local instance goldbachDecidable (N : ℕ) : Decidable (Goldbach N) :=
  Classical.propDecidable _

noncomputable def primePairWeight (N : ℕ) : ℝ :=
  ∑ n ∈ Finset.range N,
    if Nat.Prime n ∧ Nat.Prime (N - n) then
      Real.log (n : ℝ) * Real.log (N - n : ℕ) else 0

theorem primePairWeight_eq_zero_of_not_goldbach {N : ℕ} (hN : ¬ Goldbach N) :
    primePairWeight N = 0 := by
  unfold primePairWeight
  apply Finset.sum_eq_zero
  intro n hn
  have hnp : ¬ (Nat.Prime n ∧ Nat.Prime (N - n)) := by
    intro hp
    apply hN
    refine ⟨n, N - n, hp.1, hp.2, ?_⟩
    have hnN : n < N := Finset.mem_range.mp hn
    omega
  simp [hnp]

noncomputable def harmonicModulusMass (N Q : ℕ) : ℝ :=
  ∑ k ∈ actualModuli N Q, 1 / (k : ℝ)

theorem harmonicModulusMass_nonneg (N Q : ℕ) :
    0 ≤ harmonicModulusMass N Q := by
  unfold harmonicModulusMass
  exact Finset.sum_nonneg (fun k hk => le_of_lt (one_div_pos.mpr (actual_modulus_positive hk)))

noncomputable def normalizedPositiveOff (N alpha Q : ℕ) (margin : ℝ) : ℝ :=
  harmonicModulusMass N Q * max (actualOffDiagonal N alpha Q) 0 / margin ^ 2

theorem normalizedPositiveOff_nonneg (N alpha Q : ℕ) (margin : ℝ) :
    0 ≤ normalizedPositiveOff N alpha Q margin := by
  unfold normalizedPositiveOff
  exact div_nonneg
    (mul_nonneg (harmonicModulusMass_nonneg N Q) (le_max_right _ _)) (sq_nonneg margin)

/-- A missing prime pair forces a definite normalized positive off-diagonal
mass, provided the independently stated main-term and diagonal budgets hold. -/
theorem not_goldbach_forces_off_budget (N alpha Q : ℕ) (margin : ℝ)
    (hm : 0 < margin)
    (hmain : margin + actualSignedError N alpha Q ≤ primePairWeight N)
    (hdiag : harmonicModulusMass N Q * actualDiagonal N alpha Q ≤ margin ^ 2 / 2)
    (hN : ¬ Goldbach N) :
    (1 / 2 : ℝ) ≤ normalizedPositiveOff N alpha Q margin := by
  have he : margin + actualSignedError N alpha Q ≤ 0 := by
    simpa [primePairWeight_eq_zero_of_not_goldbach hN] using hmain
  have hesq : margin ^ 2 ≤ (actualSignedError N alpha Q) ^ 2 := by nlinarith
  have hc := actualSignedError_sq_le_variance N alpha Q
  rw [actualVariance_eq_diagonal_add_offDiagonal] at hc
  change (actualSignedError N alpha Q) ^ 2 ≤
    harmonicModulusMass N Q *
      (actualDiagonal N alpha Q + actualOffDiagonal N alpha Q) at hc
  have hmax := mul_le_mul_of_nonneg_left
    (le_max_left (actualOffDiagonal N alpha Q) 0) (harmonicModulusMass_nonneg N Q)
  unfold normalizedPositiveOff
  apply (le_div_iff₀ (sq_pos_of_pos hm)).2
  nlinarith

/-- Effective finite counting transfer; the unproved analytic budgets are
parameters, while Goldbach and the arithmetic rows are concrete definitions. -/
theorem goldbach_exceptional_card_le_off_sum (s : Finset ℕ)
    (alpha Q : ℕ → ℕ) (margin : ℕ → ℝ)
    (hm : ∀ N ∈ s, 0 < margin N)
    (hmain : ∀ N ∈ s, margin N + actualSignedError N (alpha N) (Q N) ≤ primePairWeight N)
    (hdiag : ∀ N ∈ s,
      harmonicModulusMass N (Q N) * actualDiagonal N (alpha N) (Q N) ≤ (margin N) ^ 2 / 2) :
    ((s.filter (fun N => ¬ Goldbach N)).card : ℝ) ≤
      2 * ∑ N ∈ s, normalizedPositiveOff N (alpha N) (Q N) (margin N) := by
  classical
  have hsubset : s.filter (fun N => ¬ Goldbach N) ⊆
      s.filter (fun N => (1 / 2 : ℝ) ≤ normalizedPositiveOff N (alpha N) (Q N) (margin N)) := by
    intro N hN
    have hNs := (Finset.mem_filter.mp hN).1
    exact Finset.mem_filter.mpr ⟨hNs,
      not_goldbach_forces_off_budget N (alpha N) (Q N) (margin N)
        (hm N hNs) (hmain N hNs) (hdiag N hNs) (Finset.mem_filter.mp hN).2⟩
  have hcard : ((s.filter (fun N => ¬ Goldbach N)).card : ℝ) ≤
      ((s.filter (fun N => (1 / 2 : ℝ) ≤ normalizedPositiveOff N (alpha N) (Q N) (margin N))).card : ℝ) := by
    exact_mod_cast Finset.card_le_card hsubset
  have hsum := card_large_le_nonneg_sum s
    (fun N => normalizedPositiveOff N (alpha N) (Q N) (margin N)) (1 / 2 : ℝ)
    (fun N hN => normalizedPositiveOff_nonneg N (alpha N) (Q N) (margin N))
  linarith

/-- A supplied normalized arithmetic off-diagonal sum budget transfers
directly to a finite exceptional cardinality. No budget is proved here. -/
theorem goldbach_exceptional_card_le_budget (s : Finset ℕ)
    (alpha Q : ℕ → ℕ) (margin : ℕ → ℝ) (B : ℝ)
    (hm : ∀ N ∈ s, 0 < margin N)
    (hmain : ∀ N ∈ s, margin N + actualSignedError N (alpha N) (Q N) ≤ primePairWeight N)
    (hdiag : ∀ N ∈ s,
      harmonicModulusMass N (Q N) * actualDiagonal N (alpha N) (Q N) ≤ (margin N) ^ 2 / 2)
    (hbudget : ∑ N ∈ s, normalizedPositiveOff N (alpha N) (Q N) (margin N) ≤ B) :
    ((s.filter (fun N => ¬ Goldbach N)).card : ℝ) ≤ 2 * B := by
  exact (goldbach_exceptional_card_le_off_sum s alpha Q margin hm hmain hdiag).trans
    (mul_le_mul_of_nonneg_left hbudget (by norm_num))

end GoldbachResearch.Exceptional

#print axioms GoldbachResearch.Exceptional.card_large_le_secondMoment
#print axioms GoldbachResearch.Exceptional.card_large_le_secondMoment_div
#print axioms GoldbachResearch.Exceptional.card_relative_defect_le
#print axioms GoldbachResearch.Exceptional.card_large_le_nonneg_sum
#print axioms GoldbachResearch.Exceptional.primePairWeight_eq_zero_of_not_goldbach
#print axioms GoldbachResearch.Exceptional.harmonicModulusMass_nonneg
#print axioms GoldbachResearch.Exceptional.normalizedPositiveOff_nonneg
#print axioms GoldbachResearch.Exceptional.not_goldbach_forces_off_budget
#print axioms GoldbachResearch.Exceptional.goldbach_exceptional_card_le_off_sum
#print axioms GoldbachResearch.Exceptional.goldbach_exceptional_card_le_budget
