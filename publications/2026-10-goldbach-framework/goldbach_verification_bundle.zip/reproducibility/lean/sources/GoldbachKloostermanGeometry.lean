import GoldbachPairStructure
import Mathlib.Algebra.Group.AddChar
import Mathlib.Data.ZMod.Units
import Mathlib.Analysis.Complex.Basic

/-!
# The unit hyperbola: an exact transform, not a cancellation theorem

Its centered selector is a permutation minus the constant projection.
On functions of mean zero it preserves energy. The additive transform
produces a Kloosterman sum with the necessary Ramanujan correction.
No Weil estimate or bound for the actual Mobius coefficients is assumed.
-/

namespace GoldbachResearch.KloostermanGeometry

open scoped BigOperators
open Finset ActualArithmetic SignedKernel

theorem common_modulus_pair (k l r : ℕ) (hk : muReal k ^ 2 = 1) :
    muReal (k * l) * muReal (k * r) =
      if k.Coprime l ∧ k.Coprime r then muReal l * muReal r else 0 := by
  rw [muReal_mul_exact, muReal_mul_exact]
  by_cases hl : k.Coprime l
  · by_cases hr : k.Coprime r
    · simp only [if_pos hl, if_pos hr, if_pos (And.intro hl hr)]
      calc
        _ = muReal k ^ 2 * (muReal l * muReal r) := by ring
        _ = _ := by rw [hk, one_mul]
    · simp [hl, hr]
  · simp [hl]

section FiniteUnits

variable {G : Type*} [CommGroup G] [Fintype G]

def reflection (t x : G) : G := t * x⁻¹

omit [Fintype G] in
theorem reflection_involutive (t : G) : Function.Involutive (reflection t) := by
  intro x
  simp [reflection, mul_assoc, mul_left_comm, mul_comm]

noncomputable def reflectionEquiv (t : G) : G ≃ G :=
  (reflection_involutive t).toPerm

noncomputable def mean (f : G → ℂ) : ℂ := (∑ x, f x) / (Fintype.card G : ℂ)

noncomputable def centeredTransform (t : G) (f : G → ℂ) (x : G) : ℂ :=
  f (reflection t x) - mean f

theorem sum_reflection (t : G) (f : G → ℂ) :
    (∑ x, f (reflection t x)) = ∑ x, f x := by
  exact (reflectionEquiv t).sum_comp f

theorem sum_centeredTransform (t : G) (f : G → ℂ) :
    (∑ x, centeredTransform t f x) = 0 := by
  classical
  have hc : (Fintype.card G : ℂ) ≠ 0 := by
    exact_mod_cast Fintype.card_ne_zero
  simp only [centeredTransform, Finset.sum_sub_distrib, sum_reflection,
    Finset.sum_const, Finset.card_univ, nsmul_eq_mul, mean]
  field_simp

theorem centeredTransform_square (t : G) (f : G → ℂ) (x : G) :
    centeredTransform t (centeredTransform t f) x = f x - mean f := by
  have hm : mean (centeredTransform t f) = 0 := by
    rw [mean, sum_centeredTransform]
    simp
  rw [centeredTransform, hm, sub_zero, centeredTransform,
    reflection_involutive t x]

theorem centeredTransform_energy_of_sum_zero (t : G) (f : G → ℂ)
    (hf : (∑ x, f x) = 0) :
    (∑ x, Complex.normSq (centeredTransform t f x)) =
      ∑ x, Complex.normSq (f x) := by
  simp only [centeredTransform, mean, hf, zero_div, sub_zero]
  exact (reflectionEquiv t).sum_comp (fun x => Complex.normSq (f x))

noncomputable def unitKernel (t x y : G) : ℂ := by
  classical
  exact
  (if x * y = t then 1 else 0) - 1 / (Fintype.card G : ℂ)

open Classical in
theorem unit_graph_row (t x : G) (f : G → ℂ) :
    (∑ y, (if x * y = t then f y else 0)) = f (reflection t x) := by
  classical
  have he (y : G) : x * y = t ↔ y = reflection t x := by
    constructor
    · intro h
      calc
        y = x⁻¹ * (x * y) := by simp
        _ = reflection t x := by rw [h]; simp [reflection, mul_comm]
    · intro h
      rw [h]
      simp [reflection, mul_assoc, mul_left_comm, mul_comm]
  simp only [he]
  simp

theorem unitKernel_transform (t x : G) (f : G → ℂ) :
    (∑ y, unitKernel t x y * f y) = centeredTransform t f x := by
  classical
  simp only [unitKernel, sub_mul, ite_mul, one_mul, zero_mul,
    Finset.sum_sub_distrib, unit_graph_row]
  rw [← Finset.mul_sum]
  simp [centeredTransform, mean, div_eq_mul_inv, mul_comm]

theorem unitKernel_separated_transform (t : G) (f g : G → ℂ) :
    (∑ x, ∑ y, unitKernel t x y * f x * g y) =
      (∑ x, f x * g (reflection t x)) -
        (∑ x, f x) * (∑ y, g y) / (Fintype.card G : ℂ) := by
  classical
  have hrow (x : G) :
      (∑ y, unitKernel t x y * f x * g y) = f x * centeredTransform t g x := by
    calc
      _ = f x * ∑ y, unitKernel t x y * g y := by
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro y hy
        ring
      _ = _ := by rw [unitKernel_transform]
  simp_rw [hrow, centeredTransform, mul_sub]
  rw [Finset.sum_sub_distrib, ← Finset.sum_mul]
  simp [mean, div_eq_mul_inv, mul_assoc]

end FiniteUnits

section ZModHyperbola

variable (k : ℕ) [NeZero k]

/-- The complete additive sum on x*y=t, using inverses in the unit group. -/
noncomputable def unitKloosterman (ψ : AddChar (ZMod k) ℂ)
    (h j : ZMod k) (t : (ZMod k)ˣ) : ℂ :=
  ∑ x : (ZMod k)ˣ, ψ (h * (x : ZMod k) + j * ((t * x⁻¹ : (ZMod k)ˣ) : ZMod k))

/-- For the usual exponential character this is the Ramanujan sum. -/
noncomputable def unitFourier (ψ : AddChar (ZMod k) ℂ) (h : ZMod k) : ℂ :=
  ∑ x : (ZMod k)ˣ, ψ (h * (x : ZMod k))

/-- Exact Kloosterman representation, including the centering correction. -/
theorem unitKernel_additive_transform (ψ : AddChar (ZMod k) ℂ)
    (h j : ZMod k) (t : (ZMod k)ˣ) :
    (∑ x : (ZMod k)ˣ, ∑ y : (ZMod k)ˣ,
      unitKernel t x y * ψ (h * (x : ZMod k) + j * (y : ZMod k))) =
      unitKloosterman k ψ h j t -
        unitFourier k ψ h * unitFourier k ψ j / (Nat.totient k : ℂ) := by
  simpa only [unitKloosterman, unitFourier, AddChar.map_add_eq_mul,
    reflection, mul_assoc, ZMod.card_units_eq_totient] using
    unitKernel_separated_transform t
      (fun x : (ZMod k)ˣ => ψ (h * (x : ZMod k)))
      (fun y : (ZMod k)ˣ => ψ (j * (y : ZMod k)))

end ZModHyperbola

#print axioms common_modulus_pair
#print axioms reflection_involutive
#print axioms sum_reflection
#print axioms sum_centeredTransform
#print axioms centeredTransform_square
#print axioms centeredTransform_energy_of_sum_zero
#print axioms unit_graph_row
#print axioms unitKernel_transform
#print axioms unitKernel_separated_transform
#print axioms unitKernel_additive_transform

end GoldbachResearch.KloostermanGeometry
