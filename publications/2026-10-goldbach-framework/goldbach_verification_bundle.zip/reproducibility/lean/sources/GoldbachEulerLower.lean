import Mathlib

/-!
Elementary finite Euler-product lower bounds. This is not the project's
prime-pair reference margin: no assertion about F, the signed error or an
effective onset is made. An infinite-product passage is not formalized.
-/

namespace GoldbachResearch.EulerLower

open scoped BigOperators
open Finset

noncomputable section

def shiftedFactor (j : ℕ) : ℝ := 1 - 1 / ((j : ℝ) + 2) ^ 2

theorem shiftedFactor_nonneg (j : ℕ) : 0 ≤ shiftedFactor j := by
  have hj0 : (0 : ℝ) ≤ (j : ℝ) := by positivity
  have hj : (2 : ℝ) ≤ (j : ℝ) + 2 := by linarith
  have hsq : 1 ≤ ((j : ℝ) + 2) ^ 2 := by nlinarith
  have hinv : 1 / ((j : ℝ) + 2) ^ 2 ≤ 1 := (div_le_one (by positivity)).mpr hsq
  unfold shiftedFactor
  linarith

theorem shiftedFactor_le_one (j : ℕ) : shiftedFactor j ≤ 1 := by
  unfold shiftedFactor
  exact sub_le_self _ (by positivity)

theorem shifted_product_exact (R : ℕ) :
    (∏ j ∈ range R, shiftedFactor j) = ((R : ℝ) + 2) / (2 * ((R : ℝ) + 1)) := by
  induction R with
  | zero => norm_num
  | succ R ih =>
    rw [prod_range_succ, ih]
    unfold shiftedFactor
    push_cast
    field_simp
    ring

theorem half_le_shifted_product (R : ℕ) :
    (1 : ℝ) / 2 ≤ ∏ j ∈ range R, shiftedFactor j := by
  rw [shifted_product_exact]
  apply (le_div_iff₀ (by positivity)).mpr
  linarith

theorem half_le_subset_product {S : Finset ℕ} {R : ℕ} (hS : S ⊆ range R) :
    (1 : ℝ) / 2 ≤ ∏ j ∈ S, shiftedFactor j := by
  classical
  have hfilter : (range R).filter (fun j => j ∈ S) = S := by
    ext j
    simp only [mem_filter]
    exact ⟨fun h => h.2, fun h => ⟨hS h, h⟩⟩
  have hprod : (∏ j ∈ range R, shiftedFactor j) ≤
      ∏ j ∈ range R, if j ∈ S then shiftedFactor j else 1 := by
    apply prod_le_prod
    · intro j hj
      exact shiftedFactor_nonneg j
    · intro j hj
      by_cases h : j ∈ S
      · simp [h]
      · simpa [h] using shiftedFactor_le_one j
  rw [← prod_filter, hfilter] at hprod
  exact (half_le_shifted_product R).trans hprod

theorem finite_odd_euler_product_ge_half (P : Finset ℕ)
    (hP : ∀ p ∈ P, 3 ≤ p) :
    (1 : ℝ) / 2 ≤ ∏ p ∈ P, (1 - 1 / (((p - 1 : ℕ) : ℝ) ^ 2)) := by
  classical
  let S := P.image (fun p => p - 3)
  have hS : S ⊆ range (P.sup id + 1) := by
    intro j hj
    rcases mem_image.mp hj with ⟨p, hp, rfl⟩
    have hpmax : p ≤ P.sup id := le_sup (f := id) hp
    exact mem_range.mpr (by omega)
  have hinj : Set.InjOn (fun p : ℕ => p - 3) P := by
    intro p hp q hq heq
    have hp3 := hP p hp
    have hq3 := hP q hq
    change p - 3 = q - 3 at heq
    omega
  have hprod : (∏ j ∈ S, shiftedFactor j) =
      ∏ p ∈ P, (1 - 1 / (((p - 1 : ℕ) : ℝ) ^ 2)) := by
    dsimp [S]
    rw [prod_image hinj]
    apply prod_congr rfl
    intro p hp
    have hp3 := hP p hp
    have hnat : p - 3 + 2 = p - 1 := by omega
    unfold shiftedFactor
    have hcast : ((p - 3 : ℕ) : ℝ) + 2 = ((p - 1 : ℕ) : ℝ) := by
      exact_mod_cast hnat
    rw [hcast]
  rw [← hprod]
  exact half_le_subset_product hS

#print axioms shiftedFactor_nonneg
#print axioms shiftedFactor_le_one
#print axioms shifted_product_exact
#print axioms half_le_shifted_product
#print axioms half_le_subset_product
#print axioms finite_odd_euler_product_ge_half

end
end GoldbachResearch.EulerLower
