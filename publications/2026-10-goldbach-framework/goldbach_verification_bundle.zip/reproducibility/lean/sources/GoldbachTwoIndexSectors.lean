import GoldbachCharacterDispersion

/-!
Four disjoint equality sectors after summing two signed indices. The real
weight w may be arbitrary; no positivity or analytic estimate is required.
-/

namespace GoldbachResearch.TwoIndexSectors

open scoped BigOperators
open Finset

noncomputable section

def energy (I J M : Finset ℕ) (w : ℕ → ℝ) (x : ℕ → ℕ → ℕ → ℝ) : ℝ :=
  ∑ b ∈ J, w b * (∑ a ∈ I, ∑ k ∈ M, x a k b) ^ 2

def entryDiagonal (I J M : Finset ℕ) (w : ℕ → ℝ) (x : ℕ → ℕ → ℕ → ℝ) : ℝ :=
  ∑ b ∈ J, w b * ∑ a ∈ I, ∑ k ∈ M, x a k b ^ 2

def aDiagonal (I J M : Finset ℕ) (w : ℕ → ℝ) (x : ℕ → ℕ → ℕ → ℝ) : ℝ :=
  ∑ b ∈ J, w b * ∑ a ∈ I, (∑ k ∈ M, x a k b) ^ 2

def kDiagonal (I J M : Finset ℕ) (w : ℕ → ℝ) (x : ℕ → ℕ → ℕ → ℝ) : ℝ :=
  ∑ b ∈ J, w b * ∑ k ∈ M, (∑ a ∈ I, x a k b) ^ 2

def selected (I J M : Finset ℕ) (w : ℕ → ℝ) (x : ℕ → ℕ → ℕ → ℝ)
    (P : ℕ → ℕ → ℕ → ℕ → Prop) : ℝ := by
  classical
  exact ∑ b ∈ J, w b * ∑ a ∈ I, ∑ k ∈ M, ∑ c ∈ I, ∑ l ∈ M,
    if P a k c l then x a k b * x c l b else 0

def sector00 := fun I J M w x => selected I J M w x (fun a k c l => a = c ∧ k = l)
def sectorA := fun I J M w x => selected I J M w x (fun a k c l => a = c ∧ k ≠ l)
def sectorK := fun I J M w x => selected I J M w x (fun a k c l => a ≠ c ∧ k = l)
def sectorMixed := fun I J M w x => selected I J M w x (fun a k c l => a ≠ c ∧ k ≠ l)

theorem energy_eq_full_correlation (I J M : Finset ℕ) (w : ℕ → ℝ)
    (x : ℕ → ℕ → ℕ → ℝ) :
    energy I J M w x = selected I J M w x (fun _ _ _ _ => True) := by
  unfold energy selected
  simp only [if_true]
  apply Finset.sum_congr rfl
  intro b hb
  congr 1
  simp_rw [pow_two, Finset.sum_mul_sum]
  apply Finset.sum_congr rfl
  intro a ha
  rw [Finset.sum_comm]

private theorem selected_split (I J M : Finset ℕ) (w : ℕ → ℝ)
    (x : ℕ → ℕ → ℕ → ℝ) (P Q : ℕ → ℕ → ℕ → ℕ → Prop) :
    selected I J M w x P =
      selected I J M w x (fun a k c l => P a k c l ∧ Q a k c l) +
      selected I J M w x (fun a k c l => P a k c l ∧ ¬Q a k c l) := by
  classical
  unfold selected
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro b hb
  rw [← mul_add]
  congr 1
  simp only [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro a ha
  apply Finset.sum_congr rfl
  intro k hk
  apply Finset.sum_congr rfl
  intro c hc
  apply Finset.sum_congr rfl
  intro l hl
  by_cases hp : P a k c l <;> by_cases hq : Q a k c l <;> simp [hp, hq]

theorem sector00_eq_entryDiagonal (I J M : Finset ℕ) (w : ℕ → ℝ)
    (x : ℕ → ℕ → ℕ → ℝ) : sector00 I J M w x = entryDiagonal I J M w x := by
  classical
  unfold sector00 selected entryDiagonal
  apply Finset.sum_congr rfl
  intro b hb
  congr 1
  apply Finset.sum_congr rfl
  intro a ha
  apply Finset.sum_congr rfl
  intro k hk
  rw [Finset.sum_eq_single a]
  · simp [hk, pow_two]
  · intro c hc hca
    have hac : a ≠ c := hca.symm
    simp [hac]
  · intro hnot
    exact False.elim (hnot ha)

theorem selected_same_a_eq_aDiagonal (I J M : Finset ℕ) (w : ℕ → ℝ)
    (x : ℕ → ℕ → ℕ → ℝ) :
    selected I J M w x (fun a _ c _ => a = c) = aDiagonal I J M w x := by
  classical
  unfold selected aDiagonal
  apply Finset.sum_congr rfl
  intro b hb
  congr 1
  apply Finset.sum_congr rfl
  intro a ha
  rw [pow_two, Finset.sum_mul_sum]
  apply Finset.sum_congr rfl
  intro k hk
  simp [ha]

theorem selected_same_k_eq_kDiagonal (I J M : Finset ℕ) (w : ℕ → ℝ)
    (x : ℕ → ℕ → ℕ → ℝ) :
    selected I J M w x (fun _ k _ l => k = l) = kDiagonal I J M w x := by
  classical
  unfold selected kDiagonal
  apply Finset.sum_congr rfl
  intro b hb
  congr 1
  dsimp only
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro k hk
  rw [pow_two, Finset.sum_mul_sum]
  apply Finset.sum_congr rfl
  intro a ha
  apply Finset.sum_congr rfl
  intro c hc
  rw [Finset.sum_eq_single k]
  · simp only [if_pos rfl, if_true]
  · intro l hl hlk
    exact if_neg hlk.symm
  · intro hnot
    exact False.elim (hnot hk)

theorem energy_eq_four_sectors (I J M : Finset ℕ) (w : ℕ → ℝ)
    (x : ℕ → ℕ → ℕ → ℝ) :
    energy I J M w x = sector00 I J M w x + sectorA I J M w x +
      sectorK I J M w x + sectorMixed I J M w x := by
  rw [energy_eq_full_correlation,
    selected_split I J M w x (fun _ _ _ _ => True) (fun a _ c _ => a = c)]
  simp only [true_and]
  rw [selected_split I J M w x (fun a _ c _ => a = c) (fun _ k _ l => k = l),
    selected_split I J M w x (fun a _ c _ => a ≠ c) (fun _ k _ l => k = l)]
  unfold sector00 sectorA sectorK sectorMixed
  ring

theorem sectorA_eq_aDiagonal_sub_entry (I J M : Finset ℕ) (w : ℕ → ℝ)
    (x : ℕ → ℕ → ℕ → ℝ) :
    sectorA I J M w x = aDiagonal I J M w x - entryDiagonal I J M w x := by
  have h := selected_split I J M w x (fun a _ c _ => a = c) (fun _ k _ l => k = l)
  rw [selected_same_a_eq_aDiagonal] at h
  change aDiagonal I J M w x = sector00 I J M w x + sectorA I J M w x at h
  rw [sector00_eq_entryDiagonal] at h
  linarith

theorem sectorK_eq_kDiagonal_sub_entry (I J M : Finset ℕ) (w : ℕ → ℝ)
    (x : ℕ → ℕ → ℕ → ℝ) :
    sectorK I J M w x = kDiagonal I J M w x - entryDiagonal I J M w x := by
  have h := selected_split I J M w x (fun _ k _ l => k = l) (fun a _ c _ => a = c)
  rw [selected_same_k_eq_kDiagonal] at h
  have h00 : selected I J M w x (fun a k c l => k = l ∧ a = c) = sector00 I J M w x := by
    simp only [sector00, and_comm]
  have hK : selected I J M w x (fun a k c l => k = l ∧ a ≠ c) = sectorK I J M w x := by
    simp only [sectorK, and_comm]
  rw [h00, hK, sector00_eq_entryDiagonal] at h
  linarith

theorem sectorMixed_eq_energy_sub_diagonals (I J M : Finset ℕ) (w : ℕ → ℝ)
    (x : ℕ → ℕ → ℕ → ℝ) :
    sectorMixed I J M w x = energy I J M w x - aDiagonal I J M w x -
      kDiagonal I J M w x + entryDiagonal I J M w x := by
  have h := energy_eq_four_sectors I J M w x
  rw [sector00_eq_entryDiagonal, sectorA_eq_aDiagonal_sub_entry,
    sectorK_eq_kDiagonal_sub_entry] at h
  linarith

theorem nonzero_a_sector_eq_energy_sub_aDiagonal (I J M : Finset ℕ)
    (w : ℕ → ℝ) (x : ℕ → ℕ → ℕ → ℝ) :
    sectorK I J M w x + sectorMixed I J M w x =
      energy I J M w x - aDiagonal I J M w x := by
  rw [sectorK_eq_kDiagonal_sub_entry, sectorMixed_eq_energy_sub_diagonals]
  ring

def actualCEntry (N cutoff a k b : ℕ) : ℝ :=
  ActualArithmetic.muReal a * ActualArithmetic.muReal k *
    ActualArithmetic.muReal (N - a * b) * CharacterDispersion.completedWeight N cutoff k (a * b)

theorem actualC_energy_eq_aggregated_dispersion (I J : Finset ℕ)
    (N cutoff Q : ℕ) (w : ℕ → ℝ) :
    energy I J (ActualArithmetic.actualModuli N Q) w (actualCEntry N cutoff) =
      ShiftedDispersion.dispersion I J ActualArithmetic.muReal w
        (ShiftedDispersion.arithmeticKernel N (CharacterDispersion.fullCharacterWeight N cutoff Q)) := by
  unfold energy ShiftedDispersion.dispersion ShiftedDispersion.column
    ShiftedDispersion.arithmeticKernel CharacterDispersion.fullCharacterWeight actualCEntry
  apply Finset.sum_congr rfl
  intro b hb
  congr 1
  congr 1
  apply Finset.sum_congr rfl
  intro a ha
  simp_rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k hk
  ring

#print axioms energy_eq_full_correlation
#print axioms sector00_eq_entryDiagonal
#print axioms selected_same_a_eq_aDiagonal
#print axioms selected_same_k_eq_kDiagonal
#print axioms energy_eq_four_sectors
#print axioms sectorA_eq_aDiagonal_sub_entry
#print axioms sectorK_eq_kDiagonal_sub_entry
#print axioms sectorMixed_eq_energy_sub_diagonals
#print axioms nonzero_a_sector_eq_energy_sub_aDiagonal
#print axioms actualC_energy_eq_aggregated_dispersion

end
end GoldbachResearch.TwoIndexSectors
