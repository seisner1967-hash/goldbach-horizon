import GoldbachArithmetic
import GoldbachPatterns
import GoldbachCutoffScale
import GoldbachExceptional

/-! An explicit diagonal bound for the literal arithmetic rows.
No signed off-diagonal estimate is assumed or proved. -/

namespace GoldbachResearch.Diagonal

open scoped BigOperators
open ActualArithmetic ArithmeticBridge

theorem odd_squarefree_totient_weight_le_one {k : ℕ}
    (hk : Odd k) (hs : Squarefree k) :
    (k : ℝ) / (k.totient : ℝ) ^ 2 ≤ 1 := by
  rw [← Patterns.primeWeight_squarefree hs]
  unfold Patterns.primeWeight Quartic.crossPair
  apply Finset.prod_le_one
  · intro p hp
    positivity
  · intro p hp
    have hpr := Nat.prime_of_mem_primeFactors hp
    have hodd : Odd p := by
      obtain ⟨m, hm⟩ := Nat.dvd_of_mem_primeFactors hp
      rw [hm] at hk
      exact (Nat.odd_mul.mp hk).1
    have hp3 : 3 ≤ p := by
      have hp2 := hpr.two_le
      have ho := Nat.odd_iff.mp hodd
      omega
    have hpR : (3 : ℝ) ≤ p := by exact_mod_cast hp3
    apply (div_le_one (by nlinarith : 0 < ((p : ℝ) - 1) ^ 2)).mpr
    nlinarith

theorem actual_modulus_odd_of_even {N Q k : ℕ}
    (hN : Even N) (hk : k ∈ actualModuli N Q) : Odd k := by
  have hc := (actualModuli_membership.mp hk).2.2.1
  have hd : 2 ∣ N := even_iff_two_dvd.mp hN
  exact (hc.of_dvd_right hd).odd_of_right

theorem actual_modulus_totient_weight_le_one {N Q k : ℕ}
    (hN : Even N) (hk : k ∈ actualModuli N Q) :
    (k : ℝ) / (k.totient : ℝ) ^ 2 ≤ 1 :=
  odd_squarefree_totient_weight_le_one (actual_modulus_odd_of_even hN hk)
    (actualModuli_membership.mp hk).2.2.2

theorem muReal_sq_le_one (n : ℕ) : (muReal n) ^ 2 ≤ 1 := by
  have ha : |muReal n| ≤ 1 := by
    unfold muReal
    exact_mod_cast (ArithmeticFunction.abs_moebius_le_one (n := n))
  have hab := abs_le.mp ha
  nlinarith

theorem actualSequence_sq_le_log_sq {N n : ℕ} (hn : 1 ≤ n) (hnN : n < N) :
    actualSequence N n ^ 2 ≤ Real.log (N : ℝ) ^ 2 := by
  have hp : 0 < (n : ℝ) := by exact_mod_cast (show 0 < n by omega)
  have hlog : Real.log (n : ℝ) ≤ Real.log (N : ℝ) :=
    Real.log_le_log hp (by exact_mod_cast hnN.le)
  have hvm := ArithmeticFunction.vonMangoldt_le_log (n := n)
  have hvm0 := ArithmeticFunction.vonMangoldt_nonneg (n := n)
  have hmu := muReal_sq_le_one (N - n)
  unfold actualSequence
  rw [mul_pow]
  calc
    _ ≤ ArithmeticFunction.vonMangoldt n ^ 2 * 1 :=
      mul_le_mul_of_nonneg_left hmu (sq_nonneg _)
    _ ≤ _ := by nlinarith

theorem active_row_log_sq_le {N alpha k n : ℕ} (hk : 0 < k) (ha : 1 ≤ alpha)
    (hs : 1 ≤ n ∧ n < N ∧ n < N - alpha * k) :
    Real.log ((k : ℝ) / (N - n : ℕ)) ^ 2 ≤ Real.log (N : ℝ) ^ 2 := by
  have hcut : n + alpha * k < N := by omega
  have hak : k ≤ alpha * k := by nlinarith
  have hm : 0 < N - n := by omega
  have hkm : k ≤ N - n := by omega
  have hkR : 0 < (k : ℝ) := by exact_mod_cast hk
  have hmR : 0 < ((N - n : ℕ) : ℝ) := by exact_mod_cast hm
  have hlogk : 0 ≤ Real.log (k : ℝ) :=
    Real.log_nonneg (by exact_mod_cast (show 1 ≤ k by omega))
  have hlogkm : Real.log (k : ℝ) ≤ Real.log (N - n : ℕ) :=
    Real.log_le_log hkR (by exact_mod_cast hkm)
  have hlogmN : Real.log (N - n : ℕ) ≤ Real.log (N : ℝ) :=
    Real.log_le_log hmR (by exact_mod_cast Nat.sub_le N n)
  rw [Real.log_div hkR.ne' hmR.ne']
  nlinarith

theorem centered_indicator_sq_le (k m : ℕ) :
    ((if k ∣ m then (1 : ℝ) else 0) - 1 / (k.totient : ℝ)) ^ 2 ≤
      (if k ∣ m then (1 : ℝ) else 0) + 1 / (k.totient : ℝ) ^ 2 := by
  have hphi : 0 ≤ 1 / (k.totient : ℝ) := by positivity
  have he : 1 / (k.totient : ℝ) ^ 2 = (1 / (k.totient : ℝ)) ^ 2 := by
    simp [div_pow]
  rw [he]
  by_cases h : k ∣ m <;> simp only [h, if_true, if_false] <;> nlinarith

theorem actual_row_term_sq_le {N alpha k n : ℕ} (hk : 0 < k) (ha : 1 ≤ alpha) :
    (actualSequence N n * actualRow N alpha k n) ^ 2 ≤
      Real.log (N : ℝ) ^ 4 *
        ((if k ∣ N - n then (1 : ℝ) else 0) + 1 / (k.totient : ℝ) ^ 2) := by
  by_cases hs : 1 ≤ n ∧ n < N ∧ n < N - alpha * k
  · have hseq := actualSequence_sq_le_log_sq hs.1 hs.2.1
    have hlog := active_row_log_sq_le hk ha hs
    have hpair := mul_le_mul hseq hlog
      (sq_nonneg (Real.log ((k : ℝ) / (N - n : ℕ)))) (sq_nonneg (Real.log (N : ℝ)))
    have hpair' : actualSequence N n ^ 2 *
        Real.log ((k : ℝ) / (N - n : ℕ)) ^ 2 ≤ Real.log (N : ℝ) ^ 4 := by
      nlinarith [hpair]
    rw [actualRow, if_pos hs]
    calc
      _ = (((if k ∣ N - n then (1 : ℝ) else 0) - 1 / (k.totient : ℝ)) ^ 2) *
          (actualSequence N n ^ 2 * Real.log ((k : ℝ) / (N - n : ℕ)) ^ 2) := by ring
      _ ≤ (((if k ∣ N - n then (1 : ℝ) else 0) - 1 / (k.totient : ℝ)) ^ 2) *
          Real.log (N : ℝ) ^ 4 := mul_le_mul_of_nonneg_left hpair' (sq_nonneg _)
      _ = Real.log (N : ℝ) ^ 4 *
          (((if k ∣ N - n then (1 : ℝ) else 0) - 1 / (k.totient : ℝ)) ^ 2) := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_left (centered_indicator_sq_le k (N - n))
        (by positivity)
  · rw [actualRow, if_neg hs]
    simp only [mul_zero, zero_pow (by decide : 4 ≠ 0), zero_pow (by decide : 2 ≠ 0)]
    apply mul_nonneg (by positivity)
    split_ifs <;> positivity

theorem complement_multiples_card_bound (N k : ℕ) (hk : 0 < k) :
    (k : ℝ) * (((Finset.range N).filter (fun n => k ∣ N - n)).card : ℝ) ≤ (N : ℝ) := by
  classical
  let u := (Finset.range N).filter (fun n => k ∣ N - n)
  let v := u.image (fun n => (N - n) / k)
  have hdiv (n : ℕ) (hn : n ∈ u) : k ∣ N - n := (Finset.mem_filter.mp hn).2
  have hnN (n : ℕ) (hn : n ∈ u) : n < N :=
    Finset.mem_range.mp (Finset.mem_filter.mp hn).1
  have hinj : Set.InjOn (fun n : ℕ => (N - n) / k) (u : Set ℕ) := by
    intro n hn m hm heq
    have hn' := Nat.mul_div_cancel' (hdiv n hn)
    have hm' := Nat.mul_div_cancel' (hdiv m hm)
    change (N - n) / k = (N - m) / k at heq
    rw [heq] at hn'
    have he := hn'.symm.trans hm'
    have hnn := hnN n hn
    have hmm := hnN m hm
    omega
  have hsub : v ⊆ Finset.Icc 1 (N / k) := by
    intro m hm
    obtain ⟨n, hn, rfl⟩ := Finset.mem_image.mp hm
    apply Finset.mem_Icc.mpr
    constructor
    · have hpos : 0 < N - n := by have hh := hnN n hn; omega
      have hquo := Nat.div_pos (Nat.le_of_dvd hpos (hdiv n hn)) hk
      omega
    · exact Nat.div_le_div_right (Nat.sub_le N n)
  have hcard : u.card ≤ N / k := by
    have hc := Finset.card_le_card hsub
    have he : v.card = u.card := Finset.card_image_iff.mpr hinj
    rw [he, Nat.card_Icc] at hc
    have hq0 : 0 ≤ N / k := Nat.zero_le _
    omega
  have hbound : k * u.card ≤ N :=
    (Nat.mul_le_mul_left k hcard).trans (Nat.mul_div_le N k)
  exact_mod_cast hbound

theorem actual_moduli_card_le (N Q : ℕ) : (actualModuli N Q).card ≤ Q := by
  have hsub : actualModuli N Q ⊆ Finset.Icc 1 Q := by
    intro k hk
    have hh := actualModuli_membership.mp hk
    exact Finset.mem_Icc.mpr ⟨hh.2.1, hh.1⟩
  have hc := Finset.card_le_card hsub
  rw [Nat.card_Icc] at hc
  omega

theorem actual_single_modulus_diagonal_le {N alpha Q k : ℕ}
    (hN : Even N) (ha : 1 ≤ alpha) (hk : k ∈ actualModuli N Q) :
    (∑ n ∈ Finset.range N, (k : ℝ) * (muReal k) ^ 2 *
      (actualSequence N n * actualRow N alpha k n) ^ 2) ≤
      2 * (N : ℝ) * Real.log (N : ℝ) ^ 4 := by
  have hkp : 0 < k := by
    have hh := (actualModuli_membership.mp hk).2.1
    omega
  have hksq := actual_modulus_mu_sq_eq_one hk
  have hcard := complement_multiples_card_bound N k hkp
  have hweight := actual_modulus_totient_weight_le_one hN hk
  have hcount : (∑ n ∈ Finset.range N, if k ∣ N - n then (1 : ℝ) else 0) =
      (((Finset.range N).filter (fun n => k ∣ N - n)).card : ℝ) := by
    rw [← Finset.sum_filter]
    simp
  have hcenter : (k : ℝ) *
      (∑ n ∈ Finset.range N,
        ((if k ∣ N - n then (1 : ℝ) else 0) + 1 / (k.totient : ℝ) ^ 2)) ≤ 2 * (N : ℝ) := by
    rw [Finset.sum_add_distrib, hcount]
    simp only [Finset.sum_const, Finset.card_range, nsmul_eq_mul]
    have hw : (N : ℝ) * ((k : ℝ) / (k.totient : ℝ) ^ 2) ≤ (N : ℝ) := by
      simpa only [mul_one] using mul_le_mul_of_nonneg_left hweight (Nat.cast_nonneg N)
    calc
      _ = (k : ℝ) * (((Finset.range N).filter (fun n => k ∣ N - n)).card : ℝ) +
          (N : ℝ) * ((k : ℝ) / (k.totient : ℝ) ^ 2) := by ring
      _ ≤ (N : ℝ) + (N : ℝ) := add_le_add hcard hw
      _ = _ := by ring
  calc
    _ ≤ ∑ n ∈ Finset.range N, (k : ℝ) * Real.log (N : ℝ) ^ 4 *
        ((if k ∣ N - n then (1 : ℝ) else 0) + 1 / (k.totient : ℝ) ^ 2) := by
      apply Finset.sum_le_sum
      intro n hn
      rw [hksq, mul_one]
      simpa only [mul_assoc] using
        mul_le_mul_of_nonneg_left (actual_row_term_sq_le (n := n) hkp ha) (Nat.cast_nonneg k)
    _ = Real.log (N : ℝ) ^ 4 * ((k : ℝ) *
        (∑ n ∈ Finset.range N,
          ((if k ∣ N - n then (1 : ℝ) else 0) + 1 / (k.totient : ℝ) ^ 2))) := by
      rw [← Finset.mul_sum]
      ring
    _ ≤ _ := by
      have hh := mul_le_mul_of_nonneg_left hcenter (by positivity : 0 ≤ Real.log (N : ℝ) ^ 4)
      nlinarith

theorem actualDiagonal_le_two_N_Q_log_four (N alpha Q : ℕ)
    (hN : Even N) (ha : 1 ≤ alpha) :
    actualDiagonal N alpha Q ≤ 2 * (N : ℝ) * (Q : ℝ) * Real.log (N : ℝ) ^ 4 := by
  unfold actualDiagonal diagonal
  calc
    _ ≤ ∑ _k ∈ actualModuli N Q, 2 * (N : ℝ) * Real.log (N : ℝ) ^ 4 :=
      Finset.sum_le_sum (fun k hk => actual_single_modulus_diagonal_le hN ha hk)
    _ = ((actualModuli N Q).card : ℝ) * (2 * (N : ℝ) * Real.log (N : ℝ) ^ 4) := by simp
    _ ≤ _ := by
      have hc : ((actualModuli N Q).card : ℝ) ≤ (Q : ℝ) := by
        exact_mod_cast actual_moduli_card_le N Q
      have hh := mul_le_mul_of_nonneg_right hc
        (by positivity : 0 ≤ 2 * (N : ℝ) * Real.log (N : ℝ) ^ 4)
      nlinarith

theorem actualDiagonal_rounded_cutoff_le (N : ℕ) (theta : ℝ)
    (hN : Even N) (hNp : 0 < N) (hscale : 2 ≤ (N : ℝ) ^ theta) :
    actualDiagonal N (CutoffScale.cutoff N theta) (CutoffScale.modulusCap N theta) ≤
      4 * (N : ℝ) ^ (2 - theta) * Real.log (N : ℝ) ^ 4 := by
  have hbase := actualDiagonal_le_two_N_Q_log_four N (CutoffScale.cutoff N theta)
    (CutoffScale.modulusCap N theta) hN
    (show 1 ≤ CutoffScale.cutoff N theta from CutoffScale.cutoff_positive hscale)
  have hcap := CutoffScale.modulusCap_le_two_rpow hNp hscale
  have hcap' := mul_le_mul_of_nonneg_left hcap
    (by positivity : 0 ≤ 2 * (N : ℝ) * Real.log (N : ℝ) ^ 4)
  have hpow : (N : ℝ) ^ (2 - theta) = (N : ℝ) * (N : ℝ) ^ (1 - theta) := by
    rw [show 2 - theta = 1 + (1 - theta) by ring,
      Real.rpow_add (by exact_mod_cast hNp : (0 : ℝ) < N), Real.rpow_one]
  rw [hpow]
  nlinarith

/-- Only the displayed numerical diagonal budget is assumed. Its implication
for the actual diagonal is proved by the preceding explicit theorem. -/
noncomputable local instance (N : ℕ) : Decidable (Exceptional.Goldbach N) :=
  Classical.propDecidable _

theorem goldbach_exceptional_card_le_with_explicit_diagonal (s : Finset ℕ)
    (alpha Q : ℕ → ℕ) (margin : ℕ → ℝ)
    (hN : ∀ N ∈ s, Even N) (ha : ∀ N ∈ s, 1 ≤ alpha N)
    (hm : ∀ N ∈ s, 0 < margin N)
    (hmain : ∀ N ∈ s, margin N + actualSignedError N (alpha N) (Q N) ≤
      Exceptional.primePairWeight N)
    (hbudget : ∀ N ∈ s,
      Exceptional.harmonicModulusMass N (Q N) *
        (2 * (N : ℝ) * (Q N : ℝ) * Real.log (N : ℝ) ^ 4) ≤ (margin N) ^ 2 / 2) :
    ((s.filter (fun N => ¬ Exceptional.Goldbach N)).card : ℝ) ≤
      2 * ∑ N ∈ s, Exceptional.normalizedPositiveOff N (alpha N) (Q N) (margin N) := by
  apply Exceptional.goldbach_exceptional_card_le_off_sum s alpha Q margin hm hmain
  intro N hn
  exact (mul_le_mul_of_nonneg_left
    (actualDiagonal_le_two_N_Q_log_four N (alpha N) (Q N) (hN N hn) (ha N hn))
    (Exceptional.harmonicModulusMass_nonneg N (Q N))).trans (hbudget N hn)

#print axioms odd_squarefree_totient_weight_le_one
#print axioms actual_modulus_odd_of_even
#print axioms actual_modulus_totient_weight_le_one
#print axioms muReal_sq_le_one
#print axioms actualSequence_sq_le_log_sq
#print axioms active_row_log_sq_le
#print axioms centered_indicator_sq_le
#print axioms actual_row_term_sq_le
#print axioms complement_multiples_card_bound
#print axioms actual_moduli_card_le
#print axioms actual_single_modulus_diagonal_le
#print axioms actualDiagonal_le_two_N_Q_log_four
#print axioms actualDiagonal_rounded_cutoff_le
#print axioms goldbach_exceptional_card_le_with_explicit_diagonal

end GoldbachResearch.Diagonal
