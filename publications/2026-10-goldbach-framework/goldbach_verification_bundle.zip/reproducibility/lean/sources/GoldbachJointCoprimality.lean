import GoldbachBilinear
import GoldbachVaughan
import Mathlib.NumberTheory.Divisors

/-!
# Exact joint coprimality masks for the shifted Goldbach correlations

Finite indicator algebra, genuine Moebius inclusion-exclusion, and integer
affine identities only. No smallness, independence, Davenport, large-sieve,
short-interval or Goldbach assertion is assumed or proved.
-/

namespace GoldbachResearch.JointCoprimality

open scoped BigOperators
open Finset ActualArithmetic

noncomputable def coprimeIndicator (b M : ℕ) : ℝ :=
  if b.Coprime M then 1 else 0

theorem coprime_product_iff (a b M : ℕ) :
    (a * b).Coprime M ↔ a.Coprime M ∧ b.Coprime M :=
  Nat.coprime_mul_iff_left

theorem crossed_coprime_iff (b N q q' : ℕ) :
    b.Coprime (N * q) ∧ b.Coprime (N * q') ↔
      b.Coprime (N * q * q') := by
  simp only [Nat.coprime_mul_iff_right]
  tauto

theorem coprimeIndicator_product (a b M : ℕ) :
    coprimeIndicator (a * b) M =
      coprimeIndicator a M * coprimeIndicator b M := by
  by_cases ha : a.Coprime M <;> by_cases hb : b.Coprime M <;>
    simp only [coprimeIndicator, coprime_product_iff, Nat.Coprime, ha, hb, and_self,
      true_and, false_and, and_true, and_false, if_true, if_false,
      one_mul, zero_mul, mul_zero]

theorem crossed_coprimeIndicator (b N q q' : ℕ) :
    coprimeIndicator b (N * q) * coprimeIndicator b (N * q') =
      coprimeIndicator b (N * q * q') := by
  by_cases hq : b.Coprime (N * q) <;>
    by_cases hq' : b.Coprime (N * q') <;>
    simp only [coprimeIndicator, ← crossed_coprime_iff, Nat.Coprime, hq, hq', and_self,
      true_and, false_and, and_true, and_false, if_true, if_false,
      one_mul, zero_mul, mul_zero]

private theorem sum_muReal_divisors (g : ℕ) :
    (∑ d ∈ g.divisors, muReal d) = if g = 1 then 1 else 0 := by
  have h := congrArg (fun f : ArithmeticFunction ℝ => f g)
    (show Vaughan.mu * Vaughan.zeta = 1 from
      ArithmeticFunction.coe_moebius_mul_coe_zeta)
  change (Vaughan.mu * (ArithmeticFunction.zeta : ArithmeticFunction ℝ)) g =
    (1 : ArithmeticFunction ℝ) g at h
  rw [ArithmeticFunction.coe_mul_zeta_apply] at h
  simpa only [Vaughan.mu, ArithmeticFunction.intCoe_apply, muReal,
    ArithmeticFunction.one_apply] using h

/-- M must be positive: Nat.divisors 0 is empty, while coprime 1 0 is true. -/
theorem coprimeIndicator_moebius_expansion (b M : ℕ) (hM : 0 < M) :
    coprimeIndicator b M =
      ∑ d ∈ M.divisors, muReal d * (if d ∣ b then 1 else 0) := by
  classical
  have hM0 : M ≠ 0 := hM.ne'
  have hg : Nat.gcd b M ≠ 0 := by
    intro hz
    exact hM0 (Nat.gcd_eq_zero_iff.mp hz).2
  have hf : M.divisors.filter (fun d => d ∣ b) = (Nat.gcd b M).divisors := by
    ext d
    simp only [Finset.mem_filter, Nat.mem_divisors, hM0, hg, and_true,
      Nat.dvd_gcd_iff]
    tauto
  symm
  calc
    (∑ d ∈ M.divisors, muReal d * (if d ∣ b then 1 else 0)) =
        ∑ d ∈ M.divisors.filter (fun d => d ∣ b), muReal d := by
      simp only [Finset.sum_filter, mul_ite, mul_one, mul_zero]
    _ = ∑ d ∈ (Nat.gcd b M).divisors, muReal d := by rw [hf]
    _ = coprimeIndicator b M := by
      rw [sum_muReal_divisors]
      rfl

/-- Inclusion-exclusion keeps the arbitrary signed summand f untouched. -/
theorem masked_sum_moebius_expansion (B : Finset ℕ) (M : ℕ) (hM : 0 < M)
    (f : ℕ → ℝ) :
    (∑ b ∈ B, coprimeIndicator b M * f b) =
      ∑ d ∈ M.divisors, muReal d * ∑ b ∈ B, if d ∣ b then f b else 0 := by
  classical
  simp_rw [coprimeIndicator_moebius_expansion _ _ hM, Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro d hd
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro b hb
  by_cases hdb : d ∣ b <;> simp [hdb]

/-- Crossing the modulus masks first gives one exact common-divisor sum. -/
theorem crossed_masked_sum_moebius_expansion (B : Finset ℕ)
    (N q q' : ℕ) (hN : 0 < N) (hq : 0 < q) (hq' : 0 < q') (f : ℕ → ℝ) :
    (∑ b ∈ B, (coprimeIndicator b (N * q) *
        coprimeIndicator b (N * q')) * f b) =
      ∑ d ∈ (N * q * q').divisors,
        muReal d * ∑ b ∈ B, if d ∣ b then f b else 0 := by
  simp_rw [crossed_coprimeIndicator]
  exact masked_sum_moebius_expansion B (N * q * q')
    (Nat.mul_pos (Nat.mul_pos hN hq) hq') f

/-- Integer arithmetic avoids a silent truncation of the shifted complement. -/
theorem affineComplement_shift (N a b h : ℤ) :
    Bilinear.affineComplement N (a + h) b =
      Bilinear.affineComplement N a b - b * h := by
  unfold Bilinear.affineComplement
  ring

/-- The determinant of the two affine factors is exactly -N*h. -/
theorem affine_pair_determinant (N a b h : ℤ) :
    a * Bilinear.affineComplement N (a + h) b -
        (a + h) * Bilinear.affineComplement N a b = -N * h := by
  unfold Bilinear.affineComplement
  ring

theorem common_divisor_dvd_shift (N a b h q : ℤ)
    (ha : q ∣ Bilinear.affineComplement N a b)
    (hc : q ∣ Bilinear.affineComplement N (a + h) b) : q ∣ b * h := by
  have hd := dvd_sub ha hc
  convert hd using 1
  unfold Bilinear.affineComplement
  ring

#print axioms coprime_product_iff
#print axioms crossed_coprime_iff
#print axioms coprimeIndicator_product
#print axioms crossed_coprimeIndicator
#print axioms coprimeIndicator_moebius_expansion
#print axioms masked_sum_moebius_expansion
#print axioms crossed_masked_sum_moebius_expansion
#print axioms affineComplement_shift
#print axioms affine_pair_determinant
#print axioms common_divisor_dvd_shift

end GoldbachResearch.JointCoprimality
