import Mathlib.Tactic

/-!
# Exact finite bounds for the Fejer grid-energy polynomial

These proofs do not assume Goldbach, the Riemann hypothesis, a prime-pair
asymptotic, or a large-sieve estimate. They formalize the finite polynomial
kernel used in the research manuscript. Its identification with a Fourier
energy and the full arithmetic coefficient expansion are separate obligations.
-/

namespace GoldbachResearch

def residualRadius (H g : ℕ) : ℕ := min (H % g) (g - H % g)

theorem residualRadius_le_width (H g : ℕ) : residualRadius H g ≤ H := by
  exact le_trans (min_le_left _ _) (Nat.mod_le _ _)

theorem twice_residualRadius_le_modulus (H g : ℕ) (hg : 0 < g) :
    2 * residualRadius H g ≤ g := by
  have hr := Nat.mod_lt H hg
  have ha := min_le_left (H % g) (g - H % g)
  have hb := min_le_right (H % g) (g - H % g)
  unfold residualRadius
  omega

noncomputable def gridNumerator (g d : ℝ) : ℝ := g * (2 * d ^ 3 + d) / 3 - d ^ 4

theorem gridNumerator_nonneg {g d : ℝ} (hd : 0 ≤ d) (hgd : 2 * d ≤ g) :
    0 ≤ gridNumerator g d := by
  have hr : 0 ≤ g - 2 * d := sub_nonneg.mpr hgd
  have heq : gridNumerator g d =
      ((g - 2 * d) * (2 * d ^ 3 + d) + d ^ 4 + 2 * d ^ 2) / 3 := by
    unfold gridNumerator
    ring
  rw [heq]
  positivity

theorem gridNumerator_le_uniform {g d : ℝ}
    (hd : 0 ≤ d) (hgd : 2 * d ≤ g) :
    gridNumerator g d ≤ g ^ 4 / 48 + g ^ 2 / 6 := by
  have hr : 0 ≤ g - 2 * d := sub_nonneg.mpr hgd
  have heq : g ^ 4 / 48 + g ^ 2 / 6 - gridNumerator g d =
      d ^ 2 * (g - 2 * d) ^ 2 / 2 +
      d * (g - 2 * d) ^ 3 / 6 +
      (g - 2 * d) ^ 4 / 48 +
      d * (g - 2 * d) / 3 + (g - 2 * d) ^ 2 / 6 := by
    unfold gridNumerator
    ring
  have hpos : 0 ≤ g ^ 4 / 48 + g ^ 2 / 6 - gridNumerator g d := by
    rw [heq]
    positivity
  linarith

theorem gridNumerator_le_residual_cube {g d : ℝ}
    (hg : 0 ≤ g) (hd : 1 ≤ d) : gridNumerator g d ≤ g * d ^ 3 := by
  have hd0 : 0 ≤ d := by linarith
  have hdm : 0 ≤ d - 1 := by linarith
  have hs : 0 ≤ (d - 1) * d * (d + 1) := by positivity
  have hcube : d ≤ d ^ 3 := by nlinarith
  have hmul : g * d ≤ g * d ^ 3 := mul_le_mul_of_nonneg_left hcube hg
  have hfour : 0 ≤ d ^ 4 := by positivity
  unfold gridNumerator
  nlinarith

noncomputable def gridEnergy (H g : ℕ) : ℝ :=
  gridNumerator (g : ℝ) (residualRadius H g : ℝ) / (H : ℝ) ^ 2

theorem gridEnergy_nonneg (H g : ℕ) (hg : 0 < g) : 0 ≤ gridEnergy H g := by
  have hd : 0 ≤ (residualRadius H g : ℝ) := Nat.cast_nonneg _
  have hgd : 2 * (residualRadius H g : ℝ) ≤ (g : ℝ) := by
    exact_mod_cast twice_residualRadius_le_modulus H g hg
  exact div_nonneg (gridNumerator_nonneg hd hgd) (sq_nonneg _)

theorem gridEnergy_le_modulus_fourth (H g : ℕ) (hg : 0 < g) :
    gridEnergy H g ≤ ((g : ℝ) ^ 4 / 48 + (g : ℝ) ^ 2 / 6) / (H : ℝ) ^ 2 := by
  have hd : 0 ≤ (residualRadius H g : ℝ) := Nat.cast_nonneg _
  have hgd : 2 * (residualRadius H g : ℝ) ≤ (g : ℝ) := by
    exact_mod_cast twice_residualRadius_le_modulus H g hg
  exact div_le_div_of_nonneg_right (gridNumerator_le_uniform hd hgd) (sq_nonneg _)

theorem gridEnergy_zero_of_dvd (H g : ℕ) (h : g ∣ H) : gridEnergy H g = 0 := by
  simp [gridEnergy, residualRadius, Nat.mod_eq_zero_of_dvd h, gridNumerator]

theorem gridEnergy_le_residual_cube (H g : ℕ) :
    gridEnergy H g ≤
      (g : ℝ) * (residualRadius H g : ℝ) ^ 3 / (H : ℝ) ^ 2 := by
  by_cases hd : residualRadius H g = 0
  · simp [gridEnergy, hd, gridNumerator]
  · have hd1 : 1 ≤ (residualRadius H g : ℝ) := by
      exact_mod_cast (Nat.one_le_iff_ne_zero.mpr hd)
    exact div_le_div_of_nonneg_right
      (gridNumerator_le_residual_cube (Nat.cast_nonneg _) hd1) (sq_nonneg _)

theorem gridEnergy_le_modulus_mul_width (H g : ℕ) (hH : 0 < H) :
    gridEnergy H g ≤ (g : ℝ) * (H : ℝ) := by
  have hh : 0 < (H : ℝ) := by exact_mod_cast hH
  have hd : (residualRadius H g : ℝ) ≤ (H : ℝ) := by
    exact_mod_cast residualRadius_le_width H g
  have hd0 : 0 ≤ (residualRadius H g : ℝ) := Nat.cast_nonneg _
  have hcube : (residualRadius H g : ℝ) ^ 3 ≤ (H : ℝ) ^ 3 :=
    pow_le_pow_left₀ hd0 hd 3
  calc
    gridEnergy H g ≤
        (g : ℝ) * (residualRadius H g : ℝ) ^ 3 / (H : ℝ) ^ 2 :=
      gridEnergy_le_residual_cube H g
    _ ≤ (g : ℝ) * (H : ℝ) ^ 3 / (H : ℝ) ^ 2 := by
      exact div_le_div_of_nonneg_right
        (mul_le_mul_of_nonneg_left hcube (Nat.cast_nonneg _)) (sq_nonneg _)
    _ = (g : ℝ) * (H : ℝ) := by field_simp; ring

noncomputable def combinedGridCap (H g : ℕ) : ℝ :=
  min ((g : ℝ) * (H : ℝ))
    (min (((g : ℝ) ^ 4 / 48 + (g : ℝ) ^ 2 / 6) / (H : ℝ) ^ 2)
      ((g : ℝ) * (residualRadius H g : ℝ) ^ 3 / (H : ℝ) ^ 2))

theorem gridEnergy_le_combined_cap (H g : ℕ) (hH : 0 < H) (hg : 0 < g) :
    gridEnergy H g ≤ combinedGridCap H g := by
  exact le_min (gridEnergy_le_modulus_mul_width H g hH)
    (le_min (gridEnergy_le_modulus_fourth H g hg) (gridEnergy_le_residual_cube H g))

/-- The sharper cap applies termwise to every finite weighted energy. -/
theorem finite_grid_energy_le_combined {ι : Type*} (s : Finset ι)
    (a : ι → ℝ) (g : ι → ℕ) (H : ℕ)
    (hH : 0 < H) (hg : ∀ i ∈ s, 0 < g i) :
    ∑ i ∈ s, a i ^ 2 * gridEnergy H (g i) ≤
      ∑ i ∈ s, a i ^ 2 * combinedGridCap H (g i) := by
  apply Finset.sum_le_sum
  intro i hi
  exact mul_le_mul_of_nonneg_left (gridEnergy_le_combined_cap H (g i) hH (hg i hi))
    (sq_nonneg _)

/-- A finite variance assembly lemma. Its explicit caps are inputs, not a
claim that all Ramanujan or large-sieve inputs have been formalized. -/
theorem finite_energy_le_weighted_caps {ι : Type*} (s : Finset ι)
    (a K C : ι → ℝ) (H : ℝ)
    (hK : ∀ i ∈ s, 0 ≤ K i)
    (hcap : ∀ i ∈ s, a i ^ 2 ≤ C i)
    (hkernel : ∀ i ∈ s, K i ≤ H)
    (hC : ∀ i ∈ s, 0 ≤ C i) :
    ∑ i ∈ s, a i ^ 2 * K i ≤ H * ∑ i ∈ s, C i := by
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro i hi
  calc
    a i ^ 2 * K i ≤ C i * K i :=
      mul_le_mul_of_nonneg_right (hcap i hi) (hK i hi)
    _ ≤ C i * H := mul_le_mul_of_nonneg_left (hkernel i hi) (hC i hi)
    _ = H * C i := by ring

#print axioms residualRadius_le_width
#print axioms twice_residualRadius_le_modulus
#print axioms gridNumerator_le_uniform
#print axioms gridEnergy_le_modulus_fourth
#print axioms gridEnergy_le_modulus_mul_width
#print axioms finite_grid_energy_le_combined
#print axioms finite_energy_le_weighted_caps

end GoldbachResearch
