import Mathlib.NumberTheory.VonMangoldt
import Mathlib.NumberTheory.ArithmeticFunction
import Mathlib.Data.Nat.Squarefree
import Mathlib.Tactic

/-!
Finite reference-gap bridge using a prime-square obstruction to squarefreeness.
The actual Mobius twist and Mangoldt prefix are used. Prime progression estimates,
the singular-series enclosure and the representation transfer are explicit inputs;
no analytic estimate or Goldbach theorem is installed as an axiom.
-/

namespace GoldbachResearch.ReferenceGap

open scoped BigOperators

noncomputable def muReal (n : ℕ) : ℝ := ArithmeticFunction.moebius n

noncomputable def psiPrefix (N : ℕ) : ℝ :=
  ∑ n ∈ Finset.range N, ArithmeticFunction.vonMangoldt n

noncomputable def actualTwist (N : ℕ) : ℝ :=
  ∑ n ∈ Finset.range N, ArithmeticFunction.vonMangoldt n * muReal (N - n)

noncomputable def squareObstructionMass (N p : ℕ) : ℝ :=
  ∑ n ∈ Finset.range N,
    if p ^ 2 ∣ N - n then ArithmeticFunction.vonMangoldt n else 0

theorem muReal_le_one (n : ℕ) : muReal n ≤ 1 := by
  have h : ArithmeticFunction.moebius n ≤ 1 :=
    (le_abs_self _).trans ArithmeticFunction.abs_moebius_le_one
  unfold muReal
  exact_mod_cast h

theorem muReal_zero_of_prime_square_dvd (m p : ℕ) (hp : p.Prime)
    (hdiv : p ^ 2 ∣ m) : muReal m = 0 := by
  have hns : ¬ Squarefree m := by
    intro hs
    exact (Nat.squarefree_iff_prime_squarefree.mp hs p hp)
      (by simpa only [pow_two] using hdiv)
  simp [muReal, ArithmeticFunction.moebius_eq_zero_of_not_squarefree hns]

theorem squareObstructionMass_nonneg (N p : ℕ) :
    0 ≤ squareObstructionMass N p := by
  unfold squareObstructionMass
  apply Finset.sum_nonneg
  intro n hn
  split_ifs
  · exact ArithmeticFunction.vonMangoldt_nonneg
  · rfl

theorem actualTwist_le_psi_sub_square_mass (N p : ℕ) (hp : p.Prime) :
    actualTwist N ≤ psiPrefix N - squareObstructionMass N p := by
  unfold actualTwist psiPrefix squareObstructionMass
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_le_sum
  intro n hn
  by_cases hd : p ^ 2 ∣ N - n
  · simp [hd, muReal_zero_of_prime_square_dvd _ _ hp hd]
  · simp only [hd, if_false, sub_zero]
    have h := mul_le_mul_of_nonneg_left (muReal_le_one (N - n))
      (ArithmeticFunction.vonMangoldt_nonneg (n := n))
    simpa only [mul_one] using h

theorem gap_lower_of_prefix_bounds (N p : ℕ) (hp : p.Prime)
    (psiUpper apLower : ℝ)
    (hpsi : psiPrefix N ≤ psiUpper)
    (hap : apLower ≤ squareObstructionMass N p) :
    (N : ℝ) - psiUpper + apLower ≤ (N : ℝ) - actualTwist N := by
  have h := actualTwist_le_psi_sub_square_mass N p hp
  linarith

theorem reference_lower_of_prefix_bounds (N p : ℕ) (hp : p.Prime)
    (singular singularLower psiUpper apLower : ℝ)
    (hs0 : 0 ≤ singularLower) (hs : singularLower ≤ singular)
    (hpsi : psiPrefix N ≤ psiUpper)
    (hap : apLower ≤ squareObstructionMass N p)
    (hgap : 0 ≤ (N : ℝ) - psiUpper + apLower) :
    singularLower * ((N : ℝ) - psiUpper + apLower) ≤
      singular * ((N : ℝ) - actualTwist N) := by
  have hg := gap_lower_of_prefix_bounds N p hp psiUpper apLower hpsi hap
  have hg0 : 0 ≤ (N : ℝ) - actualTwist N := hgap.trans hg
  exact (mul_le_mul_of_nonneg_left hg hs0).trans
    (mul_le_mul_of_nonneg_right hs hg0)

/-- Calibration only: the displayed analytic prefix inequalities remain premises. -/
theorem calibrated_gap (N p : ℕ) (hp : p.Prime) (x : ℝ) (hx : 0 ≤ x)
    (hN : (N : ℝ) = x + 1)
    (hpsi : psiPrefix N ≤ x + x / 21000 + x / 1000000000000)
    (hap : x / 9312 - x / 42000 ≤ squareObstructionMass N p) :
    (N : ℝ) / 100000 ≤ (N : ℝ) - actualTwist N := by
  have hg := gap_lower_of_prefix_bounds N p hp
    (x + x / 21000 + x / 1000000000000) (x / 9312 - x / 42000) hpsi hap
  rw [hN] at *
  linarith

/-- The residue and all other losses are still explicit unproved bounds. -/
theorem calibrated_positive_margin (N : ℕ) (hN : 0 < (N : ℝ))
    (reference residue otherLoss powerLoss : ℝ)
    (href : (2541 : ℝ) / 204800000 * N ≤ reference)
    (hres : residue ≤ (N : ℝ) / 1000000)
    (hother : otherLoss ≤ (N : ℝ) / 1000000)
    (hpower : powerLoss ≤ (N : ℝ) / 1000000) :
    0 < reference - otherLoss - powerLoss - residue := by
  linarith

#print axioms muReal_le_one
#print axioms muReal_zero_of_prime_square_dvd
#print axioms squareObstructionMass_nonneg
#print axioms actualTwist_le_psi_sub_square_mass
#print axioms gap_lower_of_prefix_bounds
#print axioms reference_lower_of_prefix_bounds
#print axioms calibrated_gap
#print axioms calibrated_positive_margin

end GoldbachResearch.ReferenceGap
