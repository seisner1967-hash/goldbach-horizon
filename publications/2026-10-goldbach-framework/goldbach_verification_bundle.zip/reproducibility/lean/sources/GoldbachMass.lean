import Mathlib.Tactic
import Mathlib.Data.Nat.Totient
import Mathlib.Data.Nat.Squarefree

/-! Positive arithmetic weights and their exact dyadic mass.
The statements here are finite; analytic estimates are not inserted as axioms.
-/

namespace GoldbachResearch.Mass

open Finset

noncomputable def primeCorrection (p : ℕ) : ℝ :=
  (2 * (p : ℝ) - 1) / ((p : ℝ) - 1) ^ 2

theorem primeCorrection_nonneg {p : ℕ} (hp : Nat.Prime p) :
    0 ≤ primeCorrection p := by
  have hp2 : (2 : ℝ) ≤ p := by exact_mod_cast hp.two_le
  unfold primeCorrection
  apply div_nonneg <;> nlinarith

theorem primeCorrection_identity {p : ℕ} (hp : Nat.Prime p) :
    1 + primeCorrection p = (p : ℝ) ^ 2 / ((p : ℝ) - 1) ^ 2 := by
  have hp2 : (2 : ℝ) ≤ p := by exact_mod_cast hp.two_le
  have hne : (p : ℝ) - 1 ≠ 0 := by linarith
  unfold primeCorrection
  field_simp
  ring

theorem squarefree_totient_product {n : ℕ} (hn : Squarefree n) :
    (Nat.totient n : ℝ) = ∏ p ∈ n.primeFactors, ((p : ℝ) - 1) := by
  rw [Nat.totient_eq_div_primeFactors_mul n, Nat.prod_primeFactors_of_squarefree hn,
    Nat.div_self (Nat.pos_of_ne_zero hn.ne_zero), one_mul, Nat.cast_prod]
  apply Finset.prod_congr rfl
  intro p hp
  exact Nat.cast_pred (Nat.prime_of_mem_primeFactors hp).pos

/-- The actual arithmetic weight has a positive finite divisor expansion,
indexed by subsets of its distinct prime factors. -/
theorem squarefree_weight_expansion {n : ℕ} (hn : Squarefree n) :
    (n : ℝ) / (Nat.totient n : ℝ) ^ 2 = (1 / (n : ℝ)) *
      ∑ s ∈ n.primeFactors.powerset, ∏ p ∈ s, primeCorrection p := by
  have hprod : ∏ p ∈ n.primeFactors, (p : ℝ) = (n : ℝ) := by
    rw [← Nat.cast_prod, Nat.prod_primeFactors_of_squarefree hn]
  have hphi := squarefree_totient_product hn
  have hnR : (n : ℝ) ≠ 0 := by exact_mod_cast hn.ne_zero
  have hphiR : (Nat.totient n : ℝ) ≠ 0 := by
    exact_mod_cast (Nat.totient_pos.mpr (Nat.pos_of_ne_zero hn.ne_zero)).ne'
  have hexp : (∑ s ∈ n.primeFactors.powerset, ∏ p ∈ s, primeCorrection p) =
      (n : ℝ) ^ 2 / (Nat.totient n : ℝ) ^ 2 := by
    rw [← Finset.prod_one_add]
    have heq : (∏ p ∈ n.primeFactors, (1 + primeCorrection p)) =
        ∏ p ∈ n.primeFactors, (p : ℝ) ^ 2 / ((p : ℝ) - 1) ^ 2 := by
      apply Finset.prod_congr rfl
      intro p hp
      exact primeCorrection_identity (Nat.prime_of_mem_primeFactors hp)
    rw [heq, Finset.prod_div_distrib, Finset.prod_pow, Finset.prod_pow, hprod, ← hphi]
  rw [hexp]
  field_simp
  ring

/-- A uniform harmonic bound on every real dyadic interval. -/
theorem dyadic_harmonic_le_one (s : Finset ℕ) (y : ℝ) (hy : 0 < y)
    (hs : ∀ n ∈ s, y < (n : ℝ) ∧ (n : ℝ) ≤ 2 * y) :
    ∑ n ∈ s, 1 / (n : ℝ) ≤ 1 := by
  let a : ℕ := Nat.floor y + 1
  have haN : 0 < a := by dsimp [a]; omega
  have ha : 0 < (a : ℝ) := by exact_mod_cast haN
  have hya : y < (a : ℝ) := by
    dsimp [a]
    simpa only [Nat.cast_add, Nat.cast_one] using Nat.lt_floor_add_one y
  have hlow (n : ℕ) (hn : n ∈ s) : a ≤ n := by
    have hf := (Nat.floor_lt (le_of_lt hy)).mpr (hs n hn).1
    dsimp [a]
    omega
  have hsub : s ⊆ Finset.Icc a (2 * a - 1) := by
    intro n hn
    have hlt : (n : ℝ) < 2 * (a : ℝ) := by linarith [(hs n hn).2]
    have hnlt : n < 2 * a := by exact_mod_cast hlt
    exact Finset.mem_Icc.mpr ⟨hlow n hn, by omega⟩
  have hcard : s.card ≤ a := by
    have hh := Finset.card_le_card hsub
    rw [Nat.card_Icc] at hh
    omega
  calc
    ∑ n ∈ s, 1 / (n : ℝ) ≤ ∑ _n ∈ s, 1 / (a : ℝ) := by
      apply Finset.sum_le_sum
      intro n hn
      exact one_div_le_one_div_of_le ha (by exact_mod_cast hlow n hn)
    _ = (s.card : ℝ) * (1 / (a : ℝ)) := by simp
    _ ≤ (a : ℝ) * (1 / (a : ℝ)) := by
      exact mul_le_mul_of_nonneg_right (by exact_mod_cast hcard) (by positivity)
    _ = 1 := by field_simp

theorem dyadic_multiples_harmonic (s : Finset ℕ) (y : ℝ) (d : ℕ)
    (hy : 0 < y) (hd : 0 < d)
    (hs : ∀ n ∈ s, y < (n : ℝ) ∧ (n : ℝ) ≤ 2 * y) :
    ∑ n ∈ s.filter (fun n => d ∣ n), 1 / (n : ℝ) ≤ 1 / (d : ℝ) := by
  let u := s.filter (fun n => d ∣ n)
  let v := u.image (fun n => n / d)
  have hdR : 0 < (d : ℝ) := by exact_mod_cast hd
  have hdiv (n : ℕ) (hn : n ∈ u) : d ∣ n := (Finset.mem_filter.mp hn).2
  have hinj : Set.InjOn (fun n : ℕ => n / d) (u : Set ℕ) := by
    intro n hn m hm heq
    have hn' := Nat.mul_div_cancel' (hdiv n hn)
    have hm' := Nat.mul_div_cancel' (hdiv m hm)
    change n / d = m / d at heq
    rw [heq] at hn'
    exact hn'.symm.trans hm'
  have hv : ∀ m ∈ v, y / (d : ℝ) < (m : ℝ) ∧ (m : ℝ) ≤ 2 * (y / (d : ℝ)) := by
    intro m hm
    obtain ⟨n, hn, rfl⟩ := Finset.mem_image.mp hm
    rw [Nat.cast_div (hdiv n hn) hdR.ne']
    have hh := hs n (Finset.mem_filter.mp hn).1
    constructor
    · exact (div_lt_div_iff_of_pos_right hdR).mpr hh.1
    · have hb := (div_le_div_iff_of_pos_right hdR).mpr hh.2
      simpa only [mul_div_assoc] using hb
  have hh := dyadic_harmonic_le_one v (y / (d : ℝ)) (div_pos hy hdR) hv
  have heq : (∑ n ∈ u, 1 / (n : ℝ)) =
      (1 / (d : ℝ)) * ∑ m ∈ v, 1 / (m : ℝ) := by
    rw [Finset.mul_sum, Finset.sum_image hinj]
    apply Finset.sum_congr rfl
    intro n hn
    rw [Nat.cast_div (hdiv n hn) hdR.ne']
    field_simp
  rw [← show u = s.filter (fun n => d ∣ n) from rfl, heq]
  calc
    (1 / (d : ℝ)) * ∑ m ∈ v, 1 / (m : ℝ) ≤ (1 / (d : ℝ)) * 1 :=
      mul_le_mul_of_nonneg_left hh (by positivity)
    _ = 1 / (d : ℝ) := by ring

noncomputable def correctionProduct (t : Finset ℕ) : ℝ :=
  ∏ p ∈ t, primeCorrection p

noncomputable def subsetDivisorMajorant (P : Finset ℕ) (n : ℕ) : ℝ :=
  ∑ t ∈ P.powerset,
    if (∏ p ∈ t, p) ∣ n then correctionProduct t / (n : ℝ) else 0

theorem correctionProduct_nonneg (P t : Finset ℕ)
    (hP : ∀ p ∈ P, Nat.Prime p) (ht : t ⊆ P) : 0 ≤ correctionProduct t := by
  apply Finset.prod_nonneg
  intro p hp
  exact primeCorrection_nonneg (hP p (ht hp))

theorem squarefree_weight_le_majorant (P : Finset ℕ) (n : ℕ)
    (hP : ∀ p ∈ P, Nat.Prime p) (hn : Squarefree n)
    (hsub : n.primeFactors ⊆ P) :
    (n : ℝ) / (Nat.totient n : ℝ) ^ 2 ≤ subsetDivisorMajorant P n := by
  have heq : (n : ℝ) / (Nat.totient n : ℝ) ^ 2 =
      ∑ t ∈ n.primeFactors.powerset,
        if (∏ p ∈ t, p) ∣ n then correctionProduct t / (n : ℝ) else 0 := by
    rw [squarefree_weight_expansion hn, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro t ht
    have htd := Finset.prod_dvd_prod_of_subset t n.primeFactors (fun p => p)
      (Finset.mem_powerset.mp ht)
    rw [Nat.prod_primeFactors_of_squarefree hn] at htd
    rw [if_pos htd]
    unfold correctionProduct
    ring
  rw [heq]
  unfold subsetDivisorMajorant
  apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.powerset_mono.mpr hsub)
  intro t ht htn
  have hc := correctionProduct_nonneg P t hP (Finset.mem_powerset.mp ht)
  split_ifs <;> positivity

theorem subsetDivisorMajorant_dyadic_mass (P s : Finset ℕ) (y : ℝ)
    (hP : ∀ p ∈ P, Nat.Prime p) (hy : 0 < y)
    (hs : ∀ n ∈ s, y < (n : ℝ) ∧ (n : ℝ) ≤ 2 * y) :
    ∑ n ∈ s, subsetDivisorMajorant P n ≤
      ∏ p ∈ P, (1 + primeCorrection p / (p : ℝ)) := by
  unfold subsetDivisorMajorant
  rw [Finset.sum_comm]
  have hterm (t : Finset ℕ) (ht : t ∈ P.powerset) :
      (∑ n ∈ s, if (∏ p ∈ t, p) ∣ n then correctionProduct t / (n : ℝ) else 0) ≤
        correctionProduct t / ((∏ p ∈ t, p : ℕ) : ℝ) := by
    have htp := Finset.mem_powerset.mp ht
    have hd : 0 < ∏ p ∈ t, p := by
      exact Finset.prod_pos (fun p hp => (hP p (htp hp)).pos)
    have hh := dyadic_multiples_harmonic s y (∏ p ∈ t, p) hy hd hs
    have hc := correctionProduct_nonneg P t hP htp
    have heq : (∑ n ∈ s, if (∏ p ∈ t, p) ∣ n then correctionProduct t / (n : ℝ) else 0) =
        correctionProduct t * ∑ n ∈ s.filter (fun n => (∏ p ∈ t, p) ∣ n), 1 / (n : ℝ) := by
      rw [Finset.mul_sum, Finset.sum_filter]
      apply Finset.sum_congr rfl
      intro n hn
      split_ifs <;> simp [div_eq_mul_inv]
    rw [heq]
    simpa only [mul_one_div] using mul_le_mul_of_nonneg_left hh hc
  calc
    (∑ t ∈ P.powerset, ∑ n ∈ s,
        if (∏ p ∈ t, p) ∣ n then correctionProduct t / (n : ℝ) else 0) ≤
      ∑ t ∈ P.powerset, correctionProduct t / ((∏ p ∈ t, p : ℕ) : ℝ) := by
        exact Finset.sum_le_sum hterm
    _ = ∏ p ∈ P, (1 + primeCorrection p / (p : ℝ)) := by
      rw [Finset.prod_one_add]
      apply Finset.sum_congr rfl
      intro t ht
      rw [Finset.prod_div_distrib, ← Nat.cast_prod]
      rfl

/-- The actual squarefree arithmetic dyadic mass, with no mass estimate
assumed as a premise. Taking P to be the odd primes <=Q gives K_Q. -/
theorem squarefree_dyadic_mass (P s : Finset ℕ) (y : ℝ)
    (hP : ∀ p ∈ P, Nat.Prime p) (hy : 0 < y)
    (hs : ∀ n ∈ s, y < (n : ℝ) ∧ (n : ℝ) ≤ 2 * y)
    (hsf : ∀ n ∈ s, Squarefree n)
    (hsub : ∀ n ∈ s, n.primeFactors ⊆ P) :
    ∑ n ∈ s, (n : ℝ) / (Nat.totient n : ℝ) ^ 2 ≤
      ∏ p ∈ P, (1 + primeCorrection p / (p : ℝ)) := by
  exact le_trans (Finset.sum_le_sum (fun n hn =>
    squarefree_weight_le_majorant P n hP (hsf n hn) (hsub n hn)))
    (subsetDivisorMajorant_dyadic_mass P s y hP hy hs)

noncomputable def oddHarmonic (Q : ℕ) : ℝ :=
  ∑ n ∈ (Finset.range (Q + 1)).filter Odd, 1 / (n : ℝ)

theorem oddHarmonic_nonneg (Q : ℕ) : 0 ≤ oddHarmonic Q := by
  exact Finset.sum_nonneg (fun n hn => by positivity)

theorem odd_multiples_harmonic (s : Finset ℕ) (Q d : ℕ) (hd : 0 < d)
    (hs : ∀ n ∈ s, Odd n ∧ n ≤ Q) :
    ∑ n ∈ s.filter (fun n => d ∣ n), 1 / (n : ℝ) ≤ oddHarmonic Q / (d : ℝ) := by
  let u := s.filter (fun n => d ∣ n)
  let v := u.image (fun n => n / d)
  have hdR : 0 < (d : ℝ) := by exact_mod_cast hd
  have hdiv (n : ℕ) (hn : n ∈ u) : d ∣ n := (Finset.mem_filter.mp hn).2
  have hinj : Set.InjOn (fun n : ℕ => n / d) (u : Set ℕ) := by
    intro n hn m hm heq
    change n / d = m / d at heq
    have hn' := Nat.mul_div_cancel' (hdiv n hn)
    have hm' := Nat.mul_div_cancel' (hdiv m hm)
    rw [heq] at hn'
    exact hn'.symm.trans hm'
  have hsub : v ⊆ (Finset.range (Q + 1)).filter Odd := by
    intro m hm
    obtain ⟨n, hn, rfl⟩ := Finset.mem_image.mp hm
    have hh := hs n (Finset.mem_filter.mp hn).1
    have hmul := Nat.mul_div_cancel' (hdiv n hn)
    have hodd : Odd (n / d) := by
      have ho : Odd (d * (n / d)) := by simpa only [hmul] using hh.1
      exact (Nat.odd_mul.mp ho).2
    exact Finset.mem_filter.mpr ⟨Finset.mem_range.mpr (by
      have hb := Nat.div_le_self n d
      omega), hodd⟩
  have hh : (∑ m ∈ v, 1 / (m : ℝ)) ≤ oddHarmonic Q := by
    exact Finset.sum_le_sum_of_subset_of_nonneg hsub (fun m hm hmv => by positivity)
  have heq : (∑ n ∈ u, 1 / (n : ℝ)) =
      (1 / (d : ℝ)) * ∑ m ∈ v, 1 / (m : ℝ) := by
    rw [Finset.mul_sum, Finset.sum_image hinj]
    apply Finset.sum_congr rfl
    intro n hn
    rw [Nat.cast_div (hdiv n hn) hdR.ne']
    field_simp
  rw [← show u = s.filter (fun n => d ∣ n) from rfl, heq]
  simpa only [one_div_mul_eq_div] using mul_le_mul_of_nonneg_left hh (by positivity : 0 ≤ 1 / (d : ℝ))

theorem squarefree_odd_full_mass (P s : Finset ℕ) (Q : ℕ)
    (hP : ∀ p ∈ P, Nat.Prime p)
    (hs : ∀ n ∈ s, Odd n ∧ n ≤ Q)
    (hsf : ∀ n ∈ s, Squarefree n)
    (hsub : ∀ n ∈ s, n.primeFactors ⊆ P) :
    ∑ n ∈ s, (n : ℝ) / (Nat.totient n : ℝ) ^ 2 ≤
      (∏ p ∈ P, (1 + primeCorrection p / (p : ℝ))) * oddHarmonic Q := by
  have hstart : (∑ n ∈ s, (n : ℝ) / (Nat.totient n : ℝ) ^ 2) ≤
      ∑ n ∈ s, subsetDivisorMajorant P n :=
    Finset.sum_le_sum (fun n hn => squarefree_weight_le_majorant P n hP (hsf n hn) (hsub n hn))
  apply le_trans hstart
  unfold subsetDivisorMajorant
  rw [Finset.sum_comm]
  have hterm (t : Finset ℕ) (ht : t ∈ P.powerset) :
      (∑ n ∈ s, if (∏ p ∈ t, p) ∣ n then correctionProduct t / (n : ℝ) else 0) ≤
        correctionProduct t / ((∏ p ∈ t, p : ℕ) : ℝ) * oddHarmonic Q := by
    have htp := Finset.mem_powerset.mp ht
    have hd : 0 < ∏ p ∈ t, p :=
      Finset.prod_pos (fun p hp => (hP p (htp hp)).pos)
    have hh := odd_multiples_harmonic s Q (∏ p ∈ t, p) hd hs
    have hc := correctionProduct_nonneg P t hP htp
    have heq : (∑ n ∈ s, if (∏ p ∈ t, p) ∣ n then correctionProduct t / (n : ℝ) else 0) =
        correctionProduct t * ∑ n ∈ s.filter (fun n => (∏ p ∈ t, p) ∣ n), 1 / (n : ℝ) := by
      rw [Finset.mul_sum, Finset.sum_filter]
      apply Finset.sum_congr rfl
      intro n hn
      split_ifs <;> simp [div_eq_mul_inv]
    rw [heq]
    convert mul_le_mul_of_nonneg_left hh hc using 1
    ring
  calc
    (∑ t ∈ P.powerset, ∑ n ∈ s,
        if (∏ p ∈ t, p) ∣ n then correctionProduct t / (n : ℝ) else 0) ≤
      ∑ t ∈ P.powerset, correctionProduct t / ((∏ p ∈ t, p : ℕ) : ℝ) * oddHarmonic Q :=
        Finset.sum_le_sum hterm
    _ = (∏ p ∈ P, (1 + primeCorrection p / (p : ℝ))) * oddHarmonic Q := by
      rw [← Finset.sum_mul, Finset.prod_one_add]
      congr 1
      apply Finset.sum_congr rfl
      intro t ht
      rw [Finset.prod_div_distrib, ← Nat.cast_prod]
      rfl

def oddPrimes (Q : ℕ) : Finset ℕ :=
  (Finset.range (Q + 1)).filter (fun p => Nat.Prime p ∧ Odd p)

noncomputable def oddEulerMass (Q : ℕ) : ℝ :=
  ∏ p ∈ oddPrimes Q,
    (1 + (2 * (p : ℝ) - 1) / ((p : ℝ) * ((p : ℝ) - 1) ^ 2))

theorem mem_oddPrimes {Q p : ℕ} : p ∈ oddPrimes Q ↔ p ≤ Q ∧ Nat.Prime p ∧ Odd p := by
  simp [oddPrimes, Nat.lt_succ_iff]

theorem odd_primeFactors_subset {n Q : ℕ} (hn : Squarefree n) (ho : Odd n) (hq : n ≤ Q) :
    n.primeFactors ⊆ oddPrimes Q := by
  intro p hp
  have hprime := Nat.prime_of_mem_primeFactors hp
  have hd := Nat.dvd_of_mem_primeFactors hp
  have hpn := Nat.le_of_dvd (Nat.pos_of_ne_zero hn.ne_zero) hd
  have hop : Odd p := by
    obtain ⟨m, hm⟩ := hd
    rw [hm] at ho
    exact (Nat.odd_mul.mp ho).1
  exact mem_oddPrimes.mpr ⟨le_trans hpn hq, hprime, hop⟩

theorem oddEulerMass_eq (Q : ℕ) :
    oddEulerMass Q = ∏ p ∈ oddPrimes Q, (1 + primeCorrection p / (p : ℝ)) := by
  unfold oddEulerMass
  apply Finset.prod_congr rfl
  intro p hp
  unfold primeCorrection
  rw [div_div]
  congr 2
  ring

/-- This is the actual odd squarefree w(n)=n/phi(n)^2 mass needed by
the terminal-band proof; prime-factor support is derived, not assumed. -/
theorem actual_odd_dyadic_mass (s : Finset ℕ) (Q : ℕ) (y : ℝ) (hy : 0 < y)
    (hs : ∀ n ∈ s, Odd n ∧ Squarefree n ∧ n ≤ Q ∧
      y < (n : ℝ) ∧ (n : ℝ) ≤ 2 * y) :
    ∑ n ∈ s, (n : ℝ) / (Nat.totient n : ℝ) ^ 2 ≤ oddEulerMass Q := by
  rw [oddEulerMass_eq]
  apply squarefree_dyadic_mass (oddPrimes Q) s y
  · intro p hp
    exact (mem_oddPrimes.mp hp).2.1
  · exact hy
  · intro n hn
    exact (hs n hn).2.2.2
  · intro n hn
    exact (hs n hn).2.1
  · intro n hn
    have hh := hs n hn
    exact odd_primeFactors_subset hh.2.1 hh.1 hh.2.2.1

theorem actual_odd_full_mass (s : Finset ℕ) (Q : ℕ)
    (hs : ∀ n ∈ s, Odd n ∧ Squarefree n ∧ n ≤ Q) :
    ∑ n ∈ s, (n : ℝ) / (Nat.totient n : ℝ) ^ 2 ≤ oddEulerMass Q * oddHarmonic Q := by
  rw [oddEulerMass_eq]
  apply squarefree_odd_full_mass (oddPrimes Q) s Q
  · intro p hp
    exact (mem_oddPrimes.mp hp).2.1
  · intro n hn
    exact ⟨(hs n hn).1, (hs n hn).2.2⟩
  · intro n hn
    exact (hs n hn).2.1
  · intro n hn
    have hh := hs n hn
    exact odd_primeFactors_subset hh.2.1 hh.1 hh.2.2

/-- The mirrored dyadic window used by the integer minima of anchor fibers. -/
theorem actual_odd_dyadic_mass_mirror (s : Finset ℕ) (Q m : ℕ) (hm : 0 < m)
    (hs : ∀ n ∈ s, Odd n ∧ Squarefree n ∧ n ≤ Q ∧ m ≤ n ∧ n < 2 * m) :
    ∑ n ∈ s, (n : ℝ) / (Nat.totient n : ℝ) ^ 2 ≤ oddEulerMass Q := by
  have hmR : (1 : ℝ) ≤ m := by exact_mod_cast hm
  apply actual_odd_dyadic_mass s Q ((m : ℝ) - 1 / 4)
  · linarith
  · intro n hn
    have hh := hs n hn
    have hlo : (m : ℝ) ≤ n := by exact_mod_cast hh.2.2.2.1
    have hhiN : n ≤ 2 * m - 1 := by omega
    have hhi : (n : ℝ) ≤ 2 * (m : ℝ) - 1 := by
      have hnlt : n + 1 ≤ 2 * m := by omega
      have hnltR : (n : ℝ) + 1 ≤ 2 * (m : ℝ) := by exact_mod_cast hnlt
      linarith
    exact ⟨hh.1, hh.2.1, hh.2.2.1, by linarith, by linarith⟩

#print axioms primeCorrection_identity
#print axioms squarefree_weight_expansion
#print axioms dyadic_harmonic_le_one
#print axioms dyadic_multiples_harmonic
#print axioms squarefree_dyadic_mass
#print axioms squarefree_odd_full_mass
#print axioms actual_odd_dyadic_mass
#print axioms actual_odd_full_mass
#print axioms actual_odd_dyadic_mass_mirror

end GoldbachResearch.Mass
