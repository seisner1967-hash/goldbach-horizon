import GoldbachTypeIIVariance

/-!
# Exact prime-factor strata in the signed Vaughan coefficient

The shared gcd is independent of b. Coprime strata give a reducible
quadratic Moebius value, whereas a shared factor enters as mu(g)^2 with
explicit squarefree compatibility masks. These are structural identities,
not cancellation estimates or polynomial-phase orthogonality.
-/

namespace GoldbachResearch.PairStructure

open ActualArithmetic SignedKernel

theorem gcd_coefficient_complement (N a b : ℕ) (hab : a * b ≤ N) :
    Nat.gcd a (N - a * b) = Nat.gcd a N := by
  have h := Nat.gcd_add_mul_left_right a (N - a * b) b
  rw [Nat.sub_add_cancel hab] at h
  exact h.symm

/-- This is mu evaluated ON a polynomial, not mu times a polynomial phase. -/
theorem coprime_pair_as_polynomial (N a b : ℕ) (hab : a * b ≤ N)
    (hcop : a.Coprime N) :
    muReal a * muReal (N - a * b) = muReal (a * (N - a * b)) := by
  have hm : a.Coprime (N - a * b) := by
    change Nat.gcd a (N - a * b) = 1
    rw [gcd_coefficient_complement N a b hab]
    exact hcop
  rw [muReal_mul_exact, if_pos hm]

/-- Shared prime signs occur twice and leave a nonnegative square, subject
to the exact compatibility masks. They need not produce alternation. -/
theorem common_factor_pair (g R r b : ℕ) :
    muReal (g * r) * muReal (g * R - (g * r) * b) =
      if g.Coprime r ∧ g.Coprime (R - r * b) then
        muReal g ^ 2 * muReal r * muReal (R - r * b)
      else 0 := by
  have he : g * R - (g * r) * b = g * (R - r * b) := by
    rw [Nat.mul_sub_left_distrib, Nat.mul_assoc]
  rw [he, muReal_mul_exact g r, muReal_mul_exact g (R - r * b)]
  by_cases hr : g.Coprime r
  · by_cases hb : g.Coprime (R - r * b)
    · simp only [if_pos hr, if_pos hb, if_pos (And.intro hr hb)]
      ring
    · simp [hr, hb]
  · simp [hr]

#print axioms gcd_coefficient_complement
#print axioms coprime_pair_as_polynomial
#print axioms common_factor_pair

end GoldbachResearch.PairStructure
