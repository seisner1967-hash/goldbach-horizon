import GoldbachTypeIIAssembly

/-!
# Literal variance reduction to signed Vaughan dispersion

All finite identities and bounds here are unconditional. The analytic
claim that the Type I remainder has arbitrary logarithmic savings is a
separate written derivation using Davenport, not a Lean theorem here.
No bound for the modulus-weighted signed Type II dispersion is assumed.
-/

namespace GoldbachResearch.TypeIIVariance

open scoped BigOperators
open Finset ActualArithmetic TypeIIAssembly

noncomputable def typeIRow (N cutoff k U V : ℕ) : ℝ :=
  Vaughan.signedRow N cutoff k (Vaughan.typeOneLog U) -
    Vaughan.signedRow N cutoff k (Vaughan.typeOneCorrection U V) +
    Vaughan.signedRow N cutoff k
      (Vaughan.cutLE V ArithmeticFunction.vonMangoldt)

noncomputable def typeIIRow (N cutoff k U V : ℕ) : ℝ :=
  Vaughan.signedRow N cutoff k (Vaughan.typeTwo U V)

noncomputable def typeIVariance (N cutoff Q U V : ℕ) : ℝ :=
  ∑ k ∈ actualModuli N Q,
    (k : ℝ) * muReal k ^ 2 * typeIRow N cutoff k U V ^ 2

noncomputable def typeIIVariance (N cutoff Q U V : ℕ) : ℝ :=
  ∑ k ∈ actualModuli N Q,
    (k : ℝ) * muReal k ^ 2 * typeIIRow N cutoff k U V ^ 2

noncomputable def signedDispersion (N cutoff k U V : ℕ) : ℝ :=
  Bilinear.rowEnergy (activeSecond N V) (activeFirst N U) muReal
    (fun b a => Bilinear.actualTypeIIKernel N cutoff k a b)

noncomputable def modulusDispersionBudget (N cutoff Q U V : ℕ) : ℝ :=
  ∑ k ∈ actualModuli N Q,
    (k : ℝ) * muReal k ^ 2 * signedDispersion N cutoff k U V

theorem actualEpsilon_eq_typeI_add_typeII (N cutoff k U V : ℕ) :
    actualEpsilon N cutoff k =
      typeIRow N cutoff k U V + typeIIRow N cutoff k U V :=
  Vaughan.actualEpsilon_vaughan N cutoff k U V

/-- The four actual Möbius signs are retained in the dispersion identity. -/
theorem signedDispersion_eq_four_signed_factors (N cutoff k U V : ℕ) :
    signedDispersion N cutoff k U V =
      ∑ a ∈ activeFirst N U, ∑ c ∈ activeFirst N U,
        muReal a * muReal c * ∑ b ∈ activeSecond N V,
          muReal (N - a * b) * muReal (N - c * b) *
            actualRow N cutoff k (a * b) * actualRow N cutoff k (c * b) := by
  rw [signedDispersion, Bilinear.signed_dispersion_eq_alpha_correlations]
  apply Finset.sum_congr rfl
  intro a ha
  apply Finset.sum_congr rfl
  intro c hc
  congr 1
  apply Finset.sum_congr rfl
  intro b hb
  unfold Bilinear.actualTypeIIKernel
  ring

theorem typeIIRow_sq_le_beta_mass_dispersion (N cutoff k U V : ℕ) :
    typeIIRow N cutoff k U V ^ 2 ≤
      Bilinear.coefficientMass (activeSecond N V) (Vaughan.beta V) *
        signedDispersion N cutoff k U V := by
  unfold typeIIRow signedDispersion
  rw [actual_signedRow_typeTwo_eq_active_bilinear]
  exact Bilinear.bilinear_sq_le_beta_mass_signed_dispersion
    (activeFirst N U) (activeSecond N V) muReal (Vaughan.beta V)
    (Bilinear.actualTypeIIKernel N cutoff k)

theorem actualVariance_le_two_typeI_add_two_typeII (N cutoff Q U V : ℕ) :
    actualVariance N cutoff Q ≤
      2 * typeIVariance N cutoff Q U V + 2 * typeIIVariance N cutoff Q U V := by
  unfold actualVariance typeIVariance typeIIVariance
  rw [Finset.mul_sum, Finset.mul_sum, ← Finset.sum_add_distrib]
  apply Finset.sum_le_sum
  intro k hk
  rw [actualEpsilon_eq_typeI_add_typeII N cutoff k U V]
  have hw : 0 ≤ (k : ℝ) * muReal k ^ 2 :=
    mul_nonneg (Nat.cast_nonneg k) (sq_nonneg _)
  have hr : (typeIRow N cutoff k U V + typeIIRow N cutoff k U V) ^ 2 ≤
      2 * typeIRow N cutoff k U V ^ 2 + 2 * typeIIRow N cutoff k U V ^ 2 := by
    nlinarith [sq_nonneg (typeIRow N cutoff k U V - typeIIRow N cutoff k U V)]
  have hh := mul_le_mul_of_nonneg_left hr hw
  nlinarith

theorem typeIIVariance_le_beta_mass_modulus_dispersion (N cutoff Q U V : ℕ) :
    typeIIVariance N cutoff Q U V ≤
      Bilinear.coefficientMass (activeSecond N V) (Vaughan.beta V) *
        modulusDispersionBudget N cutoff Q U V := by
  unfold typeIIVariance modulusDispersionBudget
  rw [Finset.mul_sum]
  apply Finset.sum_le_sum
  intro k hk
  have hh := mul_le_mul_of_nonneg_left
    (typeIIRow_sq_le_beta_mass_dispersion N cutoff k U V)
    (mul_nonneg (Nat.cast_nonneg k) (sq_nonneg (muReal k)))
  simpa only [mul_left_comm, mul_assoc] using hh

/-- The exact modulus-weighted target; no analytic cancellation is hidden. -/
theorem actualVariance_le_typeI_and_signed_dispersion (N cutoff Q U V : ℕ) :
    actualVariance N cutoff Q ≤
      2 * typeIVariance N cutoff Q U V +
        2 * Bilinear.coefficientMass (activeSecond N V) (Vaughan.beta V) *
          modulusDispersionBudget N cutoff Q U V := by
  have h1 := actualVariance_le_two_typeI_add_two_typeII N cutoff Q U V
  have h2 := typeIIVariance_le_beta_mass_modulus_dispersion N cutoff Q U V
  linarith

#print axioms actualEpsilon_eq_typeI_add_typeII
#print axioms signedDispersion_eq_four_signed_factors
#print axioms typeIIRow_sq_le_beta_mass_dispersion
#print axioms actualVariance_le_two_typeI_add_two_typeII
#print axioms typeIIVariance_le_beta_mass_modulus_dispersion
#print axioms actualVariance_le_typeI_and_signed_dispersion

end GoldbachResearch.TypeIIVariance
