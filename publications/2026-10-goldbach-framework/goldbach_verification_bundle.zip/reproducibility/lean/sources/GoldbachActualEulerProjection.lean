import Mathlib.NumberTheory.ArithmeticFunction
import Mathlib.Data.Nat.Totient
import Mathlib.Tactic

/-!
The actual finite local b-projection used in the reference model.
Both choices b=1,p retain their arithmetic Mobius signs and the
totient of the real lcm. No infinite product or analytic bound is asserted.
-/

namespace GoldbachResearch.ActualEulerProjection

open scoped BigOperators

noncomputable def localProjection (p : ℕ) (dSelected : Bool) : ℝ :=
  let d := if dSelected then p else 1
  ∑ b ∈ ({1, p} : Finset ℕ),
    (ArithmeticFunction.moebius b : ℝ) *
      (ArithmeticFunction.moebius d : ℝ) /
        (Nat.totient (Nat.lcm (b ^ 2) d) : ℝ)

theorem actual_local_euler_projection {p : ℕ} (hp : p.Prime)
    (dSelected : Bool) :
    localProjection p dSelected =
      if dSelected then -(1 : ℝ) / (p : ℝ)
      else 1 - 1 / ((p : ℝ) * ((p : ℝ) - 1)) := by
  have hp0 : (p : ℝ) ≠ 0 := by exact_mod_cast hp.ne_zero
  have hpm1 : (p : ℝ) - 1 ≠ 0 := by
    have h : (1 : ℝ) < p := by exact_mod_cast hp.one_lt
    linarith
  have hlcm : Nat.lcm (p ^ 2) p = p ^ 2 := by
    apply Nat.dvd_antisymm
    · exact Nat.lcm_dvd dvd_rfl (by
        refine ⟨p, ?_⟩
        simp [pow_two])
    · exact Nat.dvd_lcm_left _ _
  have hpne : 1 ≠ p := hp.one_lt.ne
  cases dSelected
  · simp [localProjection, hpne, ArithmeticFunction.moebius_apply_one,
      ArithmeticFunction.moebius_apply_prime hp,
      Nat.totient_prime_pow hp (by decide : 0 < 2),
      Nat.cast_mul, Nat.cast_sub hp.one_le]
    field_simp [hp0, hpm1]
    <;> ring
  · simp [localProjection, hpne, ArithmeticFunction.moebius_apply_one,
      ArithmeticFunction.moebius_apply_prime hp, hlcm,
      Nat.totient_prime hp, Nat.totient_prime_pow hp (by decide : 0 < 2),
      Nat.cast_mul, Nat.cast_sub hp.one_le]
    field_simp [hp0, hpm1]
    <;> ring

#print axioms actual_local_euler_projection

end GoldbachResearch.ActualEulerProjection
