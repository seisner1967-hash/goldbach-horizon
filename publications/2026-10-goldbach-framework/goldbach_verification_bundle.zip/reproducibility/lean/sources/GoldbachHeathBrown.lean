import GoldbachArithmetic
import Mathlib.NumberTheory.VonMangoldt
import Mathlib.Tactic

/-!
# Exact two-stage Heath--Brown decompositions for the Goldbach parity branch

This module preserves signed Möbius coefficients. The support restriction
is proved from divisor products, rather than supplied as a hypothesis.
No cancellation estimate or Goldbach conclusion is asserted.
-/

namespace GoldbachResearch.HeathBrown

open ArithmeticFunction
open scoped BigOperators
open ActualArithmetic

noncomputable def mu : ArithmeticFunction ℝ := ArithmeticFunction.moebius

noncomputable def zeta : ArithmeticFunction ℝ := ArithmeticFunction.zeta

noncomputable def muLow (z : ℕ) : ArithmeticFunction ℝ :=
  ⟨fun n => if n ≤ z then mu n else 0, by simp [mu]⟩

noncomputable def muHigh (z : ℕ) : ArithmeticFunction ℝ := mu - muLow z

@[simp] theorem muLow_apply (z n : ℕ) :
    muLow z n = if n ≤ z then mu n else 0 := rfl

@[simp] theorem muHigh_apply (z n : ℕ) :
    muHigh z n = mu n - muLow z n := rfl

theorem muHigh_zero (z n : ℕ) (hn : n ≤ z) : muHigh z n = 0 := by
  simp [hn]

theorem factor_below_square (z a b : ℕ) (hab : a * b ≤ z * z) :
    a ≤ z ∨ b ≤ z := by
  by_contra h
  push_neg at h
  nlinarith

theorem high_square_zero (z n : ℕ) (hn : n ≤ z * z) :
    (muHigh z * muHigh z) n = 0 := by
  rw [ArithmeticFunction.mul_apply]
  apply Finset.sum_eq_zero
  intro ab hab
  have hprod := (Nat.mem_divisorsAntidiagonal.mp hab).1
  obtain ha | hb := factor_below_square z ab.1 ab.2 (hprod ▸ hn)
  · rw [muHigh_zero z ab.1 ha, zero_mul]
  · rw [muHigh_zero z ab.2 hb, mul_zero]

theorem left_convolution_zero_below (f g : ArithmeticFunction ℝ) (B n : ℕ)
    (hf : ∀ d ≤ B, f d = 0) (hn : n ≤ B) : (f * g) n = 0 := by
  rw [ArithmeticFunction.mul_apply]
  apply Finset.sum_eq_zero
  intro ab hab
  obtain ⟨hprod, hn0⟩ := Nat.mem_divisorsAntidiagonal.mp hab
  have hle : ab.1 ≤ n := Nat.le_of_dvd (Nat.pos_of_ne_zero hn0) ⟨ab.2, hprod.symm⟩
  rw [hf ab.1 (hle.trans hn), zero_mul]

theorem mu_mul_zeta : mu * zeta = 1 := by
  exact ArithmeticFunction.coe_moebius_mul_coe_zeta

theorem high_square_zeta_identity (z : ℕ) :
    muHigh z * muHigh z * zeta =
      mu - (muLow z + muLow z) + muLow z * muLow z * zeta := by
  unfold muHigh
  calc
    (mu - muLow z) * (mu - muLow z) * zeta =
      mu * (mu * zeta) - (muLow z * (mu * zeta) +
      muLow z * (mu * zeta)) + muLow z * muLow z * zeta := by ring
    _ = _ := by rw [mu_mul_zeta]; simp

theorem moebius_heath_brown_two (z n : ℕ) (hn : n ≤ z * z) :
    mu n = 2 * muLow z n - (muLow z * muLow z * zeta) n := by
  have hz := left_convolution_zero_below (muHigh z * muHigh z) zeta
    (z * z) n (fun d hd => high_square_zero z d hd) hn
  rw [high_square_zeta_identity] at hz
  change mu n - (muLow z n + muLow z n) + (muLow z * muLow z * zeta) n = 0 at hz
  linarith

theorem moebius_long_branch (z n : ℕ) (hzn : z < n) (hn : n ≤ z * z) :
    mu n = -(muLow z * muLow z * zeta) n := by
  rw [moebius_heath_brown_two z n hn, muLow_apply, if_neg (by omega)]
  ring

theorem high_square_zeta_log_identity (z : ℕ) :
    muHigh z * muHigh z * zeta * ArithmeticFunction.log =
      ArithmeticFunction.vonMangoldt -
      (muLow z * ArithmeticFunction.log + muLow z * ArithmeticFunction.log) +
      muLow z * muLow z * zeta * ArithmeticFunction.log := by
  rw [high_square_zeta_identity]
  rw [add_mul, sub_mul, add_mul]
  have hlog : mu * ArithmeticFunction.log = ArithmeticFunction.vonMangoldt :=
    ArithmeticFunction.moebius_mul_log_eq_vonMangoldt
  rw [hlog]

theorem vonMangoldt_heath_brown_two (z n : ℕ) (hn : n ≤ z * z) :
    ArithmeticFunction.vonMangoldt n =
      2 * (muLow z * ArithmeticFunction.log) n -
      (muLow z * muLow z * zeta * ArithmeticFunction.log) n := by
  have hz := left_convolution_zero_below
    (muHigh z * muHigh z * zeta) ArithmeticFunction.log (z * z) n
    (fun d hd => left_convolution_zero_below (muHigh z * muHigh z) zeta
      (z * z) d (fun e he => high_square_zero z e he) hd) hn
  rw [high_square_zeta_log_identity] at hz
  change ArithmeticFunction.vonMangoldt n -
    ((muLow z * ArithmeticFunction.log) n + (muLow z * ArithmeticFunction.log) n) +
    (muLow z * muLow z * zeta * ArithmeticFunction.log) n = 0 at hz
  linarith

noncomputable def lambdaHead (z : ℕ) : ArithmeticFunction ℝ :=
  muLow z * ArithmeticFunction.log

noncomputable def lambdaTail (z : ℕ) : ArithmeticFunction ℝ :=
  muLow z * muLow z * zeta * ArithmeticFunction.log

noncomputable def moebiusTail (z : ℕ) : ArithmeticFunction ℝ :=
  muLow z * muLow z * zeta

/-- The signed short-factor coefficient, with both Möbius signs intact. -/
noncomputable def shortPair (z : ℕ) : ArithmeticFunction ℝ := muLow z * muLow z

/-- The remaining untruncated logarithmic divisor coefficient. -/
noncomputable def logDivisor : ArithmeticFunction ℝ := zeta * ArithmeticFunction.log

theorem moebiusTail_as_pair (z : ℕ) : moebiusTail z = shortPair z * zeta := rfl

theorem lambdaTail_as_pair (z : ℕ) : lambdaTail z = shortPair z * logDivisor := by
  unfold lambdaTail shortPair logDivisor
  rw [mul_assoc]

theorem shortPair_expansion (z n : ℕ) :
    shortPair z n = ∑ ab ∈ Nat.divisorsAntidiagonal n,
      (if ab.1 ≤ z then mu ab.1 else 0) *
      (if ab.2 ≤ z then mu ab.2 else 0) := by
  simp only [shortPair, ArithmeticFunction.mul_apply, muLow_apply]

theorem pair_linear_relation (a b c d N : ℕ) (h : a*b + c*d = N) :
    Nat.gcd a c ∣ N := by
  rw [← h]
  exact Nat.dvd_add (dvd_mul_of_dvd_left (Nat.gcd_dvd_left a c) b)
    (dvd_mul_of_dvd_left (Nat.gcd_dvd_right a c) d)

/-- The long--long tensor term is already a literal signed product equation.
Both short-pair coefficients remain signed. -/
theorem lambdaTail_moebiusTail_expansion (z n m : ℕ) :
    lambdaTail z n * moebiusTail z m =
      ∑ ab ∈ Nat.divisorsAntidiagonal n,
        ∑ cd ∈ Nat.divisorsAntidiagonal m,
          shortPair z ab.1 * logDivisor ab.2 * shortPair z cd.1 * zeta cd.2 := by
  rw [lambdaTail_as_pair, moebiusTail_as_pair]
  simp only [ArithmeticFunction.mul_apply, Finset.sum_mul, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro ab hab
  apply Finset.sum_congr rfl
  intro cd hcd
  ring

theorem actualSequence_two_sided (z N n : ℕ) (hN : N ≤ z * z) (hn : n ≤ N) :
    actualSequence N n =
      4 * lambdaHead z n * muLow z (N - n) -
      2 * lambdaHead z n * moebiusTail z (N - n) -
      2 * lambdaTail z n * muLow z (N - n) +
      lambdaTail z n * moebiusTail z (N - n) := by
  have hm : N - n ≤ z * z := (Nat.sub_le N n).trans hN
  unfold actualSequence muReal
  change ArithmeticFunction.vonMangoldt n * mu (N - n) = _
  rw [vonMangoldt_heath_brown_two z n (hn.trans hN), moebius_heath_brown_two z (N-n) hm]
  unfold lambdaHead lambdaTail moebiusTail
  ring

/-- A signed finite bilinear row with the unchanged actual moving cutoff. -/
noncomputable def tensorRow (N alpha k : ℕ) (f g : ArithmeticFunction ℝ) : ℝ :=
  ∑ n ∈ Finset.range N, f n * g (N - n) * actualRow N alpha k n

theorem actualEpsilon_two_sided (z N alpha k : ℕ) (hN : N ≤ z * z) :
    actualEpsilon N alpha k =
      4 * tensorRow N alpha k (lambdaHead z) (muLow z) -
      2 * tensorRow N alpha k (lambdaHead z) (moebiusTail z) -
      2 * tensorRow N alpha k (lambdaTail z) (muLow z) +
      tensorRow N alpha k (lambdaTail z) (moebiusTail z) := by
  unfold actualEpsilon ArithmeticBridge.rowSum tensorRow
  rw [Finset.mul_sum, Finset.mul_sum, Finset.mul_sum,
    ← Finset.sum_sub_distrib, ← Finset.sum_sub_distrib, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro n hn
  rw [actualSequence_two_sided z N n hN (le_of_lt (Finset.mem_range.mp hn))]
  ring

theorem actualSequence_long_complement (z N n : ℕ) (hN : N ≤ z * z)
    (hn : n ≤ N) (hLong : z < N - n) :
    actualSequence N n =
      -2 * lambdaHead z n * moebiusTail z (N - n) +
      lambdaTail z n * moebiusTail z (N - n) := by
  rw [actualSequence_two_sided z N n hN hn, muLow_apply, if_neg (by omega)]
  ring

#print axioms factor_below_square
#print axioms high_square_zero
#print axioms left_convolution_zero_below
#print axioms high_square_zeta_identity
#print axioms moebius_heath_brown_two
#print axioms moebius_long_branch
#print axioms high_square_zeta_log_identity
#print axioms vonMangoldt_heath_brown_two
#print axioms actualSequence_two_sided
#print axioms actualEpsilon_two_sided
#print axioms actualSequence_long_complement
#print axioms lambdaTail_as_pair
#print axioms shortPair_expansion
#print axioms pair_linear_relation
#print axioms lambdaTail_moebiusTail_expansion

end GoldbachResearch.HeathBrown
