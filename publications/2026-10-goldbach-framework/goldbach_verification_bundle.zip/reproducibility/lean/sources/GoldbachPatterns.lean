import Mathlib.Tactic
import Mathlib.Data.Nat.Squarefree
import Mathlib.Data.Nat.Totient
import GoldbachQuartic

/-!
# The eleven occurrence patterns of a squarefree fourth-moment expansion

The arithmetic decomposition below uses the actual prime factors of four
natural-number moduli. No factorisation or reconstruction identity is assumed.
The eleven-pattern restriction requires, explicitly, that every prime occurs
at least twice. Later local-weight lemmas justify why singleton patterns have
zero weight in the paired fourth-moment model.

The connection of that model to a complete Ramanujan coefficient expansion and
the analytic mass bound are separate obligations.
-/

namespace GoldbachResearch.Patterns

open scoped BigOperators

abbrev Index := Fin 4
abbrev Pattern := Finset Index

def patterns : Finset Pattern :=
  {{0, 1}, {0, 2}, {0, 3}, {1, 2}, {1, 3}, {2, 3},
   {0, 1, 2}, {0, 1, 3}, {0, 2, 3}, {1, 2, 3}, {0, 1, 2, 3}}

theorem patterns_eq_large_subsets :
    patterns = (Finset.univ : Finset Pattern).filter (fun I => 2 ≤ I.card) := by
  decide

theorem patterns_card : patterns.card = 11 := by decide

@[simp] theorem mem_patterns {I : Pattern} : I ∈ patterns ↔ 2 ≤ I.card := by
  rw [patterns_eq_large_subsets]
  simp

def primeUniverse (q : Index → ℕ) : Finset ℕ :=
  Finset.univ.biUnion (fun i => (q i).primeFactors)

def occurrence (q : Index → ℕ) (p : ℕ) : Pattern :=
  Finset.univ.filter (fun i => p ∣ q i)

def atomPrimes (q : Index → ℕ) (I : Pattern) : Finset ℕ :=
  (primeUniverse q).filter (fun p => occurrence q p = I)

def atom (q : Index → ℕ) (I : Pattern) : ℕ :=
  ∏ p ∈ atomPrimes q I, p

@[simp] theorem mem_occurrence {q : Index → ℕ} {p : ℕ} {i : Index} :
    i ∈ occurrence q p ↔ p ∣ q i := by simp [occurrence]

theorem universe_prime {q : Index → ℕ} {p : ℕ} (hp : p ∈ primeUniverse q) :
    p.Prime := by
  obtain ⟨i, _, hi⟩ := Finset.mem_biUnion.mp hp
  exact Nat.prime_of_mem_primeFactors hi

theorem occurrence_nonempty {q : Index → ℕ} {p : ℕ}
    (hp : p ∈ primeUniverse q) : (occurrence q p).Nonempty := by
  obtain ⟨i, _, hi⟩ := Finset.mem_biUnion.mp hp
  exact ⟨i, mem_occurrence.mpr (Nat.dvd_of_mem_primeFactors hi)⟩

theorem atomPrime_unique_pattern {q : Index → ℕ} {p : ℕ} {I J : Pattern}
    (hI : p ∈ atomPrimes q I) (hJ : p ∈ atomPrimes q J) : I = J := by
  exact (Finset.mem_filter.mp hI).2.symm.trans (Finset.mem_filter.mp hJ).2

theorem atomPrimes_disjoint (q : Index → ℕ) {I J : Pattern} (h : I ≠ J) :
    Disjoint (atomPrimes q I) (atomPrimes q J) := by
  apply Finset.disjoint_left.mpr
  intro p hI hJ
  exact h (atomPrime_unique_pattern hI hJ)

theorem atom_primeFactors (q : Index → ℕ) (I : Pattern) :
    (atom q I).primeFactors = atomPrimes q I := by
  apply Nat.primeFactors_prod
  intro p hp
  exact universe_prime (Finset.mem_filter.mp hp).1

theorem atoms_coprime (q : Index → ℕ) {I J : Pattern} (h : I ≠ J) :
    Nat.Coprime (atom q I) (atom q J) := by
  apply Nat.coprime_prod_left_iff.mpr
  intro p hp
  apply Nat.coprime_prod_right_iff.mpr
  intro r hr
  have hpp := universe_prime (Finset.mem_filter.mp hp).1
  have hrp := universe_prime (Finset.mem_filter.mp hr).1
  apply hpp.coprime_iff_not_dvd.mpr
  intro hd
  have heq : p = r := ((hrp.dvd_iff_eq hpp.ne_one).mp hd).symm
  subst r
  exact h (atomPrime_unique_pattern hp hr)

theorem universe_filter_for_modulus (q : Index → ℕ) (i : Index)
    (hqi : q i ≠ 0) :
    (primeUniverse q).filter (fun p => i ∈ occurrence q p) =
      (q i).primeFactors := by
  ext p
  constructor
  · intro hp
    have hpU := (Finset.mem_filter.mp hp).1
    have hd := mem_occurrence.mp (Finset.mem_filter.mp hp).2
    exact Nat.mem_primeFactors.mpr ⟨universe_prime hpU, hd, hqi⟩
  · intro hp
    apply Finset.mem_filter.mpr
    exact ⟨Finset.mem_biUnion.mpr ⟨i, Finset.mem_univ i, hp⟩,
      mem_occurrence.mpr (Nat.dvd_of_mem_primeFactors hp)⟩

theorem modulus_reconstructed_all (q : Index → ℕ) (i : Index)
    (hq : Squarefree (q i)) :
    ∏ I ∈ (Finset.univ : Finset Pattern).filter (fun I => i ∈ I), atom q I = q i := by
  unfold atom atomPrimes
  rw [Finset.prod_fiberwise_eq_prod_filter]
  have hfilter :
      (primeUniverse q).filter
        (fun p => occurrence q p ∈ (Finset.univ : Finset Pattern).filter (fun I => i ∈ I)) =
      (q i).primeFactors := by
    simpa using universe_filter_for_modulus q i hq.ne_zero
  rw [hfilter]
  exact Nat.prod_primeFactors_of_squarefree hq

theorem modulus_reconstructed_eleven (q : Index → ℕ) (i : Index)
    (hq : Squarefree (q i))
    (hlarge : ∀ p ∈ primeUniverse q, 2 ≤ (occurrence q p).card) :
    ∏ I ∈ patterns.filter (fun I => i ∈ I), atom q I = q i := by
  unfold atom atomPrimes
  rw [Finset.prod_fiberwise_eq_prod_filter]
  have hfilter :
      (primeUniverse q).filter
        (fun p => occurrence q p ∈ patterns.filter (fun I => i ∈ I)) =
      (primeUniverse q).filter (fun p => i ∈ occurrence q p) := by
    ext p
    simp only [Finset.mem_filter]
    constructor
    · rintro ⟨hp, _, hi⟩
      exact ⟨hp, hi⟩
    · rintro ⟨hp, hi⟩
      exact ⟨hp, mem_patterns.mpr (hlarge p hp), hi⟩
  rw [hfilter, universe_filter_for_modulus q i hq.ne_zero]
  exact Nat.prod_primeFactors_of_squarefree hq

theorem incidence_product {M : Type*} [CommMonoid M]
    (D : Pattern → M) (T : Finset Pattern) :
    (∏ i : Index, ∏ I ∈ T.filter (fun I => i ∈ I), D I) =
      ∏ I ∈ T, (D I) ^ I.card := by
  simp_rw [Finset.prod_filter]
  rw [Finset.prod_comm]
  apply Finset.prod_congr rfl
  intro I hI
  rw [← Finset.prod_filter]
  simp

theorem four_moduli_product (q : Index → ℕ)
    (hq : ∀ i, Squarefree (q i))
    (hlarge : ∀ p ∈ primeUniverse q, 2 ≤ (occurrence q p).card) :
    (∏ i : Index, q i) = ∏ I ∈ patterns, (atom q I) ^ I.card := by
  calc
    (∏ i : Index, q i) =
        ∏ i : Index, ∏ I ∈ patterns.filter (fun I => i ∈ I), atom q I := by
      apply Finset.prod_congr rfl
      intro i hi
      exact (modulus_reconstructed_eleven q i (hq i) hlarge).symm
    _ = _ := incidence_product (atom q) patterns

theorem atom_empty (q : Index → ℕ) : atom q ∅ = 1 := by
  have hempty : atomPrimes q ∅ = ∅ := by
    apply Finset.eq_empty_iff_forall_not_mem.mpr
    intro p hp
    have hU := (Finset.mem_filter.mp hp).1
    have he := (Finset.mem_filter.mp hp).2
    exact (occurrence_nonempty hU).ne_empty he
  simp [atom, hempty]

theorem atom_divides_modulus (q : Index → ℕ) {I : Pattern} {i : Index}
    (hi : i ∈ I) (hqi : Squarefree (q i)) : atom q I ∣ q i := by
  have hsub : atomPrimes q I ⊆ (q i).primeFactors := by
    intro p hp
    obtain ⟨hU, he⟩ := Finset.mem_filter.mp hp
    have hpi : i ∈ occurrence q p := he.symm ▸ hi
    exact Nat.mem_primeFactors.mpr
      ⟨universe_prime hU, mem_occurrence.mp hpi, hqi.ne_zero⟩
  have hd := Finset.prod_dvd_prod_of_subset (atomPrimes q I) (q i).primeFactors
    (fun p => p) hsub
  simpa [atom, Nat.prod_primeFactors_of_squarefree hqi] using hd

theorem atoms_squarefree (q : Index → ℕ) (hq : ∀ i, Squarefree (q i))
    (I : Pattern) : Squarefree (atom q I) := by
  by_cases he : I = ∅
  · subst I
    rw [atom_empty]
    exact squarefree_one
  · obtain ⟨i, hi⟩ := Finset.nonempty_iff_ne_empty.mpr he
    exact Squarefree.squarefree_of_dvd (atom_divides_modulus q hi (hq i)) (hq i)

theorem atoms_determine_moduli {q r : Index → ℕ}
    (hq : ∀ i, Squarefree (q i)) (hr : ∀ i, Squarefree (r i))
    (hqlarge : ∀ p ∈ primeUniverse q, 2 ≤ (occurrence q p).card)
    (hrlarge : ∀ p ∈ primeUniverse r, 2 ≤ (occurrence r p).card)
    (hatoms : ∀ I ∈ patterns, atom q I = atom r I) : q = r := by
  funext i
  rw [← modulus_reconstructed_eleven q i (hq i) hqlarge,
    ← modulus_reconstructed_eleven r i (hr i) hrlarge]
  apply Finset.prod_congr rfl
  intro I hI
  exact hatoms I (Finset.mem_filter.mp hI).1

/-! Prime-local paired coefficients. For a pair with zero, one, or two
occurrences the coefficients of 1 and c_p are respectively (1,0), (0,1),
and (p-1,p-2). The pairing weights the nonconstant channel by p. -/

def leftPair : Pattern := {0, 1}
def rightPair : Pattern := {2, 3}

def pairCount (I : Pattern) (a b : Index) : ℕ :=
  (if a ∈ I then 1 else 0) + (if b ∈ I then 1 else 0)

theorem pairCount_left_eq :
    ∀ I : Pattern, pairCount I 0 1 = (I ∩ leftPair).card := by decide

theorem pairCount_right_eq :
    ∀ I : Pattern, pairCount I 2 3 = (I ∩ rightPair).card := by decide

noncomputable def pairConstant (p : ℝ) (r : ℕ) : ℝ :=
  if r = 0 then 1 else if r = 2 then p - 1 else 0

noncomputable def pairLinear (p : ℝ) (r : ℕ) : ℝ :=
  if r = 0 then 0 else if r = 2 then p - 2 else 1

noncomputable def localWeight (p : ℝ) (I : Pattern) : ℝ :=
  (pairConstant p (pairCount I 0 1) * pairConstant p (pairCount I 2 3) +
    p * pairLinear p (pairCount I 0 1) * pairLinear p (pairCount I 2 3)) /
      (p - 1) ^ I.card

theorem singleton_weight_zero (p : ℝ) (i : Index) : localWeight p {i} = 0 := by
  have hc : ∀ j : Index,
      (pairCount {j} 0 1 = 1 ∧ pairCount {j} 2 3 = 0) ∨
      (pairCount {j} 0 1 = 0 ∧ pairCount {j} 2 3 = 1) := by decide
  rcases hc i with ⟨hl, hr⟩ | ⟨hl, hr⟩ <;>
    simp [localWeight, hl, hr, pairConstant, pairLinear]

theorem pattern_counts_cases : ∀ I ∈ patterns,
    (I.card = 2 ∧ pairCount I 0 1 = 2 ∧ pairCount I 2 3 = 0) ∨
    (I.card = 2 ∧ pairCount I 0 1 = 0 ∧ pairCount I 2 3 = 2) ∨
    (I.card = 2 ∧ pairCount I 0 1 = 1 ∧ pairCount I 2 3 = 1) ∨
    (I.card = 3 ∧ pairCount I 0 1 = 2 ∧ pairCount I 2 3 = 1) ∨
    (I.card = 3 ∧ pairCount I 0 1 = 1 ∧ pairCount I 2 3 = 2) ∨
    (I.card = 4 ∧ pairCount I 0 1 = 2 ∧ pairCount I 2 3 = 2) := by decide

theorem localWeight_classified {p : ℝ} (hp : 2 ≤ p) {I : Pattern}
    (hI : I ∈ patterns) :
    localWeight p I = Quartic.samePair p ∨
    localWeight p I = Quartic.crossPair p ∨
    localWeight p I = Quartic.threeOccurrences p ∨
    localWeight p I = Quartic.fourOccurrences p := by
  have hv : p - 1 ≠ 0 := by linarith
  rcases pattern_counts_cases I hI with h | h | h | h | h | h
  · left
    rcases h with ⟨hc, hl, hr⟩
    simp [localWeight, hl, hr, hc, pairConstant, pairLinear, Quartic.samePair]
    field_simp
    ring
  · left
    rcases h with ⟨hc, hl, hr⟩
    simp [localWeight, hl, hr, hc, pairConstant, pairLinear, Quartic.samePair]
    field_simp
    ring
  · right; left
    rcases h with ⟨hc, hl, hr⟩
    simp [localWeight, hl, hr, hc, pairConstant, pairLinear, Quartic.crossPair]
  · right; right; left
    rcases h with ⟨hc, hl, hr⟩
    simp [localWeight, hl, hr, hc, pairConstant, pairLinear, Quartic.threeOccurrences]
  · right; right; left
    rcases h with ⟨hc, hl, hr⟩
    simp [localWeight, hl, hr, hc, pairConstant, pairLinear, Quartic.threeOccurrences]
  · right; right; right
    rcases h with ⟨hc, hl, hr⟩
    simp [localWeight, hl, hr, hc, pairConstant, pairLinear, Quartic.fourOccurrences]
    field_simp
    ring

theorem localWeight_nonneg_and_bound {p : ℝ} (hp : 2 ≤ p) {I : Pattern}
    (hI : I ∈ patterns) : 0 ≤ localWeight p I ∧ localWeight p I ≤ Quartic.crossPair p := by
  have hn := Quartic.local_weights_nonneg hp
  rcases localWeight_classified hp hI with he | he | he | he
  · rw [he]; exact ⟨hn.1, Quartic.samePair_le_crossPair hp⟩
  · rw [he]; exact ⟨hn.2.1, le_rfl⟩
  · rw [he]; exact ⟨hn.2.2.1, Quartic.threeOccurrences_le_crossPair hp⟩
  · rw [he]; exact ⟨hn.2.2.2, Quartic.fourOccurrences_le_crossPair hp⟩

noncomputable def pairedWeight (q : Index → ℕ) : ℝ :=
  ∏ p ∈ primeUniverse q, localWeight (p : ℝ) (occurrence q p)

theorem nonzero_pairedWeight_large_patterns {q : Index → ℕ}
    (hw : pairedWeight q ≠ 0) :
    ∀ p ∈ primeUniverse q, 2 ≤ (occurrence q p).card := by
  intro p hp
  have hn : localWeight (p : ℝ) (occurrence q p) ≠ 0 :=
    (Finset.prod_ne_zero_iff.mp hw) p hp
  have hpos : 0 < (occurrence q p).card :=
    Finset.card_pos.mpr (occurrence_nonempty hp)
  by_contra h
  have hone : (occurrence q p).card = 1 := by omega
  obtain ⟨i, hi⟩ := Finset.card_eq_one.mp hone
  exact hn (hi ▸ singleton_weight_zero (p : ℝ) i)

theorem nonzero_weight_reconstruction (q : Index → ℕ)
    (hq : ∀ i, Squarefree (q i)) (hw : pairedWeight q ≠ 0) (i : Index) :
    ∏ I ∈ patterns.filter (fun I => i ∈ I), atom q I = q i :=
  modulus_reconstructed_eleven q i (hq i) (nonzero_pairedWeight_large_patterns hw)

theorem pairedWeight_factorized (q : Index → ℕ)
    (hlarge : ∀ p ∈ primeUniverse q, 2 ≤ (occurrence q p).card) :
    pairedWeight q =
      ∏ I ∈ patterns, ∏ p ∈ atomPrimes q I, localWeight (p : ℝ) I := by
  unfold pairedWeight atomPrimes
  symm
  calc
    _ = ∏ I ∈ patterns,
        ∏ p ∈ (primeUniverse q).filter (fun p => occurrence q p = I),
          localWeight (p : ℝ) (occurrence q p) := by
      apply Finset.prod_congr rfl
      intro I hI
      apply Finset.prod_congr rfl
      intro p hp
      rw [(Finset.mem_filter.mp hp).2]
    _ = _ := Finset.prod_fiberwise_of_maps_to
      (fun p hp => mem_patterns.mpr (hlarge p hp))
      (fun p => localWeight (p : ℝ) (occurrence q p))

/-! The prime-value identity is unconditional as an algebraic statement.
For a prime p this is the usual integer Ramanujan value c_p(n). -/

noncomputable def primeRamanujan (p n : ℕ) : ℝ :=
  if p ∣ n then (p : ℝ) - 1 else -1

theorem primeRamanujan_square (p n : ℕ) :
    primeRamanujan p n ^ 2 =
      (p : ℝ) - 1 + ((p : ℝ) - 2) * primeRamanujan p n := by
  by_cases hd : p ∣ n <;> simp [primeRamanujan, hd] <;> ring

theorem prime_pair_expansion (p n : ℕ) (a b : Bool) :
    (if a then primeRamanujan p n else 1) *
        (if b then primeRamanujan p n else 1) =
      pairConstant (p : ℝ) ((if a then 1 else 0) + (if b then 1 else 0)) +
        pairLinear (p : ℝ) ((if a then 1 else 0) + (if b then 1 else 0)) *
          primeRamanujan p n := by
  cases a <;> cases b <;> simp [pairConstant, pairLinear]
  simpa [pow_two] using primeRamanujan_square p n

noncomputable def channelCoefficient (U : Finset ℕ) (r : ℕ → ℕ)
    (g : Finset ℕ) : ℝ :=
  (∏ p ∈ g, pairLinear (p : ℝ) (r p)) *
    ∏ p ∈ U \ g, pairConstant (p : ℝ) (r p)

theorem weighted_pairing_product (U : Finset ℕ) (CL CR LL LR : ℕ → ℝ) :
    (∑ g ∈ U.powerset, (∏ p ∈ g, (p : ℝ)) *
      (((∏ p ∈ g, LL p) * ∏ p ∈ U \ g, CL p) *
       ((∏ p ∈ g, LR p) * ∏ p ∈ U \ g, CR p))) =
      ∏ p ∈ U, (CL p * CR p + (p : ℝ) * LL p * LR p) := by
  symm
  calc
    _ = ∏ p ∈ U, ((p : ℝ) * LL p * LR p + CL p * CR p) := by
      apply Finset.prod_congr rfl
      intro p hp
      ring
    _ = ∑ g ∈ U.powerset,
        (∏ p ∈ g, (p : ℝ) * LL p * LR p) *
          ∏ p ∈ U \ g, CL p * CR p := Finset.prod_add _ _ U
    _ = _ := by
      apply Finset.sum_congr rfl
      intro g hg
      simp_rw [Finset.prod_mul_distrib]
      ring

noncomputable def normalization (q : Index → ℕ) : ℝ :=
  ∏ p ∈ primeUniverse q, ((p : ℝ) - 1) ^ (occurrence q p).card

theorem pairedWeight_eq_weighted_sum (q : Index → ℕ) :
    pairedWeight q =
      (∑ g ∈ (primeUniverse q).powerset, (∏ p ∈ g, (p : ℝ)) *
        (channelCoefficient (primeUniverse q)
            (fun p => pairCount (occurrence q p) 0 1) g *
         channelCoefficient (primeUniverse q)
            (fun p => pairCount (occurrence q p) 2 3) g)) / normalization q := by
  unfold pairedWeight localWeight normalization channelCoefficient
  rw [Finset.prod_div_distrib]
  congr 1
  symm
  exact weighted_pairing_product (primeUniverse q)
    (fun p => pairConstant (p : ℝ) (pairCount (occurrence q p) 0 1))
    (fun p => pairConstant (p : ℝ) (pairCount (occurrence q p) 2 3))
    (fun p => pairLinear (p : ℝ) (pairCount (occurrence q p) 0 1))
    (fun p => pairLinear (p : ℝ) (pairCount (occurrence q p) 2 3))

theorem totient_squarefree_real {n : ℕ} (hn : Squarefree n) :
    (n.totient : ℝ) = ∏ p ∈ n.primeFactors, ((p : ℝ) - 1) := by
  have ht : n.totient = ∏ p ∈ n.primeFactors, (p - 1) := by
    rw [Nat.totient_eq_div_primeFactors_mul,
      Nat.prod_primeFactors_of_squarefree hn]
    rw [Nat.div_self (Nat.pos_of_ne_zero hn.ne_zero), one_mul]
  rw [ht, Nat.cast_prod]
  apply Finset.prod_congr rfl
  intro p hp
  have hple : 1 ≤ p := (Nat.prime_of_mem_primeFactors hp).two_le.trans' (by decide)
  rw [Nat.cast_sub hple]
  simp

theorem normalization_totient_product (q : Index → ℕ)
    (hq : ∀ i, Squarefree (q i)) :
    normalization q = ∏ i : Index, ((q i).totient : ℝ) := by
  symm
  calc
    _ = ∏ i : Index, ∏ p ∈ (primeUniverse q).filter
        (fun p => i ∈ occurrence q p), ((p : ℝ) - 1) := by
      apply Finset.prod_congr rfl
      intro i hi
      rw [universe_filter_for_modulus q i (hq i).ne_zero,
        totient_squarefree_real (hq i)]
    _ = ∏ p ∈ primeUniverse q,
        ∏ i : Index, if i ∈ occurrence q p then ((p : ℝ) - 1) else 1 := by
      simp_rw [Finset.prod_filter]
      rw [Finset.prod_comm]
    _ = normalization q := by
      unfold normalization
      apply Finset.prod_congr rfl
      intro p hp
      rw [← Finset.prod_filter]
      simp [occurrence]

noncomputable def primeWeight (n : ℕ) : ℝ :=
  ∏ p ∈ n.primeFactors, Quartic.crossPair (p : ℝ)

theorem primeWeight_squarefree {n : ℕ} (hn : Squarefree n) :
    primeWeight n = (n : ℝ) / (n.totient : ℝ) ^ 2 := by
  unfold primeWeight Quartic.crossPair
  rw [Finset.prod_div_distrib, Finset.prod_pow,
    ← Nat.cast_prod, Nat.prod_primeFactors_of_squarefree hn,
    ← totient_squarefree_real hn]

theorem pairedWeight_upper_atoms (q : Index → ℕ)
    (hlarge : ∀ p ∈ primeUniverse q, 2 ≤ (occurrence q p).card) :
    pairedWeight q ≤ ∏ I ∈ patterns, primeWeight (atom q I) := by
  rw [pairedWeight_factorized q hlarge]
  apply Finset.prod_le_prod
  · intro I hI
    apply Finset.prod_nonneg
    intro p hp
    have hpr : 2 ≤ (p : ℝ) := by
      exact_mod_cast (universe_prime (Finset.mem_filter.mp hp).1).two_le
    exact (localWeight_nonneg_and_bound hpr hI).1
  · intro I hI
    unfold primeWeight
    rw [atom_primeFactors]
    apply Finset.prod_le_prod
    · intro p hp
      have hpr : 2 ≤ (p : ℝ) := by
        exact_mod_cast (universe_prime (Finset.mem_filter.mp hp).1).two_le
      exact (localWeight_nonneg_and_bound hpr hI).1
    · intro p hp
      have hpr : 2 ≤ (p : ℝ) := by
        exact_mod_cast (universe_prime (Finset.mem_filter.mp hp).1).two_le
      exact (localWeight_nonneg_and_bound hpr hI).2

theorem pairedWeight_upper_totients (q : Index → ℕ)
    (hq : ∀ i, Squarefree (q i)) (hw : pairedWeight q ≠ 0) :
    pairedWeight q ≤ ∏ I ∈ patterns,
      (atom q I : ℝ) / ((atom q I).totient : ℝ) ^ 2 := by
  have hb := pairedWeight_upper_atoms q (nonzero_pairedWeight_large_patterns hw)
  simpa only [primeWeight_squarefree (atoms_squarefree q hq _)] using hb

#print axioms patterns_card
#print axioms atoms_coprime
#print axioms modulus_reconstructed_all
#print axioms modulus_reconstructed_eleven
#print axioms four_moduli_product
#print axioms atoms_squarefree
#print axioms atoms_determine_moduli
#print axioms singleton_weight_zero
#print axioms localWeight_classified
#print axioms localWeight_nonneg_and_bound
#print axioms nonzero_weight_reconstruction
#print axioms primeRamanujan_square
#print axioms prime_pair_expansion
#print axioms weighted_pairing_product
#print axioms pairedWeight_eq_weighted_sum
#print axioms normalization_totient_product
#print axioms primeWeight_squarefree
#print axioms pairedWeight_upper_totients

end GoldbachResearch.Patterns
