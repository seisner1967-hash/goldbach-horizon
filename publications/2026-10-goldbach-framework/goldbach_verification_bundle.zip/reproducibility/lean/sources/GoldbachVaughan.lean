import GoldbachArithmetic
import Mathlib.Tactic.Ring

/-!
# Exact signed Vaughan decomposition for the actual Goldbach rows

Multiplication of arithmetic functions below is Dirichlet convolution.  This
module proves the exact identity and its application to the literal rows.  It
does not assume or prove a cancellation estimate for a shifted Moebius factor.
-/

namespace GoldbachResearch.Vaughan

open scoped BigOperators
open ArithmeticFunction ActualArithmetic

noncomputable def cutLE (U : ℕ) (f : ArithmeticFunction ℝ) : ArithmeticFunction ℝ :=
  ⟨fun n => if n ≤ U then f n else 0, by simp⟩

noncomputable def cutGT (U : ℕ) (f : ArithmeticFunction ℝ) : ArithmeticFunction ℝ :=
  ⟨fun n => if U < n then f n else 0, by simp⟩

@[simp] theorem cutLE_apply (U n : ℕ) (f : ArithmeticFunction ℝ) :
    cutLE U f n = if n ≤ U then f n else 0 := rfl

@[simp] theorem cutGT_apply (U n : ℕ) (f : ArithmeticFunction ℝ) :
    cutGT U f n = if U < n then f n else 0 := rfl

theorem cut_split (U : ℕ) (f : ArithmeticFunction ℝ) :
    f = cutLE U f + cutGT U f := by
  ext n
  by_cases h : n ≤ U <;> simp [h, Nat.not_lt.mpr, Nat.lt_of_not_ge]

noncomputable def mu : ArithmeticFunction ℝ :=
  (ArithmeticFunction.moebius : ArithmeticFunction ℝ)

noncomputable def zeta : ArithmeticFunction ℝ :=
  (ArithmeticFunction.zeta : ArithmeticFunction ℝ)

noncomputable def typeOneLog (U : ℕ) : ArithmeticFunction ℝ :=
  cutLE U mu * ArithmeticFunction.log

noncomputable def typeOneCorrection (U V : ℕ) : ArithmeticFunction ℝ :=
  (cutLE U mu * cutLE V ArithmeticFunction.vonMangoldt) * zeta

noncomputable def typeTwo (U V : ℕ) : ArithmeticFunction ℝ :=
  (cutGT U mu * cutGT V ArithmeticFunction.vonMangoldt) * zeta

/-- The second factor in Type II is nonnegative; its divisor summation does
not eliminate the signed Moebius factor in the first variable. -/
noncomputable def beta (V : ℕ) : ArithmeticFunction ℝ :=
  cutGT V ArithmeticFunction.vonMangoldt * zeta

theorem beta_divisor_sum (V n : ℕ) :
    beta V n = ∑ d ∈ n.divisors,
      if V < d then ArithmeticFunction.vonMangoldt d else 0 := by
  unfold beta zeta
  rw [ArithmeticFunction.coe_mul_zeta_apply]
  rfl

theorem beta_nonneg (V n : ℕ) : 0 ≤ beta V n := by
  rw [beta_divisor_sum]
  apply Finset.sum_nonneg
  intro d hd
  split_ifs
  · exact ArithmeticFunction.vonMangoldt_nonneg
  · rfl

theorem beta_le_log (V n : ℕ) : beta V n ≤ Real.log n := by
  rw [beta_divisor_sum, ← ArithmeticFunction.vonMangoldt_sum]
  apply Finset.sum_le_sum
  intro d hd
  split_ifs
  · rfl
  · exact ArithmeticFunction.vonMangoldt_nonneg

theorem beta_zero_of_le {V n : ℕ} (hn : n ≤ V) : beta V n = 0 := by
  rw [beta_divisor_sum]
  apply Finset.sum_eq_zero
  intro d hd
  rcases Nat.mem_divisors.mp hd with ⟨hdn, hn0⟩
  have hdn' : d ≤ n := Nat.le_of_dvd (Nat.pos_of_ne_zero hn0) hdn
  exact if_neg (by omega)

theorem beta_support {V n : ℕ} (hn : beta V n ≠ 0) : V < n := by
  by_contra h
  exact hn (beta_zero_of_le (Nat.le_of_not_gt h))

/-- Exact bilinear coefficients and their two strict lower supports. -/
theorem typeTwo_bilinear (U V n : ℕ) :
    typeTwo U V n = ∑ p ∈ n.divisorsAntidiagonal,
      (if U < p.1 then mu p.1 else 0) * beta V p.2 := by
  unfold typeTwo beta
  rw [mul_assoc, ArithmeticFunction.mul_apply]
  rfl

theorem typeTwo_nonzero_pair_support {U V n a b : ℕ}
    (hp : (a, b) ∈ n.divisorsAntidiagonal)
    (hterm : (if U < a then mu a else 0) * beta V b ≠ 0) :
    U < a ∧ V < b ∧ a * b = n := by
  have ha : U < a := by
    by_contra h
    simp [h] at hterm
  have hb : beta V b ≠ 0 := by
    intro h
    simp [h] at hterm
  exact ⟨ha, beta_support hb, (Nat.mem_divisorsAntidiagonal.mp hp).1⟩

/-- Type I's correction coefficient is supported on the finite product cap. -/
theorem typeOne_coefficient_zero_above {U V n : ℕ} (hn : U * V < n) :
    (cutLE U mu * cutLE V ArithmeticFunction.vonMangoldt) n = 0 := by
  rw [ArithmeticFunction.mul_apply]
  apply Finset.sum_eq_zero
  intro p hp
  have hmul : p.1 * p.2 = n := (Nat.mem_divisorsAntidiagonal.mp hp).1
  by_cases ha : p.1 ≤ U
  · have hb : ¬p.2 ≤ V := by
      intro hb
      have : n ≤ U * V := hmul ▸ Nat.mul_le_mul ha hb
      omega
    simp [ha, hb]
  · simp [ha]

theorem typeOneLog_divisor_expansion (U n : ℕ) :
    typeOneLog U n = ∑ p ∈ n.divisorsAntidiagonal,
      (if p.1 ≤ U then mu p.1 else 0) * Real.log p.2 := by
  unfold typeOneLog
  rw [ArithmeticFunction.mul_apply]
  rfl

theorem typeOneCorrection_divisor_expansion (U V n : ℕ) :
    typeOneCorrection U V n = ∑ d ∈ n.divisors,
      (cutLE U mu * cutLE V ArithmeticFunction.vonMangoldt) d := by
  unfold typeOneCorrection zeta
  rw [ArithmeticFunction.coe_mul_zeta_apply]

/-- Vaughan's identity is a ring identity once the two standard inversions
have been proved.  Both Moebius factors retain their signs. -/
theorem vaughan_identity (U V : ℕ) :
    ArithmeticFunction.vonMangoldt =
      typeOneLog U - typeOneCorrection U V +
      cutLE V ArithmeticFunction.vonMangoldt + typeTwo U V := by
  have hmu : mu * zeta = 1 := by
    exact ArithmeticFunction.coe_moebius_mul_coe_zeta
  have hlog : ArithmeticFunction.vonMangoldt * zeta = ArithmeticFunction.log := by
    exact ArithmeticFunction.vonMangoldt_mul_zeta
  have hmain : mu * ArithmeticFunction.log = ArithmeticFunction.vonMangoldt := by
    exact ArithmeticFunction.moebius_mul_log_eq_vonMangoldt
  have hm : cutGT U mu = mu - cutLE U mu := by
    rw [eq_sub_iff_add_eq, add_comm]
    exact (cut_split U mu).symm
  have hv : cutGT V ArithmeticFunction.vonMangoldt =
      ArithmeticFunction.vonMangoldt - cutLE V ArithmeticFunction.vonMangoldt := by
    rw [eq_sub_iff_add_eq, add_comm]
    exact (cut_split V ArithmeticFunction.vonMangoldt).symm
  have hcancel : (mu * cutLE V ArithmeticFunction.vonMangoldt) * zeta =
      cutLE V ArithmeticFunction.vonMangoldt := by
    calc
      (mu * cutLE V ArithmeticFunction.vonMangoldt) * zeta =
          (mu * zeta) * cutLE V ArithmeticFunction.vonMangoldt := by ring
      _ = cutLE V ArithmeticFunction.vonMangoldt := by rw [hmu, one_mul]
  unfold typeOneLog typeOneCorrection typeTwo
  rw [hm, hv, ← hlog]
  calc
    ArithmeticFunction.vonMangoldt = mu * (ArithmeticFunction.vonMangoldt * zeta) := by
      rw [hlog, hmain]
    _ = cutLE U mu * (ArithmeticFunction.vonMangoldt * zeta) -
        (cutLE U mu * cutLE V ArithmeticFunction.vonMangoldt) * zeta +
        (mu * cutLE V ArithmeticFunction.vonMangoldt) * zeta +
        ((mu - cutLE U mu) *
          (ArithmeticFunction.vonMangoldt - cutLE V ArithmeticFunction.vonMangoldt)) *
          zeta := by ring
    _ = _ := by rw [hcancel]

theorem vaughan_pointwise (U V n : ℕ) :
    ArithmeticFunction.vonMangoldt n =
      typeOneLog U n - typeOneCorrection U V n +
      cutLE V ArithmeticFunction.vonMangoldt n + typeTwo U V n := by
  exact congrArg (fun f : ArithmeticFunction ℝ => f n) (vaughan_identity U V)

/-- Literal signed row functional; in particular the complement Moebius
factor has not been replaced by its absolute value. -/
noncomputable def signedRow (N alpha k : ℕ) (f : ArithmeticFunction ℝ) : ℝ :=
  ∑ n ∈ Finset.range N, f n * muReal (N - n) * actualRow N alpha k n

theorem actualEpsilon_vaughan (N alpha k U V : ℕ) :
    actualEpsilon N alpha k =
      signedRow N alpha k (typeOneLog U) -
      signedRow N alpha k (typeOneCorrection U V) +
      signedRow N alpha k (cutLE V ArithmeticFunction.vonMangoldt) +
      signedRow N alpha k (typeTwo U V) := by
  unfold actualEpsilon ArithmeticBridge.rowSum actualSequence signedRow
  simp only [← Finset.sum_sub_distrib, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro n hn
  rw [vaughan_pointwise U V n]
  ring

/-- The actual Type II row is already a signed bilinear sum, even before
dyadic localization.  The factor muReal (N - a*b) remains coupled to a*b. -/
theorem signedRow_typeTwo_bilinear (N alpha k U V : ℕ) :
    signedRow N alpha k (typeTwo U V) =
      ∑ n ∈ Finset.range N, ∑ p ∈ n.divisorsAntidiagonal,
        (if U < p.1 then mu p.1 else 0) * beta V p.2 *
          muReal (N - p.1 * p.2) * actualRow N alpha k (p.1 * p.2) := by
  unfold signedRow
  apply Finset.sum_congr rfl
  intro n hn
  rw [typeTwo_bilinear, Finset.sum_mul, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro p hp
  rw [(Nat.mem_divisorsAntidiagonal.mp hp).1]

/-- Every contributing Type II factor pair obeys both Vaughan cutoffs and
the original strict moving interval. -/
theorem actual_typeTwo_term_support {N alpha k U V n a b : ℕ}
    (hp : (a, b) ∈ n.divisorsAntidiagonal)
    (hterm : (if U < a then mu a else 0) * beta V b *
      muReal (N - a * b) * actualRow N alpha k (a * b) ≠ 0) :
    U < a ∧ V < b ∧ 1 ≤ a * b ∧ a * b + alpha * k < N := by
  have hpair : (if U < a then mu a else 0) * beta V b ≠ 0 := by
    intro h
    simp [h] at hterm
  have hrow : actualRow N alpha k (a * b) ≠ 0 := by
    intro h
    simp [h] at hterm
  have hv := typeTwo_nonzero_pair_support hp hpair
  have hr := actualRow_nonzero_support hrow
  exact ⟨hv.1, hv.2.1, hr.1, hr.2.2⟩

theorem shifted_cofactor_vaughan (N k ell U V : ℕ) :
    ArithmeticFunction.vonMangoldt (N - k * ell) * muReal ell =
      (typeOneLog U (N - k * ell) - typeOneCorrection U V (N - k * ell) +
        cutLE V ArithmeticFunction.vonMangoldt (N - k * ell) +
        typeTwo U V (N - k * ell)) * muReal ell := by
  rw [vaughan_pointwise U V (N - k * ell)]

theorem shifted_cofactor_typeTwo_bilinear (N k ell U V : ℕ) :
    typeTwo U V (N - k * ell) * muReal ell =
      ∑ p ∈ (N - k * ell).divisorsAntidiagonal,
        (if U < p.1 then mu p.1 else 0) * beta V p.2 * muReal ell := by
  rw [typeTwo_bilinear, Finset.sum_mul]

/-- Under the strict cofactor support, a factorization of the prime-side
integer is exactly an additive surface.  Truncated natural subtraction
introduces no spurious solutions here. -/
theorem cofactor_factorization_surface {N k ell a b : ℕ}
    (hstrict : k * ell < N) :
    a * b = N - k * ell ↔ a * b + k * ell = N := by
  omega

end GoldbachResearch.Vaughan

#print axioms GoldbachResearch.Vaughan.cut_split
#print axioms GoldbachResearch.Vaughan.beta_divisor_sum
#print axioms GoldbachResearch.Vaughan.beta_nonneg
#print axioms GoldbachResearch.Vaughan.beta_le_log
#print axioms GoldbachResearch.Vaughan.beta_zero_of_le
#print axioms GoldbachResearch.Vaughan.beta_support
#print axioms GoldbachResearch.Vaughan.typeTwo_bilinear
#print axioms GoldbachResearch.Vaughan.typeTwo_nonzero_pair_support
#print axioms GoldbachResearch.Vaughan.typeOne_coefficient_zero_above
#print axioms GoldbachResearch.Vaughan.typeOneLog_divisor_expansion
#print axioms GoldbachResearch.Vaughan.typeOneCorrection_divisor_expansion
#print axioms GoldbachResearch.Vaughan.vaughan_identity
#print axioms GoldbachResearch.Vaughan.vaughan_pointwise
#print axioms GoldbachResearch.Vaughan.actualEpsilon_vaughan
#print axioms GoldbachResearch.Vaughan.signedRow_typeTwo_bilinear
#print axioms GoldbachResearch.Vaughan.actual_typeTwo_term_support
#print axioms GoldbachResearch.Vaughan.shifted_cofactor_vaughan
#print axioms GoldbachResearch.Vaughan.shifted_cofactor_typeTwo_bilinear
#print axioms GoldbachResearch.Vaughan.cofactor_factorization_surface
