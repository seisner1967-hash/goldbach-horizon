import GoldbachPatterns
import GoldbachMass
import GoldbachCompressedMass

/-!
# The four dyadic anchors

This module first proves the strict diameter bounds of four anchor
coordinates when the seven other factors are fixed. These are finite,
arithmetic bounds. The full fourth-moment identification is not assumed.
-/

namespace GoldbachResearch.Anchors

open scoped BigOperators
open GoldbachResearch.Patterns

def Terminal (Q : ℝ) (q : Index → ℝ) : Prop :=
  ∀ i, Q / 2 < q i ∧ q i ≤ Q

def moduli (a b c d : ℝ) (r : Index → ℝ) : Index → ℝ :=
  ![a * b * c * r 0, a * d * r 1, b * d * r 2, c * r 3]

theorem terminal_four_product {Q x y z t : ℝ} (hQ : 0 < Q)
    (hx : Q / 2 < x ∧ x ≤ Q) (hy : Q / 2 < y ∧ y ≤ Q)
    (hz : Q / 2 < z ∧ z ≤ Q) (ht : Q / 2 < t ∧ t ≤ Q) :
    Q ^ 4 / 16 < x * y * z * t ∧ x * y * z * t ≤ Q ^ 4 := by
  have hhalf : 0 < Q / 2 := by linarith
  have hx0 : 0 < x := lt_trans hhalf hx.1
  have hy0 : 0 < y := lt_trans hhalf hy.1
  have hz0 : 0 < z := lt_trans hhalf hz.1
  have ht0 : 0 < t := lt_trans hhalf ht.1
  have hxyL : (Q / 2) * (Q / 2) < x * y :=
    mul_lt_mul hx.1 (le_of_lt hy.1) hhalf (le_of_lt hx0)
  have hztL : (Q / 2) * (Q / 2) < z * t :=
    mul_lt_mul hz.1 (le_of_lt ht.1) hhalf (le_of_lt hz0)
  have hxyU : x * y ≤ Q * Q :=
    mul_le_mul hx.2 hy.2 (le_of_lt hy0) (le_of_lt hQ)
  have hztU : z * t ≤ Q * Q :=
    mul_le_mul hz.2 ht.2 (le_of_lt ht0) (le_of_lt hQ)
  have hlo : ((Q / 2) * (Q / 2)) * ((Q / 2) * (Q / 2)) <
      (x * y) * (z * t) :=
    mul_lt_mul hxyL (le_of_lt hztL) (mul_pos hhalf hhalf)
      (le_of_lt (mul_pos hx0 hy0))
  have hhi : (x * y) * (z * t) ≤ (Q * Q) * (Q * Q) :=
    mul_le_mul hxyU hztU (le_of_lt (mul_pos hz0 ht0)) (mul_self_nonneg Q)
  constructor <;> nlinarith

theorem quartic_ratio {Q a A L R : ℝ} (hQ : 0 < Q)
    (ha : 0 < a) (hA : 0 < A)
    (hL : Q ^ 4 / 16 < L) (hR : R ≤ Q ^ 4)
    (hidentity : A ^ 2 * L = a ^ 2 * R) : A < 4 * a := by
  have hA2 : 0 < A ^ 2 := pow_pos hA 2
  have hprodL := mul_lt_mul_of_pos_left hL hA2
  have hprodR := mul_le_mul_of_nonneg_left hR (sq_nonneg a)
  have hQ4 : 0 < Q ^ 4 := pow_pos hQ 4
  have hs : A ^ 2 < 16 * a ^ 2 := by
    nlinarith
  nlinarith

theorem anchor12_diameter {Q a b c d A B C D : ℝ} {r : Index → ℝ}
    (hQ : 0 < Q) (ha : 0 < a) (hA : 0 < A)
    (hsmall : Terminal Q (moduli a b c d r))
    (hlarge : Terminal Q (moduli A B C D r)) : A < 4 * a := by
  have hlow := terminal_four_product hQ (hsmall 0) (hsmall 1) (hlarge 2) (hlarge 3)
  have hupp := terminal_four_product hQ (hlarge 0) (hlarge 1) (hsmall 2) (hsmall 3)
  apply quartic_ratio hQ ha hA hlow.1 hupp.2
  norm_num [moduli]
  ring

theorem anchor13_diameter {Q a b c d A B C D : ℝ} {r : Index → ℝ}
    (hQ : 0 < Q) (hb : 0 < b) (hB : 0 < B)
    (hsmall : Terminal Q (moduli a b c d r))
    (hlarge : Terminal Q (moduli A B C D r)) : B < 4 * b := by
  have hlow := terminal_four_product hQ (hsmall 0) (hsmall 2) (hlarge 1) (hlarge 3)
  have hupp := terminal_four_product hQ (hlarge 0) (hlarge 2) (hsmall 1) (hsmall 3)
  apply quartic_ratio hQ hb hB hlow.1 hupp.2
  norm_num [moduli]
  ring

theorem anchor23_diameter {Q a b c d A B C D : ℝ} {r : Index → ℝ}
    (hQ : 0 < Q) (hd : 0 < d) (hD : 0 < D)
    (hsmall : Terminal Q (moduli a b c d r))
    (hlarge : Terminal Q (moduli A B C D r)) : D < 4 * d := by
  have hlow := terminal_four_product hQ (hsmall 1) (hsmall 2) (hsmall 3) (hlarge 0)
  have hupp := terminal_four_product hQ (hlarge 1) (hlarge 2) (hlarge 3) (hsmall 0)
  apply quartic_ratio hQ hd hD hlow.1 hupp.2
  norm_num [moduli]
  ring

theorem anchor14_diameter {Q a b c d A B C D : ℝ} {r : Index → ℝ}
    (hQ : 0 < Q) (hc : 0 < c) (hC : 0 < C)
    (hsmall : Terminal Q (moduli a b c d r))
    (hlarge : Terminal Q (moduli A B C D r)) : C < 2 * c := by
  have hx := hsmall 3
  have hX := hlarge 3
  have hp : 0 < moduli a b c d r 3 := by linarith [hx.1]
  have he : C * moduli a b c d r 3 = c * moduli A B C D r 3 := by
    simp [moduli]
    ring
  have hlow := mul_lt_mul_of_pos_left hx.1 hC
  have hupp := mul_le_mul_of_nonneg_left hX.2 (le_of_lt hc)
  nlinarith

noncomputable def weight (n : ℕ) : ℝ := (n : ℝ) / (n.totient : ℝ) ^ 2

theorem weight_nonneg (n : ℕ) : 0 ≤ weight n := by unfold weight; positivity

theorem eulerMass_nonneg (Q : ℕ) : 0 ≤ Mass.oddEulerMass Q := by
  rw [Mass.oddEulerMass_eq]
  apply Finset.prod_nonneg
  intro p hp
  have hc := Mass.primeCorrection_nonneg (Mass.mem_oddPrimes.mp hp).2.1
  have hp0 : 0 ≤ (p : ℝ) := Nat.cast_nonneg p
  positivity

theorem fourfold_mass (s : Finset ℕ) (Q m : ℕ) (hm : 0 < m)
    (hs : ∀ n ∈ s, Odd n ∧ Squarefree n ∧ n ≤ Q ∧ m ≤ n ∧ n < 4 * m) :
    ∑ n ∈ s, weight n ≤ 2 * Mass.oddEulerMass Q := by
  classical
  have hfirst : ∑ n ∈ s.filter (fun n => n < 2 * m), weight n ≤ Mass.oddEulerMass Q := by
    apply Mass.actual_odd_dyadic_mass_mirror _ Q m hm
    intro n hn
    obtain ⟨hnS, hnU⟩ := Finset.mem_filter.mp hn
    exact ⟨(hs n hnS).1, (hs n hnS).2.1, (hs n hnS).2.2.1,
      (hs n hnS).2.2.2.1, hnU⟩
  have hsecond : ∑ n ∈ s.filter (fun n => ¬n < 2 * m), weight n ≤ Mass.oddEulerMass Q := by
    apply Mass.actual_odd_dyadic_mass_mirror _ Q (2 * m) (by omega)
    intro n hn
    obtain ⟨hnS, hnL⟩ := Finset.mem_filter.mp hn
    have hh := hs n hnS
    exact ⟨hh.1, hh.2.1, hh.2.2.1, by omega, by omega⟩
  have hsplit := Finset.sum_filter_add_sum_filter_not s (fun n => n < 2 * m) weight
  linarith

theorem sum_product_le_product_projection {ι : Type*} [Fintype ι]
    (S : Finset (ι → ℕ)) :
    (∑ f ∈ S, ∏ i, weight (f i)) ≤
      ∏ i, ∑ n ∈ S.image (fun f => f i), weight n := by
  classical
  rw [Finset.prod_univ_sum]
  apply Finset.sum_le_sum_of_subset_of_nonneg
  · intro f hf
    apply Fintype.mem_piFinset.mpr
    intro i
    exact Finset.mem_image.mpr ⟨f, hf, rfl⟩
  · intro f hf hnot
    exact Finset.prod_nonneg (fun i hi => weight_nonneg (f i))

def anchorWindows : Index → ℕ := ![2, 2, 1, 2]

theorem anchor_diameter_at {Q : ℝ} {v V : Index → ℕ} {r : Index → ℝ}
    (hQ : 0 < Q) (hv : ∀ i, 0 < v i) (hV : ∀ i, 0 < V i)
    (hsmall : Terminal Q (moduli (v 0) (v 1) (v 2) (v 3) r))
    (hlarge : Terminal Q (moduli (V 0) (V 1) (V 2) (V 3) r)) (i : Index) :
    V i < (2 * anchorWindows i) * v i := by
  have hpos : ∀ j, 0 < (v j : ℝ) := fun j => by exact_mod_cast hv j
  have hPos : ∀ j, 0 < (V j : ℝ) := fun j => by exact_mod_cast hV j
  fin_cases i
  · have hh := anchor12_diameter hQ (hpos 0) (hPos 0) hsmall hlarge
    norm_num [anchorWindows]
    exact_mod_cast hh
  · have hh := anchor13_diameter hQ (hpos 1) (hPos 1) hsmall hlarge
    norm_num [anchorWindows]
    exact_mod_cast hh
  · have hh := anchor14_diameter hQ (hpos 2) (hPos 2) hsmall hlarge
    norm_num [anchorWindows]
    exact_mod_cast hh
  · have hh := anchor23_diameter hQ (hpos 3) (hPos 3) hsmall hlarge
    norm_num [anchorWindows]
    exact_mod_cast hh

theorem anchor_projection_mass (S : Finset (Index → ℕ)) (Q : ℕ)
    (r : Index → ℝ) (hQ : 0 < Q)
    (hs : ∀ v ∈ S, (∀ i, Odd (v i) ∧ Squarefree (v i) ∧ v i ≤ Q) ∧
      Terminal (Q : ℝ) (moduli (v 0) (v 1) (v 2) (v 3) r)) (i : Index) :
    ∑ n ∈ S.image (fun v => v i), weight n ≤
      (anchorWindows i : ℝ) * Mass.oddEulerMass Q := by
  classical
  let s := S.image (fun v => v i)
  by_cases he : s.Nonempty
  · let m := s.min' he
    have hmS : m ∈ s := Finset.min'_mem s he
    obtain ⟨v₀, hv₀, hmEq⟩ := Finset.mem_image.mp hmS
    have hv₀pos : ∀ j, 0 < v₀ j := fun j =>
      Nat.pos_of_ne_zero ((hs v₀ hv₀).1 j).2.1.ne_zero
    have hm : 0 < m := hmEq ▸ hv₀pos i
    have hbounds : ∀ n ∈ s,
        Odd n ∧ Squarefree n ∧ n ≤ Q ∧ m ≤ n ∧
          n < (2 * anchorWindows i) * m := by
      intro n hn
      obtain ⟨v, hv, hEq⟩ := Finset.mem_image.mp hn
      have hvpos : ∀ j, 0 < v j := fun j =>
        Nat.pos_of_ne_zero ((hs v hv).1 j).2.1.ne_zero
      have hdiam := anchor_diameter_at (by exact_mod_cast hQ)
        hv₀pos hvpos (hs v₀ hv₀).2 (hs v hv).2 i
      have hmin : m ≤ n := Finset.min'_le s n hn
      rw [hmEq, hEq] at hdiam
      simpa [hEq] using And.intro ((hs v hv).1 i).1
        (And.intro ((hs v hv).1 i).2.1
          (And.intro ((hs v hv).1 i).2.2 (And.intro hmin hdiam)))
    have htwo : anchorWindows i = 1 ∨ anchorWindows i = 2 := by
      fin_cases i <;> norm_num [anchorWindows]
    rcases htwo with hwin | hwin
    · rw [hwin]
      simp only [Nat.cast_one, one_mul]
      apply Mass.actual_odd_dyadic_mass_mirror s Q m hm
      intro n hn
      simpa [hwin] using hbounds n hn
    · rw [hwin]
      norm_num only [Nat.cast_ofNat]
      apply fourfold_mass s Q m hm
      intro n hn
      simpa [hwin] using hbounds n hn
  · have hz : s = ∅ := Finset.not_nonempty_iff_eq_empty.mp he
    change (∑ n ∈ s, weight n) ≤ _
    rw [hz, Finset.sum_empty]
    exact mul_nonneg (Nat.cast_nonneg _) (eulerMass_nonneg Q)

theorem anchor_fiber_mass (S : Finset (Index → ℕ)) (Q : ℕ)
    (r : Index → ℝ) (hQ : 0 < Q)
    (hs : ∀ v ∈ S, (∀ i, Odd (v i) ∧ Squarefree (v i) ∧ v i ≤ Q) ∧
      Terminal (Q : ℝ) (moduli (v 0) (v 1) (v 2) (v 3) r)) :
    ∑ v ∈ S, ∏ i : Index, weight (v i) ≤ 8 * Mass.oddEulerMass Q ^ 4 := by
  have hprod : (∏ i : Index, ∑ n ∈ S.image (fun v => v i), weight n) ≤
      ∏ i : Index, (anchorWindows i : ℝ) * Mass.oddEulerMass Q := by
    apply Finset.prod_le_prod
    · intro i hi
      exact Finset.sum_nonneg (fun n hn => weight_nonneg n)
    · intro i hi
      exact anchor_projection_mass S Q r hQ hs i
  have he : (∏ i : Index, (anchorWindows i : ℝ) * Mass.oddEulerMass Q) =
      8 * Mass.oddEulerMass Q ^ 4 := by
    simp [Fin.prod_univ_succ, anchorWindows]
    ring
  exact (sum_product_le_product_projection S).trans (hprod.trans_eq he)

abbrev FreeIndex := Fin 7
abbrev Assignment := (Index → ℕ) × (FreeIndex → ℕ)

theorem sum_paired_fibers {α β : Type*} [DecidableEq α] [DecidableEq β]
    (S : Finset (α × β))
    (wa : α → ℝ) (wb : β → ℝ) :
    (∑ p ∈ S, wa p.1 * wb p.2) =
      ∑ u ∈ S.image Prod.snd,
        (∑ v ∈ (S.filter (fun p => p.2 = u)).image Prod.fst, wa v) * wb u := by
  classical
  symm
  calc
    _ = ∑ u ∈ S.image Prod.snd,
        ∑ p ∈ S.filter (fun p => p.2 = u), wa p.1 * wb p.2 := by
      apply Finset.sum_congr rfl
      intro u hu
      have hinj : ∀ p ∈ S.filter (fun p => p.2 = u),
          ∀ t ∈ S.filter (fun p => p.2 = u), p.1 = t.1 → p = t := by
        intro p hp t ht he
        exact Prod.ext he ((Finset.mem_filter.mp hp).2.trans
          (Finset.mem_filter.mp ht).2.symm)
      rw [Finset.sum_image hinj, Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro p hp
      rw [(Finset.mem_filter.mp hp).2]
    _ = _ := Finset.sum_fiberwise_of_maps_to (s := S)
      (t := S.image Prod.snd) (g := Prod.snd)
      (fun p hp => Finset.mem_image.mpr ⟨p, hp, rfl⟩) (fun p => wa p.1 * wb p.2)

theorem seven_coordinate_mass (S : Finset (FreeIndex → ℕ)) (Q : ℕ)
    (hs : ∀ f ∈ S, ∀ i, Odd (f i) ∧ Squarefree (f i) ∧ f i ≤ Q) :
    ∑ f ∈ S, ∏ i : FreeIndex, weight (f i) ≤
      (Mass.oddEulerMass Q * Mass.oddHarmonic Q) ^ 7 := by
  have hb : (∏ i : FreeIndex, ∑ n ∈ S.image (fun f => f i), weight n) ≤
      ∏ _i : FreeIndex, Mass.oddEulerMass Q * Mass.oddHarmonic Q := by
    apply Finset.prod_le_prod
    · intro i hi
      exact Finset.sum_nonneg (fun n hn => weight_nonneg n)
    · intro i hi
      apply Mass.actual_odd_full_mass
      intro n hn
      obtain ⟨f, hf, hEq⟩ := Finset.mem_image.mp hn
      simpa only [hEq] using hs f hf i
  have he : (∏ _i : FreeIndex, Mass.oddEulerMass Q * Mass.oddHarmonic Q) =
      (Mass.oddEulerMass Q * Mass.oddHarmonic Q) ^ 7 := by
    simp
  exact (sum_product_le_product_projection S).trans (hb.trans_eq he)

def Admissible (Q : ℕ) (r : (FreeIndex → ℕ) → Index → ℝ)
    (p : Assignment) : Prop :=
  (∀ i, Odd (p.1 i) ∧ Squarefree (p.1 i) ∧ p.1 i ≤ Q) ∧
  (∀ i, Odd (p.2 i) ∧ Squarefree (p.2 i) ∧ p.2 i ≤ Q) ∧
    Terminal (Q : ℝ) (moduli (p.1 0) (p.1 1) (p.1 2) (p.1 3) (r p.2))

/-- Four strict anchor diameters and seven complete arithmetic masses.
The hypotheses constrain individual coordinates and four monomials only;
no bound on the sum being proved is assumed. -/
theorem eleven_coordinate_mass (S : Finset Assignment) (Q : ℕ)
    (r : (FreeIndex → ℕ) → Index → ℝ) (hQ : 0 < Q)
    (hs : ∀ p ∈ S, Admissible Q r p) :
    ∑ p ∈ S,
      (∏ i : Index, weight (p.1 i)) * (∏ j : FreeIndex, weight (p.2 j)) ≤
        8 * Mass.oddEulerMass Q ^ 11 * Mass.oddHarmonic Q ^ 7 := by
  classical
  let R := S.image Prod.snd
  let fiber := fun u => (S.filter (fun p => p.2 = u)).image Prod.fst
  have hfiber : ∀ u ∈ R,
      (∑ v ∈ fiber u, ∏ i : Index, weight (v i)) ≤ 8 * Mass.oddEulerMass Q ^ 4 := by
    intro u hu
    apply anchor_fiber_mass _ Q (r u) hQ
    intro v hv
    obtain ⟨p, hp, he⟩ := Finset.mem_image.mp hv
    obtain ⟨hpS, hpU⟩ := Finset.mem_filter.mp hp
    have hh := hs p hpS
    exact ⟨he ▸ hh.1, hpU ▸ he ▸ hh.2.2⟩
  have hfree : ∑ u ∈ R, ∏ j : FreeIndex, weight (u j) ≤
      (Mass.oddEulerMass Q * Mass.oddHarmonic Q) ^ 7 := by
    apply seven_coordinate_mass
    intro u hu
    obtain ⟨p, hp, he⟩ := Finset.mem_image.mp hu
    exact he ▸ (hs p hp).2.1
  have hscale : 0 ≤ 8 * Mass.oddEulerMass Q ^ 4 := by positivity
  calc
    _ = ∑ u ∈ R,
        (∑ v ∈ fiber u, ∏ i : Index, weight (v i)) *
          (∏ j : FreeIndex, weight (u j)) :=
      sum_paired_fibers S (fun v => ∏ i : Index, weight (v i))
        (fun u => ∏ j : FreeIndex, weight (u j))
    _ ≤ ∑ u ∈ R, (8 * Mass.oddEulerMass Q ^ 4) *
        (∏ j : FreeIndex, weight (u j)) := by
      apply Finset.sum_le_sum
      intro u hu
      apply mul_le_mul_of_nonneg_right (hfiber u hu)
      exact Finset.prod_nonneg (fun j hj => weight_nonneg (u j))
    _ = (8 * Mass.oddEulerMass Q ^ 4) *
        (∑ u ∈ R, ∏ j : FreeIndex, weight (u j)) := by rw [Finset.mul_sum]
    _ ≤ (8 * Mass.oddEulerMass Q ^ 4) *
        (Mass.oddEulerMass Q * Mass.oddHarmonic Q) ^ 7 :=
      mul_le_mul_of_nonneg_left hfree hscale
    _ = _ := by ring

def anchorCode : Index → Pattern := ![{0, 1}, {0, 2}, {0, 3}, {1, 2}]

def freeCode : FreeIndex → Pattern :=
  ![{1, 3}, {2, 3}, {0, 1, 2}, {0, 1, 3}, {0, 2, 3}, {1, 2, 3}, {0, 1, 2, 3}]

theorem vector_sixth {α : Type*} (a b c d e f g : α) :
    ![a, b, c, d, e, f, g] (5 : Fin 7) = f := rfl

theorem vector_seventh {α : Type*} (a b c d e f g : α) :
    ![a, b, c, d, e, f, g] (6 : Fin 7) = g := rfl

def patternCode : Index ⊕ FreeIndex → Pattern := Sum.elim anchorCode freeCode

theorem patternCode_injective : Function.Injective patternCode := by decide

theorem patternCode_image :
    (Finset.univ : Finset (Index ⊕ FreeIndex)).image patternCode = patterns := by decide

theorem coded_product {M : Type*} [CommMonoid M] (F : Pattern → M) :
    (∏ I ∈ patterns, F I) =
      (∏ i : Index, F (anchorCode i)) * (∏ j : FreeIndex, F (freeCode j)) := by
  classical
  rw [← patternCode_image, Finset.prod_image
    (fun i _ j _ h => patternCode_injective h), Fintype.prod_sum_type]
  rfl

def natRest (f : FreeIndex → ℕ) : Index → ℕ :=
  ![f 2 * f 3 * f 4 * f 6,
    f 0 * f 2 * f 3 * f 5 * f 6,
    f 1 * f 2 * f 4 * f 5 * f 6,
    f 0 * f 1 * f 3 * f 4 * f 5 * f 6]

noncomputable def realRest (f : FreeIndex → ℕ) (i : Index) : ℝ := natRest f i

def natModuli (v : Index → ℕ) (f : FreeIndex → ℕ) : Index → ℕ :=
  ![v 0 * v 1 * v 2 * natRest f 0,
    v 0 * v 3 * natRest f 1,
    v 1 * v 3 * natRest f 2,
    v 2 * natRest f 3]

theorem natModuli_cast (v : Index → ℕ) (f : FreeIndex → ℕ) (i : Index) :
    (natModuli v f i : ℝ) = moduli (v 0) (v 1) (v 2) (v 3) (realRest f) i := by
  fin_cases i <;> norm_num [natModuli, moduli, realRest]

theorem coded_modulus (D : Pattern → ℕ) (i : Index) :
    (∏ I ∈ patterns.filter (fun I => i ∈ I), D I) =
      natModuli (fun j => D (anchorCode j)) (fun j => D (freeCode j)) i := by
  rw [Finset.prod_filter, coded_product]
  fin_cases i <;>
    norm_num [Fin.prod_univ_succ, anchorCode, freeCode, natModuli, natRest,
      vector_sixth, vector_seventh, Fin.ext_iff, Fin.coe_ofNat_eq_mod] <;> ring_nf <;> simp

def extract (q : Index → ℕ) : Assignment :=
  (fun i => atom q (anchorCode i), fun i => atom q (freeCode i))

theorem extracted_moduli (q : Index → ℕ) (hq : ∀ i, Squarefree (q i))
    (hw : pairedWeight q ≠ 0) (i : Index) :
    natModuli (extract q).1 (extract q).2 i = q i := by
  rw [← nonzero_weight_reconstruction q hq hw i, coded_modulus]
  rfl

theorem extract_injective_on {q t : Index → ℕ}
    (hq : ∀ i, Squarefree (q i)) (ht : ∀ i, Squarefree (t i))
    (hwq : pairedWeight q ≠ 0) (hwt : pairedWeight t ≠ 0)
    (he : extract q = extract t) : q = t := by
  funext i
  rw [← extracted_moduli q hq hwq i, ← extracted_moduli t ht hwt i, he]

theorem coded_pattern_nonempty (k : Index ⊕ FreeIndex) : (patternCode k).Nonempty := by
  have hc : ∀ k : Index ⊕ FreeIndex, 2 ≤ (patternCode k).card := by decide
  exact Finset.card_pos.mp (lt_of_lt_of_le (by decide : 0 < 2) (hc k))

theorem atom_admissible_coordinate (q : Index → ℕ) (Q : ℕ)
    (hq : ∀ i, Odd (q i) ∧ Squarefree (q i) ∧ q i ≤ Q)
    (I : Pattern) (hI : I.Nonempty) :
    Odd (atom q I) ∧ Squarefree (atom q I) ∧ atom q I ≤ Q := by
  obtain ⟨i, hi⟩ := hI
  have hd := atom_divides_modulus q hi (hq i).2.1
  have hodd : Odd (atom q I) := by
    obtain ⟨m, hm⟩ := hd
    have hh := (hq i).1
    rw [hm] at hh
    exact (Nat.odd_mul.mp hh).1
  have hle : atom q I ≤ q i := Nat.le_of_dvd
    (Nat.pos_of_ne_zero (hq i).2.1.ne_zero) hd
  exact ⟨hodd, atoms_squarefree q (fun j => (hq j).2.1) I,
    le_trans hle (hq i).2.2⟩

theorem extract_admissible (q : Index → ℕ) (Q : ℕ)
    (hq : ∀ i, Odd (q i) ∧ Squarefree (q i) ∧ q i ≤ Q)
    (hw : pairedWeight q ≠ 0) (hterminal : Terminal (Q : ℝ) (fun i => (q i : ℝ))) :
    Admissible Q realRest (extract q) := by
  have hs : ∀ i, Squarefree (q i) := fun i => (hq i).2.1
  refine ⟨?_, ?_, ?_⟩
  · intro i
    exact atom_admissible_coordinate q Q hq (anchorCode i)
      (coded_pattern_nonempty (Sum.inl i))
  · intro i
    exact atom_admissible_coordinate q Q hq (freeCode i)
      (coded_pattern_nonempty (Sum.inr i))
  · intro i
    rw [← natModuli_cast, extracted_moduli q hs hw i]
    exact hterminal i

theorem pairedWeight_le_extracted_weight (q : Index → ℕ)
    (hq : ∀ i, Squarefree (q i)) (hw : pairedWeight q ≠ 0) :
    pairedWeight q ≤
      (∏ i : Index, weight ((extract q).1 i)) *
        (∏ j : FreeIndex, weight ((extract q).2 j)) := by
  have hb := pairedWeight_upper_totients q hq hw
  rw [coded_product] at hb
  exact hb

/-- The full eleven-coordinate bound applied to actual squarefree terminal
quadruplets and their unique prime-pattern decomposition. -/
theorem actual_terminal_paired_mass (S : Finset (Index → ℕ)) (Q : ℕ) (hQ : 0 < Q)
    (hs : ∀ q ∈ S, (∀ i, Odd (q i) ∧ Squarefree (q i) ∧ q i ≤ Q) ∧
      pairedWeight q ≠ 0 ∧ Terminal (Q : ℝ) (fun i => (q i : ℝ))) :
    ∑ q ∈ S, pairedWeight q ≤ 8 * Mass.oddEulerMass Q ^ 11 * Mass.oddHarmonic Q ^ 7 := by
  classical
  have hinj : ∀ q ∈ S, ∀ t ∈ S, extract q = extract t → q = t := by
    intro q hq t ht he
    exact extract_injective_on (fun i => (hs q hq).1 i |>.2.1)
      (fun i => (hs t ht).1 i |>.2.1) (hs q hq).2.1 (hs t ht).2.1 he
  calc
    _ ≤ ∑ q ∈ S, (∏ i : Index, weight ((extract q).1 i)) *
        (∏ j : FreeIndex, weight ((extract q).2 j)) := by
      apply Finset.sum_le_sum
      intro q hq
      exact pairedWeight_le_extracted_weight q (fun i => (hs q hq).1 i |>.2.1)
        (hs q hq).2.1
    _ = ∑ p ∈ S.image extract, (∏ i : Index, weight (p.1 i)) *
        (∏ j : FreeIndex, weight (p.2 j)) := by
      symm
      apply Finset.sum_image hinj
    _ ≤ _ := by
      apply eleven_coordinate_mass _ Q realRest hQ
      intro p hp
      obtain ⟨q, hq, he⟩ := Finset.mem_image.mp hp
      exact he ▸ extract_admissible q Q (hs q hq).1 (hs q hq).2.1 (hs q hq).2.2

theorem actual_terminal_paired_mass_all (S : Finset (Index → ℕ)) (Q : ℕ) (hQ : 0 < Q)
    (hs : ∀ q ∈ S, (∀ i, Odd (q i) ∧ Squarefree (q i) ∧ q i ≤ Q) ∧
      Terminal (Q : ℝ) (fun i => (q i : ℝ))) :
    ∑ q ∈ S, pairedWeight q ≤ 8 * Mass.oddEulerMass Q ^ 11 * Mass.oddHarmonic Q ^ 7 := by
  classical
  have hb := actual_terminal_paired_mass (S.filter (fun q => pairedWeight q ≠ 0)) Q hQ
    (by
      intro q hq
      obtain ⟨hqS, hqW⟩ := Finset.mem_filter.mp hq
      exact ⟨(hs q hqS).1, hqW, (hs q hqS).2⟩)
  simpa only [Finset.sum_filter_ne_zero] using hb

def freeDegreeProduct (f : FreeIndex → ℕ) : ℕ :=
  f 0 ^ 2 * f 1 ^ 2 * f 2 ^ 3 * f 3 ^ 3 * f 4 ^ 3 * f 5 ^ 3 * f 6 ^ 4

theorem natModuli_product (v : Index → ℕ) (f : FreeIndex → ℕ) :
    (∏ i : Index, natModuli v f i) =
      (v 0 * v 1 * v 2 * v 3) ^ 2 * freeDegreeProduct f := by
  simp [Fin.prod_univ_succ, natModuli, natRest, freeDegreeProduct]
  ring

theorem free_degree_constraint (v : Index → ℕ) (f : FreeIndex → ℕ) (Q : ℕ)
    (hv : ∀ i, 0 < v i) (hupper : ∀ i, natModuli v f i ≤ Q) :
    freeDegreeProduct f ≤ Q ^ 4 := by
  have hA : 0 < v 0 * v 1 * v 2 * v 3 :=
    mul_pos (mul_pos (mul_pos (hv 0) (hv 1)) (hv 2)) (hv 3)
  have hA2 : 1 ≤ (v 0 * v 1 * v 2 * v 3) ^ 2 := by
    have hp := pow_pos hA 2
    omega
  have hsmall : freeDegreeProduct f ≤
      (v 0 * v 1 * v 2 * v 3) ^ 2 * freeDegreeProduct f := by nlinarith
  have hlarge : (∏ i : Index, natModuli v f i) ≤ Q ^ 4 := by
    calc
      _ ≤ ∏ _i : Index, Q := Finset.prod_le_prod' (fun i hi => hupper i)
      _ = _ := by simp
  rw [natModuli_product] at hlarge
  exact le_trans hsmall hlarge

theorem extracted_free_degree_constraint (q : Index → ℕ) (Q : ℕ)
    (hq : ∀ i, Odd (q i) ∧ Squarefree (q i) ∧ q i ≤ Q)
    (hw : pairedWeight q ≠ 0) : freeDegreeProduct (extract q).2 ≤ Q ^ 4 := by
  apply free_degree_constraint (extract q).1 (extract q).2 Q
  · intro i
    have hh := atom_admissible_coordinate q Q hq (anchorCode i)
      (coded_pattern_nonempty (Sum.inl i))
    exact Nat.pos_of_ne_zero hh.2.1.ne_zero
  · intro i
    rw [extracted_moduli q (fun j => (hq j).2.1) hw i]
    exact (hq i).2.2

def freeDegrees : FreeIndex → ℕ := ![2, 2, 3, 3, 3, 3, 4]

theorem freeDegree_as_product (f : FreeIndex → ℕ) :
    freeDegreeProduct f = ∏ i : FreeIndex, f i ^ freeDegrees i := by
  simp [freeDegreeProduct, Fin.prod_univ_succ, freeDegrees, vector_sixth, vector_seventh]
  ring_nf
  rfl

theorem log_freeDegreeProduct (f : FreeIndex → ℕ) (hf : ∀ i, 0 < f i) :
    Real.log (freeDegreeProduct f : ℝ) =
      ∑ i : FreeIndex, (freeDegrees i : ℝ) * Real.log (f i : ℝ) := by
  rw [freeDegree_as_product, Nat.cast_prod]
  simp_rw [Nat.cast_pow]
  rw [Real.log_prod]
  · simp_rw [Real.log_pow]
  · intro i hi
    apply pow_ne_zero
    exact ne_of_gt (by exact_mod_cast hf i : 0 < (f i : ℝ))

theorem extracted_free_log_constraint (q : Index → ℕ) (Q : ℕ)
    (hq : ∀ i, Odd (q i) ∧ Squarefree (q i) ∧ q i ≤ Q)
    (hw : pairedWeight q ≠ 0) :
    (∑ i : FreeIndex, (freeDegrees i : ℝ) * Real.log ((extract q).2 i : ℝ)) ≤
      4 * Real.log (Q : ℝ) := by
  have hfpos : ∀ i, 0 < (extract q).2 i := by
    intro i
    have hh := atom_admissible_coordinate q Q hq (freeCode i)
      (coded_pattern_nonempty (Sum.inr i))
    exact Nat.pos_of_ne_zero hh.2.1.ne_zero
  have hprodpos : 0 < freeDegreeProduct (extract q).2 := by
    rw [freeDegree_as_product]
    exact Finset.prod_pos (fun i hi => pow_pos (hfpos i) _)
  have hprod := extracted_free_degree_constraint q Q hq hw
  have hlog := Real.log_le_log (by exact_mod_cast hprodpos)
    (by exact_mod_cast hprod : (freeDegreeProduct (extract q).2 : ℝ) ≤ (Q ^ 4 : ℕ))
  rw [log_freeDegreeProduct _ hfpos, Nat.cast_pow, Real.log_pow] at hlog
  norm_num only [Nat.cast_ofNat] at hlog
  exact hlog

noncomputable def supportPolynomial (R : ℝ) : ℝ :=
  ∑ I : Finset FreeIndex, (R / 2) ^ I.card /
    ((I.card.factorial : ℝ) * ∏ i ∈ I, (freeDegrees i : ℝ))

theorem seven_coordinate_compressed_mass (S : Finset (FreeIndex → ℕ))
    (Q : ℕ) (R : ℝ) (hR : 0 ≤ R)
    (hs : ∀ f ∈ S, (∀ i, Odd (f i) ∧ Squarefree (f i) ∧ f i ≤ Q) ∧
      (∑ i : FreeIndex, (freeDegrees i : ℝ) * Real.log (f i : ℝ)) ≤ R) :
    ∑ f ∈ S, ∏ i : FreeIndex, weight (f i) ≤
      Mass.oddEulerMass Q ^ 7 * supportPolynomial R := by
  have hdegrees : ∀ i : FreeIndex, 0 < freeDegrees i := by decide
  have hh := CompressedMass.actual_odd_weighted_simplex_mass S Q
    (fun i => (freeDegrees i : ℝ)) R
    (fun i => by
      change 0 < (freeDegrees i : ℝ)
      exact_mod_cast hdegrees i) hR hs
  exact hh

theorem eleven_coordinate_compressed_mass (S : Finset Assignment) (Q : ℕ)
    (r : (FreeIndex → ℕ) → Index → ℝ) (R : ℝ) (hQ : 0 < Q) (hR : 0 ≤ R)
    (hs : ∀ p ∈ S, Admissible Q r p ∧
      (∑ i : FreeIndex, (freeDegrees i : ℝ) * Real.log (p.2 i : ℝ)) ≤ R) :
    ∑ p ∈ S,
      (∏ i : Index, weight (p.1 i)) * (∏ j : FreeIndex, weight (p.2 j)) ≤
        8 * Mass.oddEulerMass Q ^ 11 * supportPolynomial R := by
  classical
  let T := S.image Prod.snd
  let fiber := fun u => (S.filter (fun p => p.2 = u)).image Prod.fst
  have hfiber : ∀ u ∈ T,
      (∑ v ∈ fiber u, ∏ i : Index, weight (v i)) ≤ 8 * Mass.oddEulerMass Q ^ 4 := by
    intro u hu
    apply anchor_fiber_mass _ Q (r u) hQ
    intro v hv
    obtain ⟨p, hp, he⟩ := Finset.mem_image.mp hv
    obtain ⟨hpS, hpU⟩ := Finset.mem_filter.mp hp
    have hh := (hs p hpS).1
    exact ⟨he ▸ hh.1, hpU ▸ he ▸ hh.2.2⟩
  have hfree : ∑ u ∈ T, ∏ j : FreeIndex, weight (u j) ≤
      Mass.oddEulerMass Q ^ 7 * supportPolynomial R := by
    apply seven_coordinate_compressed_mass _ Q R hR
    intro u hu
    obtain ⟨p, hp, he⟩ := Finset.mem_image.mp hu
    exact ⟨he ▸ (hs p hp).1.2.1, he ▸ (hs p hp).2⟩
  have hscale : 0 ≤ 8 * Mass.oddEulerMass Q ^ 4 := by positivity
  calc
    _ = ∑ u ∈ T,
        (∑ v ∈ fiber u, ∏ i : Index, weight (v i)) *
          (∏ j : FreeIndex, weight (u j)) :=
      sum_paired_fibers S (fun v => ∏ i : Index, weight (v i))
        (fun u => ∏ j : FreeIndex, weight (u j))
    _ ≤ ∑ u ∈ T, (8 * Mass.oddEulerMass Q ^ 4) *
        (∏ j : FreeIndex, weight (u j)) := by
      apply Finset.sum_le_sum
      intro u hu
      apply mul_le_mul_of_nonneg_right (hfiber u hu)
      exact Finset.prod_nonneg (fun j hj => weight_nonneg (u j))
    _ = (8 * Mass.oddEulerMass Q ^ 4) *
        (∑ u ∈ T, ∏ j : FreeIndex, weight (u j)) := by rw [Finset.mul_sum]
    _ ≤ (8 * Mass.oddEulerMass Q ^ 4) *
        (Mass.oddEulerMass Q ^ 7 * supportPolynomial R) :=
      mul_le_mul_of_nonneg_left hfree hscale
    _ = _ := by ring

theorem actual_terminal_paired_mass_compressed (S : Finset (Index → ℕ))
    (Q : ℕ) (hQ : 0 < Q)
    (hs : ∀ q ∈ S, (∀ i, Odd (q i) ∧ Squarefree (q i) ∧ q i ≤ Q) ∧
      pairedWeight q ≠ 0 ∧ Terminal (Q : ℝ) (fun i => (q i : ℝ))) :
    ∑ q ∈ S, pairedWeight q ≤
      8 * Mass.oddEulerMass Q ^ 11 * supportPolynomial (4 * Real.log (Q : ℝ)) := by
  classical
  have hinj : ∀ q ∈ S, ∀ t ∈ S, extract q = extract t → q = t := by
    intro q hq t ht he
    exact extract_injective_on (fun i => ((hs q hq).1 i).2.1)
      (fun i => ((hs t ht).1 i).2.1) (hs q hq).2.1 (hs t ht).2.1 he
  have hR : 0 ≤ 4 * Real.log (Q : ℝ) := by
    have hQ1 : (1 : ℝ) ≤ Q := by exact_mod_cast hQ
    exact mul_nonneg (by norm_num) (Real.log_nonneg hQ1)
  calc
    _ ≤ ∑ q ∈ S, (∏ i : Index, weight ((extract q).1 i)) *
        (∏ j : FreeIndex, weight ((extract q).2 j)) := by
      apply Finset.sum_le_sum
      intro q hq
      exact pairedWeight_le_extracted_weight q (fun i => ((hs q hq).1 i).2.1)
        (hs q hq).2.1
    _ = ∑ p ∈ S.image extract, (∏ i : Index, weight (p.1 i)) *
        (∏ j : FreeIndex, weight (p.2 j)) := by
      symm
      apply Finset.sum_image hinj
    _ ≤ _ := by
      apply eleven_coordinate_compressed_mass _ Q realRest _ hQ hR
      intro p hp
      obtain ⟨q, hq, he⟩ := Finset.mem_image.mp hp
      exact he ▸ And.intro
        (extract_admissible q Q (hs q hq).1 (hs q hq).2.1 (hs q hq).2.2)
        (extracted_free_log_constraint q Q (hs q hq).1 (hs q hq).2.1)

/-- Unconditional compressed finite bound for the actual terminal tuple
weights. The seven-dimensional simplex estimate is proved upstream. -/
theorem actual_terminal_paired_mass_compressed_all (S : Finset (Index → ℕ))
    (Q : ℕ) (hQ : 0 < Q)
    (hs : ∀ q ∈ S, (∀ i, Odd (q i) ∧ Squarefree (q i) ∧ q i ≤ Q) ∧
      Terminal (Q : ℝ) (fun i => (q i : ℝ))) :
    ∑ q ∈ S, pairedWeight q ≤
      8 * Mass.oddEulerMass Q ^ 11 * supportPolynomial (4 * Real.log (Q : ℝ)) := by
  classical
  have hb := actual_terminal_paired_mass_compressed
    (S.filter (fun q => pairedWeight q ≠ 0)) Q hQ
    (by
      intro q hq
      obtain ⟨hqS, hqW⟩ := Finset.mem_filter.mp hq
      exact ⟨(hs q hqS).1, hqW, (hs q hqS).2⟩)
  simpa only [Finset.sum_filter_ne_zero] using hb

theorem actual_terminal_paired_mass_min (S : Finset (Index → ℕ)) (Q : ℕ) (hQ : 0 < Q)
    (hs : ∀ q ∈ S, (∀ i, Odd (q i) ∧ Squarefree (q i) ∧ q i ≤ Q) ∧
      Terminal (Q : ℝ) (fun i => (q i : ℝ))) :
    ∑ q ∈ S, pairedWeight q ≤
      8 * Mass.oddEulerMass Q ^ 11 * min (Mass.oddHarmonic Q ^ 7)
        (supportPolynomial (4 * Real.log (Q : ℝ))) := by
  have hc : 0 ≤ 8 * Mass.oddEulerMass Q ^ 11 := by
    exact mul_nonneg (by norm_num) (pow_nonneg (eulerMass_nonneg Q) _)
  rw [mul_min_of_nonneg _ _ hc]
  exact le_min (actual_terminal_paired_mass_all S Q hQ hs)
    (actual_terminal_paired_mass_compressed_all S Q hQ hs)

theorem freeDegrees_cast_eq :
    (fun i : FreeIndex => (freeDegrees i : ℝ)) = goldbachSimplexWeightFn := by
  funext i
  fin_cases i <;> norm_num [freeDegrees, goldbachSimplexWeightFn, vector_sixth, vector_seventh]

theorem supportPolynomial_eq_explicit (R : ℝ) :
    supportPolynomial R = goldbachSimplexPolynomial (R / 2) := by
  unfold supportPolynomial
  have hw : ∀ i : FreeIndex, (freeDegrees i : ℝ) = goldbachSimplexWeightFn i :=
    fun i => congrFun freeDegrees_cast_eq i
  simp_rw [hw]
  exact goldbachSimplex_support_expansion (R / 2)

theorem actual_terminal_paired_mass_polynomial (S : Finset (Index → ℕ))
    (Q : ℕ) (hQ : 0 < Q)
    (hs : ∀ q ∈ S, (∀ i, Odd (q i) ∧ Squarefree (q i) ∧ q i ≤ Q) ∧
      Terminal (Q : ℝ) (fun i => (q i : ℝ))) :
    ∑ q ∈ S, pairedWeight q ≤
      8 * Mass.oddEulerMass Q ^ 11 * goldbachSimplexPolynomial (2 * Real.log (Q : ℝ)) := by
  have hb := actual_terminal_paired_mass_compressed_all S Q hQ hs
  rw [supportPolynomial_eq_explicit,
    show (4 * Real.log (Q : ℝ)) / 2 = 2 * Real.log (Q : ℝ) by ring] at hb
  exact hb

theorem actual_terminal_paired_mass_min_polynomial (S : Finset (Index → ℕ))
    (Q : ℕ) (hQ : 0 < Q)
    (hs : ∀ q ∈ S, (∀ i, Odd (q i) ∧ Squarefree (q i) ∧ q i ≤ Q) ∧
      Terminal (Q : ℝ) (fun i => (q i : ℝ))) :
    ∑ q ∈ S, pairedWeight q ≤
      8 * Mass.oddEulerMass Q ^ 11 * min (Mass.oddHarmonic Q ^ 7)
        (goldbachSimplexPolynomial (2 * Real.log (Q : ℝ))) := by
  have hb := actual_terminal_paired_mass_min S Q hQ hs
  rw [supportPolynomial_eq_explicit,
    show (4 * Real.log (Q : ℝ)) / 2 = 2 * Real.log (Q : ℝ) by ring] at hb
  exact hb

#print axioms terminal_four_product
#print axioms anchor12_diameter
#print axioms anchor13_diameter
#print axioms anchor14_diameter
#print axioms anchor23_diameter
#print axioms fourfold_mass
#print axioms sum_product_le_product_projection
#print axioms anchor_projection_mass
#print axioms anchor_fiber_mass
#print axioms seven_coordinate_mass
#print axioms eleven_coordinate_mass
#print axioms coded_modulus
#print axioms extracted_moduli
#print axioms extract_admissible
#print axioms actual_terminal_paired_mass
#print axioms actual_terminal_paired_mass_all
#print axioms extracted_free_degree_constraint
#print axioms extracted_free_log_constraint
#print axioms seven_coordinate_compressed_mass
#print axioms eleven_coordinate_compressed_mass
#print axioms actual_terminal_paired_mass_compressed_all
#print axioms actual_terminal_paired_mass_min
#print axioms supportPolynomial_eq_explicit
#print axioms actual_terminal_paired_mass_polynomial
#print axioms actual_terminal_paired_mass_min_polynomial

end GoldbachResearch.Anchors
