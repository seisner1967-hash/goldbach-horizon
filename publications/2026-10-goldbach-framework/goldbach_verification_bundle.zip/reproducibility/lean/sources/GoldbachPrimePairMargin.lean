import GoldbachArithmetic
import Mathlib.NumberTheory.VonMangoldt
import Mathlib.Analysis.SpecialFunctions.Log.Basic

/-!
# The finite terminal bridge to two actual primes

The squarefree Mangoldt factor has exactly prime support. Its representation
sum splits into genuine weighted prime pairs and the first-variable proper
prime-power contamination. The final budget theorem keeps its transfer
identity and numerical estimates as explicit hypotheses: none is proved by
the finite algebra below. Four specified targets have kernel-checked positive
weighted margins from actual prime witnesses. No general Goldbach claim.
-/

namespace GoldbachResearch.PrimePairMargin

open scoped BigOperators
open Finset ActualArithmetic

noncomputable def squarefreeMangoldt (n : ℕ) : ℝ :=
  (muReal n) ^ 2 * ArithmeticFunction.vonMangoldt n

noncomputable def representationTerm (N n : ℕ) : ℝ :=
  ArithmeticFunction.vonMangoldt n * squarefreeMangoldt (N - n)

noncomputable def primePairTerm (N n : ℕ) : ℝ :=
  if n.Prime ∧ (N - n).Prime then
    Real.log (n : ℝ) * Real.log ((N - n : ℕ) : ℝ) else 0

noncomputable def properPowerTerm (N n : ℕ) : ℝ :=
  if n.Prime then 0 else representationTerm N n

noncomputable def squarefreeRepresentation (N : ℕ) : ℝ :=
  ∑ n ∈ range N, representationTerm N n

noncomputable def weightedPrimePairs (N : ℕ) : ℝ :=
  ∑ n ∈ range N, primePairTerm N n

noncomputable def properPowerContribution (N : ℕ) : ℝ :=
  ∑ n ∈ range N, properPowerTerm N n

theorem squarefreeMangoldt_eq_prime_log (n : ℕ) :
    squarefreeMangoldt n = if n.Prime then Real.log (n : ℝ) else 0 := by
  classical
  by_cases hp : n.Prime
  · simp [squarefreeMangoldt, muReal, ArithmeticFunction.moebius_apply_prime hp,
      ArithmeticFunction.vonMangoldt_apply_prime hp, hp]
  · by_cases hpp : IsPrimePow n
    · have hz := ArithmeticFunction.moebius_apply_isPrimePow_not_prime hpp hp
      simp [squarefreeMangoldt, muReal, hz, hp]
    · have hz := ArithmeticFunction.vonMangoldt_eq_zero_iff.mpr hpp
      simp [squarefreeMangoldt, hz, hp]

theorem representationTerm_nonneg (N n : ℕ) : 0 ≤ representationTerm N n := by
  unfold representationTerm squarefreeMangoldt
  exact mul_nonneg ArithmeticFunction.vonMangoldt_nonneg
    (mul_nonneg (sq_nonneg _) ArithmeticFunction.vonMangoldt_nonneg)

theorem primePairTerm_nonneg (N n : ℕ) : 0 ≤ primePairTerm N n := by
  classical
  unfold primePairTerm
  split_ifs with hp
  · exact mul_nonneg
      (Real.log_nonneg (by exact_mod_cast hp.1.one_lt.le))
      (Real.log_nonneg (by exact_mod_cast hp.2.one_lt.le))
  · rfl

theorem representationTerm_split (N n : ℕ) :
    representationTerm N n = primePairTerm N n + properPowerTerm N n := by
  classical
  by_cases hp : n.Prime <;> by_cases hq : (N - n).Prime
  all_goals
    simp [representationTerm, primePairTerm, properPowerTerm,
      squarefreeMangoldt_eq_prime_log, hp, hq,
      ArithmeticFunction.vonMangoldt_apply_prime]

theorem squarefreeRepresentation_split (N : ℕ) :
    squarefreeRepresentation N = weightedPrimePairs N + properPowerContribution N := by
  unfold squarefreeRepresentation weightedPrimePairs properPowerContribution
  simp_rw [representationTerm_split]
  exact Finset.sum_add_distrib

theorem properPowerContribution_nonneg (N : ℕ) : 0 ≤ properPowerContribution N := by
  unfold properPowerContribution
  apply Finset.sum_nonneg
  intro n hn
  unfold properPowerTerm
  split_ifs
  · rfl
  · exact representationTerm_nonneg N n

theorem properPowerTerm_nonzero_support (N n : ℕ)
    (hne : properPowerTerm N n ≠ 0) :
    IsPrimePow n ∧ ¬n.Prime ∧ (N - n).Prime := by
  have hn : ¬n.Prime := by
    intro hp
    exact hne (by simp [properPowerTerm, hp])
  have hpp : IsPrimePow n := by
    apply ArithmeticFunction.vonMangoldt_ne_zero_iff.mp
    intro hz
    exact hne (by simp [properPowerTerm, hn, representationTerm, hz])
  have hq : (N - n).Prime := by
    by_contra hq
    exact hne (by simp [properPowerTerm, hn, representationTerm,
      squarefreeMangoldt_eq_prime_log, hq])
  exact ⟨hpp, hn, hq⟩

theorem prime_pair_of_weighted_positive (N : ℕ) (h : 0 < weightedPrimePairs N) :
    ∃ p q : ℕ, p.Prime ∧ q.Prime ∧ p + q = N := by
  classical
  by_contra! hnone
  have hz : weightedPrimePairs N = 0 := by
    unfold weightedPrimePairs
    apply Finset.sum_eq_zero
    intro n hn
    have hno : ¬ (n.Prime ∧ (N - n).Prime) := by
      intro hp
      have hnN : n ≤ N := le_of_lt (Finset.mem_range.mp hn)
      exact hnone n (N - n) hp.1 hp.2 (Nat.add_sub_of_le hnN)
    simp [primePairTerm, hno]
  linarith

theorem prime_pair_of_squarefree_margin (N : ℕ)
    (h : properPowerContribution N < squarefreeRepresentation N) :
    ∃ p q : ℕ, p.Prime ∧ q.Prime ∧ p + q = N := by
  apply prime_pair_of_weighted_positive N
  rw [squarefreeRepresentation_split] at h
  linarith

/-- The identity and all error budgets are explicit unproved inputs. -/
theorem prime_pair_of_actual_signed_budget (N alpha Q : ℕ)
    (reference remainder lowerReference remainderBudget signedLoss powerBudget : ℝ)
    (hidentity : squarefreeRepresentation N =
      reference + actualSignedError N alpha Q + remainder)
    (href : lowerReference ≤ reference)
    (hrem : |remainder| ≤ remainderBudget)
    (hsigned : -signedLoss ≤ actualSignedError N alpha Q)
    (hpowers : properPowerContribution N ≤ powerBudget)
    (hmargin : powerBudget + signedLoss + remainderBudget < lowerReference) :
    ∃ p q : ℕ, p.Prime ∧ q.Prime ∧ p + q = N := by
  apply prime_pair_of_squarefree_margin N
  have hremLower := (abs_le.mp hrem).1
  linarith

theorem half_le_log_of_two_le (x : ℝ) (hx : 2 ≤ x) : 1 / 2 ≤ Real.log x := by
  have hx0 : 0 < x := by linarith
  have hinv : x⁻¹ ≤ (2 : ℝ)⁻¹ := by
    simpa only [one_div] using
      (one_div_le_one_div_of_le (by norm_num : 0 < (2 : ℝ)) hx)
  have hlog := Real.one_sub_inv_le_log_of_pos hx0
  norm_num at hinv
  linarith

theorem prime_log_product_ge_quarter (p q : ℕ) (hp : p.Prime) (hq : q.Prime) :
    (1 : ℝ) / 4 ≤ Real.log (p : ℝ) * Real.log (q : ℝ) := by
  have hpLog := half_le_log_of_two_le (p : ℝ) (by exact_mod_cast hp.two_le)
  have hqLog := half_le_log_of_two_le (q : ℝ) (by exact_mod_cast hq.two_le)
  nlinarith [mul_nonneg (sub_nonneg.mpr hpLog) (sub_nonneg.mpr hqLog)]

theorem weightedPrimePairs_ge_quarter_of_witness (N p q : ℕ)
    (hp : p.Prime) (hq : q.Prime) (hsum : p + q = N) :
    (1 : ℝ) / 4 ≤ weightedPrimePairs N := by
  have hpN : p < N := by have := hq.pos; omega
  have hsub : N - p = q := by omega
  have hpq : (N - p).Prime := by simpa only [hsub] using hq
  have hterm : (1 : ℝ) / 4 ≤ primePairTerm N p := by
    rw [primePairTerm, if_pos ⟨hp, hpq⟩, hsub]
    exact prime_log_product_ge_quarter p q hp hq
  exact hterm.trans (Finset.single_le_sum
    (fun n _ => primePairTerm_nonneg N n) (Finset.mem_range.mpr hpN))

theorem weighted_margin_1000 : (1 : ℝ) / 4 ≤ weightedPrimePairs 1000 := by
  apply weightedPrimePairs_ge_quarter_of_witness 1000 3 997 <;> norm_num

theorem weighted_margin_2310 : (1 : ℝ) / 4 ≤ weightedPrimePairs 2310 := by
  apply weightedPrimePairs_ge_quarter_of_witness 2310 13 2297 <;> norm_num

theorem weighted_margin_10000 : (1 : ℝ) / 4 ≤ weightedPrimePairs 10000 := by
  apply weightedPrimePairs_ge_quarter_of_witness 10000 59 9941 <;> norm_num

theorem weighted_margin_30030 : (1 : ℝ) / 4 ≤ weightedPrimePairs 30030 := by
  apply weightedPrimePairs_ge_quarter_of_witness 30030 17 30013 <;> norm_num

#print axioms squarefreeMangoldt_eq_prime_log
#print axioms representationTerm_nonneg
#print axioms primePairTerm_nonneg
#print axioms representationTerm_split
#print axioms squarefreeRepresentation_split
#print axioms properPowerContribution_nonneg
#print axioms properPowerTerm_nonzero_support
#print axioms prime_pair_of_weighted_positive
#print axioms prime_pair_of_squarefree_margin
#print axioms prime_pair_of_actual_signed_budget
#print axioms half_le_log_of_two_le
#print axioms prime_log_product_ge_quarter
#print axioms weightedPrimePairs_ge_quarter_of_witness
#print axioms weighted_margin_1000
#print axioms weighted_margin_2310
#print axioms weighted_margin_10000
#print axioms weighted_margin_30030

end GoldbachResearch.PrimePairMargin
