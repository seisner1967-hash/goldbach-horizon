import GoldbachSignedKernel

/-!
# Signed bilinear correlations for the literal Goldbach arithmetic

Two Cauchy--Schwarz steps reduce a bilinear sum to an exact signed box
correlation. No entrywise absolute value is substituted for its four
arithmetic signs. No small-box estimate is postulated as a conclusion.
-/

namespace GoldbachResearch.Bilinear

open scoped BigOperators
open Finset ActualArithmetic

variable {I J : Type*}

noncomputable def bilinearSum (s : Finset I) (t : Finset J)
    (alpha : I → ℝ) (beta : J → ℝ) (K : I → J → ℝ) : ℝ :=
  ∑ a ∈ s, alpha a * ∑ b ∈ t, beta b * K a b

noncomputable def coefficientMass (s : Finset I) (alpha : I → ℝ) : ℝ :=
  ∑ a ∈ s, alpha a ^ 2

noncomputable def columnGram (s : Finset I) (K : I → J → ℝ) (b c : J) : ℝ :=
  ∑ a ∈ s, K a b * K a c

noncomputable def signedBox (s : Finset I) (t : Finset J) (K : I → J → ℝ) : ℝ :=
  ∑ b ∈ t, ∑ c ∈ t, (columnGram s K b c) ^ 2

noncomputable def rowEnergy (s : Finset I) (t : Finset J)
    (beta : J → ℝ) (K : I → J → ℝ) : ℝ :=
  ∑ a ∈ s, (∑ b ∈ t, beta b * K a b) ^ 2

theorem coefficientMass_nonneg (s : Finset I) (alpha : I → ℝ) :
    0 ≤ coefficientMass s alpha :=
  Finset.sum_nonneg (fun _ _ => sq_nonneg _)

theorem rowEnergy_nonneg (s : Finset I) (t : Finset J)
    (beta : J → ℝ) (K : I → J → ℝ) : 0 ≤ rowEnergy s t beta K :=
  Finset.sum_nonneg (fun _ _ => sq_nonneg _)

theorem signedBox_nonneg (s : Finset I) (t : Finset J) (K : I → J → ℝ) :
    0 ≤ signedBox s t K :=
  Finset.sum_nonneg (fun _ _ => Finset.sum_nonneg (fun _ _ => sq_nonneg _))

/-- This is a signed four-corner expansion, not a sum of absolute corners. -/
theorem signedBox_eq_four_corners (s : Finset I) (t : Finset J) (K : I → J → ℝ) :
    signedBox s t K =
      ∑ b ∈ t, ∑ c ∈ t, ∑ a ∈ s, ∑ d ∈ s,
        K a b * K a c * K d b * K d c := by
  unfold signedBox columnGram
  simp_rw [pow_two, Finset.sum_mul_sum]
  apply Finset.sum_congr rfl
  intro b hb
  apply Finset.sum_congr rfl
  intro c hc
  apply Finset.sum_congr rfl
  intro a ha
  apply Finset.sum_congr rfl
  intro d hd
  ring

theorem rowEnergy_eq_signed_gram (s : Finset I) (t : Finset J)
    (beta : J → ℝ) (K : I → J → ℝ) :
    rowEnergy s t beta K =
      ∑ b ∈ t, ∑ c ∈ t, beta b * beta c * columnGram s K b c := by
  unfold rowEnergy
  simp_rw [pow_two, Finset.sum_mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro b hb
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro c hc
  unfold columnGram
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro a ha
  ring

/-- Swapping the two factors does not change the signed contraction. -/
theorem bilinearSum_eq_transpose (s : Finset I) (t : Finset J)
    (alpha : I → ℝ) (beta : J → ℝ) (K : I → J → ℝ) :
    bilinearSum s t alpha beta K =
      bilinearSum t s beta alpha (fun b a => K a b) := by
  unfold bilinearSum
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro b hb
  apply Finset.sum_congr rfl
  intro a ha
  ring

/-- A single Cauchy step in the beta variable keeps alpha's signs inside
the exact dispersion energy. This is weaker than arbitrary-coefficient
box control and remains useful for the specific Vaughan alpha = mu. -/
theorem bilinear_sq_le_beta_mass_signed_dispersion (s : Finset I) (t : Finset J)
    (alpha : I → ℝ) (beta : J → ℝ) (K : I → J → ℝ) :
    bilinearSum s t alpha beta K ^ 2 ≤ coefficientMass t beta *
      rowEnergy t s alpha (fun b a => K a b) := by
  rw [bilinearSum_eq_transpose]
  exact Finset.sum_mul_sq_le_sq_mul_sq t beta
    (fun b => ∑ a ∈ s, alpha a * K a b)

/-- Both alpha signs stay visible alongside the two arithmetic kernel signs. -/
theorem signed_dispersion_eq_alpha_correlations (s : Finset I) (t : Finset J)
    (alpha : I → ℝ) (K : I → J → ℝ) :
    rowEnergy t s alpha (fun b a => K a b) =
      ∑ a ∈ s, ∑ c ∈ s, alpha a * alpha c * ∑ b ∈ t, K a b * K c b :=
  rowEnergy_eq_signed_gram t s alpha (fun b a => K a b)

theorem rowEnergy_sq_le_mass_sq_box (s : Finset I) (t : Finset J)
    (beta : J → ℝ) (K : I → J → ℝ) :
    rowEnergy s t beta K ^ 2 ≤ coefficientMass t beta ^ 2 * signedBox s t K := by
  have hp := Finset.sum_mul_sq_le_sq_mul_sq (t.product t)
    (fun x : J × J => beta x.1 * beta x.2)
    (fun x : J × J => columnGram s K x.1 x.2)
  have he : (∑ x ∈ t.product t, (beta x.1 * beta x.2) ^ 2) =
      coefficientMass t beta ^ 2 := by
    have hprod : (∑ x ∈ t.product t, (beta x.1 * beta x.2) ^ (2 : ℕ)) =
        ∑ b ∈ t, ∑ c ∈ t, (beta b * beta c) ^ (2 : ℕ) :=
      Finset.sum_product t t (fun x : J × J => (beta x.1 * beta x.2) ^ (2 : ℕ))
    rw [hprod]
    simp_rw [mul_pow, ← Finset.mul_sum, ← Finset.sum_mul]
    simp only [coefficientMass, pow_two]
  have hgram : (∑ x ∈ t.product t,
      beta x.1 * beta x.2 * columnGram s K x.1 x.2) =
      ∑ b ∈ t, ∑ c ∈ t, beta b * beta c * columnGram s K b c :=
    Finset.sum_product t t
      (fun x : J × J => beta x.1 * beta x.2 * columnGram s K x.1 x.2)
  have hbox : (∑ x ∈ t.product t, columnGram s K x.1 x.2 ^ (2 : ℕ)) =
      signedBox s t K :=
    Finset.sum_product t t (fun x : J × J => columnGram s K x.1 x.2 ^ (2 : ℕ))
  rw [he, hgram, hbox, ← rowEnergy_eq_signed_gram] at hp
  exact hp

/-- The sign-sensitive bilinear reduction. A power saving requires a new
estimate for the exact signed box; this theorem supplies no such estimate. -/
theorem bilinear_fourth_le_signed_box (s : Finset I) (t : Finset J)
    (alpha : I → ℝ) (beta : J → ℝ) (K : I → J → ℝ) :
    bilinearSum s t alpha beta K ^ 4 ≤
      coefficientMass s alpha ^ 2 * coefficientMass t beta ^ 2 * signedBox s t K := by
  have hfirst := Finset.sum_mul_sq_le_sq_mul_sq s alpha
    (fun a => ∑ b ∈ t, beta b * K a b)
  change bilinearSum s t alpha beta K ^ 2 ≤
    coefficientMass s alpha * rowEnergy s t beta K at hfirst
  have hA := coefficientMass_nonneg s alpha
  have hE := rowEnergy_nonneg s t beta K
  have hsecond := rowEnergy_sq_le_mass_sq_box s t beta K
  have hsquare : bilinearSum s t alpha beta K ^ 4 ≤
      coefficientMass s alpha ^ 2 * rowEnergy s t beta K ^ 2 := by
    nlinarith [sq_nonneg (bilinearSum s t alpha beta K),
      mul_nonneg hA hE]
  calc
    _ ≤ coefficientMass s alpha ^ 2 * rowEnergy s t beta K ^ 2 := hsquare
    _ ≤ _ := by
      have hh := mul_le_mul_of_nonneg_left hsecond (sq_nonneg (coefficientMass s alpha))
      simpa only [mul_assoc] using hh

noncomputable def shiftedMoebiusKernel (N : ℕ) (a b : ℕ) : ℝ :=
  if a * b < N then muReal (N - a * b) else 0

noncomputable def actualTypeIIKernel (N cutoff k : ℕ) (a b : ℕ) : ℝ :=
  muReal (N - a * b) * actualRow N cutoff k (a * b)

/-- Specialization to the literal endpoint and centered progression row. -/
theorem actualTypeII_fourth_le_signed_box (s t : Finset ℕ)
    (N cutoff k : ℕ) (alpha beta : ℕ → ℝ) :
    bilinearSum s t alpha beta (actualTypeIIKernel N cutoff k) ^ 4 ≤
      coefficientMass s alpha ^ 2 * coefficientMass t beta ^ 2 *
        signedBox s t (actualTypeIIKernel N cutoff k) :=
  bilinear_fourth_le_signed_box s t alpha beta _

def affineComplement (N a b : ℤ) : ℤ := N - a * b

theorem complement_rectangle_determinant (N a c b d : ℤ) :
    affineComplement N a b * affineComplement N c d -
      affineComplement N a d * affineComplement N c b =
        -N * (a - c) * (b - d) := by
  unfold affineComplement
  ring

/-- Every common divisor on a row divides the corresponding N-weighted
column difference. No sign decorrelation is inferred from this identity. -/
theorem common_divisor_dvd_N_difference (N a b c q : ℤ)
    (hb : q ∣ affineComplement N a b) (hc : q ∣ affineComplement N a c) :
    q ∣ N * (b - c) := by
  have hd := dvd_sub (dvd_mul_of_dvd_right hc b) (dvd_mul_of_dvd_right hb c)
  convert hd using 1
  unfold affineComplement
  ring

#print axioms signedBox_eq_four_corners
#print axioms rowEnergy_eq_signed_gram
#print axioms bilinearSum_eq_transpose
#print axioms bilinear_sq_le_beta_mass_signed_dispersion
#print axioms signed_dispersion_eq_alpha_correlations
#print axioms rowEnergy_sq_le_mass_sq_box
#print axioms bilinear_fourth_le_signed_box
#print axioms actualTypeII_fourth_le_signed_box
#print axioms complement_rectangle_determinant
#print axioms common_divisor_dvd_N_difference

end GoldbachResearch.Bilinear
