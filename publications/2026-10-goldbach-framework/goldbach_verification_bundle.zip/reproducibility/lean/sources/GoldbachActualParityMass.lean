import Mathlib.Tactic
import Mathlib.NumberTheory.ArithmeticFunction

/-!
Exact finite parity masses for the actual Mobius function on squarefree
divisor fibres. Positive masses use the discrete CRT count before any
continuous model is subtracted. No analytic bound or reserve is proved.
-/

namespace GoldbachResearch.ActualParityMass

open scoped BigOperators

noncomputable section

def muReal (d : ℕ) : ℝ := (ArithmeticFunction.moebius d : ℝ)

def D (y d : ℕ) : ℕ := (d.divisors.filter (fun u => y < u ∧ y < d / u)).card

def U (y a : ℕ) : ℝ := ∑ d ∈ a.divisors, (D y d : ℝ)

def H (y a : ℕ) : ℝ := ∑ d ∈ a.divisors, muReal d * (D y d : ℝ)

def positiveMass (y a r : ℕ) : ℝ :=
  ∑ d ∈ a.divisors, ∑ e ∈ r.divisors,
    if muReal d * muReal e = 1 then (D y d : ℝ) * (D y e : ℝ) else 0

def negativeMass (y a r : ℕ) : ℝ :=
  ∑ d ∈ a.divisors, ∑ e ∈ r.divisors,
    if muReal d * muReal e = -1 then (D y d : ℝ) * (D y e : ℝ) else 0

def discreteRootCount (N a r : ℕ) (w : ℕ → ℝ) : ℝ :=
  ∑ n ∈ Finset.Icc 1 (N - 1),
    if n % a = 0 ∧ (N - n) % r = 0 then w n else 0

theorem moebius_squarefree_sign {d : ℕ} (hd : Squarefree d) :
    muReal d = 1 ∨ muReal d = -1 := by
  have hs := ArithmeticFunction.moebius_ne_zero_iff_eq_or.mp
    (ArithmeticFunction.moebius_ne_zero_iff_squarefree.mpr hd)
  rcases hs with hs | hs
  · left
    simp only [muReal, hs, Int.cast_one]
  · right
    simp only [muReal, hs, Int.cast_neg, Int.cast_one]

theorem divisor_pair_sign {a r d e : ℕ} (ha : Squarefree a) (hr : Squarefree r)
    (hd : d ∈ a.divisors) (he : e ∈ r.divisors) :
    muReal d * muReal e = 1 ∨ muReal d * muReal e = -1 := by
  have hds := moebius_squarefree_sign
    (Squarefree.squarefree_of_dvd (Nat.dvd_of_mem_divisors hd) ha)
  have hes := moebius_squarefree_sign
    (Squarefree.squarefree_of_dvd (Nat.dvd_of_mem_divisors he) hr)
  rcases hds with hds | hds <;> rcases hes with hes | hes <;>
    simp [hds, hes]

theorem signed_parts_add (s w : ℝ) (hs : s = 1 ∨ s = -1) :
    (if s = 1 then w else 0) + (if s = -1 then w else 0) = w := by
  rcases hs with hs | hs <;> subst s <;> norm_num

theorem signed_parts_sub (s w : ℝ) (hs : s = 1 ∨ s = -1) :
    (if s = 1 then w else 0) - (if s = -1 then w else 0) = s * w := by
  rcases hs with hs | hs <;> subst s <;> norm_num

theorem positive_mass_nonnegative (y a r : ℕ) : 0 ≤ positiveMass y a r := by
  unfold positiveMass
  apply Finset.sum_nonneg
  intro d hd
  apply Finset.sum_nonneg
  intro e he
  split_ifs <;> positivity

theorem negative_mass_nonnegative (y a r : ℕ) : 0 ≤ negativeMass y a r := by
  unfold negativeMass
  apply Finset.sum_nonneg
  intro d hd
  apply Finset.sum_nonneg
  intro e he
  split_ifs <;> positivity

theorem parity_mass_sum (y a r : ℕ) (ha : Squarefree a) (hr : Squarefree r) :
    positiveMass y a r + negativeMass y a r = U y a * U y r := by
  unfold positiveMass negativeMass U
  rw [Finset.sum_mul]
  simp_rw [Finset.mul_sum]
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro d hd
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro e he
  exact signed_parts_add _ _ (divisor_pair_sign ha hr hd he)

theorem parity_mass_difference (y a r : ℕ) (ha : Squarefree a) (hr : Squarefree r) :
    positiveMass y a r - negativeMass y a r = H y a * H y r := by
  unfold positiveMass negativeMass H
  rw [Finset.sum_mul]
  simp_rw [Finset.mul_sum]
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro d hd
  rw [← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro e he
  rw [signed_parts_sub _ _ (divisor_pair_sign ha hr hd he)]
  ring

theorem internal_pairing_capacity (y a r : ℕ) (ha : Squarefree a) (hr : Squarefree r) :
    min (positiveMass y a r) (negativeMass y a r) =
      (U y a * U y r - |H y a * H y r|) / 2 := by
  rw [← parity_mass_sum y a r ha hr, ← parity_mass_difference y a r ha hr]
  by_cases hpq : positiveMass y a r ≤ negativeMass y a r
  · rw [min_eq_left hpq, abs_of_nonpos (sub_nonpos.mpr hpq)]
    ring
  · have hqp := le_of_not_ge hpq
    rw [min_eq_right hqp, abs_of_nonneg (sub_nonneg.mpr hqp)]
    ring

theorem discrete_root_count_nonnegative (N a r : ℕ) (w : ℕ → ℝ)
    (hw : ∀ n ∈ Finset.Icc 1 (N - 1), 0 ≤ w n) :
    0 ≤ discreteRootCount N a r w := by
  unfold discreteRootCount
  apply Finset.sum_nonneg
  intro n hn
  split_ifs
  · exact hw n hn
  · exact le_refl _

theorem discrete_parity_masses_nonnegative (N y a r : ℕ) (w : ℕ → ℝ)
    (hw : ∀ n ∈ Finset.Icc 1 (N - 1), 0 ≤ w n) :
    0 ≤ discreteRootCount N a r w * positiveMass y a r ∧
      0 ≤ discreteRootCount N a r w * negativeMass y a r := by
  exact ⟨mul_nonneg (discrete_root_count_nonnegative N a r w hw)
      (positive_mass_nonnegative y a r),
    mul_nonneg (discrete_root_count_nonnegative N a r w hw)
      (negative_mass_nonnegative y a r)⟩

theorem discrete_parity_mass_sum (N y a r : ℕ) (w : ℕ → ℝ)
    (ha : Squarefree a) (hr : Squarefree r) :
    discreteRootCount N a r w * positiveMass y a r +
      discreteRootCount N a r w * negativeMass y a r =
      discreteRootCount N a r w * (U y a * U y r) := by
  rw [← mul_add, parity_mass_sum y a r ha hr]

theorem discrete_parity_mass_difference (N y a r : ℕ) (w : ℕ → ℝ)
    (ha : Squarefree a) (hr : Squarefree r) :
    discreteRootCount N a r w * positiveMass y a r -
      discreteRootCount N a r w * negativeMass y a r =
      discreteRootCount N a r w * (H y a * H y r) := by
  rw [← mul_sub, parity_mass_difference y a r ha hr]

theorem model_subtracted_once (N y a r : ℕ) (w : ℕ → ℝ) (M : ℝ)
    (ha : Squarefree a) (hr : Squarefree r) :
    (discreteRootCount N a r w - M) * (H y a * H y r) =
      discreteRootCount N a r w * positiveMass y a r -
      discreteRootCount N a r w * negativeMass y a r - M * (H y a * H y r) := by
  rw [discrete_parity_mass_difference N y a r w ha hr]
  ring

theorem unmatched_positive_obstruction (N y a r : ℕ) (w : ℕ → ℝ)
    (hC : 0 < discreteRootCount N a r w)
    (hP : 0 < positiveMass y a r) (hQ : negativeMass y a r = 0) :
    0 < discreteRootCount N a r w * positiveMass y a r -
      discreteRootCount N a r w * negativeMass y a r := by
  rw [hQ, mul_zero, sub_zero]
  exact mul_pos hC hP

#print axioms moebius_squarefree_sign
#print axioms divisor_pair_sign
#print axioms signed_parts_add
#print axioms signed_parts_sub
#print axioms positive_mass_nonnegative
#print axioms negative_mass_nonnegative
#print axioms parity_mass_sum
#print axioms parity_mass_difference
#print axioms internal_pairing_capacity
#print axioms discrete_root_count_nonnegative
#print axioms discrete_parity_masses_nonnegative
#print axioms discrete_parity_mass_sum
#print axioms discrete_parity_mass_difference
#print axioms model_subtracted_once
#print axioms unmatched_positive_obstruction

end
end GoldbachResearch.ActualParityMass
