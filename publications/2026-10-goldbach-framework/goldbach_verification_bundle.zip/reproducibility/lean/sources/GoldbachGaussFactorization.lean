import Mathlib.Tactic
import Mathlib.Analysis.Complex.Basic

/-!
Exact finite multiplicative-character factorization of the unit hyperbola.
E and F are arbitrary functions, so the second additive frequency can be
nonunit or zero after instantiation. Characters take values in complex
units and inverses are used explicitly; no unit-norm assumption is made.
No analytic bound, distribution premise or Goldbach assertion occurs.
-/

namespace GoldbachResearch.GaussFactorization

open scoped BigOperators
open Finset

noncomputable section

variable {G : Type*} [CommGroup G] [Fintype G]

def hyperbolaKernel (E F : G → ℂ) (eta b : G) : ℂ :=
  ∑ x, E (eta * b * x) * F x⁻¹

def gaussMoment (chi : G →* ℂˣ) (E : G → ℂ) : ℂ :=
  ∑ t, (chi t : ℂ) * E t

theorem shifted_character_sum (chi : G →* ℂˣ) (E : G → ℂ) (b x : G) :
    (∑ eta, (chi eta : ℂ) * E (eta * b * x)) =
      (chi b⁻¹ : ℂ) * (chi x⁻¹ : ℂ) * gaussMoment chi E := by
  classical
  calc
    _ = ∑ t, (chi (t * (b * x)⁻¹) : ℂ) * E t := by
      apply Fintype.sum_bijective (fun eta : G => eta * (b * x))
        (Group.mulRight_bijective (b * x))
        (fun eta => (chi eta : ℂ) * E (eta * b * x))
        (fun t => (chi (t * (b * x)⁻¹) : ℂ) * E t)
      intro eta
      simp [mul_assoc]
    _ = _ := by
      simp_rw [mul_inv_rev, map_mul, Units.val_mul]
      unfold gaussMoment
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro t ht
      ring

theorem character_hyperbola_factorization
    (chi : G →* ℂˣ) (E F : G → ℂ) (b : G) :
    (∑ eta, (chi eta : ℂ) * hyperbolaKernel E F eta b) =
      (chi b⁻¹ : ℂ) * gaussMoment chi E * gaussMoment chi F := by
  classical
  calc
    _ = ∑ x, (∑ eta, (chi eta : ℂ) * E (eta * b * x)) * F x⁻¹ := by
      unfold hyperbolaKernel
      simp_rw [Finset.mul_sum]
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro x hx
      rw [Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro eta heta
      ring
    _ = ∑ x, ((chi b⁻¹ : ℂ) * (chi x⁻¹ : ℂ) * gaussMoment chi E) * F x⁻¹ := by
      simp_rw [shifted_character_sum]
    _ = (chi b⁻¹ : ℂ) * gaussMoment chi E *
        (∑ x, (chi x⁻¹ : ℂ) * F x⁻¹) := by
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro x hx
      ring
    _ = _ := by
      unfold gaussMoment
      have hi := Fintype.sum_bijective (fun x : G => x⁻¹) (Equiv.inv G).bijective
        (fun x => (chi x⁻¹ : ℂ) * F x⁻¹)
        (fun y => (chi y : ℂ) * F y) (fun _ => rfl)
      rw [hi]

theorem weighted_character_hyperbola_factorization
    (chi : G →* ℂˣ) (E F beta : G → ℂ) :
    (∑ eta, (chi eta : ℂ) * ∑ b, beta b * hyperbolaKernel E F eta b) =
      (∑ b, beta b * (chi b⁻¹ : ℂ)) * gaussMoment chi E * gaussMoment chi F := by
  classical
  calc
    _ = ∑ b, beta b * (∑ eta, (chi eta : ℂ) * hyperbolaKernel E F eta b) := by
      simp_rw [Finset.mul_sum]
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro b hb
      apply Finset.sum_congr rfl
      intro eta heta
      ring
    _ = _ := by
      simp_rw [character_hyperbola_factorization]
      rw [Finset.sum_mul, Finset.sum_mul]
      apply Finset.sum_congr rfl
      intro b hb
      ring

#print axioms shifted_character_sum
#print axioms character_hyperbola_factorization
#print axioms weighted_character_hyperbola_factorization

end
end GoldbachResearch.GaussFactorization
