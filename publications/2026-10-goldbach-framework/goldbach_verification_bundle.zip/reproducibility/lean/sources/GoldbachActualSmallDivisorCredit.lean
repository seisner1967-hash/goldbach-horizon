import Mathlib.NumberTheory.VonMangoldt
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Tactic

/-!
The literal small-divisor credit with actual Mobius coefficients.
The factor L has no prime at or below alpha. The entire proper-divisor
fibre of P is below alpha, while P itself is above alpha. The theorem
proves the actual divisor selection before evaluating its signed sum.
No lower density, shifted prime estimate or global deficit is asserted.
-/

namespace GoldbachResearch.ActualSmallDivisorCredit

open scoped BigOperators

noncomputable def smallDivisorCredit (alpha m : ℕ) : ℝ :=
  -(∑ d ∈ m.divisors.filter (fun d => d ≤ alpha),
    (ArithmeticFunction.moebius d : ℝ) * Real.log (d : ℝ))

theorem literal_small_divisors_product {alpha P L : ℕ}
    (hP : alpha < P) (hL : 0 < L)
    (hproper : ∀ d ∈ P.divisors, d ≠ P → d ≤ alpha)
    (hrough : ∀ p : ℕ, p.Prime → p ∣ L → alpha < p) :
    (P * L).divisors.filter (fun d => d ≤ alpha) = P.divisors.erase P := by
  have hP0 : 0 < P := by omega
  ext d
  simp only [Finset.mem_filter, Finset.mem_erase]
  constructor
  · rintro ⟨hd, hda⟩
    have hd0 : 0 < d := Nat.pos_of_mem_divisors hd
    have hcop : Nat.Coprime d L := by
      apply Nat.coprime_of_dvd
      intro p hp hpd hpL
      have hple : p ≤ d := Nat.le_of_dvd hd0 hpd
      exact (not_lt_of_ge (hple.trans hda)) (hrough p hp hpL)
    have hdP : d ∣ P := hcop.dvd_of_dvd_mul_right (Nat.mem_divisors.mp hd).1
    exact ⟨by omega, Nat.mem_divisors.mpr ⟨hdP, hP0.ne'⟩⟩
  · rintro ⟨hdne, hdP⟩
    refine ⟨Nat.mem_divisors.mpr ⟨?_, (Nat.mul_pos hP0 hL).ne'⟩,
      hproper d hdP hdne⟩
    exact dvd_mul_of_dvd_left (Nat.mem_divisors.mp hdP).1 L

theorem actual_small_divisor_credit {alpha P L : ℕ}
    (hP : alpha < P) (hL : 0 < L)
    (hproper : ∀ d ∈ P.divisors, d ≠ P → d ≤ alpha)
    (hrough : ∀ p : ℕ, p.Prime → p ∣ L → alpha < p) :
    smallDivisorCredit alpha (P * L) = ArithmeticFunction.vonMangoldt P +
      (ArithmeticFunction.moebius P : ℝ) * Real.log (P : ℝ) := by
  have hP0 : P ≠ 0 := by omega
  have hmem : P ∈ P.divisors := Nat.mem_divisors.mpr ⟨dvd_rfl, hP0⟩
  have hsum := Finset.sum_erase_add P.divisors
    (fun d => (ArithmeticFunction.moebius d : ℝ) * Real.log (d : ℝ)) hmem
  have hfull :
      (∑ d ∈ P.divisors, (ArithmeticFunction.moebius d : ℝ) *
        Real.log (d : ℝ)) = -ArithmeticFunction.vonMangoldt P := by
    simpa only [ArithmeticFunction.log_apply] using
      (ArithmeticFunction.sum_moebius_mul_log_eq (n := P))
  unfold smallDivisorCredit
  rw [literal_small_divisors_product hP hL hproper hrough]
  rw [hfull] at hsum
  dsimp only at hsum
  linarith

theorem actual_negative_composite_credit {alpha P L : ℕ}
    (hP : alpha < P) (hL : 0 < L)
    (hproper : ∀ d ∈ P.divisors, d ≠ P → d ≤ alpha)
    (hrough : ∀ p : ℕ, p.Prime → p ∣ L → alpha < p)
    (hpow : ¬IsPrimePow P) (hmu : ArithmeticFunction.moebius P = -1) :
    smallDivisorCredit alpha (P * L) = -Real.log (P : ℝ) := by
  rw [actual_small_divisor_credit hP hL hproper hrough,
    ArithmeticFunction.vonMangoldt_eq_zero_iff.mpr hpow, hmu]
  simp

#print axioms literal_small_divisors_product
#print axioms actual_small_divisor_credit
#print axioms actual_negative_composite_credit

end GoldbachResearch.ActualSmallDivisorCredit
