import GoldbachCharacterSplit
import Mathlib.Algebra.BigOperators.Module

/-!
Finite Abel reduction for the genuine completed character row.  This file does
not assert a large sieve or an arithmetic bound for the resulting prefixes.
-/

namespace GoldbachResearch.CharacterPrefix

open scoped BigOperators
open Finset

noncomputable section

def coefficient (N : ℕ) (f : ArithmeticFunction ℝ) (n : ℕ) : ℝ :=
  if n.Coprime N then f n * ActualArithmetic.muReal (N - n) else 0

def twisted {k : ℕ} (N : ℕ) (f : ArithmeticFunction ℝ)
    (χ : DirichletCharacter ℂ k) (n : ℕ) : ℂ :=
  (coefficient N f n : ℂ) * χ (n : ZMod k)

def individualRow {k : ℕ} (N cutoff : ℕ) (f : ArithmeticFunction ℝ)
    (χ : DirichletCharacter ℂ k) : ℂ :=
  ∑ n ∈ range N, (CharacterSplit.rowAmplitude N cutoff k n) • twisted N f χ n

def partialSum (a : ℕ → ℂ) (j : ℕ) : ℂ := ∑ n ∈ range j, a n

theorem coefficient_zero (N : ℕ) (f : ArithmeticFunction ℝ) :
    coefficient N f 0 = 0 := by
  simp [coefficient]

theorem twisted_zero {k : ℕ} (N : ℕ) (f : ArithmeticFunction ℝ)
    (χ : DirichletCharacter ℂ k) : twisted N f χ 0 = 0 := by
  simp [twisted, coefficient_zero]

theorem twisted_prefix_one {k : ℕ} (N : ℕ) (f : ArithmeticFunction ℝ)
    (χ : DirichletCharacter ℂ k) : partialSum (twisted N f χ) 1 = 0 := by
  simp [partialSum, twisted_zero]

theorem characterRow_eq_individual_sum {k : ℕ} [NeZero k]
    (N cutoff : ℕ) (f : ArithmeticFunction ℝ) :
    CharacterSplit.characterRow (k := k) N cutoff f =
      (∑ χ ∈ CharacterSplit.nonprincipal k,
        χ (N : ZMod k)⁻¹ * individualRow N cutoff f χ) / (k.totient : ℂ) := by
  classical
  calc
    _ = (∑ n ∈ range N, ∑ χ ∈ CharacterSplit.nonprincipal k,
          χ (N : ZMod k)⁻¹ *
            (CharacterSplit.rowAmplitude N cutoff k n • twisted N f χ n)) /
          (k.totient : ℂ) := by
      unfold CharacterSplit.characterRow CharacterSplit.spectrum twisted coefficient
      rw [Finset.sum_div]
      apply Finset.sum_congr rfl
      intro n hn
      by_cases hc : n.Coprime N
      · simp only [if_pos hc, Algebra.smul_def]
        rw [← mul_div_assoc]
        congr 1
        rw [Finset.mul_sum]
        apply Finset.sum_congr rfl
        intro χ hχ
        push_cast
        change (f n : ℂ) * (ActualArithmetic.muReal (N - n) : ℂ) *
          (CharacterSplit.rowAmplitude N cutoff k n : ℂ) * (χ (N : ZMod k)⁻¹ * χ (n : ZMod k)) =
          χ (N : ZMod k)⁻¹ * ((CharacterSplit.rowAmplitude N cutoff k n : ℂ) *
            ((f n : ℂ) * (ActualArithmetic.muReal (N - n) : ℂ) * χ (n : ZMod k)))
        ring
      · simp [hc]
    _ = _ := by
      rw [Finset.sum_comm]
      congr 1
      apply Finset.sum_congr rfl
      intro χ hχ
      unfold individualRow
      rw [Finset.mul_sum]

theorem individualRow_eq_interval {k : ℕ}
    (N cutoff : ℕ) (f : ArithmeticFunction ℝ) (χ : DirichletCharacter ℂ k) :
    individualRow N cutoff f χ =
      ∑ n ∈ Ico 1 (N - cutoff * k),
        Real.log ((k : ℝ) / (N - n : ℕ)) • twisted N f χ n := by
  classical
  unfold individualRow
  calc
    _ = ∑ n ∈ Ico 1 (N - cutoff * k),
        CharacterSplit.rowAmplitude N cutoff k n • twisted N f χ n := by
      symm
      apply Finset.sum_subset (fun n hn => by
        simp only [Finset.mem_Ico, Finset.mem_range] at hn ⊢
        omega)
      intro n hn hnot
      simp only [Finset.mem_range, Finset.mem_Ico] at hn hnot
      have hs : ¬(1 ≤ n ∧ n < N ∧ n < N - cutoff * k) := by omega
      simp [CharacterSplit.rowAmplitude, hs]
    _ = _ := by
      apply Finset.sum_congr rfl
      intro n hn
      simp only [Finset.mem_Ico] at hn
      have hs : 1 ≤ n ∧ n < N ∧ n < N - cutoff * k := by omega
      simp [CharacterSplit.rowAmplitude, hs]

theorem finite_abel_identity (a : ℕ → ℂ) (w : ℕ → ℝ) {m M : ℕ}
    (hmM : m < M) :
    (∑ n ∈ Ico m M, w n • a n) =
      w (M - 1) • partialSum a M - w m • partialSum a m -
        ∑ n ∈ Ico m (M - 1), (w (n + 1) - w n) • partialSum a (n + 1) := by
  exact Finset.sum_Ico_by_parts w a hmM

def variationBudget (w : ℕ → ℝ) (m M : ℕ) : ℝ :=
  |w (M - 1)| + |w m| +
    ∑ n ∈ Ico m (M - 1), |w (n + 1) - w n|

theorem finite_abel_prefix_bound (a : ℕ → ℂ) (w : ℕ → ℝ) {m M : ℕ}
    (hmM : m < M) {P : ℝ}
    (hp : ∀ j, j ≤ M → ‖partialSum a j‖ ≤ P) :
    ‖∑ n ∈ Ico m M, w n • a n‖ ≤ variationBudget w m M * P := by
  rw [finite_abel_identity a w hmM]
  calc
    _ ≤ ‖w (M - 1) • partialSum a M‖ + ‖w m • partialSum a m‖ +
        ‖∑ n ∈ Ico m (M - 1), (w (n + 1) - w n) • partialSum a (n + 1)‖ := by
      exact (norm_sub_le _ _).trans (add_le_add_right (norm_sub_le _ _) _)
    _ ≤ |w (M - 1)| * P + |w m| * P +
        ∑ n ∈ Ico m (M - 1), |w (n + 1) - w n| * P := by
      apply add_le_add
      · apply add_le_add
        · simpa [norm_smul, Real.norm_eq_abs] using
            mul_le_mul_of_nonneg_left (hp M le_rfl) (abs_nonneg (w (M - 1)))
        · simpa [norm_smul, Real.norm_eq_abs] using
            mul_le_mul_of_nonneg_left (hp m hmM.le) (abs_nonneg (w m))
      · refine (norm_sum_le _ _).trans (Finset.sum_le_sum ?_)
        intro n hn
        have hnj : n + 1 ≤ M := by
          simp only [Finset.mem_Ico] at hn
          omega
        change ‖(w (n + 1) - w n : ℝ) • partialSum a (n + 1)‖ ≤ _
        rw [norm_smul, Real.norm_eq_abs]
        exact mul_le_mul_of_nonneg_left (hp (n + 1) hnj)
          (abs_nonneg (w (n + 1) - w n))
    _ = variationBudget w m M * P := by
      rw [← Finset.sum_mul]
      unfold variationBudget
      ring

theorem finite_abel_prefix_bound_zero_lower (a : ℕ → ℂ) (w : ℕ → ℝ) {m M : ℕ}
    (hmM : m < M) (hzero : partialSum a m = 0) {P : ℝ}
    (hp : ∀ j, j ≤ M → ‖partialSum a j‖ ≤ P) :
    ‖∑ n ∈ Ico m M, w n • a n‖ ≤
      (variationBudget w m M - |w m|) * P := by
  rw [finite_abel_identity a w hmM, hzero, smul_zero, sub_zero]
  calc
    _ ≤ ‖w (M - 1) • partialSum a M‖ +
        ‖∑ n ∈ Ico m (M - 1), (w (n + 1) - w n) • partialSum a (n + 1)‖ :=
      norm_sub_le _ _
    _ ≤ |w (M - 1)| * P +
        ∑ n ∈ Ico m (M - 1), |w (n + 1) - w n| * P := by
      apply add_le_add
      · simpa [norm_smul, Real.norm_eq_abs] using
          mul_le_mul_of_nonneg_left (hp M le_rfl) (abs_nonneg (w (M - 1)))
      · refine (norm_sum_le _ _).trans (Finset.sum_le_sum ?_)
        intro n hn
        have hnj : n + 1 ≤ M := by
          simp only [Finset.mem_Ico] at hn
          omega
        change ‖(w (n + 1) - w n : ℝ) • partialSum a (n + 1)‖ ≤ _
        rw [norm_smul, Real.norm_eq_abs]
        exact mul_le_mul_of_nonneg_left (hp (n + 1) hnj)
          (abs_nonneg (w (n + 1) - w n))
    _ = _ := by
      rw [← Finset.sum_mul]
      unfold variationBudget
      ring

theorem variationBudget_of_negative_monotone (w : ℕ → ℝ) {m M : ℕ}
    (hmM : m < M) (hfirst : w m ≤ 0) (hlast : w (M - 1) ≤ 0)
    (hstep : ∀ n ∈ Ico m (M - 1), w n ≤ w (n + 1)) :
    variationBudget w m M = -2 * w m := by
  unfold variationBudget
  rw [abs_of_nonpos hlast, abs_of_nonpos hfirst]
  have hs : (∑ n ∈ Ico m (M - 1), |w (n + 1) - w n|) =
      w (M - 1) - w m := by
    calc
      _ = ∑ n ∈ Ico m (M - 1), (w (n + 1) - w n) := by
        apply Finset.sum_congr rfl
        intro n hn
        exact abs_of_nonneg (sub_nonneg.mpr (hstep n hn))
      _ = _ := by
        rw [Finset.sum_Ico_eq_sub _ (Nat.le_sub_one_of_lt hmM),
          Finset.sum_range_sub, Finset.sum_range_sub]
        ring
  rw [hs]
  ring

def logWeight (N k n : ℕ) : ℝ := Real.log k - Real.log (N - n : ℕ)

theorem logWeight_eq_log_div {N k n : ℕ} (hk : 0 < k) (hn : n < N) :
    logWeight N k n = Real.log ((k : ℝ) / (N - n : ℕ)) := by
  unfold logWeight
  rw [Real.log_div (by exact_mod_cast hk.ne') (by
    exact_mod_cast (Nat.sub_pos_of_lt hn).ne')]

theorem logWeight_nonpos {N cutoff k n : ℕ}
    (hk : 0 < k) (hc : 1 ≤ cutoff) (hn : n < N - cutoff * k) :
    logWeight N k n ≤ 0 := by
  have hprod : k ≤ cutoff * k := by simpa using Nat.mul_le_mul_right k hc
  have hden : k ≤ N - n := by omega
  have hlog := Real.log_le_log (by exact_mod_cast hk : (0 : ℝ) < k)
    (by exact_mod_cast hden : (k : ℝ) ≤ (N - n : ℕ))
  unfold logWeight
  linarith

theorem logWeight_step {N k n : ℕ} (hn : n + 1 < N) :
    logWeight N k n ≤ logWeight N k (n + 1) := by
  have hdpos : 0 < N - (n + 1) := Nat.sub_pos_of_lt hn
  have hdle : N - (n + 1) ≤ N - n := by omega
  have hlog := Real.log_le_log
    (by exact_mod_cast hdpos : (0 : ℝ) < (N - (n + 1) : ℕ))
    (by exact_mod_cast hdle : ((N - (n + 1) : ℕ) : ℝ) ≤ (N - n : ℕ))
  unfold logWeight
  linarith

theorem logWeight_variation_le {N cutoff k : ℕ}
    (hk : 0 < k) (hc : 1 ≤ cutoff) (hwin : 1 < N - cutoff * k) :
    variationBudget (logWeight N k) 1 (N - cutoff * k) ≤ 2 * Real.log N := by
  have hfirst := logWeight_nonpos hk hc hwin
  have hlast : logWeight N k (N - cutoff * k - 1) ≤ 0 :=
    logWeight_nonpos hk hc (by omega)
  have hstep : ∀ n ∈ Ico 1 (N - cutoff * k - 1),
      logWeight N k n ≤ logWeight N k (n + 1) := by
    intro n hn
    simp only [Finset.mem_Ico] at hn
    apply logWeight_step
    omega
  rw [variationBudget_of_negative_monotone (logWeight N k) hwin hfirst hlast hstep]
  have hN : 1 < N := by omega
  have hklog : 0 ≤ Real.log k := Real.log_nonneg (by exact_mod_cast hk)
  have hNlog : Real.log (N - 1 : ℕ) ≤ Real.log N :=
    Real.log_le_log (by exact_mod_cast (by omega : 0 < N - 1))
      (by exact_mod_cast (Nat.sub_le N 1))
  unfold logWeight
  linarith

theorem individualRow_prefix_bound {k : ℕ} {N cutoff : ℕ}
    (f : ArithmeticFunction ℝ) (χ : DirichletCharacter ℂ k)
    (hk : 0 < k) (hc : 1 ≤ cutoff) (hwin : 1 < N - cutoff * k) {P : ℝ}
    (hp : ∀ j, j ≤ N - cutoff * k → ‖partialSum (twisted N f χ) j‖ ≤ P) :
    ‖individualRow N cutoff f χ‖ ≤ 2 * Real.log N * P := by
  have hP : 0 ≤ P := (norm_nonneg _).trans (hp 0 (Nat.zero_le _))
  rw [individualRow_eq_interval]
  have heq : (∑ n ∈ Ico 1 (N - cutoff * k),
      Real.log ((k : ℝ) / (N - n : ℕ)) • twisted N f χ n) =
      ∑ n ∈ Ico 1 (N - cutoff * k), logWeight N k n • twisted N f χ n := by
    apply Finset.sum_congr rfl
    intro n hn
    simp only [Finset.mem_Ico] at hn
    rw [logWeight_eq_log_div hk (by omega)]
  rw [heq]
  exact (finite_abel_prefix_bound (twisted N f χ) (logWeight N k) hwin hp).trans
    (mul_le_mul_of_nonneg_right (logWeight_variation_le hk hc hwin) hP)

theorem individualRow_prefix_bound_sharp {k : ℕ} {N cutoff : ℕ}
    (f : ArithmeticFunction ℝ) (χ : DirichletCharacter ℂ k)
    (hk : 0 < k) (hc : 1 ≤ cutoff) (hwin : 1 < N - cutoff * k) {P : ℝ}
    (hp : ∀ j, j ≤ N - cutoff * k → ‖partialSum (twisted N f χ) j‖ ≤ P) :
    ‖individualRow N cutoff f χ‖ ≤ Real.log N * P := by
  have hP : 0 ≤ P := (norm_nonneg _).trans (hp 0 (Nat.zero_le _))
  have hfirst := logWeight_nonpos hk hc hwin
  have hlast : logWeight N k (N - cutoff * k - 1) ≤ 0 :=
    logWeight_nonpos hk hc (by omega)
  have hstep : ∀ n ∈ Ico 1 (N - cutoff * k - 1),
      logWeight N k n ≤ logWeight N k (n + 1) := by
    intro n hn
    simp only [Finset.mem_Ico] at hn
    apply logWeight_step
    omega
  have hbudget : variationBudget (logWeight N k) 1 (N - cutoff * k) -
      |logWeight N k 1| ≤ Real.log N := by
    rw [variationBudget_of_negative_monotone (logWeight N k) hwin hfirst hlast hstep,
      abs_of_nonpos hfirst]
    have hklog : 0 ≤ Real.log k := Real.log_nonneg (by exact_mod_cast hk)
    have hNlog : Real.log (N - 1 : ℕ) ≤ Real.log N :=
      Real.log_le_log (by exact_mod_cast (by omega : 0 < N - 1))
        (by exact_mod_cast (Nat.sub_le N 1))
    unfold logWeight
    linarith
  rw [individualRow_eq_interval]
  have heq : (∑ n ∈ Ico 1 (N - cutoff * k),
      Real.log ((k : ℝ) / (N - n : ℕ)) • twisted N f χ n) =
      ∑ n ∈ Ico 1 (N - cutoff * k), logWeight N k n • twisted N f χ n := by
    apply Finset.sum_congr rfl
    intro n hn
    simp only [Finset.mem_Ico] at hn
    rw [logWeight_eq_log_div hk (by omega)]
  rw [heq]
  exact (finite_abel_prefix_bound_zero_lower (twisted N f χ) (logWeight N k)
    hwin (twisted_prefix_one N f χ) hp).trans
      (mul_le_mul_of_nonneg_right hbudget hP)

#print axioms coefficient_zero
#print axioms twisted_zero
#print axioms twisted_prefix_one
#print axioms characterRow_eq_individual_sum
#print axioms individualRow_eq_interval
#print axioms finite_abel_identity
#print axioms finite_abel_prefix_bound
#print axioms finite_abel_prefix_bound_zero_lower
#print axioms variationBudget_of_negative_monotone
#print axioms logWeight_eq_log_div
#print axioms logWeight_nonpos
#print axioms logWeight_step
#print axioms logWeight_variation_le
#print axioms individualRow_prefix_bound
#print axioms individualRow_prefix_bound_sharp

end
end GoldbachResearch.CharacterPrefix

