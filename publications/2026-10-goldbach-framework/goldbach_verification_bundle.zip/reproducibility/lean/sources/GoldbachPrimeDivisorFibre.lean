import GoldbachActualMobiusLogFibre

/-!
Exact prime-divisor boundary branches for the same actual signed
coefficient. The complete fibre is already proved in the imported
module. These two statements retain the original rt <= alpha test.
No classification of admissible modules or analytical estimate occurs.
-/

namespace GoldbachResearch.PrimeDivisorFibre

open GoldbachResearch.ActualMobiusLogFibre

theorem signed_coefficient_prime_partial {r p alpha : ℕ}
    (hr : 0 < r) (hp : p.Prime) (hrle : r ≤ alpha) (hface : alpha < r * p) :
    signedDivisorCoefficient r p alpha =
      -(ArithmeticFunction.moebius r : ℝ) * Real.log (r : ℝ) := by
  unfold signedDivisorCoefficient
  rw [hp.sum_divisors]
  simp [ArithmeticFunction.moebius_apply_prime hp, hrle, Nat.not_le.mpr hface]

theorem signed_coefficient_prime_empty {r p alpha : ℕ}
    (hr : 0 < r) (hp : p.Prime) (hface : alpha < r) :
    signedDivisorCoefficient r p alpha = 0 := by
  have hprod : alpha < r * p := by nlinarith [hp.two_le]
  unfold signedDivisorCoefficient
  rw [hp.sum_divisors]
  simp [Nat.not_le.mpr hface, Nat.not_le.mpr hprod]

#print axioms signed_coefficient_prime_partial
#print axioms signed_coefficient_prime_empty

end GoldbachResearch.PrimeDivisorFibre
