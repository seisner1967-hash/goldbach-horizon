import GoldbachIntervals
import GoldbachFourier

/-!
# Goldbach at100 from the certified19mode Fourier score

This connects the rational/real interval trace with Mathlib's actual DFT.
It deliberately obtains the pair from the spectral certificate, rather than
supplying a known prime pair as the proof.
-/

namespace GoldbachHundred

open Finset GoldbachIntervals GoldbachResearch

def primeList : List (ZMod 201) := hundredPrimes.map (fun (p : ℤ) => (p : ZMod 201))
def primeSupport : Finset (ZMod 201) := primeList.toFinset
def modeList : List (ZMod 201) := hundredModes.map (fun (k : ℤ) => (k : ZMod 201))
def selectedModes : Finset (ZMod 201) := modeList.toFinset

noncomputable def f : ZMod 201 → ℝ := supportIndicator (fun x => x ∈ primeSupport)

theorem primeList_nodup : primeList.Nodup := by decide +kernel
theorem modeList_nodup : modeList.Nodup := by decide +kernel
theorem primeSupport_card : primeSupport.card = 25 := by decide +kernel

theorem residue_matches (k p : ℤ) :
    ((k : ZMod 201) * ((p : ZMod 201) - 50)).val = (hundredResidue k p).val := by
  have h := congrArg Int.toNat (ZMod.val_intCast (n := 201) (k*(p-50)))
  simpa only [hundredResidue, Int.toNat_natCast, Int.cast_mul, Int.cast_sub,
    Int.cast_ofNat] using h

theorem centered_matches (k : ℤ) :
    (centeredDFT f (50 : ZMod 201) (k : ZMod 201)).re = hundredCosineSum k := by
  rw [centered_cosine]
  simp only [f, supportIndicator, ite_mul, one_mul, zero_mul]
  rw [Fintype.sum_ite_mem]
  rw [primeSupport, List.sum_toFinset _ primeList_nodup]
  simp only [primeList, List.map_map, hundredCosineSum]
  apply congrArg List.sum
  apply List.map_congr_left
  intro p hp
  change Real.cos (2*Real.pi*((k : ZMod 201)*((p : ZMod 201)-50)).val/201) =
    Real.cos (2*Real.pi*((hundredResidue k p).val : ℝ)/201)
  rw [residue_matches]

theorem energy : (∑ x, (f x)^2) = 25 := by
  have hf (x : ZMod 201) : (f x)^2 = if x ∈ primeSupport then 1 else 0 := by
    by_cases hx : x ∈ primeSupport <;> simp [f, supportIndicator, hx]
  simp_rw [hf]
  rw [Fintype.sum_ite_mem]
  simpa using
    congrArg (fun n : ℕ => (n : ℝ)) primeSupport_card

theorem selected_energy :
    (∑ k ∈ selectedModes, ((centeredDFT f (50 : ZMod 201) k).re)^2) =
      ((hundredModes.map hundredCosineSum).map (fun x => x^2)).sum := by
  rw [selectedModes, List.sum_toFinset _ modeList_nodup]
  simp only [modeList, List.map_map]
  apply congrArg List.sum
  apply List.map_congr_left
  intro k hk
  change (centeredDFT f 50 (k : ZMod 201)).re^2 = (hundredCosineSum k)^2
  exact congrArg (fun x : ℝ => x^2) (centered_matches k)

theorem spectral_margin :
    (201 : ℝ) * ∑ x, (f x)^2 <
      2 * (∑ k ∈ selectedModes, ((centeredDFT f (50 : ZMod 201) k).re)^2) := by
  rw [energy, selected_energy]
  have hc := semantic_hundred_margin
  nlinarith

theorem cyclic_pair : ∃ x : ZMod 201, x ∈ primeSupport ∧ (100-x) ∈ primeSupport := by
  have hc := cyclic_indicator_pair (fun x : ZMod 201 => x ∈ primeSupport)
    (50 : ZMod 201) selectedModes spectral_margin
  simpa using hc

theorem support_primality (x : ZMod 201) (hx : x ∈ primeSupport) :
    Nat.Prime x.val ∧ x.val ≤ 100-2 := by
  have hall : ∀ p ∈ hundredPrimes,
      Nat.Prime ((p : ZMod 201).val) ∧ ((p : ZMod 201).val) ≤ 100-2 := by
    simp only [hundredPrimes, List.forall_mem_cons, List.forall_mem_nil]
    decide +kernel
  have hx' : x ∈ (hundredPrimes.map (fun (p : ℤ) => (p : ZMod 201))).toFinset := hx
  have hm := List.mem_toFinset.mp hx'
  obtain ⟨p, hp, hpx⟩ := List.mem_map.mp hm
  simpa only [hpx] using hall p hp

/-- The complete finite Goldbach conclusion is derived through the actual
DFT/Parseval certificate and a proved modular wraparound bound. -/
theorem goldbach_hundred_via_spectral_certificate :
    ∃ p q : ℕ, Nat.Prime p ∧ Nat.Prime q ∧ 100 = p+q := by
  apply natural_prime_pair_of_cyclic_small 100
    (fun x : ZMod 201 => x ∈ primeSupport) (50 : ZMod 201)
  · exact support_primality
  · norm_num
  · norm_num
  · norm_num
  · exact cyclic_pair

#print axioms spectral_margin
#print axioms goldbach_hundred_via_spectral_certificate

end GoldbachHundred
