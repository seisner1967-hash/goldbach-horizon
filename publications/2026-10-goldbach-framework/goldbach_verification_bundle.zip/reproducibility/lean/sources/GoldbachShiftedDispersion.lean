import GoldbachBetaWeighted
import Mathlib.Algebra.BigOperators.Intervals

/-!
Finite signed shifted dispersion. A module sum may remain INSIDE the kernel;
the a=c diagonal still contains its inter-module cross terms.
-/

namespace GoldbachResearch.ShiftedDispersion

open scoped BigOperators
open Finset ActualArithmetic

noncomputable section

def column (I : Finset ℕ) (alpha : ℕ → ℝ) (K : ℕ → ℕ → ℝ) (b : ℕ) : ℝ :=
  ∑ a ∈ I, alpha a * K a b

def dispersion (I J : Finset ℕ) (alpha beta : ℕ → ℝ) (K : ℕ → ℕ → ℝ) : ℝ :=
  ∑ b ∈ J, beta b * column I alpha K b ^ 2

def correlation (J : Finset ℕ) (alpha beta : ℕ → ℝ)
    (K : ℕ → ℕ → ℝ) (a c : ℕ) : ℝ :=
  alpha a * alpha c * ∑ b ∈ J, beta b * K a b * K c b

def diagonal (I J : Finset ℕ) (alpha beta : ℕ → ℝ) (K : ℕ → ℕ → ℝ) : ℝ :=
  ∑ a ∈ I, alpha a ^ 2 * ∑ b ∈ J, beta b * K a b ^ 2

def upperCorrelation (I J : Finset ℕ) (alpha beta : ℕ → ℝ)
    (K : ℕ → ℕ → ℝ) : ℝ :=
  ∑ a ∈ I, ∑ c ∈ I, if a < c then correlation J alpha beta K a c else 0

theorem dispersion_nonneg (I J : Finset ℕ) (alpha beta : ℕ → ℝ)
    (K : ℕ → ℕ → ℝ) (hb : ∀ b ∈ J, 0 ≤ beta b) :
    0 ≤ dispersion I J alpha beta K :=
  Finset.sum_nonneg (fun b h => mul_nonneg (hb b h) (sq_nonneg _))

theorem weighted_contraction_sq_le (I J : Finset ℕ) (alpha beta : ℕ → ℝ)
    (K : ℕ → ℕ → ℝ) (hb : ∀ b ∈ J, 0 ≤ beta b) :
    (∑ b ∈ J, beta b * column I alpha K b) ^ 2 ≤
      (∑ b ∈ J, beta b) * dispersion I J alpha beta K :=
  BetaWeighted.weighted_sum_sq_le_mass_energy J beta (column I alpha K) hb

theorem correlation_symmetric (J : Finset ℕ) (alpha beta : ℕ → ℝ)
    (K : ℕ → ℕ → ℝ) (a c : ℕ) :
    correlation J alpha beta K a c = correlation J alpha beta K c a := by
  unfold correlation
  have hs : (∑ b ∈ J, beta b * K a b * K c b) =
      ∑ b ∈ J, beta b * K c b * K a b := by
    apply Finset.sum_congr rfl
    intro b hb
    ring
  rw [hs]
  ring

theorem dispersion_eq_signed_correlations (I J : Finset ℕ)
    (alpha beta : ℕ → ℝ) (K : ℕ → ℕ → ℝ) :
    dispersion I J alpha beta K =
      ∑ a ∈ I, ∑ c ∈ I, correlation J alpha beta K a c := by
  unfold dispersion column correlation
  simp_rw [pow_two, Finset.sum_mul_sum, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a ha
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro c hc
  apply Finset.sum_congr rfl
  intro b hb
  ring

theorem symmetric_double_sum_diagonal_upper (I : Finset ℕ) (R : ℕ → ℕ → ℝ)
    (hsym : ∀ a c, R a c = R c a) :
    (∑ a ∈ I, ∑ c ∈ I, R a c) = (∑ a ∈ I, R a a) +
      2 * ∑ a ∈ I, ∑ c ∈ I, if a < c then R a c else 0 := by
  have hpoint (a c : ℕ) : R a c =
      (if a = c then R a a else 0) + (if a < c then R a c else 0) +
        (if c < a then R a c else 0) := by
    rcases lt_trichotomy a c with h | h | h
    · simp [h, h.ne, not_lt_of_ge h.le]
    · subst c
      simp
    · simp [h, h.ne', not_lt_of_ge h.le]
  have hdiag : (∑ a ∈ I, ∑ c ∈ I, if a = c then R a a else 0) =
      ∑ a ∈ I, R a a := by
    apply Finset.sum_congr rfl
    intro a ha
    simp [ha]
  have hswap : (∑ a ∈ I, ∑ c ∈ I, if c < a then R a c else 0) =
      ∑ a ∈ I, ∑ c ∈ I, if a < c then R a c else 0 := by
    rw [Finset.sum_comm]
    apply Finset.sum_congr rfl
    intro a ha
    apply Finset.sum_congr rfl
    intro c hc
    rw [hsym c a]
  have hsum : (∑ a ∈ I, ∑ c ∈ I, R a c) =
      ∑ a ∈ I, ∑ c ∈ I,
        ((if a = c then R a a else 0) + (if a < c then R a c else 0) +
          (if c < a then R a c else 0)) := by
    apply Finset.sum_congr rfl
    intro a ha
    apply Finset.sum_congr rfl
    intro c hc
    exact hpoint a c
  rw [hsum]
  simp only [Finset.sum_add_distrib]
  rw [hdiag, hswap]
  ring

theorem dispersion_eq_diagonal_add_twice_upper (I J : Finset ℕ)
    (alpha beta : ℕ → ℝ) (K : ℕ → ℕ → ℝ) :
    dispersion I J alpha beta K = diagonal I J alpha beta K +
      2 * upperCorrelation I J alpha beta K := by
  rw [dispersion_eq_signed_correlations,
    symmetric_double_sum_diagonal_upper I (correlation J alpha beta K)
      (correlation_symmetric J alpha beta K)]
  unfold diagonal upperCorrelation correlation
  congr 1
  apply Finset.sum_congr rfl
  intro a ha
  rw [Finset.mul_sum, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro b hb
  ring

theorem upper_interval_eq_positive_shifts {L H a : ℕ} (ha : a ∈ Ico L H)
    (F : ℕ → ℝ) :
    (∑ c ∈ Ico L H, if a < c then F c else 0) =
      ∑ h ∈ Ico 1 (H - a), F (a + h) := by
  have hamem := Finset.mem_Ico.mp ha
  calc
    _ = ∑ c ∈ Ico (a + 1) H, F c := by
      have hsubset : Ico (a + 1) H ⊆ Ico L H := by
        intro c hc
        simp only [Finset.mem_Ico] at hc ⊢
        omega
      calc
        _ = ∑ c ∈ Ico (a + 1) H, if a < c then F c else 0 := by
          symm
          apply Finset.sum_subset hsubset
          intro c hc hout
          simp only [Finset.mem_Ico] at hc hout
          have hnot : ¬a < c := by omega
          simp [hnot]
        _ = _ := by
          apply Finset.sum_congr rfl
          intro c hc
          have hlt : a < c := by
            simp only [Finset.mem_Ico] at hc
            omega
          simp [hlt]
    _ = _ := by
      rw [Finset.sum_Ico_eq_sum_range, Finset.sum_Ico_eq_sum_range]
      have hr : H - (a + 1) = H - a - 1 := by omega
      rw [hr]
      apply Finset.sum_congr rfl
      intro h hh
      congr 1
      omega

theorem dispersion_interval_eq_shifted (L H : ℕ) (J : Finset ℕ)
    (alpha beta : ℕ → ℝ) (K : ℕ → ℕ → ℝ) :
    dispersion (Ico L H) J alpha beta K = diagonal (Ico L H) J alpha beta K +
      2 * ∑ a ∈ Ico L H, ∑ h ∈ Ico 1 (H - a),
        correlation J alpha beta K a (a + h) := by
  rw [dispersion_eq_diagonal_add_twice_upper]
  unfold upperCorrelation
  congr 2
  apply Finset.sum_congr rfl
  intro a ha
  exact upper_interval_eq_positive_shifts ha (correlation J alpha beta K a)

def arithmeticKernel (N : ℕ) (W : ℕ → ℝ) (a b : ℕ) : ℝ :=
  muReal (N - a * b) * W (a * b)

def fullSignedWeight (N cutoff Q n : ℕ) : ℝ :=
  ∑ k ∈ actualModuli N Q, muReal k * actualRow N cutoff k n

theorem arithmeticKernel_fullSignedWeight (N cutoff Q a b : ℕ) :
    arithmeticKernel N (fullSignedWeight N cutoff Q) a b =
      ∑ k ∈ actualModuli N Q, muReal k * Bilinear.actualTypeIIKernel N cutoff k a b := by
  unfold arithmeticKernel fullSignedWeight Bilinear.actualTypeIIKernel
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro k hk
  ring

theorem signed_typeII_eq_aggregated_column (N cutoff Q U V : ℕ) :
    (∑ k ∈ actualModuli N Q, muReal k * TypeIIVariance.typeIIRow N cutoff k U V) =
      ∑ b ∈ TypeIIAssembly.activeSecond N V, Vaughan.beta V b *
        column (TypeIIAssembly.activeFirst N U) muReal
          (arithmeticKernel N (fullSignedWeight N cutoff Q)) b := by
  have hr (k : ℕ) : TypeIIVariance.typeIIRow N cutoff k U V =
      ∑ b ∈ TypeIIAssembly.activeSecond N V, Vaughan.beta V b *
        column (TypeIIAssembly.activeFirst N U) muReal
          (Bilinear.actualTypeIIKernel N cutoff k) b := by
    rw [TypeIIVariance.typeIIRow,
      TypeIIAssembly.actual_signedRow_typeTwo_eq_active_bilinear,
      Bilinear.bilinearSum_eq_transpose]
    rfl
  simp_rw [hr]
  unfold column
  simp_rw [arithmeticKernel_fullSignedWeight, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro b hb
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro a ha
  apply Finset.sum_congr rfl
  intro k hk
  ring

theorem arithmetic_correlation_four_moebius (N : ℕ) (J : Finset ℕ)
    (beta W : ℕ → ℝ) (a c : ℕ) :
    correlation J muReal beta (arithmeticKernel N W) a c =
      ∑ b ∈ J, beta b * muReal a * muReal c *
        muReal (N - a * b) * muReal (N - c * b) * W (a * b) * W (c * b) := by
  unfold correlation arithmeticKernel
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro b hb
  ring

theorem aggregated_diagonal_keeps_module_cross_terms (I J M : Finset ℕ)
    (alpha beta : ℕ → ℝ) (K : ℕ → ℕ → ℕ → ℝ) :
    diagonal I J alpha beta (fun a b => ∑ q ∈ M, K q a b) =
      ∑ a ∈ I, alpha a ^ 2 * ∑ b ∈ J, beta b *
        ∑ q ∈ M, ∑ r ∈ M, K q a b * K r a b := by
  unfold diagonal
  simp_rw [pow_two, Finset.sum_mul_sum]

theorem complement_shift (N a b h : ℤ) :
    Bilinear.affineComplement N (a + h) b = Bilinear.affineComplement N a b - h * b := by
  unfold Bilinear.affineComplement
  ring

theorem common_divisor_dvd_N_row_difference (N a c b d : ℤ)
    (ha : d ∣ Bilinear.affineComplement N a b)
    (hc : d ∣ Bilinear.affineComplement N c b) : d ∣ N * (c - a) := by
  have hd := dvd_sub (dvd_mul_of_dvd_right ha c) (dvd_mul_of_dvd_right hc a)
  convert hd using 1
  unfold Bilinear.affineComplement
  ring

theorem common_divisor_dvd_shift_times_column (N a b h d : ℤ)
    (ha : d ∣ Bilinear.affineComplement N a b)
    (hh : d ∣ Bilinear.affineComplement N (a + h) b) : d ∣ h * b := by
  have hd := dvd_sub ha hh
  convert hd using 1
  unfold Bilinear.affineComplement
  ring

#print axioms dispersion_nonneg
#print axioms weighted_contraction_sq_le
#print axioms correlation_symmetric
#print axioms dispersion_eq_signed_correlations
#print axioms symmetric_double_sum_diagonal_upper
#print axioms dispersion_eq_diagonal_add_twice_upper
#print axioms upper_interval_eq_positive_shifts
#print axioms dispersion_interval_eq_shifted
#print axioms arithmetic_correlation_four_moebius
#print axioms arithmeticKernel_fullSignedWeight
#print axioms signed_typeII_eq_aggregated_column
#print axioms aggregated_diagonal_keeps_module_cross_terms
#print axioms complement_shift
#print axioms common_divisor_dvd_N_row_difference
#print axioms common_divisor_dvd_shift_times_column

end
end GoldbachResearch.ShiftedDispersion
