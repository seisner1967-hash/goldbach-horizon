import Mathlib.Analysis.SpecialFunctions.Integrals
import Mathlib.Tactic
import Mathlib.Data.List.Sublists
import Mathlib.MeasureTheory.Measure.Lebesgue.Basic

/-!
# Actual interval integrals for weighted simplices

`weightedSimplexIntegral` is a nested interval integral, not a definition
of the proposed closed form.  The product-measure interpretation and the
full discrete harmonic comparison are proved below.  The arithmetic
coefficient and variance identifications remain separate obligations.
No prime-counting or Goldbach assertion is assumed here.
-/

namespace GoldbachResearch

set_option autoImplicit false

open scoped Interval

theorem weighted_power_integral (a R : ℝ) (m : ℕ) (ha : 0 < a) :
    (∫ t in (0 : ℝ)..R / a, (R - a * t) ^ m) =
      R ^ (m + 1) / (a * (m + 1)) := by
  have ha0 : a ≠ 0 := ne_of_gt ha
  rw [intervalIntegral.integral_comp_sub_mul (fun x : ℝ => x ^ m) ha0 R]
  simp only [mul_zero, sub_zero, mul_div_cancel₀ R ha0, sub_self,
    integral_pow, zero_pow (Nat.succ_ne_zero m), sub_zero, smul_eq_mul]
  simp only [div_eq_mul_inv, mul_inv_rev]
  ring

noncomputable def weightedSimplexIntegral : List ℝ → ℝ → ℝ
  | [], _ => 1
  | a :: as, R => ∫ t in (0 : ℝ)..R / a, weightedSimplexIntegral as (R - a * t)

theorem weightedSimplexIntegral_closed (as : List ℝ)
    (ha : ∀ a ∈ as, 0 < a) (R : ℝ) (hR : 0 ≤ R) :
    weightedSimplexIntegral as R =
      R ^ as.length / ((as.length.factorial : ℝ) * as.prod) := by
  induction as generalizing R with
  | nil => simp [weightedSimplexIntegral]
  | cons a as ih =>
    have hapos : 0 < a := ha a (by simp)
    have haa : ∀ b ∈ as, 0 < b := by
      intro b hb
      exact ha b (by simp [hb])
    have hRa : 0 ≤ R / a := div_nonneg hR hapos.le
    have hreplace :
        (∫ t in (0 : ℝ)..R / a, weightedSimplexIntegral as (R - a * t)) =
        ∫ t in (0 : ℝ)..R / a,
          (R - a * t) ^ as.length / ((as.length.factorial : ℝ) * as.prod) := by
      apply intervalIntegral.integral_congr
      intro t ht
      have ht' : t ∈ Set.Icc (0 : ℝ) (R / a) := by
        simpa [Set.uIcc_of_le hRa] using ht
      apply ih haa
      have hat : a * t ≤ R := by
        have h := (le_div_iff₀ hapos).mp ht'.2
        simpa [mul_comm] using h
      exact sub_nonneg.mpr hat
    rw [weightedSimplexIntegral, hreplace, intervalIntegral.integral_div,
      weighted_power_integral a R as.length hapos]
    simp only [List.length_cons, List.prod_cons, Nat.factorial_succ, Nat.cast_mul,
      Nat.cast_add, Nat.cast_one]
    simp only [div_eq_mul_inv, mul_inv_rev]
    ring

#print axioms weighted_power_integral
#print axioms weightedSimplexIntegral_closed

noncomputable def subsetSimplexIntegral (as : List ℝ) (R : ℝ) : ℝ :=
  (as.sublists'.map fun s => weightedSimplexIntegral s R).sum

noncomputable def subsetSimplexPolynomial (as : List ℝ) (R : ℝ) : ℝ :=
  (as.sublists'.map fun s =>
    R ^ s.length / ((s.length.factorial : ℝ) * s.prod)).sum

theorem subsetSimplexIntegral_eq (as : List ℝ)
    (ha : ∀ a ∈ as, 0 < a) (R : ℝ) (hR : 0 ≤ R) :
    subsetSimplexIntegral as R = subsetSimplexPolynomial as R := by
  unfold subsetSimplexIntegral subsetSimplexPolynomial
  congr 1
  apply List.map_congr_left
  intro s hs
  apply weightedSimplexIntegral_closed s _ R hR
  intro a has
  exact ha a ((List.mem_sublists'.mp hs).subset has)

def goldbachSimplexWeights : List ℝ := [2, 2, 3, 3, 3, 3, 4]

theorem goldbachSimplexWeights_pos : ∀ a ∈ goldbachSimplexWeights, 0 < a := by
  intro a ha
  simp only [goldbachSimplexWeights, List.mem_cons, List.not_mem_nil, or_false] at ha
  rcases ha with h | h | h | h | h | h | h <;> subst a <;> norm_num

noncomputable def goldbachSimplexPolynomial (R : ℝ) : ℝ :=
  1 + (31 / 12 : ℝ) * R + (17 / 12 : ℝ) * R ^ 2 +
    (739 / 2592 : ℝ) * R ^ 3 + (199 / 7776 : ℝ) * R ^ 4 +
    (17 / 15552 : ℝ) * R ^ 5 + (1 / 46656 : ℝ) * R ^ 6 +
    (1 / 6531840 : ℝ) * R ^ 7

set_option maxRecDepth 4000 in
set_option maxHeartbeats 1000000 in
theorem goldbachSimplexPolynomial_expansion (R : ℝ) :
    subsetSimplexPolynomial goldbachSimplexWeights R = goldbachSimplexPolynomial R := by
  norm_num [subsetSimplexPolynomial, goldbachSimplexWeights, goldbachSimplexPolynomial,
    List.sublists'_cons, List.sublists'_nil, List.map_append,
    List.map_cons, List.map_nil, List.sum_append, List.sum_cons, List.sum_nil,
    List.length_cons, List.length_nil, List.prod_cons, List.prod_nil,
    Nat.factorial_succ, Nat.factorial_zero]
  ring

theorem goldbachSimplexIntegral_polynomial (R : ℝ) (hR : 0 ≤ R) :
    subsetSimplexIntegral goldbachSimplexWeights R = goldbachSimplexPolynomial R := by
  rw [subsetSimplexIntegral_eq goldbachSimplexWeights goldbachSimplexWeights_pos R hR,
    goldbachSimplexPolynomial_expansion]

theorem weightedSimplexIntegral_half (as : List ℝ)
    (ha : ∀ a ∈ as, 0 < a) (R : ℝ) (hR : 0 ≤ R) :
    (1 / 2 : ℝ) ^ as.length * weightedSimplexIntegral as R =
      weightedSimplexIntegral as (R / 2) := by
  rw [weightedSimplexIntegral_closed as ha R hR,
    weightedSimplexIntegral_closed as ha (R / 2) (by positivity)]
  simp only [div_pow, one_div, div_eq_mul_inv]
  ring

noncomputable def halfWeightedSubsetIntegral (as : List ℝ) (R : ℝ) : ℝ :=
  (as.sublists'.map fun s =>
    (1 / 2 : ℝ) ^ s.length * weightedSimplexIntegral s R).sum

theorem halfWeightedSubsetIntegral_eq (as : List ℝ)
    (ha : ∀ a ∈ as, 0 < a) (R : ℝ) (hR : 0 ≤ R) :
    halfWeightedSubsetIntegral as R = subsetSimplexIntegral as (R / 2) := by
  unfold halfWeightedSubsetIntegral subsetSimplexIntegral
  congr 1
  apply List.map_congr_left
  intro s hs
  apply weightedSimplexIntegral_half s _ R hR
  intro a has
  exact ha a ((List.mem_sublists'.mp hs).subset has)

theorem goldbach_halfWeighted_log_polynomial (Q : ℝ) (hQ : 1 ≤ Q) :
    halfWeightedSubsetIntegral goldbachSimplexWeights (4 * Real.log Q) =
      goldbachSimplexPolynomial (2 * Real.log Q) := by
  have hlog := Real.log_nonneg hQ
  rw [halfWeightedSubsetIntegral_eq goldbachSimplexWeights goldbachSimplexWeights_pos
    (4 * Real.log Q) (by positivity)]
  have heq : 4 * Real.log Q / 2 = 2 * Real.log Q := by ring
  rw [heq, goldbachSimplexIntegral_polynomial (2 * Real.log Q) (by positivity)]

/-- The factor `1/2` comes from the disjoint logarithmic cells of odd integers. -/
theorem reciprocal_le_half_log_cell (n : ℝ) (hn : 3 ≤ n) :
    1 / n ≤ (Real.log n - Real.log (n - 2)) / 2 := by
  have hnpos : 0 < n := by linarith
  have hnmpos : 0 < n - 2 := by linarith
  have h := Real.one_sub_inv_le_log_of_pos (div_pos hnpos hnmpos)
  rw [Real.log_div (ne_of_gt hnpos) (ne_of_gt hnmpos)] at h
  have heq : 1 - (n / (n - 2))⁻¹ = 2 / n := by
    rw [inv_div]
    field_simp
  rw [heq] at h
  have heq2 : 2 / n = 2 * (1 / n) := by ring
  rw [heq2] at h
  linarith

theorem reciprocal_le_half_harmonic_cell_integral (n : ℝ) (hn : 3 ≤ n) :
    1 / n ≤ (1 / 2 : ℝ) * (∫ x in (n - 2)..n, 1 / x) := by
  have hnpos : 0 < n := by linarith
  have hnmpos : 0 < n - 2 := by linarith
  rw [integral_one_div_of_pos hnmpos hnpos,
    Real.log_div (ne_of_gt hnpos) (ne_of_gt hnmpos)]
  have := reciprocal_le_half_log_cell n hn
  linarith

#print axioms subsetSimplexIntegral_eq
#print axioms goldbachSimplexPolynomial_expansion
#print axioms goldbachSimplexIntegral_polynomial
#print axioms goldbach_halfWeighted_log_polynomial
#print axioms reciprocal_le_half_log_cell
#print axioms reciprocal_le_half_harmonic_cell_integral

section LogBoxes

open MeasureTheory Set

variable {ι : Type*} [Fintype ι]

noncomputable def oddLogBox (n : ι → ℕ) : Set (ι → ℝ) :=
  Set.pi Set.univ fun i => Set.Ioc (Real.log ((n i : ℝ) - 2)) (Real.log (n i))

noncomputable def weightedLogSimplex (a : ι → ℝ) (R : ℝ) : Set (ι → ℝ) :=
  {t | (∀ i, 0 ≤ t i) ∧ (∑ i, a i * t i) ≤ R}

theorem oddLogBox_measurable (n : ι → ℕ) : MeasurableSet (oddLogBox n) := by
  exact MeasurableSet.pi (Set.to_countable _) (fun _ _ => measurableSet_Ioc)

theorem oddLogBox_subset_weightedLogSimplex (n : ι → ℕ) (a : ι → ℝ) (R : ℝ)
    (hn : ∀ i, 3 ≤ n i) (ha : ∀ i, 0 ≤ a i)
    (hbudget : (∑ i, a i * Real.log (n i)) ≤ R) :
    oddLogBox n ⊆ weightedLogSimplex a R := by
  intro t ht
  have ht' : ∀ i, t i ∈ Set.Ioc (Real.log ((n i : ℝ) - 2)) (Real.log (n i)) := by
    intro i
    exact ht i (Set.mem_univ i)
  constructor
  · intro i
    have hi : (3 : ℝ) ≤ n i := by exact_mod_cast hn i
    have hlog : 0 ≤ Real.log ((n i : ℝ) - 2) := Real.log_nonneg (by linarith)
    exact hlog.trans (ht' i).1.le
  · apply le_trans _ hbudget
    exact Finset.sum_le_sum (fun i _ => mul_le_mul_of_nonneg_left (ht' i).2 (ha i))

theorem oddLogCell_disjoint (n m : ℕ) (hn : 3 ≤ n) (hm : 3 ≤ m)
    (hno : n % 2 = 1) (hmo : m % 2 = 1) (hne : n ≠ m) :
    Disjoint (Ioc (Real.log ((n : ℝ) - 2)) (Real.log (n : ℝ)))
      (Ioc (Real.log ((m : ℝ) - 2)) (Real.log (m : ℝ))) := by
  apply Set.disjoint_left.mpr
  intro x hx hy
  rcases lt_or_gt_of_ne hne with hlt | hgt
  · have hgap : n + 2 ≤ m := by omega
    have hgap' : (n : ℝ) + 2 ≤ m := by exact_mod_cast hgap
    have hnpos : (0 : ℝ) < n := by exact_mod_cast (show 0 < n by omega)
    have hlog := Real.log_le_log hnpos (show (n : ℝ) ≤ (m : ℝ) - 2 by linarith)
    linarith [hx.2, hy.1]
  · have hgap : m + 2 ≤ n := by omega
    have hgap' : (m : ℝ) + 2 ≤ n := by exact_mod_cast hgap
    have hmpos : (0 : ℝ) < m := by exact_mod_cast (show 0 < m by omega)
    have hlog := Real.log_le_log hmpos (show (m : ℝ) ≤ (n : ℝ) - 2 by linarith)
    linarith [hy.2, hx.1]

theorem oddLogBox_disjoint (n m : ι → ℕ)
    (hn : ∀ i, 3 ≤ n i) (hm : ∀ i, 3 ≤ m i)
    (hno : ∀ i, n i % 2 = 1) (hmo : ∀ i, m i % 2 = 1) (hne : n ≠ m) :
    Disjoint (oddLogBox n) (oddLogBox m) := by
  apply Set.disjoint_left.mpr
  intro t ht hu
  have hex : ∃ i, n i ≠ m i := by
    by_contra h
    apply hne
    ext i
    exact not_not.mp (not_exists.mp h i)
  obtain ⟨i, hi⟩ := hex
  exact Set.disjoint_left.mp
    (oddLogCell_disjoint (n i) (m i) (hn i) (hm i) (hno i) (hmo i) hi)
    (ht i (Set.mem_univ i)) (hu i (Set.mem_univ i))

theorem reciprocal_product_le_half_box (n : ι → ℕ) (hn : ∀ i, 3 ≤ n i) :
    (∏ i, 1 / (n i : ℝ)) ≤ (1 / 2 : ℝ) ^ Fintype.card ι *
      (∏ i, (Real.log (n i) - Real.log ((n i : ℝ) - 2))) := by
  have h := Finset.prod_le_prod
    (s := Finset.univ) (f := fun i => 1 / (n i : ℝ))
    (g := fun i => (1 / 2 : ℝ) * (Real.log (n i) - Real.log ((n i : ℝ) - 2)))
    (fun i _ => by positivity)
    (fun i _ => by
      have hi : (3 : ℝ) ≤ n i := by exact_mod_cast hn i
      have := reciprocal_le_half_log_cell (n i) hi
      linarith)
  simpa only [Finset.prod_mul_distrib, Finset.prod_const, Finset.card_univ] using h

theorem reciprocal_product_ennreal_le_half_volume (n : ι → ℕ) (hn : ∀ i, 3 ≤ n i) :
    ENNReal.ofReal (∏ i, 1 / (n i : ℝ)) ≤
      ENNReal.ofReal ((1 / 2 : ℝ) ^ Fintype.card ι) * volume (oddLogBox n) := by
  have h := ENNReal.ofReal_le_ofReal (reciprocal_product_le_half_box n hn)
  rw [ENNReal.ofReal_mul (by positivity)] at h
  have hprod : ENNReal.ofReal (∏ i, (Real.log (n i) - Real.log ((n i : ℝ) - 2))) =
      ∏ i, ENNReal.ofReal (Real.log (n i) - Real.log ((n i : ℝ) - 2)) := by
    apply ENNReal.ofReal_prod_of_nonneg
    intro i _
    have hi : (3 : ℝ) ≤ n i := by exact_mod_cast hn i
    apply sub_nonneg.mpr
    exact Real.log_le_log (by linarith) (by linarith)
  rw [hprod] at h
  simpa only [oddLogBox, Real.volume_pi_Ioc] using h

theorem odd_reciprocal_family_le_simplex_volume (s : Finset (ι → ℕ))
    (a : ι → ℝ) (R : ℝ) (ha : ∀ i, 0 ≤ a i)
    (hn : ∀ n ∈ s, ∀ i, 3 ≤ n i) (ho : ∀ n ∈ s, ∀ i, n i % 2 = 1)
    (hbudget : ∀ n ∈ s, (∑ i, a i * Real.log (n i)) ≤ R) :
    ENNReal.ofReal (∑ n ∈ s, ∏ i, 1 / (n i : ℝ)) ≤
      ENNReal.ofReal ((1 / 2 : ℝ) ^ Fintype.card ι) * volume (weightedLogSimplex a R) := by
  classical
  have hd : Set.PairwiseDisjoint (s : Set (ι → ℕ)) oddLogBox := by
    intro n hns m hms hne
    exact oddLogBox_disjoint n m (hn n hns) (hn m hms) (ho n hns) (ho m hms) hne
  have hunion : (⋃ n ∈ s, oddLogBox n) ⊆ weightedLogSimplex a R := by
    intro t ht
    obtain ⟨n, hns, hnt⟩ := Set.mem_iUnion₂.mp ht
    exact oddLogBox_subset_weightedLogSimplex n a R (hn n hns) ha (hbudget n hns) hnt
  calc
    ENNReal.ofReal (∑ n ∈ s, ∏ i, 1 / (n i : ℝ)) =
        ∑ n ∈ s, ENNReal.ofReal (∏ i, 1 / (n i : ℝ)) :=
      ENNReal.ofReal_sum_of_nonneg (fun _ _ => by positivity)
    _ ≤ ∑ n ∈ s, ENNReal.ofReal ((1 / 2 : ℝ) ^ Fintype.card ι) * volume (oddLogBox n) :=
      Finset.sum_le_sum (fun n hns => reciprocal_product_ennreal_le_half_volume n (hn n hns))
    _ = ENNReal.ofReal ((1 / 2 : ℝ) ^ Fintype.card ι) * (∑ n ∈ s, volume (oddLogBox n)) :=
      (Finset.mul_sum ..).symm
    _ = ENNReal.ofReal ((1 / 2 : ℝ) ^ Fintype.card ι) * volume (⋃ n ∈ s, oddLogBox n) := by
      rw [measure_biUnion_finset hd (fun n _ => oddLogBox_measurable n)]
    _ ≤ ENNReal.ofReal ((1 / 2 : ℝ) ^ Fintype.card ι) * volume (weightedLogSimplex a R) := by
      exact mul_le_mul_left' (measure_mono hunion) _

#print axioms oddLogBox_disjoint
#print axioms reciprocal_product_ennreal_le_half_volume
#print axioms odd_reciprocal_family_le_simplex_volume

end LogBoxes

section SimplexVolume

open MeasureTheory Set

variable {n : ℕ}

theorem weightedLogSimplex_measurable (a : Fin n → ℝ) (R : ℝ) :
    MeasurableSet (weightedLogSimplex a R) := by
  have hc : Continuous (fun t : Fin n → ℝ => ∑ i, a i * t i) := by fun_prop
  have hcoords : MeasurableSet {t : Fin n → ℝ | ∀ i, 0 ≤ t i} := by
    simp only [setOf_forall]
    exact MeasurableSet.iInter (fun i =>
      (isClosed_le continuous_const (continuous_apply i)).measurableSet)
  exact hcoords.inter ((isClosed_le hc continuous_const).measurableSet)

theorem weightedLogSimplex_cons_mem (a : Fin (n + 1) → ℝ) (R t : ℝ) (u : Fin n → ℝ) :
    Fin.cons t u ∈ weightedLogSimplex a R ↔
      0 ≤ t ∧ u ∈ weightedLogSimplex (fun i => a i.succ) (R - a 0 * t) := by
  simp only [weightedLogSimplex, mem_setOf_eq, Fin.forall_fin_succ, Fin.cons_zero, Fin.cons_succ,
    Fin.sum_univ_succ]
  constructor
  · rintro ⟨⟨ht, hu⟩, hsum⟩
    exact ⟨ht, hu, by linarith⟩
  · rintro ⟨ht, hu, hsum⟩
    exact ⟨⟨ht, hu⟩, by linarith⟩

theorem weightedLogSimplex_volume_fubini (a : Fin (n + 1) → ℝ) (R : ℝ) :
    volume (weightedLogSimplex a R) =
      ∫⁻ t : ℝ, volume {u : Fin n → ℝ | Fin.cons t u ∈ weightedLogSimplex a R} := by
  let e := MeasurableEquiv.piFinSuccAbove (fun _ : Fin (n + 1) => ℝ) 0
  have hp := (volume_preserving_piFinSuccAbove (fun _ : Fin (n + 1) => ℝ) 0).symm
  have he := hp.measure_preimage_equiv (weightedLogSimplex a R)
  rw [← he, Measure.volume_eq_prod, Measure.prod_apply]
  · apply lintegral_congr
    intro t
    congr 1
    ext u
    simp [e, MeasurableEquiv.piFinSuccAbove_symm_apply, Fin.insertNthEquiv,
      Fin.insertNth_zero, Fin.zero_succAbove]
  · exact (weightedLogSimplex_measurable a R).preimage e.symm.measurable

theorem weightedLogSimplex_fiber (a : Fin (n + 1) → ℝ) (R t : ℝ) (ha : ∀ i, 0 < a i) :
    {u : Fin n → ℝ | Fin.cons t u ∈ weightedLogSimplex a R} =
      if t ∈ Icc 0 (R / a 0) then
        weightedLogSimplex (fun i => a i.succ) (R - a 0 * t) else ∅ := by
  split_ifs with ht
  · ext u
    simp only [mem_setOf_eq, weightedLogSimplex_cons_mem]
    exact and_iff_right ht.1
  · apply Set.eq_empty_iff_forall_not_mem.mpr
    intro u hu
    have h := (weightedLogSimplex_cons_mem a R t u).mp hu
    have hcost : 0 ≤ ∑ i : Fin n, a i.succ * u i :=
      Finset.sum_nonneg (fun i _ => mul_nonneg (ha i.succ).le (h.2.1 i))
    have hat : a 0 * t ≤ R := by linarith [h.2.2]
    have htupper : t ≤ R / a 0 := (le_div_iff₀ (ha 0)).mpr (by simpa [mul_comm] using hat)
    exact ht ⟨h.1, htupper⟩

theorem weightedLogSimplex_volume_recursion (a : Fin (n + 1) → ℝ) (R : ℝ)
    (ha : ∀ i, 0 < a i) :
    volume (weightedLogSimplex a R) =
      ∫⁻ t : ℝ in Icc 0 (R / a 0),
        volume (weightedLogSimplex (fun i : Fin n => a i.succ) (R - a 0 * t)) := by
  rw [weightedLogSimplex_volume_fubini, ← lintegral_indicator measurableSet_Icc]
  apply lintegral_congr
  intro t
  rw [weightedLogSimplex_fiber a R t ha]
  by_cases ht : t ∈ Icc 0 (R / a 0) <;> simp [ht, Set.indicator]

#print axioms weightedLogSimplex_volume_recursion

theorem weightedLogSimplex_volume_closed (n : ℕ) (a : Fin n → ℝ)
    (ha : ∀ i, 0 < a i) (R : ℝ) (hR : 0 ≤ R) :
    volume (weightedLogSimplex a R) =
      ENNReal.ofReal (R ^ n / ((n.factorial : ℝ) * ∏ i, a i)) := by
  induction n generalizing R with
  | zero =>
    have hs : weightedLogSimplex a R = univ := by
      ext t
      simp [weightedLogSimplex, hR]
    simp [hs, volume_pi, Measure.pi_empty_univ]
  | succ n ih =>
    rw [weightedLogSimplex_volume_recursion a R ha]
    let f : ℝ → ℝ := fun t =>
      (R - a 0 * t) ^ n / ((n.factorial : ℝ) * ∏ i : Fin n, a i.succ)
    have hden : 0 < (n.factorial : ℝ) * (∏ i : Fin n, a i.succ) :=
      mul_pos (Nat.cast_pos.mpr (Nat.factorial_pos n))
        (Finset.prod_pos (fun i _ => ha i.succ))
    have hres : ∀ t ∈ Icc 0 (R / a 0), 0 ≤ R - a 0 * t := by
      intro t ht
      have h := (le_div_iff₀ (ha 0)).mp ht.2
      nlinarith
    have hint : IntegrableOn f (Icc 0 (R / a 0)) := by
      have hc : Continuous f := by unfold f; fun_prop
      exact hc.integrableOn_Icc
    have hnn : ∀ t ∈ Icc 0 (R / a 0), 0 ≤ f t := by
      intro t ht
      exact div_nonneg (pow_nonneg (hres t ht) n) hden.le
    have heq : (∫⁻ t : ℝ in Icc 0 (R / a 0),
        volume (weightedLogSimplex (fun i : Fin n => a i.succ) (R - a 0 * t))) =
        ∫⁻ t : ℝ in Icc 0 (R / a 0), ENNReal.ofReal (f t) := by
      apply lintegral_congr_ae
      exact (ae_restrict_mem measurableSet_Icc).mono
        (fun t ht => ih _ (fun i => ha i.succ) _ (hres t ht))
    rw [heq, ← ofReal_integral_eq_lintegral_ofReal hint
      ((ae_restrict_mem measurableSet_Icc).mono (fun t ht => hnn t ht))]
    rw [integral_Icc_eq_integral_Ioc,
      ← intervalIntegral.integral_of_le (div_nonneg hR (ha 0).le)]
    unfold f
    rw [intervalIntegral.integral_div, weighted_power_integral (a 0) R n (ha 0)]
    simp only [Nat.factorial_succ, Nat.cast_mul, Nat.cast_add, Nat.cast_one, Fin.prod_univ_succ]
    congr 1
    simp only [div_eq_mul_inv, mul_inv_rev]
    ring

/-- This closes the link between product-measure volume and the actual iterated integral. -/
theorem weightedLogSimplex_volume_eq_nested (as : List ℝ)
    (ha : ∀ a ∈ as, 0 < a) (R : ℝ) (hR : 0 ≤ R) :
    volume (weightedLogSimplex as.get R) = ENNReal.ofReal (weightedSimplexIntegral as R) := by
  rw [weightedLogSimplex_volume_closed as.length as.get
    (fun i => ha _ (List.get_mem as i)) R hR,
    weightedSimplexIntegral_closed as ha R hR]
  congr 2
  rw [← Fin.prod_ofFn, List.ofFn_get]

theorem odd_reciprocal_family_le_closed_simplex (s : Finset (Fin n → ℕ))
    (a : Fin n → ℝ) (R : ℝ) (ha : ∀ i, 0 < a i) (hR : 0 ≤ R)
    (hn : ∀ m ∈ s, ∀ i, 3 ≤ m i) (ho : ∀ m ∈ s, ∀ i, m i % 2 = 1)
    (hbudget : ∀ m ∈ s, (∑ i, a i * Real.log (m i)) ≤ R) :
    (∑ m ∈ s, ∏ i, 1 / (m i : ℝ)) ≤
      (R / 2) ^ n / ((n.factorial : ℝ) * ∏ i, a i) := by
  have h := odd_reciprocal_family_le_simplex_volume s a R (fun i => (ha i).le) hn ho hbudget
  rw [weightedLogSimplex_volume_closed n a ha R hR,
    ← ENNReal.ofReal_mul (by positivity)] at h
  simp only [Fintype.card_fin] at h
  have hden : 0 < (n.factorial : ℝ) * (∏ i, a i) :=
    mul_pos (Nat.cast_pos.mpr (Nat.factorial_pos n)) (Finset.prod_pos (fun i _ => ha i))
  have hnonneg : 0 ≤ (1 / 2 : ℝ) ^ n * (R ^ n / ((n.factorial : ℝ) * ∏ i, a i)) := by
    exact mul_nonneg (by positivity) (div_nonneg (pow_nonneg hR n) hden.le)
  have hreal := (ENNReal.ofReal_le_ofReal_iff hnonneg).mp h
  have heq : (1 / 2 : ℝ) ^ n * (R ^ n / ((n.factorial : ℝ) * ∏ i, a i)) =
      (R / 2) ^ n / ((n.factorial : ℝ) * ∏ i, a i) := by
    simp only [div_pow, one_div, div_eq_mul_inv]
    ring
  exact heq ▸ hreal

#print axioms weightedLogSimplex_volume_closed
#print axioms weightedLogSimplex_volume_eq_nested
#print axioms odd_reciprocal_family_le_closed_simplex

theorem weightedLogSimplex_volume_closed_fintype {ι : Type*} [Fintype ι]
    (a : ι → ℝ) (ha : ∀ i, 0 < a i) (R : ℝ) (hR : 0 ≤ R) :
    volume (weightedLogSimplex a R) =
      ENNReal.ofReal (R ^ (Fintype.card ι) /
        (((Fintype.card ι).factorial : ℝ) * ∏ i, a i)) := by
  let e : Fin (Fintype.card ι) ≃ ι := (Fintype.equivFin ι).symm
  have hp := volume_measurePreserving_piCongrLeft (fun _ : ι => ℝ) e
  have he := hp.measure_preimage_equiv (weightedLogSimplex a R)
  have hpre : (MeasurableEquiv.piCongrLeft (fun _ : ι => ℝ) e) ⁻¹' weightedLogSimplex a R =
      weightedLogSimplex (fun j : Fin (Fintype.card ι) => a (e j)) R := by
    ext t
    simp only [mem_preimage, weightedLogSimplex, mem_setOf_eq,
      MeasurableEquiv.coe_piCongrLeft, Equiv.piCongrLeft_apply_eq_cast, cast_eq]
    have hcost : (∑ i : ι, a i * t (e.symm i)) =
        ∑ j : Fin (Fintype.card ι), a (e j) * t j := by
      simpa using (e.sum_comp (fun i => a i * t (e.symm i))).symm
    rw [hcost]
    constructor
    · rintro ⟨ht, hc⟩
      exact ⟨fun j => by simpa using ht (e j), hc⟩
    · rintro ⟨ht, hc⟩
      exact ⟨fun i => ht (e.symm i), hc⟩
  rw [hpre] at he
  rw [← he, weightedLogSimplex_volume_closed (Fintype.card ι)
    (fun j => a (e j)) (fun j => ha (e j)) R hR, e.prod_comp a]

theorem odd_reciprocal_family_le_closed_simplex_fintype {ι : Type*} [Fintype ι]
    (s : Finset (ι → ℕ)) (a : ι → ℝ) (R : ℝ) (ha : ∀ i, 0 < a i) (hR : 0 ≤ R)
    (hn : ∀ m ∈ s, ∀ i, 3 ≤ m i) (ho : ∀ m ∈ s, ∀ i, m i % 2 = 1)
    (hbudget : ∀ m ∈ s, (∑ i, a i * Real.log (m i)) ≤ R) :
    (∑ m ∈ s, ∏ i, 1 / (m i : ℝ)) ≤
      (R / 2) ^ (Fintype.card ι) /
        (((Fintype.card ι).factorial : ℝ) * ∏ i, a i) := by
  have h := odd_reciprocal_family_le_simplex_volume s a R (fun i => (ha i).le) hn ho hbudget
  rw [weightedLogSimplex_volume_closed_fintype a ha R hR,
    ← ENNReal.ofReal_mul (by positivity)] at h
  have hden : 0 < ((Fintype.card ι).factorial : ℝ) * (∏ i, a i) :=
    mul_pos (Nat.cast_pos.mpr (Nat.factorial_pos _)) (Finset.prod_pos (fun i _ => ha i))
  have hnonneg : 0 ≤ (1 / 2 : ℝ) ^ (Fintype.card ι) *
      (R ^ (Fintype.card ι) / (((Fintype.card ι).factorial : ℝ) * ∏ i, a i)) :=
    mul_nonneg (by positivity) (div_nonneg (pow_nonneg hR _) hden.le)
  have hreal := (ENNReal.ofReal_le_ofReal_iff hnonneg).mp h
  have heq : (1 / 2 : ℝ) ^ (Fintype.card ι) *
      (R ^ (Fintype.card ι) / (((Fintype.card ι).factorial : ℝ) * ∏ i, a i)) =
      (R / 2) ^ (Fintype.card ι) /
        (((Fintype.card ι).factorial : ℝ) * ∏ i, a i) := by
    simp only [div_pow, one_div, div_eq_mul_inv]
    ring
  exact heq ▸ hreal

#print axioms weightedLogSimplex_volume_closed_fintype
#print axioms odd_reciprocal_family_le_closed_simplex_fintype

end SimplexVolume

section Supports

variable {ι : Type*} [Fintype ι]

def activeSupport (m : ι → ℕ) : Finset ι := Finset.univ.filter (fun i => m i ≠ 1)

theorem activeSupport_reciprocal_product (I : Finset ι) (m : ι → ℕ)
    (hm : activeSupport m = I) :
    (∏ i : I, 1 / (m i : ℝ)) = ∏ i, 1 / (m i : ℝ) := by
  classical
  rw [Finset.prod_coe_sort I (fun i => 1 / (m i : ℝ))]
  apply Finset.prod_subset (Finset.subset_univ I)
  intro i _ hi
  have hm1 : m i = 1 := by
    by_contra h
    apply hi
    rw [← hm]
    simp [activeSupport, h]
  simp [hm1]

theorem activeSupport_log_budget (I : Finset ι) (m : ι → ℕ)
    (hm : activeSupport m = I) (a : ι → ℝ) :
    (∑ i : I, a i * Real.log (m i)) = ∑ i, a i * Real.log (m i) := by
  classical
  rw [Finset.sum_coe_sort I (fun i => a i * Real.log (m i))]
  apply Finset.sum_subset (Finset.subset_univ I)
  intro i _ hi
  have hm1 : m i = 1 := by
    by_contra h
    apply hi
    rw [← hm]
    simp [activeSupport, h]
  simp [hm1]

/-- Full discrete bound, including coordinates equal to one. -/
theorem odd_reciprocal_family_le_support_simplexes [DecidableEq ι]
    (s : Finset (ι → ℕ)) (a : ι → ℝ) (R : ℝ)
    (ha : ∀ i, 0 < a i) (hR : 0 ≤ R)
    (ho : ∀ m ∈ s, ∀ i, m i % 2 = 1)
    (hbudget : ∀ m ∈ s, (∑ i, a i * Real.log (m i)) ≤ R) :
    (∑ m ∈ s, ∏ i, 1 / (m i : ℝ)) ≤
      ∑ I : Finset ι, (R / 2) ^ I.card /
        ((I.card.factorial : ℝ) * (∏ i ∈ I, a i)) := by
  classical
  rw [← Finset.sum_fiberwise s activeSupport (fun m => ∏ i, 1 / (m i : ℝ))]
  apply Finset.sum_le_sum
  intro I _
  let sf := s.filter (fun m => activeSupport m = I)
  let f : (ι → ℕ) → (I → ℕ) := fun m i => m i
  have hinj : ∀ m ∈ sf, ∀ n ∈ sf, f m = f n → m = n := by
    intro m hm n hn hmn
    have hms := (Finset.mem_filter.mp hm).2
    have hns := (Finset.mem_filter.mp hn).2
    ext i
    by_cases hi : i ∈ I
    · exact congr_fun hmn ⟨i, hi⟩
    · have hm1 : m i = 1 := by
        by_contra h
        apply hi
        rw [← hms]
        simp [activeSupport, h]
      have hn1 : n i = 1 := by
        by_contra h
        apply hi
        rw [← hns]
        simp [activeSupport, h]
      rw [hm1, hn1]
  have hsum : (∑ u ∈ sf.image f, ∏ i : I, 1 / (u i : ℝ)) =
      ∑ m ∈ sf, ∏ i, 1 / (m i : ℝ) := by
    rw [Finset.sum_image hinj]
    apply Finset.sum_congr rfl
    intro m hm
    exact activeSupport_reciprocal_product I m (Finset.mem_filter.mp hm).2
  have h := odd_reciprocal_family_le_closed_simplex_fintype
    (sf.image f) (fun i : I => a i) R (fun i => ha i) hR ?_ ?_ ?_
  · rw [hsum] at h
    simpa only [Fintype.card_coe, Finset.prod_coe_sort] using h
  · intro u hu i
    obtain ⟨m, hm, rfl⟩ := Finset.mem_image.mp hu
    have hms := (Finset.mem_filter.mp hm).2
    have hom := ho m (Finset.mem_filter.mp hm).1 i
    have hneq : m i ≠ 1 := by
      have : (i : ι) ∈ activeSupport m := by rw [hms]; exact i.2
      simpa [activeSupport] using this
    change 3 ≤ m i
    omega
  · intro u hu i
    obtain ⟨m, hm, rfl⟩ := Finset.mem_image.mp hu
    exact ho m (Finset.mem_filter.mp hm).1 i
  · intro u hu
    obtain ⟨m, hm, rfl⟩ := Finset.mem_image.mp hu
    rw [activeSupport_log_budget I m (Finset.mem_filter.mp hm).2 a]
    exact hbudget m (Finset.mem_filter.mp hm).1

#print axioms odd_reciprocal_family_le_support_simplexes

end Supports

def goldbachSimplexWeightFn : Fin 7 → ℝ := ![2, 2, 3, 3, 3, 3, 4]

def goldbachSimplexIndices : List (Fin 7) := [0, 1, 2, 3, 4, 5, 6]

def goldbachIndexedSubsets : List (Finset (Fin 7)) :=
  goldbachSimplexIndices.sublists'.map List.toFinset

theorem goldbachSimplexWeightFn_pos : ∀ i, 0 < goldbachSimplexWeightFn i := by
  intro i
  fin_cases i
  all_goals first
    | (change (0 : ℝ) < 2; norm_num)
    | (change (0 : ℝ) < 3; norm_num)
    | (change (0 : ℝ) < 4; norm_num)

set_option maxRecDepth 4000 in
set_option maxHeartbeats 1000000 in
theorem goldbachSimplex_support_expansion (R : ℝ) :
    (∑ I : Finset (Fin 7), R ^ I.card /
      ((I.card.factorial : ℝ) * (∏ i ∈ I, goldbachSimplexWeightFn i))) =
      goldbachSimplexPolynomial R := by
  have hsub : goldbachIndexedSubsets.Nodup := by decide
  have huniv : (Finset.univ : Finset (Finset (Fin 7))) =
      goldbachIndexedSubsets.toFinset := by decide
  have hbase : goldbachSimplexIndices.map goldbachSimplexWeightFn =
      goldbachSimplexWeights := by rfl
  rw [huniv, List.sum_toFinset _ hsub]
  rw [← goldbachSimplexPolynomial_expansion]
  unfold goldbachIndexedSubsets subsetSimplexPolynomial
  rw [← hbase, List.sublists'_map, List.map_map, List.map_map]
  congr 1

theorem goldbach_odd_harmonic_family_le_polynomial (s : Finset (Fin 7 → ℕ))
    (R : ℝ) (hR : 0 ≤ R) (ho : ∀ m ∈ s, ∀ i, m i % 2 = 1)
    (hbudget : ∀ m ∈ s, (∑ i, goldbachSimplexWeightFn i * Real.log (m i)) ≤ R) :
    (∑ m ∈ s, ∏ i, 1 / (m i : ℝ)) ≤ goldbachSimplexPolynomial (R / 2) := by
  have h := odd_reciprocal_family_le_support_simplexes s goldbachSimplexWeightFn R
    goldbachSimplexWeightFn_pos hR ho hbudget
  rw [goldbachSimplex_support_expansion] at h
  exact h

theorem goldbach_odd_harmonic_log_family_le_polynomial (s : Finset (Fin 7 → ℕ))
    (Q : ℝ) (hQ : 1 ≤ Q) (ho : ∀ m ∈ s, ∀ i, m i % 2 = 1)
    (hbudget : ∀ m ∈ s,
      (∑ i, goldbachSimplexWeightFn i * Real.log (m i)) ≤ 4 * Real.log Q) :
    (∑ m ∈ s, ∏ i, 1 / (m i : ℝ)) ≤ goldbachSimplexPolynomial (2 * Real.log Q) := by
  have hlog := Real.log_nonneg hQ
  have h := goldbach_odd_harmonic_family_le_polynomial s (4 * Real.log Q)
    (by positivity) ho hbudget
  have heq : 4 * Real.log Q / 2 = 2 * Real.log Q := by ring
  simpa only [heq] using h

#print axioms goldbachSimplex_support_expansion
#print axioms goldbach_odd_harmonic_log_family_le_polynomial

end GoldbachResearch
