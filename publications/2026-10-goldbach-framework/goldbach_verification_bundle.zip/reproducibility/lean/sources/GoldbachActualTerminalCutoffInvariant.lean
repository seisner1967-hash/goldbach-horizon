import GoldbachVaughan

/-!
Actual finite terminal arithmetic is invariant under the Vaughan U-cut.
The modulus cap, strict cofactor boundary, unit masks, genuine mu and
beta coefficients are retained. This gives no upper bound for the
terminal arithmetic and does not prove the covered-sector bridge.
-/
namespace GoldbachResearch.ActualTerminalCutoffInvariant

open scoped BigOperators
open GoldbachResearch

noncomputable def smallCoefficient (U V : ℕ) : ArithmeticFunction ℝ :=
  Vaughan.cutLE U Vaughan.mu * Vaughan.beta V

noncomputable def literalKernel (N alpha Q n : ℕ) : ℝ :=
  if Nat.Coprime n N then
    ActualArithmetic.muReal (N - n) *
      ((∑ k ∈ (N - n).divisors,
          if k ≤ Q ∧ alpha * k < N - n then
            ActualArithmetic.muReal k * Real.log ((k : ℝ) / (N - n : ℕ))
          else 0) -
       ∑ k ∈ Finset.Icc 1 Q,
          if Nat.Coprime k N ∧ Nat.Coprime n k ∧ alpha * k < N - n then
            ActualArithmetic.muReal k / (Nat.totient k : ℝ) *
              Real.log ((k : ℝ) / (N - n : ℕ))
          else 0)
  else 0

noncomputable def fullRow (N alpha Q U V : ℕ) : ℝ :=
  ∑ n ∈ Finset.range N,
    Vaughan.typeTwo U V n * literalKernel N alpha Q n

noncomputable def smallRow (N alpha Q U V : ℕ) : ℝ :=
  ∑ n ∈ Finset.range N,
    smallCoefficient U V n * literalKernel N alpha Q n

noncomputable def primeRow (N alpha Q V : ℕ) : ℝ :=
  ∑ n ∈ Finset.range N,
    Vaughan.cutGT V ArithmeticFunction.vonMangoldt n *
      literalKernel N alpha Q n

/-- This is the ledger's D only after its exact covered bridge is established. -/
noncomputable def ledgerDeficit (N alpha Q U V : ℕ) (e : ℝ) : ℝ :=
  -fullRow N alpha Q U V + e + |e|

private theorem coefficients_complete (U V : ℕ) :
    Vaughan.typeTwo U V + smallCoefficient U V =
      Vaughan.cutGT V ArithmeticFunction.vonMangoldt := by
  have hmu : Vaughan.mu * Vaughan.zeta = 1 :=
    ArithmeticFunction.coe_moebius_mul_coe_zeta
  have hsplit : Vaughan.cutGT U Vaughan.mu + Vaughan.cutLE U Vaughan.mu =
      Vaughan.mu := by
    rw [add_comm]
    exact (Vaughan.cut_split U Vaughan.mu).symm
  unfold Vaughan.typeTwo smallCoefficient Vaughan.beta
  rw [mul_assoc, ← add_mul, hsplit]
  calc
    Vaughan.mu * (Vaughan.cutGT V ArithmeticFunction.vonMangoldt * Vaughan.zeta) =
        (Vaughan.mu * Vaughan.zeta) *
          Vaughan.cutGT V ArithmeticFunction.vonMangoldt := by ring
    _ = _ := by rw [hmu, one_mul]

/-- Exact finite completion with the original moving kernel, without norms. -/
theorem actual_rows_complete (N alpha Q U V : ℕ) :
    fullRow N alpha Q U V + smallRow N alpha Q U V =
      primeRow N alpha Q V := by
  unfold fullRow smallRow primeRow
  rw [← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro n hn
  have h := congrArg (fun f : ArithmeticFunction ℝ => f n)
    (coefficients_complete U V)
  change Vaughan.typeTwo U V n + smallCoefficient U V n =
    Vaughan.cutGT V ArithmeticFunction.vonMangoldt n at h
  rw [← add_mul, h]

/-- The true terminal defect retains the signed e correction. -/
theorem actual_terminal_defect (N alpha Q U V : ℕ) (e : ℝ) :
    ledgerDeficit N alpha Q U V e - smallRow N alpha Q U V =
      -primeRow N alpha Q V + e + |e| := by
  have h := actual_rows_complete N alpha Q U V
  unfold ledgerDeficit
  linarith

/-- Changing U alone merely transfers between Type I and Type II. -/
theorem actual_terminal_U_invariant (N alpha Q U U' V : ℕ) (e e' : ℝ) :
    (ledgerDeficit N alpha Q U V e - smallRow N alpha Q U V) -
      (ledgerDeficit N alpha Q U' V e' - smallRow N alpha Q U' V) =
        (e + |e|) - (e' + |e'|) := by
  rw [actual_terminal_defect, actual_terminal_defect]
  ring

#print axioms actual_rows_complete
#print axioms actual_terminal_defect
#print axioms actual_terminal_U_invariant

end GoldbachResearch.ActualTerminalCutoffInvariant
