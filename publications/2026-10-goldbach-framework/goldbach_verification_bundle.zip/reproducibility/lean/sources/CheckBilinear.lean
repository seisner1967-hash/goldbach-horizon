import GoldbachSignedKernel
open scoped BigOperators
#check Finset.sum_product
#check Finset.sum_product'
#check Finset.sum_mul_sq_le_sq_mul_sq
example (t : Finset ℕ) (f : ℕ × ℕ → ℝ) :
    (∑ x ∈ t.product t, f x) = ∑ a ∈ t, ∑ b ∈ t, f (a,b) := by
  exact Finset.sum_product t t f
set_option pp.all true in
example {J : Type*} (t : Finset J) (beta : J → ℝ) :
    (∑ x ∈ t.product t, (beta x.1 * beta x.2)^2) = (∑ b ∈ t, beta b^2)^2 := by
  classical
  rw [Finset.sum_product' t t (fun x y : J => (beta x * beta y)^2)]
  simp_rw [mul_pow, ← Finset.mul_sum, ← Finset.sum_mul]
  rfl
