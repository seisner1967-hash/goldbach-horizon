import Mathlib.Tactic
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Data.Nat.GCD.BigOperators

/-!
Exact integer boundary convention for the Rosser remainder.
Phi uses primes STRICTLY below z, whereas I_W excludes primes <= W.
This module certifies finite support logic only. It does not prove the
Rosser coefficient identity, its analytic density estimate, or Goldbach.
-/

namespace GoldbachResearch.RosserBoundary

open scoped BigOperators

noncomputable section

def primeSet (z : ℕ) : Finset ℕ := (Finset.range z).filter Nat.Prime

def primorial (z : ℕ) : ℕ := ∏ p ∈ primeSet z, p

def RoughLT (n z : ℕ) : Prop := ∀ p, Nat.Prime p → p < z → ¬ p ∣ n

def RoughLE (n W : ℕ) : Prop := ∀ p, Nat.Prime p → p ≤ W → ¬ p ∣ n

def Phi (n z : ℕ) : ℕ := by
  classical
  exact if RoughLT n z then 1 else 0

def I (n W : ℕ) : ℕ := by
  classical
  exact if RoughLE n W then 1 else 0

theorem roughLE_iff_roughLT_succ (n W : ℕ) :
    RoughLE n W ↔ RoughLT n (W + 1) := by
  simp only [RoughLE, RoughLT, Nat.lt_succ_iff]

theorem I_eq_Phi_succ (n W : ℕ) : I n W = Phi n (W + 1) := by
  unfold I Phi
  rw [← roughLE_iff_roughLT_succ]

theorem roughLT_iff_coprime_primorial (n z : ℕ) :
    RoughLT n z ↔ Nat.Coprime n (primorial z) := by
  classical
  rw [primorial, Nat.coprime_prod_right_iff]
  constructor
  · intro hn p hp
    have h := Finset.mem_filter.mp hp
    exact (h.2.coprime_iff_not_dvd.mpr
      (hn p h.2 (Finset.mem_range.mp h.1))).symm
  · intro hn p hp hz
    have hmem : p ∈ primeSet z := by simp [primeSet, hp, hz]
    exact hp.coprime_iff_not_dvd.mp (hn p hmem).symm

theorem Phi_eq_coprime_indicator (n z : ℕ) :
    Phi n z = if Nat.Coprime n (primorial z) then 1 else 0 := by
  simp only [Phi, roughLT_iff_coprime_primorial]

theorem roughLT_minFac_self {e : ℕ} (_he : e ≠ 1) :
    RoughLT e (Nat.minFac e) := by
  intro p hp hlt hdvd
  have hle := Nat.minFac_le_of_dvd hp.two_le hdvd
  omega

theorem Phi_minFac_self {e : ℕ} (he : e ≠ 1) :
    Phi e (Nat.minFac e) = 1 := by
  simp [Phi, roughLT_minFac_self he]

theorem I_minFac_of_dvd {e n : ℕ} (he : e ≠ 1) (hen : e ∣ n) :
    I n (Nat.minFac e) = 0 := by
  have hp := Nat.minFac_prime he
  have hdvd : Nat.minFac e ∣ n := (Nat.minFac_dvd e).trans hen
  have hnot : ¬ RoughLE n (Nat.minFac e) := by
    intro h
    exact h (Nat.minFac e) hp (le_refl _) hdvd
  simp [I, hnot]

theorem strict_inclusive_boundary_distinct {e : ℕ} (he : e ≠ 1) :
    Phi e (Nat.minFac e) ≠ I e (Nat.minFac e) := by
  rw [Phi_minFac_self he, I_minFac_of_dvd he (dvd_refl e)]
  decide

theorem incorrect_remainder_is_zero
    (s : Finset ℕ) (sigma : ℕ → ℝ) (n : ℕ)
    (h_one : ∀ e ∈ s, e ≠ 1) :
    (∑ e ∈ s, sigma e *
      (if e ∣ n then (I n (Nat.minFac e) : ℝ) else 0)) = 0 := by
  classical
  apply Finset.sum_eq_zero
  intro e he
  by_cases hdvd : e ∣ n
  · simp [hdvd, I_minFac_of_dvd (h_one e he) hdvd]
  · simp [hdvd]

theorem prime_boundary_counterexample {p : ℕ} (hp : Nat.Prime p) :
    Phi p p = 1 ∧ I p p = 0 := by
  have hlt : RoughLT p p := by
    intro q hq hqp hqdiv
    have hqp_eq : q = p := (Nat.dvd_prime hp).mp hqdiv |>.resolve_left hq.ne_one
    omega
  have hnot : ¬ RoughLE p p := by
    intro h
    exact h p hp (le_refl p) (dvd_refl p)
  simp [Phi, I, hlt, hnot]

#print axioms roughLE_iff_roughLT_succ
#print axioms I_eq_Phi_succ
#print axioms roughLT_iff_coprime_primorial
#print axioms Phi_eq_coprime_indicator
#print axioms roughLT_minFac_self
#print axioms Phi_minFac_self
#print axioms I_minFac_of_dvd
#print axioms strict_inclusive_boundary_distinct
#print axioms incorrect_remainder_is_zero
#print axioms prime_boundary_counterexample

end
end GoldbachResearch.RosserBoundary
