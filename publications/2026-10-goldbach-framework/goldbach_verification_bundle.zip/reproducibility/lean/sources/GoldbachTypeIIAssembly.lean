import GoldbachVaughan
import GoldbachBilinear

/-!
# The actual signed Type II row as a rectangular bilinear sum

The change of summation indices is proved rather than supplied as a premise.
The actual row vanishes at product zero and outside the target; hence a full
finite rectangle represents exactly the original hyperbolic divisor sum.
-/

namespace GoldbachResearch.TypeIIAssembly

open scoped BigOperators
open Finset ActualArithmetic

/-- A finite divisor-antidiagonal reindexing with explicit zero support. -/
theorem divisor_sum_eq_rectangle (N : ℕ) (f : ℕ × ℕ → ℝ)
    (hfzero : ∀ p, p.1 * p.2 = 0 → f p = 0)
    (hfoutside : ∀ p, N ≤ p.1 * p.2 → f p = 0) :
    (∑ n ∈ range N, ∑ p ∈ n.divisorsAntidiagonal, f p) =
      ∑ p ∈ (range N).product (range N), f p := by
  classical
  let s := (range N).sigma (fun n => n.divisorsAntidiagonal)
  let t := ((range N).product (range N)).filter
    (fun p => p.1 * p.2 ≠ 0 ∧ p.1 * p.2 < N)
  have hbij : (∑ x ∈ s, f x.2) = ∑ p ∈ t, f p := by
    apply Finset.sum_bij (fun x _ => x.2)
    · intro x hx
      have hx' := Finset.mem_sigma.mp hx
      have hp := Nat.mem_divisorsAntidiagonal.mp hx'.2
      have hn : x.1 < N := Finset.mem_range.mp hx'.1
      have hp0 : x.2.1 * x.2.2 ≠ 0 := by simpa [hp.1] using hp.2
      have ha0 : 0 < x.2.1 := Nat.pos_of_ne_zero (by
        intro ha
        simp [ha] at hp0)
      have hb0 : 0 < x.2.2 := Nat.pos_of_ne_zero (by
        intro hb
        simp [hb] at hp0)
      have ha : x.2.1 < N :=
        lt_of_le_of_lt (Nat.le_mul_of_pos_right _ hb0) (by omega)
      have hb : x.2.2 < N :=
        lt_of_le_of_lt (Nat.le_mul_of_pos_left _ ha0) (by omega)
      exact Finset.mem_filter.mpr
        ⟨Finset.mem_product.mpr ⟨Finset.mem_range.mpr ha, Finset.mem_range.mpr hb⟩,
          hp0, by omega⟩
    · intro x hx y hy hxy
      rcases x with ⟨n, p⟩
      rcases y with ⟨m, q⟩
      have hp : p.1 * p.2 = n :=
        (Nat.mem_divisorsAntidiagonal.mp (Finset.mem_sigma.mp hx).2).1
      have hq : q.1 * q.2 = m :=
        (Nat.mem_divisorsAntidiagonal.mp (Finset.mem_sigma.mp hy).2).1
      change p = q at hxy
      subst q
      have hnm : n = m := by omega
      subst m
      simp only [hnm]
    · intro p hp
      have hp' := Finset.mem_filter.mp hp
      refine ⟨⟨p.1 * p.2, p⟩, ?_, rfl⟩
      apply Finset.mem_sigma.mpr
      exact ⟨Finset.mem_range.mpr hp'.2.2,
        Nat.mem_divisorsAntidiagonal.mpr ⟨rfl, hp'.2.1⟩⟩
    · intro x hx
      rfl
  have hext : (∑ p ∈ t, f p) =
      ∑ p ∈ (range N).product (range N), f p := by
    apply Finset.sum_subset (Finset.filter_subset _ _)
    intro p hp hpt
    have hbad : ¬(p.1 * p.2 ≠ 0 ∧ p.1 * p.2 < N) := by
      intro h
      exact hpt (Finset.mem_filter.mpr ⟨hp, h⟩)
    by_cases hz : p.1 * p.2 = 0
    · exact hfzero p hz
    · exact hfoutside p (by omega)
  calc
    _ = ∑ x ∈ s, f x.2 := by rw [Finset.sum_sigma]
    _ = ∑ p ∈ t, f p := hbij
    _ = _ := hext

noncomputable def vaughanAlpha (U a : ℕ) : ℝ :=
  if U < a then Vaughan.mu a else 0

/-- Exact assembly of the genuine Vaughan row and the signed box machinery. -/
theorem actual_signedRow_typeTwo_eq_bilinear (N cutoff k U V : ℕ) :
    Vaughan.signedRow N cutoff k (Vaughan.typeTwo U V) =
      Bilinear.bilinearSum (range N) (range N) (vaughanAlpha U)
        (Vaughan.beta V) (Bilinear.actualTypeIIKernel N cutoff k) := by
  rw [Vaughan.signedRow_typeTwo_bilinear]
  let f : ℕ × ℕ → ℝ := fun p =>
    (if U < p.1 then Vaughan.mu p.1 else 0) * Vaughan.beta V p.2 *
      muReal (N - p.1 * p.2) * actualRow N cutoff k (p.1 * p.2)
  have hz : ∀ p, p.1 * p.2 = 0 → f p = 0 := by
    intro p hp
    simp [f, hp, actualRow_zero_at_zero]
  have ho : ∀ p, N ≤ p.1 * p.2 → f p = 0 := by
    intro p hp
    simp [f, actualRow_zero_outside_target hp]
  rw [divisor_sum_eq_rectangle N f hz ho]
  have hprod : (∑ p ∈ (range N).product (range N), f p) =
      ∑ a ∈ range N, ∑ b ∈ range N, f (a, b) :=
    Finset.sum_product (range N) (range N) f
  rw [hprod]
  unfold Bilinear.bilinearSum Bilinear.actualTypeIIKernel vaughanAlpha
  apply Finset.sum_congr rfl
  intro a ha
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro b hb
  dsimp [f]
  ring

/-- The exact signed fourth-moment bound for the actual Type II row. -/
theorem actual_signedRow_typeTwo_fourth_le_signed_box (N cutoff k U V : ℕ) :
    Vaughan.signedRow N cutoff k (Vaughan.typeTwo U V) ^ 4 ≤
      Bilinear.coefficientMass (range N) (vaughanAlpha U) ^ 2 *
      Bilinear.coefficientMass (range N) (Vaughan.beta V) ^ 2 *
      Bilinear.signedBox (range N) (range N)
        (Bilinear.actualTypeIIKernel N cutoff k) := by
  rw [actual_signedRow_typeTwo_eq_bilinear]
  exact Bilinear.actualTypeII_fourth_le_signed_box (range N) (range N)
    N cutoff k (vaughanAlpha U) (Vaughan.beta V)

def activeFirst (N U : ℕ) : Finset ℕ :=
  (range N).filter (fun a => U < a)

def activeSecond (N V : ℕ) : Finset ℕ :=
  (range N).filter (fun b => V < b)

/-- Inactive Vaughan rows and columns can be removed exactly from the box
representation. This yields the actual smaller target for signed estimates. -/
theorem actual_signedRow_typeTwo_eq_active_bilinear (N cutoff k U V : ℕ) :
    Vaughan.signedRow N cutoff k (Vaughan.typeTwo U V) =
      Bilinear.bilinearSum (activeFirst N U) (activeSecond N V) muReal
        (Vaughan.beta V) (Bilinear.actualTypeIIKernel N cutoff k) := by
  rw [actual_signedRow_typeTwo_eq_bilinear]
  have hfirst :
      Bilinear.bilinearSum (range N) (range N) (vaughanAlpha U)
        (Vaughan.beta V) (Bilinear.actualTypeIIKernel N cutoff k) =
      Bilinear.bilinearSum (activeFirst N U) (range N) muReal
        (Vaughan.beta V) (Bilinear.actualTypeIIKernel N cutoff k) := by
    unfold Bilinear.bilinearSum activeFirst
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro a ha
    by_cases hu : U < a
    · simp only [vaughanAlpha, if_pos hu]
      rfl
    · simp [vaughanAlpha, hu]
  rw [hfirst]
  unfold Bilinear.bilinearSum
  apply Finset.sum_congr rfl
  intro a ha
  congr 1
  symm
  apply Finset.sum_subset (Finset.filter_subset _ _)
  intro b hb hbnot
  have hble : b ≤ V := by
    have hbad : ¬V < b := by
      intro h
      exact hbnot (Finset.mem_filter.mpr ⟨hb, h⟩)
    omega
  rw [Vaughan.beta_zero_of_le hble, zero_mul]

theorem actual_signedRow_typeTwo_fourth_le_active_signed_box (N cutoff k U V : ℕ) :
    Vaughan.signedRow N cutoff k (Vaughan.typeTwo U V) ^ 4 ≤
      Bilinear.coefficientMass (activeFirst N U) muReal ^ 2 *
      Bilinear.coefficientMass (activeSecond N V) (Vaughan.beta V) ^ 2 *
      Bilinear.signedBox (activeFirst N U) (activeSecond N V)
        (Bilinear.actualTypeIIKernel N cutoff k) := by
  rw [actual_signedRow_typeTwo_eq_active_bilinear]
  exact Bilinear.actualTypeII_fourth_le_signed_box (activeFirst N U) (activeSecond N V)
    N cutoff k muReal (Vaughan.beta V)

/-- The specific Moebius coefficient is retained inside this dispersion
energy, rather than replaced by arbitrary normalized coefficients. -/
noncomputable def actualSignedDispersion (N cutoff k U V : ℕ) : ℝ :=
  Bilinear.rowEnergy (activeSecond N V) (activeFirst N U) muReal
    (fun b a => Bilinear.actualTypeIIKernel N cutoff k a b)

theorem actual_signedRow_typeTwo_sq_le_signed_dispersion (N cutoff k U V : ℕ) :
    Vaughan.signedRow N cutoff k (Vaughan.typeTwo U V) ^ 2 ≤
      Bilinear.coefficientMass (activeSecond N V) (Vaughan.beta V) *
        actualSignedDispersion N cutoff k U V := by
  rw [actual_signedRow_typeTwo_eq_active_bilinear]
  exact Bilinear.bilinear_sq_le_beta_mass_signed_dispersion
    (activeFirst N U) (activeSecond N V) muReal (Vaughan.beta V)
    (Bilinear.actualTypeIIKernel N cutoff k)

/-- The exact dispersion retains the two coefficient Moebius signs and
the two complementary Moebius signs. -/
theorem actualSignedDispersion_eq_four_moebius_signs (N cutoff k U V : ℕ) :
    actualSignedDispersion N cutoff k U V =
      ∑ a ∈ activeFirst N U, ∑ c ∈ activeFirst N U,
        muReal a * muReal c * ∑ b ∈ activeSecond N V,
          muReal (N - a * b) * muReal (N - c * b) *
            actualRow N cutoff k (a * b) * actualRow N cutoff k (c * b) := by
  unfold actualSignedDispersion
  rw [Bilinear.signed_dispersion_eq_alpha_correlations]
  apply Finset.sum_congr rfl
  intro a ha
  apply Finset.sum_congr rfl
  intro c hc
  congr 1
  apply Finset.sum_congr rfl
  intro b hb
  unfold Bilinear.actualTypeIIKernel
  ring

end GoldbachResearch.TypeIIAssembly

#print axioms GoldbachResearch.TypeIIAssembly.divisor_sum_eq_rectangle
#print axioms GoldbachResearch.TypeIIAssembly.actual_signedRow_typeTwo_eq_bilinear
#print axioms GoldbachResearch.TypeIIAssembly.actual_signedRow_typeTwo_fourth_le_signed_box
#print axioms GoldbachResearch.TypeIIAssembly.actual_signedRow_typeTwo_eq_active_bilinear
#print axioms GoldbachResearch.TypeIIAssembly.actual_signedRow_typeTwo_fourth_le_active_signed_box
#print axioms GoldbachResearch.TypeIIAssembly.actual_signedRow_typeTwo_sq_le_signed_dispersion
#print axioms GoldbachResearch.TypeIIAssembly.actualSignedDispersion_eq_four_moebius_signs
