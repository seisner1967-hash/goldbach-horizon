import GoldbachMass
import GoldbachSimplex

/-! Positive divisor profiles transport the actual squarefree totient weight
to odd harmonic families. The harmonic budget is a premise of the generic
transport lemma, not an asserted arithmetic off-diagonal estimate. -/

namespace GoldbachResearch.CompressedMass

open scoped BigOperators
open Mass

variable {ι : Type*} [Fintype ι]

noncomputable def weight (n : ℕ) : ℝ := (n : ℝ) / (n.totient : ℝ) ^ 2

theorem weight_nonneg (n : ℕ) : 0 ≤ weight n := by unfold weight; positivity

theorem multiples_family_harmonic (s : Finset (ι → ℕ)) (d : ι → ℕ)
    (a : ι → ℝ) (R C : ℝ) (hd : ∀ i, 0 < d i) (ha : ∀ i, 0 ≤ a i)
    (hs : ∀ n ∈ s, (∀ i, Odd (n i) ∧ 0 < n i) ∧
      (∑ i, a i * Real.log (n i)) ≤ R)
    (hC : ∀ u : Finset (ι → ℕ),
      (∀ m ∈ u, (∀ i, Odd (m i) ∧ 0 < m i) ∧
        (∑ i, a i * Real.log (m i)) ≤ R) →
      (∑ m ∈ u, ∏ i, 1 / (m i : ℝ)) ≤ C) :
    (∑ n ∈ s.filter (fun n => ∀ i, d i ∣ n i), ∏ i, 1 / (n i : ℝ)) ≤
      (∏ i, 1 / (d i : ℝ)) * C := by
  classical
  let u := s.filter (fun n => ∀ i, d i ∣ n i)
  let v := u.image (fun n i => n i / d i)
  have hdiv (n : ι → ℕ) (hn : n ∈ u) (i : ι) : d i ∣ n i :=
    (Finset.mem_filter.mp hn).2 i
  have hinj : Set.InjOn (fun n : ι → ℕ => fun i => n i / d i) (u : Set (ι → ℕ)) := by
    intro n hn m hm heq
    funext i
    have hi := congrFun heq i
    change n i / d i = m i / d i at hi
    have hn' := Nat.mul_div_cancel' (hdiv n hn i)
    have hm' := Nat.mul_div_cancel' (hdiv m hm i)
    rw [hi] at hn'
    exact hn'.symm.trans hm'
  have hv : ∀ m ∈ v, (∀ i, Odd (m i) ∧ 0 < m i) ∧
      (∑ i, a i * Real.log (m i)) ≤ R := by
    intro m hm
    obtain ⟨n, hn, rfl⟩ := Finset.mem_image.mp hm
    have hh := hs n (Finset.mem_filter.mp hn).1
    have hpos (i : ι) : 0 < n i / d i := by
      exact Nat.div_pos (Nat.le_of_dvd (hh.1 i).2 (hdiv n hn i)) (hd i)
    constructor
    · intro i
      have hmul := Nat.mul_div_cancel' (hdiv n hn i)
      have ho : Odd (d i * (n i / d i)) := by simpa only [hmul] using (hh.1 i).1
      exact ⟨(Nat.odd_mul.mp ho).2, hpos i⟩
    · apply le_trans _ hh.2
      apply Finset.sum_le_sum
      intro i hi
      apply mul_le_mul_of_nonneg_left _ (ha i)
      apply Real.log_le_log (by exact_mod_cast hpos i)
      exact_mod_cast Nat.div_le_self (n i) (d i)
  have heq : (∑ n ∈ u, ∏ i, 1 / (n i : ℝ)) =
      (∏ i, 1 / (d i : ℝ)) * (∑ m ∈ v, ∏ i, 1 / (m i : ℝ)) := by
    rw [Finset.mul_sum, Finset.sum_image hinj]
    apply Finset.sum_congr rfl
    intro n hn
    rw [← Finset.prod_mul_distrib]
    apply Finset.prod_congr rfl
    intro i hi
    have hdR : (d i : ℝ) ≠ 0 := by exact_mod_cast (hd i).ne'
    rw [Nat.cast_div (hdiv n hn i) hdR]
    field_simp
  change (∑ n ∈ u, ∏ i, 1 / (n i : ℝ)) ≤ _
  rw [heq]
  exact mul_le_mul_of_nonneg_left (hC v hv) (Finset.prod_nonneg (fun _ _ => by positivity))

#print axioms multiples_family_harmonic

theorem divisor_profile_compression (P : Finset ℕ) (s : Finset (ι → ℕ))
    (a : ι → ℝ) (R C : ℝ) (hP : ∀ p ∈ P, Nat.Prime p)
    (ha : ∀ i, 0 ≤ a i)
    (hs : ∀ n ∈ s, (∀ i, Odd (n i) ∧ Squarefree (n i) ∧
      (n i).primeFactors ⊆ P) ∧ (∑ i, a i * Real.log (n i)) ≤ R)
    (hC : ∀ u : Finset (ι → ℕ),
      (∀ m ∈ u, (∀ i, Odd (m i) ∧ 0 < m i) ∧
        (∑ i, a i * Real.log (m i)) ≤ R) →
      (∑ m ∈ u, ∏ i, 1 / (m i : ℝ)) ≤ C) :
    (∑ n ∈ s, ∏ i, weight (n i)) ≤
      (∏ p ∈ P, (1 + primeCorrection p / (p : ℝ))) ^ Fintype.card ι * C := by
  classical
  let profiles := Fintype.piFinset (fun _ : ι => P.powerset)
  let d := fun (t : ι → Finset ℕ) i => ∏ p ∈ t i, p
  have hfirst : (∑ n ∈ s, ∏ i, weight (n i)) ≤
      ∑ n ∈ s, ∏ i, subsetDivisorMajorant P (n i) := by
    apply Finset.sum_le_sum
    intro n hn
    apply Finset.prod_le_prod
    · intro i hi
      exact weight_nonneg (n i)
    · intro i hi
      exact squarefree_weight_le_majorant P (n i) hP ((hs n hn).1 i).2.1
        ((hs n hn).1 i).2.2
  have hterm (t : ι → Finset ℕ) (ht : t ∈ profiles) :
      (∑ n ∈ s, ∏ i, if d t i ∣ n i then correctionProduct (t i) / (n i : ℝ) else 0) ≤
        (∏ i, correctionProduct (t i) / (d t i : ℝ)) * C := by
    have hsub (i : ι) : t i ⊆ P :=
      Finset.mem_powerset.mp (Fintype.mem_piFinset.mp ht i)
    have hd (i : ι) : 0 < d t i :=
      Finset.prod_pos (fun p hp => (hP p (hsub i hp)).pos)
    have hc : 0 ≤ ∏ i, correctionProduct (t i) :=
      Finset.prod_nonneg (fun i _ => correctionProduct_nonneg P (t i) hP (hsub i))
    have he (n : ι → ℕ) :
        (∏ i, if d t i ∣ n i then correctionProduct (t i) / (n i : ℝ) else 0) =
          if (∀ i, d t i ∣ n i) then
            (∏ i, correctionProduct (t i)) * (∏ i, 1 / (n i : ℝ)) else 0 := by
      by_cases hn : ∀ i, d t i ∣ n i
      · rw [if_pos hn]
        simp only [if_pos (hn _), div_eq_mul_inv, one_mul, one_div]
        rw [Finset.prod_mul_distrib]
      · rw [if_neg hn]
        obtain ⟨i, hi⟩ := not_forall.mp hn
        apply Finset.prod_eq_zero (Finset.mem_univ i)
        simp [hi]
    have hh := multiples_family_harmonic s (d t) a R C hd ha
      (fun n hn => ⟨fun i => ⟨((hs n hn).1 i).1,
        Nat.pos_of_ne_zero ((hs n hn).1 i).2.1.ne_zero⟩, (hs n hn).2⟩) hC
    calc
      (∑ n ∈ s, ∏ i, if d t i ∣ n i then correctionProduct (t i) / (n i : ℝ) else 0) =
          (∏ i, correctionProduct (t i)) *
            (∑ n ∈ s.filter (fun n => ∀ i, d t i ∣ n i), ∏ i, 1 / (n i : ℝ)) := by
        simp_rw [he]
        rw [Finset.mul_sum, Finset.sum_filter]
      _ ≤ (∏ i, correctionProduct (t i)) * ((∏ i, 1 / (d t i : ℝ)) * C) :=
        mul_le_mul_of_nonneg_left hh hc
      _ = (∏ i, correctionProduct (t i) / (d t i : ℝ)) * C := by
        rw [← mul_assoc, ← Finset.prod_mul_distrib]
        simp only [mul_one_div]
  have hmass : (∑ t ∈ profiles, ∏ i, correctionProduct (t i) / (d t i : ℝ)) =
      (∏ p ∈ P, (1 + primeCorrection p / (p : ℝ))) ^ Fintype.card ι := by
    change (∑ t ∈ Fintype.piFinset (fun _ : ι => P.powerset),
      ∏ i, correctionProduct (t i) / ((∏ p ∈ t i, p : ℕ) : ℝ)) = _
    rw [← Finset.prod_univ_sum (fun _ : ι => P.powerset)
      (fun _ t => correctionProduct t / ((∏ p ∈ t, p : ℕ) : ℝ))]
    have hi : (∑ t ∈ P.powerset, correctionProduct t / ((∏ p ∈ t, p : ℕ) : ℝ)) =
        ∏ p ∈ P, (1 + primeCorrection p / (p : ℝ)) := by
      rw [Finset.prod_one_add]
      apply Finset.sum_congr rfl
      intro t ht
      rw [Finset.prod_div_distrib, ← Nat.cast_prod]
      rfl
    simp only [hi, Finset.prod_const, Finset.card_univ]
  apply hfirst.trans
  unfold subsetDivisorMajorant
  simp_rw [Finset.prod_univ_sum]
  rw [Finset.sum_comm]
  change (∑ t ∈ profiles, ∑ n ∈ s,
      ∏ i, if d t i ∣ n i then correctionProduct (t i) / (n i : ℝ) else 0) ≤ _
  calc
    _ ≤ ∑ t ∈ profiles, (∏ i, correctionProduct (t i) / (d t i : ℝ)) * C :=
      Finset.sum_le_sum hterm
    _ = _ := by rw [← Finset.sum_mul, hmass]

#print axioms divisor_profile_compression

theorem actual_odd_compressed_mass (s : Finset (ι → ℕ)) (Q : ℕ)
    (a : ι → ℝ) (R C : ℝ) (ha : ∀ i, 0 ≤ a i)
    (hs : ∀ n ∈ s, (∀ i, Odd (n i) ∧ Squarefree (n i) ∧ n i ≤ Q) ∧
      (∑ i, a i * Real.log (n i)) ≤ R)
    (hC : ∀ u : Finset (ι → ℕ),
      (∀ m ∈ u, (∀ i, Odd (m i) ∧ 0 < m i) ∧
        (∑ i, a i * Real.log (m i)) ≤ R) →
      (∑ m ∈ u, ∏ i, 1 / (m i : ℝ)) ≤ C) :
    (∑ n ∈ s, ∏ i, weight (n i)) ≤ oddEulerMass Q ^ Fintype.card ι * C := by
  rw [oddEulerMass_eq]
  apply divisor_profile_compression (oddPrimes Q) s a R C
  · intro p hp
    exact (mem_oddPrimes.mp hp).2.1
  · exact ha
  · intro n hn
    refine ⟨?_, (hs n hn).2⟩
    intro i
    have hi := (hs n hn).1 i
    exact ⟨hi.1, hi.2.1, odd_primeFactors_subset hi.2.1 hi.1 hi.2.2⟩
  · exact hC

#print axioms actual_odd_compressed_mass

theorem actual_odd_weighted_simplex_mass [DecidableEq ι]
    (s : Finset (ι → ℕ)) (Q : ℕ) (a : ι → ℝ) (R : ℝ)
    (ha : ∀ i, 0 < a i) (hR : 0 ≤ R)
    (hs : ∀ n ∈ s, (∀ i, Odd (n i) ∧ Squarefree (n i) ∧ n i ≤ Q) ∧
      (∑ i, a i * Real.log (n i)) ≤ R) :
    (∑ n ∈ s, ∏ i, weight (n i)) ≤ oddEulerMass Q ^ Fintype.card ι *
      (∑ I : Finset ι, (R / 2) ^ I.card /
        ((I.card.factorial : ℝ) * (∏ i ∈ I, a i))) := by
  apply actual_odd_compressed_mass s Q a R _ (fun i => (ha i).le) hs
  intro u hu
  apply odd_reciprocal_family_le_support_simplexes u a R ha hR
  · intro m hm i
    exact Nat.odd_iff.mp ((hu m hm).1 i).1
  · intro m hm
    exact (hu m hm).2

#print axioms actual_odd_weighted_simplex_mass

end GoldbachResearch.CompressedMass
