import GoldbachArithmetic
import Mathlib.Analysis.SpecialFunctions.Pow.Real

/-!
# Rounded real-power cutoffs for the actual arithmetic rows

The moving cutoff is an integer alpha, not a real power substituted silently.
These finite bounds give its comparison with N^theta and prove that the rounded
modulus cap covers every nonzero literal row. No asymptotic estimate is assumed.
-/

namespace GoldbachResearch.CutoffScale

open ActualArithmetic

noncomputable def cutoff (N : ℕ) (theta : ℝ) : ℕ :=
  Nat.floor ((N : ℝ) ^ theta)

noncomputable def modulusCap (N : ℕ) (theta : ℝ) : ℕ :=
  Nat.floor ((N : ℝ) / (cutoff N theta : ℝ))

theorem modulusCap_eq_nat_div (N : ℕ) (theta : ℝ) :
    modulusCap N theta = N / cutoff N theta :=
  Nat.floor_div_eq_div N (cutoff N theta)

theorem modulusCap_le_target (N : ℕ) (theta : ℝ) : modulusCap N theta ≤ N := by
  rw [modulusCap_eq_nat_div]
  exact Nat.div_le_self N (cutoff N theta)

/-- An explicit real threshold ensures the scale is large enough to round.
No eventuality or unspecified asymptotic threshold is used. -/
theorem scale_ge_two_of_explicit_threshold {N : ℕ} {theta : ℝ}
    (ht : 0 < theta) (hN : (2 : ℝ) ^ (1 / theta) ≤ (N : ℝ)) :
    2 ≤ (N : ℝ) ^ theta := by
  have hp : 0 ≤ (2 : ℝ) ^ (1 / theta) := Real.rpow_nonneg (by norm_num) _
  have h := Real.rpow_le_rpow hp hN ht.le
  rw [← Real.rpow_mul (by norm_num), one_div_mul_cancel (ne_of_gt ht), Real.rpow_one] at h
  exact h

theorem floor_ge_half {x : ℝ} (hx : 2 ≤ x) :
    x / 2 ≤ (Nat.floor x : ℝ) := by
  have hlt := Nat.lt_floor_add_one x
  nlinarith

theorem floor_positive {x : ℝ} (hx : 2 ≤ x) : 0 < Nat.floor x :=
  Nat.floor_pos.mpr (by linarith)

theorem floor_le_input {x : ℝ} (hx : 0 ≤ x) : (Nat.floor x : ℝ) ≤ x :=
  Nat.floor_le hx

theorem cutoff_positive {N : ℕ} {theta : ℝ} (hscale : 2 ≤ (N : ℝ) ^ theta) :
    0 < cutoff N theta := floor_positive hscale

theorem cutoff_ge_half {N : ℕ} {theta : ℝ} (hscale : 2 ≤ (N : ℝ) ^ theta) :
    (N : ℝ) ^ theta / 2 ≤ (cutoff N theta : ℝ) := floor_ge_half hscale

theorem cutoff_le_rpow (N : ℕ) (theta : ℝ) :
    (cutoff N theta : ℝ) ≤ (N : ℝ) ^ theta :=
  floor_le_input (Real.rpow_nonneg (Nat.cast_nonneg N) theta)

theorem cutoff_lt_rpow_add_one (N : ℕ) (theta : ℝ) :
    (N : ℝ) ^ theta < (cutoff N theta : ℝ) + 1 :=
  Nat.lt_floor_add_one _

/-- The inverse cutoff costs at most a factor two after real-power rounding. -/
theorem quotient_le_two_rpow {N : ℕ} {theta : ℝ} (hN : 0 < N)
    (hscale : 2 ≤ (N : ℝ) ^ theta) :
    (N : ℝ) / (cutoff N theta : ℝ) ≤ 2 * (N : ℝ) ^ (1 - theta) := by
  have hNr : 0 < (N : ℝ) := by exact_mod_cast hN
  have hp : 0 < (N : ℝ) ^ theta := Real.rpow_pos_of_pos hNr theta
  have ha : 0 < (cutoff N theta : ℝ) := by exact_mod_cast cutoff_positive hscale
  have hl := cutoff_ge_half hscale
  rw [Real.rpow_sub hNr 1 theta, Real.rpow_one]
  apply (div_le_iff₀ ha).2
  have hmul : (N : ℝ) / ((N : ℝ) ^ theta) * ((N : ℝ) ^ theta / 2) ≤
      (N : ℝ) / ((N : ℝ) ^ theta) * (cutoff N theta : ℝ) :=
    mul_le_mul_of_nonneg_left hl (div_nonneg hNr.le hp.le)
  have heq : (N : ℝ) / ((N : ℝ) ^ theta) * ((N : ℝ) ^ theta / 2) = (N : ℝ) / 2 := by
    field_simp [ne_of_gt hp]
  nlinarith

theorem modulusCap_le_quotient {N : ℕ} {theta : ℝ}
    (hscale : 2 ≤ (N : ℝ) ^ theta) :
    (modulusCap N theta : ℝ) ≤ (N : ℝ) / (cutoff N theta : ℝ) := by
  unfold modulusCap
  exact Nat.floor_le (div_nonneg (Nat.cast_nonneg N) (by
    exact_mod_cast (cutoff_positive hscale).le))

theorem modulusCap_le_two_rpow {N : ℕ} {theta : ℝ} (hN : 0 < N)
    (hscale : 2 ≤ (N : ℝ) ^ theta) :
    (modulusCap N theta : ℝ) ≤ 2 * (N : ℝ) ^ (1 - theta) :=
  (modulusCap_le_quotient hscale).trans (quotient_le_two_rpow hN hscale)

/-- Explicit effective scaling contract, valid beyond the displayed threshold. -/
theorem explicit_cutoff_contract {N : ℕ} {theta : ℝ} (ht : 0 < theta)
    (hN : (2 : ℝ) ^ (1 / theta) ≤ (N : ℝ)) :
    0 < cutoff N theta ∧
      (N : ℝ) ^ theta / 2 ≤ (cutoff N theta : ℝ) ∧
      (cutoff N theta : ℝ) ≤ (N : ℝ) ^ theta ∧
      (modulusCap N theta : ℝ) ≤ 2 * (N : ℝ) ^ (1 - theta) ∧
      modulusCap N theta ≤ N := by
  have hs := scale_ge_two_of_explicit_threshold ht hN
  have hNr : 0 < (N : ℝ) :=
    (Real.rpow_pos_of_pos (by norm_num : (0 : ℝ) < 2) (1 / theta)).trans_le hN
  have hNn : 0 < N := by exact_mod_cast hNr
  exact ⟨cutoff_positive hs, cutoff_ge_half hs, cutoff_le_rpow N theta,
    modulusCap_le_two_rpow hNn hs, modulusCap_le_target N theta⟩

/-- The integer cutoff is also bounded by N when theta is at most one. -/
theorem cutoff_le_target {N : ℕ} {theta : ℝ} (hN : 1 ≤ N) (ht : theta ≤ 1) :
    cutoff N theta ≤ N := by
  have hNr : 1 ≤ (N : ℝ) := by exact_mod_cast hN
  have hh := (cutoff_le_rpow N theta).trans (Real.rpow_le_self_of_one_le hNr ht)
  exact_mod_cast hh

/-- Strict natural moving endpoints agree with the real cofactor inequality. -/
theorem strict_cutoff_iff_real_cofactor {N n alpha k : ℕ} (hk : 0 < k) :
    n + alpha * k < N ↔
      (alpha : ℝ) < ((N : ℝ) - (n : ℝ)) / (k : ℝ) := by
  have hkr : 0 < (k : ℝ) := by exact_mod_cast hk
  rw [lt_div_iff₀ hkr]
  constructor
  · intro h
    have hr : (n : ℝ) + (alpha : ℝ) * (k : ℝ) < (N : ℝ) := by exact_mod_cast h
    linarith
  · intro h
    have hr : (n : ℝ) + (alpha : ℝ) * (k : ℝ) < (N : ℝ) := by linarith
    exact_mod_cast hr

theorem strict_cutoff_iff_nat_cofactor {N n alpha k : ℕ} (hk : 0 < k) (hn : n ≤ N) :
    n + alpha * k < N ↔
      (alpha : ℝ) < (N - n : ℕ) / (k : ℝ) := by
  simpa only [Nat.cast_sub hn] using
    (strict_cutoff_iff_real_cofactor (N := N) (n := n) (alpha := alpha) hk)

/-- A nonzero actual row cannot lie outside the rounded real quotient cap. -/
theorem nonzero_row_modulus_le_cap {N n k : ℕ} {theta : ℝ}
    (hscale : 2 ≤ (N : ℝ) ^ theta)
    (hrow : actualRow N (cutoff N theta) k n ≠ 0) : k ≤ modulusCap N theta := by
  have hs := actualRow_nonzero_support hrow
  have ha : 0 < (cutoff N theta : ℝ) := by exact_mod_cast cutoff_positive hscale
  have hr : (n : ℝ) + (cutoff N theta : ℝ) * (k : ℝ) < (N : ℝ) := by
    exact_mod_cast hs.2.2
  unfold modulusCap
  apply Nat.le_floor
  apply (le_div_iff₀ ha).2
  nlinarith [(Nat.cast_nonneg n : 0 ≤ (n : ℝ))]

theorem nonzero_row_real_cofactor {N n k : ℕ} {theta : ℝ} (hk : 0 < k)
    (hrow : actualRow N (cutoff N theta) k n ≠ 0) :
    (cutoff N theta : ℝ) < (N - n : ℕ) / (k : ℝ) := by
  have hs := actualRow_nonzero_support hrow
  exact (strict_cutoff_iff_nat_cofactor hk hs.2.1.le).mp hs.2.2

end GoldbachResearch.CutoffScale

#print axioms GoldbachResearch.CutoffScale.floor_ge_half
#print axioms GoldbachResearch.CutoffScale.modulusCap_eq_nat_div
#print axioms GoldbachResearch.CutoffScale.modulusCap_le_target
#print axioms GoldbachResearch.CutoffScale.scale_ge_two_of_explicit_threshold
#print axioms GoldbachResearch.CutoffScale.floor_positive
#print axioms GoldbachResearch.CutoffScale.floor_le_input
#print axioms GoldbachResearch.CutoffScale.cutoff_positive
#print axioms GoldbachResearch.CutoffScale.cutoff_ge_half
#print axioms GoldbachResearch.CutoffScale.cutoff_le_rpow
#print axioms GoldbachResearch.CutoffScale.cutoff_lt_rpow_add_one
#print axioms GoldbachResearch.CutoffScale.quotient_le_two_rpow
#print axioms GoldbachResearch.CutoffScale.modulusCap_le_quotient
#print axioms GoldbachResearch.CutoffScale.modulusCap_le_two_rpow
#print axioms GoldbachResearch.CutoffScale.explicit_cutoff_contract
#print axioms GoldbachResearch.CutoffScale.cutoff_le_target
#print axioms GoldbachResearch.CutoffScale.strict_cutoff_iff_real_cofactor
#print axioms GoldbachResearch.CutoffScale.strict_cutoff_iff_nat_cofactor
#print axioms GoldbachResearch.CutoffScale.nonzero_row_modulus_le_cap
#print axioms GoldbachResearch.CutoffScale.nonzero_row_real_cofactor
