import Mathlib.Tactic
import Mathlib.Analysis.Complex.Basic
import Mathlib.Data.ZMod.Basic

/-!
Exact finite ratio pushforward and the principal/residual contraction.
The coefficient attached to an outer tuple remains coupled throughout.
No distribution, analytic smallness, cancellation or Goldbach assertion
is introduced. The unit branch is a finite group; nonunits must be treated
separately by the application.
-/

namespace GoldbachResearch.RatioPushforward

open scoped BigOperators
open Finset

noncomputable section

variable {I G : Type*} [Fintype I] [Fintype G] [Nonempty G]

def histogram (rho : I → G) (weight : I → ℂ) (g : G) : ℂ := by
  classical
  exact ∑ i, if rho i = g then weight i else 0

def mean (f : G → ℂ) : ℂ := (∑ g, f g) / (Fintype.card G : ℂ)

def residual (f : G → ℂ) (g : G) : ℂ := f g - mean f

omit [Nonempty G] in
theorem histogram_contraction (rho : I → G) (weight : I → ℂ) (K : G → ℂ) :
    (∑ i, weight i * K (rho i)) = ∑ g, histogram rho weight g * K g := by
  classical
  unfold histogram
  simp_rw [Finset.sum_mul]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i hi
  simp only [ite_mul, zero_mul]
  simp

omit [Nonempty G] in
theorem histogram_mass (rho : I → G) (weight : I → ℂ) :
    (∑ g, histogram rho weight g) = ∑ i, weight i := by
  classical
  unfold histogram
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i hi
  simp

theorem card_mul_mean (f : G → ℂ) :
    (Fintype.card G : ℂ) * mean f = ∑ g, f g := by
  have hc : (Fintype.card G : ℂ) ≠ 0 := by
    exact_mod_cast Fintype.card_ne_zero
  unfold mean
  field_simp

theorem residual_sum (f : G → ℂ) : (∑ g, residual f g) = 0 := by
  classical
  unfold residual
  rw [Finset.sum_sub_distrib]
  simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, card_mul_mean]
  ring

theorem principal_residual_contraction (f K : G → ℂ) :
    (∑ g, f g * K g) =
      (∑ g, f g) * mean K + ∑ g, residual f g * residual K g := by
  classical
  have hf := card_mul_mean f
  have hK := card_mul_mean K
  simp only [residual, sub_mul, mul_sub, Finset.sum_sub_distrib,
    ← Finset.sum_mul, ← Finset.mul_sum, Finset.sum_const,
    Finset.card_univ, nsmul_eq_mul]
  rw [← hf, ← hK]
  ring

theorem coupled_histogram_principal_residual
    (rho : I → G) (weight : I → ℂ) (K : G → ℂ) :
    (∑ i, weight i * K (rho i)) =
      (∑ i, weight i) * mean K +
        ∑ g, residual (histogram rho weight) g * residual K g := by
  rw [histogram_contraction, principal_residual_contraction, histogram_mass]

def squareMass (f : G → ℂ) : ℝ := ∑ g, ‖f g‖ ^ 2

theorem residual_squareMass (f : G → ℂ) :
    squareMass (residual f) =
      squareMass f - (Fintype.card G : ℝ) * ‖mean f‖ ^ 2 := by
  classical
  have hf := card_mul_mean f
  have hre : ∑ g, (f g).re = (Fintype.card G : ℝ) * (mean f).re := by
    simpa using (congrArg Complex.re hf).symm
  have him : ∑ g, (f g).im = (Fintype.card G : ℝ) * (mean f).im := by
    simpa using (congrArg Complex.im hf).symm
  simp only [squareMass, residual, ← Complex.normSq_eq_norm_sq,
    Complex.normSq_apply, Complex.sub_re, Complex.sub_im]
  have hexpand (g : G) :
      ((f g).re - (mean f).re) * ((f g).re - (mean f).re) +
        ((f g).im - (mean f).im) * ((f g).im - (mean f).im) =
      (f g).re * (f g).re + (f g).im * (f g).im -
        2 * (mean f).re * (f g).re - 2 * (mean f).im * (f g).im +
        ((mean f).re * (mean f).re + (mean f).im * (mean f).im) := by ring
  simp_rw [hexpand, Finset.sum_add_distrib, Finset.sum_sub_distrib,
    ← Finset.mul_sum]
  simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, hre, him]
  rw [Finset.sum_add_distrib]
  ring

omit [Nonempty G] [Fintype G] in
theorem histogram_at_image_of_injective (rho : I → G) (weight : I → ℂ)
    (hrho : Function.Injective rho) (i : I) :
    histogram rho weight (rho i) = weight i := by
  classical
  simp [histogram, hrho.eq_iff]

omit [Nonempty G] in
theorem histogram_squareMass_of_injective (rho : I → G) (weight : I → ℂ)
    (hrho : Function.Injective rho) :
    squareMass (histogram rho weight) = ∑ i, ‖weight i‖ ^ 2 := by
  classical
  have hg (g : G) : ‖histogram rho weight g‖ ^ 2 =
      ∑ i, if rho i = g then ‖weight i‖ ^ 2 else 0 := by
    by_cases h : ∃ i, rho i = g
    · obtain ⟨i, rfl⟩ := h
      simp [histogram_at_image_of_injective rho weight hrho, hrho.eq_iff]
    · have hn : ∀ i, rho i ≠ g := not_exists.mp h
      simp [histogram, hn]
  unfold squareMass
  simp_rw [hg]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i hi
  simp

omit [Nonempty G] in
theorem contraction_sq_le (f K : G → ℂ) :
    ‖∑ g, f g * K g‖ ^ 2 ≤ squareMass f * squareMass K := by
  classical
  have ht : ‖∑ g, f g * K g‖ ≤ ∑ g, ‖f g‖ * ‖K g‖ := by
    simpa only [norm_mul] using norm_sum_le (univ : Finset G) (fun g => f g * K g)
  have hs : (∑ g, ‖f g‖ * ‖K g‖) ^ 2 ≤ squareMass f * squareMass K := by
    unfold squareMass
    apply Finset.sum_sq_le_sum_mul_sum_of_sq_eq_mul
    · intro g hg
      exact sq_nonneg _
    · intro g hg
      exact sq_nonneg _
    · intro g hg
      ring
  have hn : 0 ≤ ∑ g, ‖f g‖ * ‖K g‖ :=
    Finset.sum_nonneg (fun g hg => mul_nonneg (norm_nonneg _) (norm_nonneg _))
  have ht2 : ‖∑ g, f g * K g‖ ^ 2 ≤ (∑ g, ‖f g‖ * ‖K g‖) ^ 2 := by
    nlinarith [norm_nonneg (∑ g, f g * K g)]
  exact ht2.trans hs

theorem normalized_contraction_sq_le (f K : G → ℂ) :
    ‖(∑ g, f g * K g) / (Fintype.card G : ℂ)‖ ^ 2 ≤
      (squareMass f / (Fintype.card G : ℝ)) *
        (squareMass K / (Fintype.card G : ℝ)) := by
  have hcard : 0 < (Fintype.card G : ℝ) := by
    exact_mod_cast Fintype.card_pos
  have hs := contraction_sq_le f K
  have hdivide := div_le_div_of_nonneg_right hs (sq_nonneg (Fintype.card G : ℝ))
  simpa only [norm_div, Complex.norm_natCast, div_pow, mul_div_mul_comm,
    pow_two] using hdivide

theorem coupled_residual_sq_le
    (rho : I → G) (weight : I → ℂ) (K : G → ℂ) :
    ‖(∑ i, weight i * K (rho i)) - (∑ i, weight i) * mean K‖ ^ 2 ≤
      squareMass (residual (histogram rho weight)) * squareMass (residual K) := by
  rw [coupled_histogram_principal_residual]
  simp only [add_sub_cancel_left]
  exact contraction_sq_le _ _

section Multiplier

variable [Group G]

def reflected (t : G) (f : G → ℂ) (x : G) : ℂ := f (t * x⁻¹)

omit [Nonempty G] in
theorem multiplier_average (f : G → ℂ) (x : G) :
    (∑ t, reflected t f x) = ∑ g, f g := by
  exact Fintype.sum_bijective (fun t : G => t * x⁻¹)
    (Group.mulRight_bijective x⁻¹) (fun t => reflected t f x) f (fun _ => rfl)

omit [Nonempty G] in
theorem normalized_multiplier_average (f : G → ℂ) (x : G) :
    (∑ t, reflected t f x) / (Fintype.card G : ℂ) = mean f := by
  rw [multiplier_average]
  rfl

omit [Nonempty G] in
theorem weighted_character_reflection
    (weight : G → ℂ) (chi : G →* ℂˣ) (x : G) :
    (∑ t, weight t * (chi (t * x⁻¹) : ℂ)) =
      (∑ t, weight t * (chi t : ℂ)) * (chi x⁻¹ : ℂ) := by
  simp_rw [map_mul, Units.val_mul]
  rw [Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro t ht
  ring

end Multiplier

/-- A short reduced-rational packet cannot contain a congruence collision.
This applies after the genuine (s,t) coefficients have been grouped at C=s*t.
The unit multiplier h may then be cancelled separately in the unit group. -/
theorem short_reduced_rational_injective
    {q a C a' C' : ℕ} (ha : 0 < a)
    (hc : a.Coprime C) (hc' : a'.Coprime C')
    (hshort : a * C' < q) (hshort' : a' * C < q)
    (hcong : ((a * C' : ℕ) : ZMod q) = ((a' * C : ℕ) : ZMod q)) :
    a = a' ∧ C = C' := by
  have hcross : a * C' = a' * C := by
    have hval := congrArg ZMod.val hcong
    simpa only [ZMod.val_natCast_of_lt hshort,
      ZMod.val_natCast_of_lt hshort'] using hval
  have hd : a ∣ a' := hc.dvd_mul_right.mp (by
    rw [← hcross]
    exact dvd_mul_right a C')
  have hd' : a' ∣ a := hc'.dvd_mul_right.mp (by
    rw [hcross]
    exact dvd_mul_right a' C)
  have heqa : a = a' := Nat.dvd_antisymm hd hd'
  refine ⟨heqa, ?_⟩
  rw [← heqa] at hcross
  exact (Nat.eq_of_mul_eq_mul_left ha hcross).symm

#print axioms histogram_contraction
#print axioms histogram_mass
#print axioms card_mul_mean
#print axioms residual_sum
#print axioms principal_residual_contraction
#print axioms coupled_histogram_principal_residual
#print axioms residual_squareMass
#print axioms histogram_at_image_of_injective
#print axioms histogram_squareMass_of_injective
#print axioms contraction_sq_le
#print axioms normalized_contraction_sq_le
#print axioms coupled_residual_sq_le
#print axioms multiplier_average
#print axioms normalized_multiplier_average
#print axioms weighted_character_reflection
#print axioms short_reduced_rational_injective

end
end GoldbachResearch.RatioPushforward
