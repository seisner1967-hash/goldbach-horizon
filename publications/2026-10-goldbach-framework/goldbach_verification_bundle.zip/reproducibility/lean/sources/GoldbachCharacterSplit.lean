import GoldbachTypeIIAssembly
import Mathlib.NumberTheory.DirichletCharacter.Orthogonality
import Mathlib.NumberTheory.MulChar.Lemmas
import Mathlib.Analysis.Complex.Polynomial.Basic
import Mathlib.RingTheory.RootsOfUnity.AlgebraicallyClosed

/-!
# Exact nonprincipal-character splitting with the nonunit correction

Only finite algebra and library character orthogonality are used. No analytic
smallness assertion is included.
-/

namespace GoldbachResearch.CharacterSplit

open scoped BigOperators
open Finset

noncomputable section

variable {k : ℕ} [NeZero k]

def nonprincipal (k : ℕ) : Finset (DirichletCharacter ℂ k) :=
  by classical exact univ.erase 1

def spectrum (N x : ZMod k) : ℂ :=
  (∑ χ ∈ nonprincipal k, χ N⁻¹ * χ x) / (k.totient : ℂ)

def centered (N x : ZMod k) : ℂ :=
  (if N = x then 1 else 0) - 1 / (k.totient : ℂ)

def nonunitCorrection (x : ZMod k) : ℂ :=
  (if IsUnit x then 0 else 1) / (k.totient : ℂ)

omit [NeZero k] in
theorem character_inv_eq_conj (χ : DirichletCharacter ℂ k)
    {N : ZMod k} (hN : IsUnit N) : χ N⁻¹ = star (χ N) := by
  rw [MulChar.star_apply', MulChar.inv_apply]
  have hi : Ring.inverse N = N⁻¹ := by
    rcases hN with ⟨u, rfl⟩
    simp only [Ring.inverse_unit, ZMod.inv_coe_unit]
  rw [hi]

omit [NeZero k] in
theorem spectrum_eq_conjugate_sum {N : ZMod k} (hN : IsUnit N) (x : ZMod k) :
    spectrum N x =
      (∑ χ ∈ nonprincipal k, star (χ N) * χ x) / (k.totient : ℂ) := by
  unfold spectrum
  congr 1
  apply Finset.sum_congr rfl
  intro χ hχ
  rw [character_inv_eq_conj χ hN]

theorem principal_term {N : ZMod k} (hN : IsUnit N) (x : ZMod k) :
    (1 : DirichletCharacter ℂ k) N⁻¹ * (1 : DirichletCharacter ℂ k) x =
      if IsUnit x then 1 else 0 := by
  rw [character_inv_eq_conj 1 hN, MulChar.one_apply hN]
  by_cases hx : IsUnit x
  · simp [hx, MulChar.one_apply hx]
  · simp [hx, MulChar.map_nonunit _ hx]

theorem centered_eq_spectrum_sub_nonunit {N : ZMod k} (hN : IsUnit N)
    (x : ZMod k) : centered N x = spectrum N x - nonunitCorrection x := by
  classical
  have ht : (k.totient : ℂ) ≠ 0 := by
    exact_mod_cast (Nat.totient_pos.mpr (NeZero.pos k)).ne'
  have hall := DirichletCharacter.sum_char_inv_mul_char_eq ℂ hN x
  have hs :
      (∑ χ ∈ nonprincipal k, χ N⁻¹ * χ x) +
          (if IsUnit x then 1 else 0) =
        if N = x then (k.totient : ℂ) else 0 := by
    rw [← principal_term hN x]
    change (∑ χ ∈ (univ : Finset (DirichletCharacter ℂ k)).erase 1, χ N⁻¹ * χ x) +
      (1 : DirichletCharacter ℂ k) N⁻¹ * (1 : DirichletCharacter ℂ k) x = _
    rw [Finset.sum_erase_add _ _ (Finset.mem_univ 1)]
    exact hall
  unfold centered spectrum nonunitCorrection
  by_cases he : N = x <;> by_cases hx : IsUnit x <;>
    simp only [he, hx, if_true, if_false] at hs ⊢
  all_goals field_simp
  all_goals linear_combination -hs

omit [NeZero k] in
theorem spectrum_zero_on_nonunits (N : ZMod k) {x : ZMod k}
    (hx : ¬IsUnit x) : spectrum N x = 0 := by
  classical
  simp [spectrum, MulChar.map_nonunit _ hx]

omit [NeZero k] in
theorem spectrum_product {N : ZMod k} (hN : IsUnit N) (a b : ZMod k) :
    spectrum N (a * b) =
      (∑ χ ∈ nonprincipal k, star (χ N) * χ a * χ b) / (k.totient : ℂ) := by
  rw [spectrum_eq_conjugate_sum hN]
  congr 1
  apply Finset.sum_congr rfl
  intro χ hχ
  rw [map_mul]
  ring

omit [NeZero k] in
theorem centered_natCast (N n : ℕ) (hn : n ≤ N) :
    centered (N : ZMod k) (n : ZMod k) =
      ((if k ∣ N - n then (1 : ℝ) else 0) - 1 / (k.totient : ℝ) : ℝ) := by
  classical
  have he : ((N : ZMod k) = (n : ZMod k)) ↔ k ∣ N - n := by
    rw [ZMod.natCast_eq_natCast_iff]
    exact Nat.ModEq.comm.trans (Nat.modEq_iff_dvd' hn)
  simp only [centered, he]
  push_cast
  split_ifs <;> simp

theorem nonunitCorrection_natCast (n : ℕ) :
    nonunitCorrection (n : ZMod k) =
      (if n.Coprime k then 0 else 1) / (k.totient : ℂ) := by
  simp only [nonunitCorrection, ZMod.isUnit_iff_coprime]

def rowAmplitude (N cutoff k n : ℕ) : ℝ :=
  if 1 ≤ n ∧ n < N ∧ n < N - cutoff * k then
    Real.log ((k : ℝ) / (N - n : ℕ)) else 0

omit [NeZero k] in
theorem actualRow_eq_amplitude_centered (N cutoff n : ℕ) :
    (ActualArithmetic.actualRow N cutoff k n : ℂ) =
      (rowAmplitude N cutoff k n : ℂ) * centered (N : ZMod k) (n : ZMod k) := by
  classical
  by_cases hs : 1 ≤ n ∧ n < N ∧ n < N - cutoff * k
  · rw [centered_natCast N n hs.2.1.le]
    simp only [ActualArithmetic.actualRow, rowAmplitude, if_pos hs, Complex.ofReal_mul]
    ring
  · simp [ActualArithmetic.actualRow, rowAmplitude, hs]

def badNRow (N cutoff k : ℕ) (f : ArithmeticFunction ℝ) : ℝ :=
  ∑ n ∈ range N, f n * ActualArithmetic.muReal (N - n) *
    ActualArithmetic.actualRow N cutoff k n * (if n.Coprime N then 0 else 1)

def characterRow (N cutoff : ℕ) (f : ArithmeticFunction ℝ) : ℂ :=
  ∑ n ∈ range N, if n.Coprime N then
    (f n * ActualArithmetic.muReal (N - n) * rowAmplitude N cutoff k n : ℝ) *
      spectrum (N : ZMod k) (n : ZMod k) else 0

def residualRow (N cutoff : ℕ) (f : ArithmeticFunction ℝ) : ℂ :=
  -∑ n ∈ range N, if n.Coprime N then
    (f n * ActualArithmetic.muReal (N - n) * rowAmplitude N cutoff k n : ℝ) *
      nonunitCorrection (n : ZMod k) else 0

theorem signedRow_eq_badN_add_character_add_residual
    (N cutoff : ℕ) (f : ArithmeticFunction ℝ) (hNk : N.Coprime k) :
    (Vaughan.signedRow N cutoff k f : ℂ) =
      (badNRow N cutoff k f : ℂ) + characterRow (k := k) N cutoff f +
        residualRow (k := k) N cutoff f := by
  classical
  have hN : IsUnit (N : ZMod k) := (ZMod.isUnit_iff_coprime N k).mpr hNk
  unfold Vaughan.signedRow badNRow characterRow residualRow
  push_cast
  rw [← Finset.sum_neg_distrib, ← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro n hn
  by_cases hc : n.Coprime N
  · rw [actualRow_eq_amplitude_centered,
    centered_eq_spectrum_sub_nonunit hN]
    simp only [if_pos hc, Complex.ofReal_zero, mul_zero, zero_add]
    ring
  · simp only [hc, if_false, Complex.ofReal_one, mul_one, add_zero, neg_zero]

theorem actual_typeTwo_character_split (N cutoff U V : ℕ) (hNk : N.Coprime k) :
    (Vaughan.signedRow N cutoff k (Vaughan.typeTwo U V) : ℂ) =
      (badNRow N cutoff k (Vaughan.typeTwo U V) : ℂ) +
      characterRow (k := k) N cutoff (Vaughan.typeTwo U V) +
      residualRow (k := k) N cutoff (Vaughan.typeTwo U V) :=
  signedRow_eq_badN_add_character_add_residual N cutoff (Vaughan.typeTwo U V) hNk

theorem spectrum_im_eq_zero {N : ZMod k} (hN : IsUnit N) (x : ZMod k) :
    (spectrum N x).im = 0 := by
  have heq : spectrum N x = centered N x + nonunitCorrection x :=
    sub_eq_iff_eq_add.mp (centered_eq_spectrum_sub_nonunit hN x).symm
  rw [heq]
  by_cases he : N = x <;> by_cases hu : IsUnit x <;>
    simp [centered, nonunitCorrection, he, hu]

theorem characterRow_im_eq_zero (N cutoff : ℕ) (f : ArithmeticFunction ℝ)
    (hNk : N.Coprime k) : (characterRow (k := k) N cutoff f).im = 0 := by
  classical
  have hN : IsUnit (N : ZMod k) := (ZMod.isUnit_iff_coprime N k).mpr hNk
  unfold characterRow
  change Complex.imAddGroupHom (∑ n ∈ range N, _) = 0
  rw [map_sum]
  apply Finset.sum_eq_zero
  intro n hn
  change (if n.Coprime N then
    (f n * ActualArithmetic.muReal (N - n) * rowAmplitude N cutoff k n : ℝ) *
      spectrum (N : ZMod k) (n : ZMod k) else (0 : ℂ)).im = 0
  by_cases hc : n.Coprime N
  · simp only [if_pos hc, Complex.mul_im, Complex.ofReal_im, Complex.ofReal_re,
      spectrum_im_eq_zero hN, mul_zero, zero_mul, add_zero]
  · simp only [if_neg hc, Complex.zero_im]

theorem actualRow_mod_one_zero (N cutoff n : ℕ) :
    ActualArithmetic.actualRow N cutoff 1 n = 0 := by
  simp [ActualArithmetic.actualRow]

#print axioms character_inv_eq_conj
#print axioms spectrum_eq_conjugate_sum
#print axioms principal_term
#print axioms centered_eq_spectrum_sub_nonunit
#print axioms spectrum_zero_on_nonunits
#print axioms spectrum_product
#print axioms centered_natCast
#print axioms nonunitCorrection_natCast
#print axioms actualRow_eq_amplitude_centered
#print axioms signedRow_eq_badN_add_character_add_residual
#print axioms actual_typeTwo_character_split
#print axioms spectrum_im_eq_zero
#print axioms characterRow_im_eq_zero
#print axioms actualRow_mod_one_zero

end
end GoldbachResearch.CharacterSplit
