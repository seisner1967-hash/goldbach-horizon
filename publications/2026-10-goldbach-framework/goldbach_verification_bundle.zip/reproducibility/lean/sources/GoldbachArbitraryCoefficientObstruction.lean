import GoldbachBilinear

/-!
# Scope of an arbitrary-coefficient short-interval claim

For one fixed column, coefficients allowed to adapt to the summands attain
their full absolute mass. This rules out a saving below that mass uniformly
over all bounded coefficients. It does not rule out a large sieve for one
fixed sequence across many characters, or a genuine bilinear interval bound.
-/

namespace GoldbachResearch.ArbitraryCoefficientObstruction

open scoped BigOperators
open Finset

noncomputable def matchingSign (x : ℝ) : ℝ := if 0 ≤ x then 1 else -1

theorem matchingSign_abs (x : ℝ) : |matchingSign x| = 1 := by
  unfold matchingSign
  split_ifs <;> norm_num

theorem matchingSign_mul (x : ℝ) : matchingSign x * x = |x| := by
  by_cases hx : 0 ≤ x
  · simp [matchingSign, hx, abs_of_nonneg hx]
  · simp [matchingSign, hx, abs_of_neg (lt_of_not_ge hx)]

theorem matching_coefficients_attain_mass {ι : Type*} (s : Finset ι) (z : ι → ℝ) :
    |∑ i ∈ s, matchingSign (z i) * z i| = ∑ i ∈ s, |z i| := by
  simp_rw [matchingSign_mul]
  exact abs_of_nonneg (Finset.sum_nonneg (fun i hi => abs_nonneg (z i)))

/-- Every proposed uniform multiplicative saving must be at least one. -/
theorem universal_saving_factor_ge_one {ι : Type*} (s : Finset ι) (z : ι → ℝ)
    (η : ℝ) (hmass : 0 < ∑ i ∈ s, |z i|)
    (hbound : ∀ u : ι → ℝ, (∀ i ∈ s, |u i| ≤ 1) →
      |∑ i ∈ s, u i * z i| ≤ η * ∑ i ∈ s, |z i|) : 1 ≤ η := by
  have hu : ∀ i ∈ s, |matchingSign (z i)| ≤ 1 := by
    intro i hi
    rw [matchingSign_abs]
  have hb := hbound (fun i => matchingSign (z i)) hu
  rw [matching_coefficients_attain_mass] at hb
  exact (mul_le_mul_right hmass).mp (by simpa using hb)

#print axioms matchingSign_abs
#print axioms matchingSign_mul
#print axioms matching_coefficients_attain_mass
#print axioms universal_saving_factor_ge_one

end GoldbachResearch.ArbitraryCoefficientObstruction
