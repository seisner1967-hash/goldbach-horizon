import Mathlib.Tactic

/-!
# Local arithmetic inequalities for the terminal fourth-moment bound

These finite rational and polynomial statements are the prime-local and
four-anchor algebra of the log^7 proof. The eleven-pattern decomposition,
arithmetic divisor-mass estimates, logarithmic simplex integration, and
identification of the Ramanujan expansion are separate obligations.
-/

namespace GoldbachResearch.Quartic

noncomputable def samePair (p : ℝ) : ℝ := 1 / (p - 1)
noncomputable def crossPair (p : ℝ) : ℝ := p / (p - 1) ^ 2
noncomputable def threeOccurrences (p : ℝ) : ℝ := p * (p - 2) / (p - 1) ^ 3
noncomputable def fourOccurrences (p : ℝ) : ℝ :=
  1 / (p - 1) ^ 2 + p * (p - 2) ^ 2 / (p - 1) ^ 4

theorem local_weights_nonneg {p : ℝ} (hp : 2 ≤ p) :
    0 ≤ samePair p ∧ 0 ≤ crossPair p ∧
    0 ≤ threeOccurrences p ∧ 0 ≤ fourOccurrences p := by
  have hp0 : 0 ≤ p := by linarith
  have hv : 0 < p - 1 := by linarith
  have hm : 0 ≤ p - 2 := by linarith
  unfold samePair crossPair threeOccurrences fourOccurrences
  constructor
  · positivity
  constructor
  · positivity
  constructor <;> positivity

theorem samePair_le_crossPair {p : ℝ} (hp : 2 ≤ p) :
    samePair p ≤ crossPair p := by
  have hv : 0 < p - 1 := by linarith
  unfold samePair crossPair
  apply (div_le_div_iff₀ hv (pow_pos hv 2)).2
  nlinarith

theorem threeOccurrences_le_crossPair {p : ℝ} (hp : 2 ≤ p) :
    threeOccurrences p ≤ crossPair p := by
  have hp0 : 0 ≤ p := by linarith
  have hv : 0 < p - 1 := by linarith
  have hbase : p * (p - 2) ≤ p * (p - 1) := by nlinarith
  have hm := mul_le_mul_of_nonneg_right hbase (sq_nonneg (p - 1))
  unfold threeOccurrences crossPair
  apply (div_le_div_iff₀ (pow_pos hv 3) (pow_pos hv 2)).2
  nlinarith

theorem fourOccurrences_le_crossPair {p : ℝ} (hp : 2 ≤ p) :
    fourOccurrences p ≤ crossPair p := by
  have hv : 0 < p - 1 := by linarith
  have hv0 : p - 1 ≠ 0 := ne_of_gt hv
  have hpoly : 0 ≤ (p - 2) * (p + 1) := by
    apply mul_nonneg <;> linarith
  have hnum : (p - 1) ^ 2 + p * (p - 2) ^ 2 ≤ p * (p - 1) ^ 2 := by
    nlinarith
  have hl : fourOccurrences p =
      ((p - 1) ^ 2 + p * (p - 2) ^ 2) / (p - 1) ^ 4 := by
    unfold fourOccurrences
    field_simp
    ring
  have hr : crossPair p = p * (p - 1) ^ 2 / (p - 1) ^ 4 := by
    unfold crossPair
    field_simp
    ring
  rw [hl, hr]
  exact div_le_div_of_nonneg_right hnum (le_of_lt (pow_pos hv 4))

theorem anchor12_identity
    (a b c d r₁ r₂ r₃ r₄ q₁ q₂ q₃ q₄ : ℝ)
    (h₁ : q₁ = a * b * c * r₁) (h₂ : q₂ = a * d * r₂)
    (h₃ : q₃ = b * d * r₃) (h₄ : q₄ = c * r₄) :
    a ^ 2 * q₃ * q₄ * r₁ * r₂ = q₁ * q₂ * r₃ * r₄ := by
  rw [h₁, h₂, h₃, h₄]
  ring

theorem anchor13_identity
    (a b c d r₁ r₂ r₃ r₄ q₁ q₂ q₃ q₄ : ℝ)
    (h₁ : q₁ = a * b * c * r₁) (h₂ : q₂ = a * d * r₂)
    (h₃ : q₃ = b * d * r₃) (h₄ : q₄ = c * r₄) :
    b ^ 2 * q₂ * q₄ * r₁ * r₃ = q₁ * q₃ * r₂ * r₄ := by
  rw [h₁, h₂, h₃, h₄]
  ring

theorem anchor23_identity
    (a b c d r₁ r₂ r₃ r₄ q₁ q₂ q₃ q₄ : ℝ)
    (h₁ : q₁ = a * b * c * r₁) (h₂ : q₂ = a * d * r₂)
    (h₃ : q₃ = b * d * r₃) (h₄ : q₄ = c * r₄) :
    d ^ 2 * q₁ * r₂ * r₃ * r₄ = q₂ * q₃ * q₄ * r₁ := by
  rw [h₁, h₂, h₃, h₄]
  ring

theorem fourModuli_product_identity
    (a b c d r₁ r₂ r₃ r₄ q₁ q₂ q₃ q₄ : ℝ)
    (h₁ : q₁ = a * b * c * r₁) (h₂ : q₂ = a * d * r₂)
    (h₃ : q₃ = b * d * r₃) (h₄ : q₄ = c * r₄) :
    q₁ * q₂ * q₃ * q₄ =
      a ^ 2 * b ^ 2 * c ^ 2 * d ^ 2 * r₁ * r₂ * r₃ * r₄ := by
  rw [h₁, h₂, h₃, h₄]
  ring

#print axioms local_weights_nonneg
#print axioms samePair_le_crossPair
#print axioms threeOccurrences_le_crossPair
#print axioms fourOccurrences_le_crossPair
#print axioms anchor12_identity
#print axioms anchor13_identity
#print axioms anchor23_identity
#print axioms fourModuli_product_identity

end GoldbachResearch.Quartic
