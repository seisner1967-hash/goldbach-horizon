import GoldbachActualMobiusLogFibre

/-!
An actual pointwise bound for the signed divisor fibre, preserving rt<=alpha.
Its divisor-cardinality factor is tau(s); no AP or second-moment estimate
is asserted by this finite theorem.
-/

namespace GoldbachResearch.ActualDivisorFibreBound

open scoped BigOperators
open GoldbachResearch.ActualMobiusLogFibre

theorem actual_truncated_fibre_abs_bound {r s alpha : ℕ}
    (hr : 1 ≤ r) (hs : 1 ≤ s) (ha : 1 ≤ alpha) :
    |signedDivisorCoefficient r s alpha| ≤
      (s.divisors.card : ℝ) * Real.log (alpha : ℝ) := by
  have hmu (n : ℕ) : |(ArithmeticFunction.moebius n : ℝ)| ≤ 1 := by
    exact_mod_cast (ArithmeticFunction.abs_moebius_le_one (n := n))
  have halog : 0 ≤ Real.log (alpha : ℝ) :=
    Real.log_nonneg (by exact_mod_cast ha)
  have hterm (e : ℕ) (he : e ∈ s.divisors) :
      |if r * e ≤ alpha then
          (ArithmeticFunction.moebius e : ℝ) * Real.log ((r * e : ℕ) : ℝ)
        else 0| ≤ Real.log (alpha : ℝ) := by
    by_cases hcut : r * e ≤ alpha
    · rw [if_pos hcut, abs_mul]
      have here : (1 : ℝ) ≤ ((r * e : ℕ) : ℝ) := by
        exact_mod_cast (Nat.one_le_iff_ne_zero.mpr
          (Nat.mul_pos (by omega : 0 < r) (Nat.pos_of_mem_divisors he)).ne')
      have hlog : 0 ≤ Real.log ((r * e : ℕ) : ℝ) := Real.log_nonneg here
      rw [abs_of_nonneg hlog]
      calc
        |(ArithmeticFunction.moebius e : ℝ)| * Real.log ((r * e : ℕ) : ℝ)
            ≤ 1 * Real.log ((r * e : ℕ) : ℝ) :=
          mul_le_mul_of_nonneg_right (hmu e) hlog
        _ = Real.log ((r * e : ℕ) : ℝ) := one_mul _
        _ ≤ Real.log (alpha : ℝ) :=
          Real.log_le_log (by linarith) (by exact_mod_cast hcut)
    · rw [if_neg hcut, abs_zero]
      exact halog
  have hprod : |(ArithmeticFunction.moebius s : ℝ)| *
      |(ArithmeticFunction.moebius r : ℝ)| ≤ 1 := by
    calc
      _ ≤ (1 : ℝ) * 1 :=
        mul_le_mul (hmu s) (hmu r) (abs_nonneg _) (by norm_num)
      _ = 1 := by norm_num
  unfold signedDivisorCoefficient
  rw [abs_mul, abs_mul]
  calc
    _ ≤ 1 * |∑ e ∈ s.divisors,
        if r * e ≤ alpha then
          (ArithmeticFunction.moebius e : ℝ) * Real.log ((r * e : ℕ) : ℝ)
        else 0| := mul_le_mul_of_nonneg_right hprod (abs_nonneg _)
    _ = |∑ e ∈ s.divisors,
        if r * e ≤ alpha then
          (ArithmeticFunction.moebius e : ℝ) * Real.log ((r * e : ℕ) : ℝ)
        else 0| := one_mul _
    _ ≤ ∑ e ∈ s.divisors,
        |if r * e ≤ alpha then
          (ArithmeticFunction.moebius e : ℝ) * Real.log ((r * e : ℕ) : ℝ)
        else 0| := Finset.abs_sum_le_sum_abs _ _
    _ ≤ ∑ e ∈ s.divisors, Real.log (alpha : ℝ) :=
      Finset.sum_le_sum hterm
    _ = (s.divisors.card : ℝ) * Real.log (alpha : ℝ) := by simp

#print axioms actual_truncated_fibre_abs_bound

end GoldbachResearch.ActualDivisorFibreBound
