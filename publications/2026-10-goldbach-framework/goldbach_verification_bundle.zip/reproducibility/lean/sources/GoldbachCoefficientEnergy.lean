import GoldbachAnchors
import GoldbachArithmetic

/-!
# Finite coefficient energy of the squarefree prime-local divisor proxy

The proxy is defined from the actual values p-1 and -1 of the prime-local
Ramanujan factors. This module does not assume an exponential Fourier identity.
-/

namespace GoldbachResearch.CoefficientEnergy

open scoped BigOperators
open Patterns ActualArithmetic

abbrev Pair := ℕ × ℕ
abbrev Four := Pair × Pair

def quad (x : Four) : Index → ℕ := ![x.1.1, x.1.2, x.2.1, x.2.2]

theorem quad_injective : Function.Injective quad := by
  intro x y h
  apply Prod.ext
  · apply Prod.ext
    · exact congrFun h 0
    · exact congrFun h 1
  · apply Prod.ext
    · exact congrFun h 2
    · exact congrFun h 3

def multiplicity (q r p : ℕ) : ℕ :=
  (if p ∣ q then 1 else 0) + (if p ∣ r then 1 else 0)

noncomputable def factor (q p n : ℕ) : ℝ :=
  if p ∣ q then primeRamanujan p n else 1

noncomputable def divisorProxy (U S : Finset ℕ) (n : ℕ) : ℝ :=
  ∑ q ∈ S, muReal q / (q.totient : ℝ) * ∏ p ∈ U, factor q p n

noncomputable def pairScalar (x : Pair) : ℝ :=
  muReal x.1 * muReal x.2 / ((x.1.totient : ℝ) * (x.2.totient : ℝ))

noncomputable def pairChannel (U : Finset ℕ) (x : Pair) (g : Finset ℕ) : ℝ :=
  channelCoefficient U (multiplicity x.1 x.2) g

noncomputable def squareCoefficient (U S : Finset ℕ) (g : Finset ℕ) : ℝ :=
  ∑ x ∈ S.product S, pairScalar x * pairChannel U x g

noncomputable def subsetPrimeProduct (g : Finset ℕ) : ℝ := ∏ p ∈ g, (p : ℝ)

noncomputable def coefficientEnergy (U S : Finset ℕ) : ℝ :=
  ∑ g ∈ U.powerset, subsetPrimeProduct g * (squareCoefficient U S g) ^ 2

theorem coefficientEnergy_nonneg (U S : Finset ℕ) : 0 ≤ coefficientEnergy U S := by
  apply Finset.sum_nonneg
  intro g hg
  apply mul_nonneg _ (sq_nonneg _)
  exact Finset.prod_nonneg (fun p hp => Nat.cast_nonneg p)

theorem local_factor_pair (q r p n : ℕ) :
    factor q p n * factor r p n =
      pairConstant (p : ℝ) (multiplicity q r p) +
        pairLinear (p : ℝ) (multiplicity q r p) * primeRamanujan p n := by
  by_cases hq : p ∣ q <;> by_cases hr : p ∣ r <;>
    simp [factor, multiplicity, hq, hr, pairConstant, pairLinear]
  simpa only [pow_two] using primeRamanujan_square p n

theorem pair_product_expansion (U : Finset ℕ) (q r n : ℕ) :
    (∏ p ∈ U, factor q p n) * (∏ p ∈ U, factor r p n) =
      ∑ g ∈ U.powerset, pairChannel U (q, r) g * ∏ p ∈ g, primeRamanujan p n := by
  rw [← Finset.prod_mul_distrib]
  have he : (∏ p ∈ U, factor q p n * factor r p n) =
      ∏ p ∈ U, (pairLinear (p : ℝ) (multiplicity q r p) * primeRamanujan p n +
        pairConstant (p : ℝ) (multiplicity q r p)) := by
    apply Finset.prod_congr rfl
    intro p hp
    rw [local_factor_pair]
    ring
  rw [he, Finset.prod_add]
  apply Finset.sum_congr rfl
  intro g hg
  unfold pairChannel channelCoefficient
  rw [Finset.prod_mul_distrib]
  ring

theorem divisorProxy_square_expansion (U S : Finset ℕ) (n : ℕ) :
    divisorProxy U S n ^ 2 =
      ∑ g ∈ U.powerset, squareCoefficient U S g * ∏ p ∈ g, primeRamanujan p n := by
  unfold divisorProxy squareCoefficient
  rw [pow_two, Finset.sum_mul_sum]
  rw [← Finset.sum_product S S (fun x : Pair =>
    (muReal x.1 / (x.1.totient : ℝ) * ∏ p ∈ U, factor x.1 p n) *
    (muReal x.2 / (x.2.totient : ℝ) * ∏ p ∈ U, factor x.2 p n))]
  calc
    _ = ∑ x ∈ S.product S, ∑ g ∈ U.powerset,
        (pairScalar x * pairChannel U x g) * ∏ p ∈ g, primeRamanujan p n := by
      apply Finset.sum_congr rfl
      intro x hx
      have he : (muReal x.1 / (x.1.totient : ℝ) * ∏ p ∈ U, factor x.1 p n) *
          (muReal x.2 / (x.2.totient : ℝ) * ∏ p ∈ U, factor x.2 p n) =
          pairScalar x * ((∏ p ∈ U, factor x.1 p n) * ∏ p ∈ U, factor x.2 p n) := by
        unfold pairScalar
        simp only [div_eq_mul_inv, mul_inv_rev]
        ring
      rw [he, pair_product_expansion, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro g hg
      ring
    _ = _ := by
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro g hg
      rw [Finset.sum_mul]

theorem finite_coefficient_energy_expansion {α β : Type*} (s : Finset α) (u : Finset β)
    (C : α → β → ℝ) (w : β → ℝ) :
    (∑ g ∈ u, w g * (∑ x ∈ s, C x g) ^ 2) =
      ∑ x ∈ s, ∑ y ∈ s, ∑ g ∈ u, w g * C x g * C y g := by
  calc
    _ = ∑ g ∈ u, ∑ x ∈ s, ∑ y ∈ s, w g * C x g * C y g := by
      apply Finset.sum_congr rfl
      intro g hg
      rw [pow_two, Finset.sum_mul_sum, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro x hx
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro y hy
      ring
    _ = _ := by
      rw [Finset.sum_comm]
      apply Finset.sum_congr rfl
      intro x hx
      rw [Finset.sum_comm]

theorem multiplicity_quad_left (x : Four) (p : ℕ) :
    multiplicity x.1.1 x.1.2 p = pairCount (occurrence (quad x) p) 0 1 := by
  simp [multiplicity, pairCount, occurrence, quad]

theorem multiplicity_quad_right (x : Four) (p : ℕ) :
    multiplicity x.2.1 x.2.2 p = pairCount (occurrence (quad x) p) 2 3 := by
  simp [multiplicity, pairCount, occurrence, quad]

theorem localWeight_empty (p : ℝ) : localWeight p ∅ = 1 := by
  simp [localWeight, pairCount, pairConstant, pairLinear]

theorem occurrence_empty_of_outside {q : Index → ℕ} {p : ℕ}
    (hq : ∀ i, Squarefree (q i)) (hp : p.Prime) (houtside : p ∉ primeUniverse q) :
    occurrence q p = ∅ := by
  apply Finset.eq_empty_iff_forall_not_mem.mpr
  intro i hi
  have hd := mem_occurrence.mp hi
  apply houtside
  exact Finset.mem_biUnion.mpr ⟨i, Finset.mem_univ i,
    Nat.mem_primeFactors.mpr ⟨hp, hd, (hq i).ne_zero⟩⟩

theorem extended_pairedWeight (U : Finset ℕ) (q : Index → ℕ)
    (hU : ∀ p ∈ U, p.Prime) (hq : ∀ i, Squarefree (q i)) (hsub : primeUniverse q ⊆ U) :
    (∏ p ∈ U, localWeight (p : ℝ) (occurrence q p)) = pairedWeight q := by
  symm
  apply Finset.prod_subset hsub
  intro p hp hnot
  rw [occurrence_empty_of_outside hq (hU p hp) hnot, localWeight_empty]

theorem extended_normalization (U : Finset ℕ) (q : Index → ℕ)
    (hU : ∀ p ∈ U, p.Prime) (hq : ∀ i, Squarefree (q i)) (hsub : primeUniverse q ⊆ U) :
    (∏ p ∈ U, ((p : ℝ) - 1) ^ (occurrence q p).card) =
      ∏ i : Index, ((q i).totient : ℝ) := by
  rw [← normalization_totient_product q hq]
  symm
  apply Finset.prod_subset hsub
  intro p hp hnot
  rw [occurrence_empty_of_outside hq (hU p hp) hnot]
  simp

noncomputable def channelPairing (U : Finset ℕ) (x : Four) : ℝ :=
  ∑ g ∈ U.powerset, subsetPrimeProduct g *
    (pairChannel U x.1 g * pairChannel U x.2 g)

noncomputable def quadSign (q : Index → ℕ) : ℝ :=
  muReal (q 0) * muReal (q 1) * muReal (q 2) * muReal (q 3)

theorem channelPairing_product (U : Finset ℕ) (x : Four) :
    channelPairing U x = ∏ p ∈ U,
      (pairConstant (p : ℝ) (pairCount (occurrence (quad x) p) 0 1) *
       pairConstant (p : ℝ) (pairCount (occurrence (quad x) p) 2 3) +
       (p : ℝ) * pairLinear (p : ℝ) (pairCount (occurrence (quad x) p) 0 1) *
       pairLinear (p : ℝ) (pairCount (occurrence (quad x) p) 2 3)) := by
  unfold channelPairing subsetPrimeProduct pairChannel
  have hl : multiplicity x.1.1 x.1.2 =
      fun p => pairCount (occurrence (quad x) p) 0 1 := funext (multiplicity_quad_left x)
  have hr : multiplicity x.2.1 x.2.2 =
      fun p => pairCount (occurrence (quad x) p) 2 3 := funext (multiplicity_quad_right x)
  rw [hl, hr]
  exact weighted_pairing_product U _ _ _ _

theorem channelPairing_normalized (U : Finset ℕ) (x : Four)
    (hU : ∀ p ∈ U, p.Prime) (hq : ∀ i, Squarefree (quad x i))
    (hsub : primeUniverse (quad x) ⊆ U) :
    channelPairing U x / (∏ i : Index, ((quad x i).totient : ℝ)) = pairedWeight (quad x) := by
  rw [← extended_normalization U (quad x) hU hq hsub,
    channelPairing_product, ← Finset.prod_div_distrib]
  exact extended_pairedWeight U (quad x) hU hq hsub

theorem scalar_pairing_eq_signedWeight (U : Finset ℕ) (x : Four)
    (hU : ∀ p ∈ U, p.Prime) (hq : ∀ i, Squarefree (quad x i))
    (hsub : primeUniverse (quad x) ⊆ U) :
    pairScalar x.1 * pairScalar x.2 * channelPairing U x =
      quadSign (quad x) * pairedWeight (quad x) := by
  rw [← channelPairing_normalized U x hU hq hsub]
  simp [pairScalar, quadSign, quad, Fin.prod_univ_succ, div_eq_mul_inv, mul_inv_rev]
  ring

theorem coefficientEnergy_signed_expansion (U S : Finset ℕ)
    (hU : ∀ p ∈ U, p.Prime) (hS : ∀ q ∈ S, Squarefree q)
    (hsub : ∀ q ∈ S, q.primeFactors ⊆ U) :
    coefficientEnergy U S =
      ∑ x ∈ (S.product S).product (S.product S),
        quadSign (quad x) * pairedWeight (quad x) := by
  unfold coefficientEnergy squareCoefficient
  rw [finite_coefficient_energy_expansion]
  rw [← Finset.sum_product (S.product S) (S.product S) (fun x : Four =>
    ∑ g ∈ U.powerset, subsetPrimeProduct g *
      (pairScalar x.1 * pairChannel U x.1 g) *
      (pairScalar x.2 * pairChannel U x.2 g))]
  apply Finset.sum_congr rfl
  intro x hx
  have hm := Finset.mem_product.mp hx
  have hl := Finset.mem_product.mp hm.1
  have hr := Finset.mem_product.mp hm.2
  have hqx : ∀ i, Squarefree (quad x i) := by
    intro i
    fin_cases i
    · exact hS _ hl.1
    · exact hS _ hl.2
    · exact hS _ hr.1
    · exact hS _ hr.2
  have hqxsub : primeUniverse (quad x) ⊆ U := by
    intro p hp
    obtain ⟨i, _, hi⟩ := Finset.mem_biUnion.mp hp
    fin_cases i
    · exact hsub _ hl.1 hi
    · exact hsub _ hl.2 hi
    · exact hsub _ hr.1 hi
    · exact hsub _ hr.2 hi
  rw [← scalar_pairing_eq_signedWeight U x hU hqx hqxsub]
  unfold channelPairing
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro g hg
  ring

theorem pairedWeight_nonneg (q : Index → ℕ) : 0 ≤ pairedWeight q := by
  unfold pairedWeight
  apply Finset.prod_nonneg
  intro p hp
  by_cases hl : 2 ≤ (occurrence q p).card
  · exact (localWeight_nonneg_and_bound (by exact_mod_cast (universe_prime hp).two_le)
      (mem_patterns.mpr hl)).1
  · have hc : (occurrence q p).card = 1 := by
      have hpos := Finset.card_pos.mpr (occurrence_nonempty hp)
      omega
    obtain ⟨i, hi⟩ := Finset.card_eq_one.mp hc
    rw [hi, singleton_weight_zero]

theorem quadSign_le_one (q : Index → ℕ) (hq : ∀ i, Squarefree (q i)) :
    quadSign q ≤ 1 := by
  have hm : ∀ i, muReal (q i) ^ 2 = 1 := by
    intro i
    unfold muReal
    exact_mod_cast ArithmeticFunction.moebius_sq_eq_one_of_squarefree (hq i)
  have hs : quadSign q ^ 2 = 1 := by
    calc
      _ = (muReal (q 0) ^ 2) * (muReal (q 1) ^ 2) *
          (muReal (q 2) ^ 2) * (muReal (q 3) ^ 2) := by unfold quadSign; ring
      _ = 1 := by rw [hm 0, hm 1, hm 2, hm 3]; norm_num
  nlinarith [sq_nonneg (quadSign q - 1)]

theorem coefficientEnergy_le_paired_mass (U S : Finset ℕ)
    (hU : ∀ p ∈ U, p.Prime) (hS : ∀ q ∈ S, Squarefree q)
    (hsub : ∀ q ∈ S, q.primeFactors ⊆ U) :
    coefficientEnergy U S ≤
      ∑ q ∈ ((S.product S).product (S.product S)).image quad, pairedWeight q := by
  classical
  rw [coefficientEnergy_signed_expansion U S hU hS hsub,
    Finset.sum_image (fun x hx y hy h => quad_injective h)]
  apply Finset.sum_le_sum
  intro x hx
  apply mul_le_of_le_one_left (pairedWeight_nonneg _)
  apply quadSign_le_one
  intro i
  have hm := Finset.mem_product.mp hx
  have hl := Finset.mem_product.mp hm.1
  have hr := Finset.mem_product.mp hm.2
  fin_cases i
  · exact hS _ hl.1
  · exact hS _ hl.2
  · exact hS _ hr.1
  · exact hS _ hr.2

theorem quad_mem_support {S : Finset ℕ} {x : Four}
    (hx : x ∈ (S.product S).product (S.product S)) (i : Index) : quad x i ∈ S := by
  obtain ⟨hl, hr⟩ := Finset.mem_product.mp hx
  obtain ⟨h0, h1⟩ := Finset.mem_product.mp hl
  obtain ⟨h2, h3⟩ := Finset.mem_product.mp hr
  fin_cases i
  · exact h0
  · exact h1
  · exact h2
  · exact h3

theorem actual_terminal_coefficient_energy (S : Finset ℕ) (Q : ℕ) (hQ : 0 < Q)
    (hs : ∀ q ∈ S, Odd q ∧ Squarefree q ∧ q ≤ Q ∧ (Q : ℝ) / 2 < q) :
    coefficientEnergy (Mass.oddPrimes Q) S ≤
      8 * Mass.oddEulerMass Q ^ 11 * Mass.oddHarmonic Q ^ 7 := by
  classical
  apply le_trans (coefficientEnergy_le_paired_mass (Mass.oddPrimes Q) S
    (fun p hp => (Mass.mem_oddPrimes.mp hp).2.1)
    (fun q hq => (hs q hq).2.1)
    (fun q hq => Mass.odd_primeFactors_subset (hs q hq).2.1 (hs q hq).1 (hs q hq).2.2.1))
  apply Anchors.actual_terminal_paired_mass_all _ Q hQ
  intro q hq
  obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hq
  constructor
  · intro i
    exact ⟨(hs _ (quad_mem_support hx i)).1,
      (hs _ (quad_mem_support hx i)).2.1, (hs _ (quad_mem_support hx i)).2.2.1⟩
  · intro i
    exact ⟨(hs _ (quad_mem_support hx i)).2.2.2,
      by
        change (quad x i : ℝ) ≤ (Q : ℝ)
        exact_mod_cast (hs _ (quad_mem_support hx i)).2.2.1⟩

theorem actual_terminal_coefficient_energy_min (S : Finset ℕ) (Q : ℕ) (hQ : 0 < Q)
    (hs : ∀ q ∈ S, Odd q ∧ Squarefree q ∧ q ≤ Q ∧ (Q : ℝ) / 2 < q) :
    coefficientEnergy (Mass.oddPrimes Q) S ≤
      8 * Mass.oddEulerMass Q ^ 11 * min (Mass.oddHarmonic Q ^ 7)
        (Anchors.supportPolynomial (4 * Real.log (Q : ℝ))) := by
  classical
  apply le_trans (coefficientEnergy_le_paired_mass (Mass.oddPrimes Q) S
    (fun p hp => (Mass.mem_oddPrimes.mp hp).2.1)
    (fun q hq => (hs q hq).2.1)
    (fun q hq => Mass.odd_primeFactors_subset (hs q hq).2.1 (hs q hq).1 (hs q hq).2.2.1))
  apply Anchors.actual_terminal_paired_mass_min _ Q hQ
  intro q hq
  obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp hq
  constructor
  · intro i
    exact ⟨(hs _ (quad_mem_support hx i)).1,
      (hs _ (quad_mem_support hx i)).2.1, (hs _ (quad_mem_support hx i)).2.2.1⟩
  · intro i
    exact ⟨(hs _ (quad_mem_support hx i)).2.2.2, by
      change (quad x i : ℝ) ≤ (Q : ℝ)
      exact_mod_cast (hs _ (quad_mem_support hx i)).2.2.1⟩

noncomputable def squarefreeRamanujanProduct (q n : ℕ) : ℝ :=
  ∏ p ∈ q.primeFactors, primeRamanujan p n

theorem common_universe_factor_product (U : Finset ℕ) (q n : ℕ)
    (hU : ∀ p ∈ U, p.Prime) (hq : Squarefree q) (hsub : q.primeFactors ⊆ U) :
    (∏ p ∈ U, factor q p n) = squarefreeRamanujanProduct q n := by
  unfold squarefreeRamanujanProduct
  calc
    _ = ∏ p ∈ q.primeFactors, factor q p n := by
      symm
      apply Finset.prod_subset hsub
      intro p hp hnot
      have hd : ¬p ∣ q := by
        intro h
        exact hnot (Nat.mem_primeFactors.mpr ⟨hU p hp, h, hq.ne_zero⟩)
      simp [factor, hd]
    _ = _ := by
      apply Finset.prod_congr rfl
      intro p hp
      simp [factor, Nat.dvd_of_mem_primeFactors hp]

theorem divisorProxy_eq_squarefree_sum (U S : Finset ℕ) (n : ℕ)
    (hU : ∀ p ∈ U, p.Prime) (hS : ∀ q ∈ S, Squarefree q)
    (hsub : ∀ q ∈ S, q.primeFactors ⊆ U) :
    divisorProxy U S n =
      ∑ q ∈ S, muReal q / (q.totient : ℝ) * squarefreeRamanujanProduct q n := by
  unfold divisorProxy
  apply Finset.sum_congr rfl
  intro q hq
  rw [common_universe_factor_product U q n hU (hS q hq) (hsub q hq)]

noncomputable def terminalSupport (Q : ℕ) : Finset ℕ := by
  classical
  exact (Finset.range (Q + 1)).filter (fun q => Odd q ∧ Squarefree q ∧ Q < 2 * q)

theorem terminalSupport_conditions (Q q : ℕ) (hq : q ∈ terminalSupport Q) :
    Odd q ∧ Squarefree q ∧ q ≤ Q ∧ (Q : ℝ) / 2 < q := by
  have hh := Finset.mem_filter.mp hq
  have hup : q ≤ Q := by have := Finset.mem_range.mp hh.1; omega
  refine ⟨hh.2.1, hh.2.2.1, hup, ?_⟩
  have hlow : (Q : ℝ) < 2 * (q : ℝ) := by exact_mod_cast hh.2.2.2
  linarith

theorem terminal_coefficient_energy_bound (Q : ℕ) (hQ : 0 < Q) :
    coefficientEnergy (Mass.oddPrimes Q) (terminalSupport Q) ≤
      8 * Mass.oddEulerMass Q ^ 11 * min (Mass.oddHarmonic Q ^ 7)
        (Anchors.supportPolynomial (4 * Real.log (Q : ℝ))) :=
  actual_terminal_coefficient_energy_min (terminalSupport Q) Q hQ
    (fun q hq => terminalSupport_conditions Q q hq)

noncomputable def centeredCoefficientEnergy (U S : Finset ℕ) : ℝ :=
  ∑ g ∈ U.powerset.filter (fun g => g ≠ ∅),
    subsetPrimeProduct g * (squareCoefficient U S g) ^ 2

theorem centeredCoefficientEnergy_le (U S : Finset ℕ) :
    centeredCoefficientEnergy U S ≤ coefficientEnergy U S := by
  apply Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _)
  intro g hg hnot
  exact mul_nonneg (Finset.prod_nonneg (fun p hp => Nat.cast_nonneg p)) (sq_nonneg _)

theorem terminal_centered_coefficient_energy_bound (Q : ℕ) (hQ : 0 < Q) :
    centeredCoefficientEnergy (Mass.oddPrimes Q) (terminalSupport Q) ≤
      8 * Mass.oddEulerMass Q ^ 11 * min (Mass.oddHarmonic Q ^ 7)
        (Anchors.supportPolynomial (4 * Real.log (Q : ℝ))) :=
  (centeredCoefficientEnergy_le _ _).trans (terminal_coefficient_energy_bound Q hQ)

theorem terminal_coefficient_energy_polynomial_bound (Q : ℕ) (hQ : 0 < Q) :
    coefficientEnergy (Mass.oddPrimes Q) (terminalSupport Q) ≤
      8 * Mass.oddEulerMass Q ^ 11 * min (Mass.oddHarmonic Q ^ 7)
        (goldbachSimplexPolynomial (2 * Real.log (Q : ℝ))) := by
  have hb := terminal_coefficient_energy_bound Q hQ
  rw [Anchors.supportPolynomial_eq_explicit,
    show (4 * Real.log (Q : ℝ)) / 2 = 2 * Real.log (Q : ℝ) by ring] at hb
  exact hb

theorem terminal_centered_coefficient_energy_polynomial_bound (Q : ℕ) (hQ : 0 < Q) :
    centeredCoefficientEnergy (Mass.oddPrimes Q) (terminalSupport Q) ≤
      8 * Mass.oddEulerMass Q ^ 11 * min (Mass.oddHarmonic Q ^ 7)
        (goldbachSimplexPolynomial (2 * Real.log (Q : ℝ))) :=
  (centeredCoefficientEnergy_le _ _).trans (terminal_coefficient_energy_polynomial_bound Q hQ)

#print axioms divisorProxy_square_expansion
#print axioms finite_coefficient_energy_expansion
#print axioms extended_pairedWeight
#print axioms extended_normalization
#print axioms coefficientEnergy_signed_expansion
#print axioms coefficientEnergy_le_paired_mass
#print axioms actual_terminal_coefficient_energy
#print axioms actual_terminal_coefficient_energy_min
#print axioms divisorProxy_eq_squarefree_sum
#print axioms terminal_coefficient_energy_bound
#print axioms terminal_centered_coefficient_energy_bound
#print axioms terminal_coefficient_energy_polynomial_bound
#print axioms terminal_centered_coefficient_energy_polynomial_bound

end GoldbachResearch.CoefficientEnergy
