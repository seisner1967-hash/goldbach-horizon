import GoldbachKloostermanGeometry
import Mathlib.NumberTheory.VonMangoldt

/-!
Exact localization of the signed divisibility branch.  The strict cutoff and
the omitted-divisor union remain visible; no estimate of that defect is assumed.
-/

namespace GoldbachResearch.SignedDivisorLocalization

open scoped BigOperators
open Finset ActualArithmetic SignedKernel

noncomputable section

theorem divisor_pair_with_mask {m k : ℕ} (hkm : k ∣ m) :
    muReal k * muReal m =
      if k.Coprime (m / k) then muReal k ^ 2 * muReal (m / k) else 0 := by
  have hm : k * (m / k) = m := Nat.mul_div_cancel' hkm
  have hmul := muReal_mul_exact k (m / k)
  rw [hm] at hmul
  rw [hmul]
  by_cases hc : k.Coprime (m / k)
  · simp only [if_pos hc]
    ring
  · simp [hc]

theorem divisor_sign_to_complement {m k : ℕ} (hkm : k ∣ m) :
    muReal k * muReal m = muReal m ^ 2 * muReal (m / k) := by
  by_cases hsf : Squarefree m
  · have hsfk : Squarefree k := Squarefree.squarefree_of_dvd hkm hsf
    have hm : k * (m / k) = m := Nat.mul_div_cancel' hkm
    have hcop : k.Coprime (m / k) := Nat.coprime_of_squarefree_mul (by simpa [hm] using hsf)
    have hmsq : muReal m ^ 2 = 1 := by
      unfold muReal
      exact_mod_cast ArithmeticFunction.moebius_sq_eq_one_of_squarefree hsf
    have hksq : muReal k ^ 2 = 1 := by
      unfold muReal
      exact_mod_cast ArithmeticFunction.moebius_sq_eq_one_of_squarefree hsfk
    rw [divisor_pair_with_mask hkm, if_pos hcop, hksq, hmsq]
  · have hmzero : muReal m = 0 := by
      simp [muReal, ArithmeticFunction.moebius_eq_zero_of_not_squarefree hsf]
    simp [hmzero]

theorem divisor_log_eq_neg_complement {m k : ℕ} (hm : 0 < m) (hkm : k ∣ m) :
    Real.log ((k : ℝ) / (m : ℝ)) = -Real.log (m / k : ℕ) := by
  have hk : 0 < k := Nat.pos_of_dvd_of_pos hkm hm
  have ht : 0 < m / k := Nat.div_pos (Nat.le_of_dvd hm hkm) hk
  have hprod : k * (m / k) = m := Nat.mul_div_cancel' hkm
  have h := cofactor_log hk ht
  rw [hprod] at h
  exact h

theorem sum_divisors_complement {R : Type*} [AddCommMonoid R]
    (m : ℕ) (F : ℕ → R) :
    (∑ k ∈ m.divisors, F k) = ∑ t ∈ m.divisors, F (m / t) := by
  calc
    _ = ∑ p ∈ m.divisorsAntidiagonal, F p.1 :=
      (Nat.sum_divisorsAntidiagonal (fun k _ => F k)).symm
    _ = _ := Nat.sum_divisorsAntidiagonal' (fun k _ => F k)

theorem complete_divisor_log (m : ℕ) :
    (∑ k ∈ m.divisors, muReal k * Real.log ((k : ℝ) / (m : ℝ))) =
      -ArithmeticFunction.vonMangoldt m := by
  by_cases hm : m = 0
  · simp [hm]
  have hsplit : (∑ k ∈ m.divisors, muReal k * Real.log ((k : ℝ) / (m : ℝ))) =
      (∑ k ∈ m.divisors, muReal k * Real.log k) -
        (∑ k ∈ m.divisors, muReal k) * Real.log m := by
    rw [Finset.sum_mul, ← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro k hk
    have hkm := (Nat.mem_divisors.mp hk).1
    have hkpos := Nat.pos_of_dvd_of_pos hkm (Nat.pos_of_ne_zero hm)
    rw [Real.log_div (by exact_mod_cast hkpos.ne') (by exact_mod_cast hm)]
    ring
  have hsum : (∑ k ∈ m.divisors, muReal k) = if m = 1 then 1 else 0 := by
    have h : ((ArithmeticFunction.moebius : ArithmeticFunction ℝ) *
        ArithmeticFunction.zeta) m = if m = 1 then 1 else 0 := by
      rw [ArithmeticFunction.coe_moebius_mul_coe_zeta]
      simp [ArithmeticFunction.one_apply]
    rw [ArithmeticFunction.coe_mul_zeta_apply] at h
    exact h
  have hlog : (∑ k ∈ m.divisors, muReal k * Real.log k) =
      -ArithmeticFunction.vonMangoldt m := by
    simpa [muReal, ArithmeticFunction.log_apply] using
      (ArithmeticFunction.sum_moebius_mul_log_eq (n := m))
  rw [hsplit, hlog, hsum]
  by_cases hmone : m = 1 <;> simp [hmone]

theorem completed_prime_detector (m : ℕ) :
    muReal m ^ 2 * ArithmeticFunction.vonMangoldt m =
      if m.Prime then Real.log m else 0 := by
  by_cases hp : m.Prime
  · have hs : muReal m ^ 2 = 1 := by
      unfold muReal
      exact_mod_cast ArithmeticFunction.moebius_sq_eq_one_of_squarefree hp.squarefree
    rw [if_pos hp, hs, one_mul, ArithmeticFunction.vonMangoldt_apply_prime hp]
  · rw [if_neg hp]
    by_cases hpow : IsPrimePow m
    · have hz : muReal m = 0 := by
        simp [muReal, ArithmeticFunction.moebius_apply_isPrimePow_not_prime hpow hp]
      simp [hz]
    · rw [ArithmeticFunction.vonMangoldt_eq_zero_iff.mpr hpow, mul_zero]

def truncatedDetector (m alpha Q : ℕ) : ℝ :=
  muReal m * ∑ k ∈ m.divisors,
    if k ≤ Q ∧ alpha * k < m then
      muReal k * Real.log ((k : ℝ) / (m : ℝ)) else 0

def omittedComplement (m alpha Q : ℕ) : ℝ :=
  ∑ t ∈ m.divisors, if t ≤ alpha ∨ Q < m / t then
    muReal t * Real.log t else 0

theorem truncatedDetector_eq_complement (m alpha Q : ℕ) (hm : 0 < m) :
    truncatedDetector m alpha Q =
      -muReal m ^ 2 * ∑ t ∈ m.divisors,
        if alpha < t ∧ m / t ≤ Q then muReal t * Real.log t else 0 := by
  unfold truncatedDetector
  rw [sum_divisors_complement, Finset.mul_sum, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro t ht
  have htm := (Nat.mem_divisors.mp ht).1
  have htpos := Nat.pos_of_dvd_of_pos htm hm
  have hkdiv : m / t ∣ m := Nat.div_dvd_of_dvd htm
  have hkpos := Nat.div_pos (Nat.le_of_dvd hm htm) htpos
  have hprod : (m / t) * t = m := Nat.div_mul_cancel htm
  have hcut : alpha * (m / t) < m ↔ alpha < t := by
    calc
      _ ↔ alpha * (m / t) < (m / t) * t := by rw [hprod]
      _ ↔ alpha < t := by
        rw [Nat.mul_comm alpha]
        exact Nat.mul_lt_mul_left hkpos
  simp only [hcut]
  by_cases hact : alpha < t ∧ m / t ≤ Q
  · have hact' : m / t ≤ Q ∧ alpha < t := hact.symm
    rw [if_pos hact', if_pos hact,
      divisor_log_eq_neg_complement hm hkdiv, Nat.div_div_self htm hm.ne']
    have hsign := divisor_sign_to_complement hkdiv
    rw [Nat.div_div_self htm hm.ne'] at hsign
    calc
      _ = -(muReal (m / t) * muReal m) * Real.log t := by ring
      _ = -(muReal m ^ 2 * muReal t) * Real.log t := by rw [hsign]
      _ = _ := by ring
  · have hact' : ¬(m / t ≤ Q ∧ alpha < t) := fun h => hact h.symm
    simp [hact, hact']

theorem truncatedDetector_exact_defect (m alpha Q : ℕ) (hm : 0 < m) :
    truncatedDetector m alpha Q = (if m.Prime then Real.log m else 0) +
      muReal m ^ 2 * omittedComplement m alpha Q := by
  have hsplit : (∑ t ∈ m.divisors,
      if alpha < t ∧ m / t ≤ Q then muReal t * Real.log t else 0) +
      omittedComplement m alpha Q = -ArithmeticFunction.vonMangoldt m := by
    unfold omittedComplement
    rw [← Finset.sum_add_distrib]
    have heq : (∑ t ∈ m.divisors,
        ((if alpha < t ∧ m / t ≤ Q then muReal t * Real.log t else 0) +
        (if t ≤ alpha ∨ Q < m / t then muReal t * Real.log t else 0))) =
        ∑ t ∈ m.divisors, muReal t * Real.log t := by
      apply Finset.sum_congr rfl
      intro t ht
      by_cases hact : alpha < t ∧ m / t ≤ Q
      · have homit : ¬(t ≤ alpha ∨ Q < m / t) := by omega
        simp [hact, homit]
      · have homit : t ≤ alpha ∨ Q < m / t := by omega
        simp [hact, homit]
    rw [heq]
    simpa [muReal, ArithmeticFunction.log_apply] using
      (ArithmeticFunction.sum_moebius_mul_log_eq (n := m))
  rw [truncatedDetector_eq_complement m alpha Q hm,
    ← completed_prime_detector m]
  nlinarith [hsplit]

theorem canonical_complement_cap {N m alpha t : ℕ}
    (ha : 0 < alpha) (hmN : m ≤ N - 1) (ht : alpha < t) :
    m / t ≤ (N - 1) / alpha := by
  apply (Nat.le_div_iff_mul_le ha).mpr
  calc
    m / t * alpha ≤ m / t * t := Nat.mul_le_mul_left (m / t) ht.le
    _ ≤ m := Nat.div_mul_le_self m t
    _ ≤ N - 1 := hmN

theorem omittedComplement_canonical {N m alpha : ℕ}
    (ha : 0 < alpha) (hmN : m ≤ N - 1) :
    omittedComplement m alpha ((N - 1) / alpha) =
      ∑ t ∈ m.divisors, if t ≤ alpha then muReal t * Real.log t else 0 := by
  unfold omittedComplement
  apply Finset.sum_congr rfl
  intro t ht
  by_cases hta : t ≤ alpha
  · simp [hta]
  · have hcap := canonical_complement_cap ha hmN (Nat.lt_of_not_ge hta)
    simp [hta, Nat.not_lt.mpr hcap]

theorem truncatedDetector_canonical_exact_defect {N m alpha : ℕ}
    (ha : 0 < alpha) (hm : 0 < m) (hmN : m ≤ N - 1) :
    truncatedDetector m alpha ((N - 1) / alpha) =
      (if m.Prime then Real.log m else 0) + muReal m ^ 2 *
        ∑ t ∈ m.divisors, if t ≤ alpha then muReal t * Real.log t else 0 := by
  rw [truncatedDetector_exact_defect m alpha ((N - 1) / alpha) hm,
    omittedComplement_canonical ha hmN]

#print axioms divisor_pair_with_mask
#print axioms divisor_sign_to_complement
#print axioms divisor_log_eq_neg_complement
#print axioms sum_divisors_complement
#print axioms complete_divisor_log
#print axioms completed_prime_detector
#print axioms truncatedDetector_eq_complement
#print axioms truncatedDetector_exact_defect
#print axioms canonical_complement_cap
#print axioms omittedComplement_canonical
#print axioms truncatedDetector_canonical_exact_defect

end
end GoldbachResearch.SignedDivisorLocalization
