import GoldbachTypeIIAssembly

/-!
# Exact small-divisor structure of the genuine Vaughan beta coefficient

The identities below retain an arbitrary signed column profile.  They expose
the beta contraction as a logarithmic contraction minus a small-divisor
contraction.  They do not assert a cancellation or uniform smallness estimate.
-/

namespace GoldbachResearch.BetaStructure

open scoped BigOperators
open Finset ActualArithmetic

/-- A signed beta column profile, including the literal moving row. -/
noncomputable def actualProfile (N cutoff k U b : ℕ) : ℝ :=
  ∑ a ∈ TypeIIAssembly.activeFirst N U,
    muReal a * Bilinear.actualTypeIIKernel N cutoff k a b

/-- This is an identity of arithmetic functions, not an asymptotic estimate. -/
theorem beta_eq_log_sub_small (V : ℕ) :
    Vaughan.beta V = ArithmeticFunction.log -
      Vaughan.cutLE V ArithmeticFunction.vonMangoldt * Vaughan.zeta := by
  have hv : Vaughan.cutGT V ArithmeticFunction.vonMangoldt =
      ArithmeticFunction.vonMangoldt -
        Vaughan.cutLE V ArithmeticFunction.vonMangoldt := by
    rw [eq_sub_iff_add_eq, add_comm]
    exact (Vaughan.cut_split V ArithmeticFunction.vonMangoldt).symm
  have hlog : ArithmeticFunction.vonMangoldt * Vaughan.zeta =
      ArithmeticFunction.log := ArithmeticFunction.vonMangoldt_mul_zeta
  unfold Vaughan.beta
  rw [hv, sub_mul, hlog]

/-- The small-divisor correction is exact, including b=0. -/
theorem beta_pointwise_log_sub_small (V b : ℕ) :
    Vaughan.beta V b = Real.log b - ∑ d ∈ b.divisors,
      if d ≤ V then ArithmeticFunction.vonMangoldt d else 0 := by
  rw [beta_eq_log_sub_small]
  change Real.log b -
    (Vaughan.cutLE V ArithmeticFunction.vonMangoldt * Vaughan.zeta) b = _
  unfold Vaughan.zeta
  rw [ArithmeticFunction.coe_mul_zeta_apply]
  rfl

/-- No absolute values or positivity assumptions are imposed on T. -/
theorem beta_weighted_contraction (B : Finset ℕ) (V : ℕ) (T : ℕ → ℝ) :
    (∑ b ∈ B, Vaughan.beta V b * T b) =
      (∑ b ∈ B, Real.log b * T b) -
        ∑ b ∈ B, (∑ d ∈ b.divisors,
          if d ≤ V then ArithmeticFunction.vonMangoldt d else 0) * T b := by
  simp_rw [beta_pointwise_log_sub_small, sub_mul]
  exact Finset.sum_sub_distrib

/-- Complete multiplicative fibers cancel exactly. This does not remove
the strict Vaughan first-factor cutoff or a dyadic rectangle restriction. -/
theorem moebius_mul_beta_eq_highLambda (V : ℕ) :
    Vaughan.mu * Vaughan.beta V =
      Vaughan.cutGT V ArithmeticFunction.vonMangoldt := by
  have hmu : Vaughan.mu * Vaughan.zeta = 1 :=
    ArithmeticFunction.coe_moebius_mul_coe_zeta
  calc
    Vaughan.mu * Vaughan.beta V =
        (Vaughan.mu * Vaughan.zeta) *
          Vaughan.cutGT V ArithmeticFunction.vonMangoldt := by
      unfold Vaughan.beta
      ring
    _ = _ := by rw [hmu, one_mul]

/-- Only the complete divisor-antidiagonal is contracted in this identity. -/
theorem complete_fiber_moebius_beta (V n : ℕ) :
    (∑ p ∈ n.divisorsAntidiagonal, Vaughan.mu p.1 * Vaughan.beta V p.2) =
      if V < n then ArithmeticFunction.vonMangoldt n else 0 := by
  have h := congrArg (fun f : ArithmeticFunction ℝ => f n)
    (moebius_mul_beta_eq_highLambda V)
  change (Vaughan.mu * Vaughan.beta V) n =
    Vaughan.cutGT V ArithmeticFunction.vonMangoldt n at h
  rw [ArithmeticFunction.mul_apply] at h
  exact h

/-- Removing small first factors leaves an exact boundary correction.
Bounding this correction is still an arithmetic task; this identity alone
is a reorganization of Vaughan and gives no new cancellation estimate. -/
theorem typeTwo_eq_highLambda_sub_boundary (U V : ℕ) :
    Vaughan.typeTwo U V = Vaughan.cutGT V ArithmeticFunction.vonMangoldt -
      Vaughan.cutLE U Vaughan.mu * Vaughan.beta V := by
  have hm : Vaughan.cutGT U Vaughan.mu =
      Vaughan.mu - Vaughan.cutLE U Vaughan.mu := by
    rw [eq_sub_iff_add_eq, add_comm]
    exact (Vaughan.cut_split U Vaughan.mu).symm
  unfold Vaughan.typeTwo
  rw [mul_assoc]
  change Vaughan.cutGT U Vaughan.mu * Vaughan.beta V = _
  rw [hm, sub_mul, moebius_mul_beta_eq_highLambda]

/-- The small divisor can be separated from its complementary factor exactly. -/
theorem small_divisor_antidiagonal (V b : ℕ) :
    (∑ d ∈ b.divisors,
      if d ≤ V then ArithmeticFunction.vonMangoldt d else 0) =
      ∑ p ∈ b.divisorsAntidiagonal,
        if p.1 ≤ V then ArithmeticFunction.vonMangoldt p.1 else 0 := by
  change (∑ d ∈ b.divisors,
    Vaughan.cutLE V ArithmeticFunction.vonMangoldt d) = _
  rw [← ArithmeticFunction.coe_mul_zeta_apply, ArithmeticFunction.mul_apply]
  apply Finset.sum_congr rfl
  intro p hp
  have hp0 : p.1 * p.2 ≠ 0 :=
    (Nat.mem_divisorsAntidiagonal.mp hp).1 ▸ (Nat.mem_divisorsAntidiagonal.mp hp).2
  rw [ArithmeticFunction.natCoe_apply,
    ArithmeticFunction.zeta_apply_ne (right_ne_zero_of_mul hp0)]
  simp only [Nat.cast_one, mul_one, Vaughan.cutLE_apply]

/-- A general rectangle reindexing for the signed small-divisor contraction.
The two support premises are literal zero conditions, not cancellation bounds. -/
theorem small_divisor_profile_rectangle (N V : ℕ) (T : ℕ → ℝ)
    (hzero : T 0 = 0) (houtside : ∀ b, N ≤ b → T b = 0) :
    (∑ b ∈ range N, (∑ d ∈ b.divisors,
      if d ≤ V then ArithmeticFunction.vonMangoldt d else 0) * T b) =
      ∑ d ∈ range N, ∑ e ∈ range N,
        (if d ≤ V then ArithmeticFunction.vonMangoldt d else 0) * T (d * e) := by
  simp_rw [small_divisor_antidiagonal, Finset.sum_mul]
  let f : ℕ × ℕ → ℝ := fun p =>
    (if p.1 ≤ V then ArithmeticFunction.vonMangoldt p.1 else 0) * T (p.1 * p.2)
  have hindex : (∑ b ∈ range N, ∑ p ∈ b.divisorsAntidiagonal,
      (if p.1 ≤ V then ArithmeticFunction.vonMangoldt p.1 else 0) * T b) =
      ∑ b ∈ range N, ∑ p ∈ b.divisorsAntidiagonal, f p := by
    apply Finset.sum_congr rfl
    intro b hb
    apply Finset.sum_congr rfl
    intro p hp
    simp only [f, (Nat.mem_divisorsAntidiagonal.mp hp).1]
  rw [hindex]
  have hz : ∀ p, p.1 * p.2 = 0 → f p = 0 := by
    intro p hp
    simp [f, hp, hzero]
  have ho : ∀ p, N ≤ p.1 * p.2 → f p = 0 := by
    intro p hp
    simp [f, houtside _ hp]
  rw [TypeIIAssembly.divisor_sum_eq_rectangle N f hz ho]
  exact Finset.sum_product (range N) (range N) f

theorem actualProfile_zero (N cutoff k U : ℕ) :
    actualProfile N cutoff k U 0 = 0 := by
  simp [actualProfile, Bilinear.actualTypeIIKernel, actualRow_zero_at_zero]

theorem actualProfile_zero_outside (N cutoff k U b : ℕ) (hb : N ≤ b) :
    actualProfile N cutoff k U b = 0 := by
  unfold actualProfile
  apply Finset.sum_eq_zero
  intro a ha
  have ha0 : 0 < a := by
    have hu : U < a := (Finset.mem_filter.mp ha).2
    omega
  have hab : N ≤ a * b :=
    le_trans hb (Nat.le_mul_of_pos_left b ha0)
  simp [Bilinear.actualTypeIIKernel, actualRow_zero_outside_target hab]

/-- The actual Type II row retains every sign in its logarithmic and
small-divisor contractions. The support comes from the actual arithmetic row. -/
theorem actual_signedRow_typeTwo_beta_split (N cutoff k U V : ℕ) :
    Vaughan.signedRow N cutoff k (Vaughan.typeTwo U V) =
      (∑ b ∈ range N, Real.log b * actualProfile N cutoff k U b) -
        ∑ d ∈ range N, ∑ e ∈ range N,
          (if d ≤ V then ArithmeticFunction.vonMangoldt d else 0) *
            actualProfile N cutoff k U (d * e) := by
  rw [TypeIIAssembly.actual_signedRow_typeTwo_eq_bilinear,
    Bilinear.bilinearSum_eq_transpose]
  have hprofile :
      Bilinear.bilinearSum (range N) (range N) (Vaughan.beta V)
        (TypeIIAssembly.vaughanAlpha U)
        (fun b a => Bilinear.actualTypeIIKernel N cutoff k a b) =
      ∑ b ∈ range N, Vaughan.beta V b * actualProfile N cutoff k U b := by
    unfold Bilinear.bilinearSum actualProfile TypeIIAssembly.activeFirst
    apply Finset.sum_congr rfl
    intro b hb
    congr 1
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro a ha
    by_cases hu : U < a
    · simp only [TypeIIAssembly.vaughanAlpha, if_pos hu]
      rfl
    · simp [TypeIIAssembly.vaughanAlpha, hu]
  rw [hprofile, beta_weighted_contraction]
  rw [small_divisor_profile_rectangle N V (actualProfile N cutoff k U)
    (actualProfile_zero N cutoff k U)
    (fun b hb => actualProfile_zero_outside N cutoff k U b hb)]

#print axioms beta_eq_log_sub_small
#print axioms beta_pointwise_log_sub_small
#print axioms beta_weighted_contraction
#print axioms moebius_mul_beta_eq_highLambda
#print axioms complete_fiber_moebius_beta
#print axioms typeTwo_eq_highLambda_sub_boundary
#print axioms small_divisor_antidiagonal
#print axioms small_divisor_profile_rectangle
#print axioms actual_signedRow_typeTwo_beta_split

end GoldbachResearch.BetaStructure
