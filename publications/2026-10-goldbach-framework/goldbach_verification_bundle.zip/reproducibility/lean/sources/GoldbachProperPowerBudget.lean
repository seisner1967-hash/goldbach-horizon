import GoldbachPrimePairMargin
import Mathlib.Data.Nat.Log
import Mathlib.Data.Nat.Sqrt
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Algebra.BigOperators.Intervals

/-!
An unconditional elementary contamination budget for the literal terminal
representation. Proper prime powers are covered by a finite base/exponent box.
No cancellation bound, prime-pair margin, or contamination estimate is a premise.
-/

namespace GoldbachResearch.ProperPowerBudget

open scoped BigOperators
open Finset ActualArithmetic PrimePairMargin

noncomputable section

def properPrimePowersBelow (N : ℕ) : Finset ℕ :=
  (range N).filter fun n => IsPrimePow n ∧ ¬n.Prime

def powerBox (N : ℕ) : Finset (ℕ × ℕ) :=
  (Icc 1 (Nat.sqrt N)).product (Icc 1 (Nat.log 2 N))

theorem proper_prime_power_bounds {N n : ℕ} (hn : n < N)
    (hpp : IsPrimePow n) (hprime : ¬n.Prime) :
    ∃ p e : ℕ, p.Prime ∧ 2 ≤ e ∧ p ^ e = n ∧
      p ≤ Nat.sqrt N ∧ e ≤ Nat.log 2 N := by
  rcases (isPrimePow_nat_iff n).mp hpp with ⟨p, e, hp, he, hpow⟩
  have he1 : e ≠ 1 := by
    intro h
    apply hprime
    simpa only [← hpow, h, pow_one] using hp
  have he2 : 2 ≤ e := by omega
  have hsq : p ^ 2 ≤ N := by
    calc
      p ^ 2 ≤ p ^ e := Nat.pow_le_pow_right hp.one_lt.le he2
      _ = n := hpow
      _ ≤ N := hn.le
  have htwo : 2 ^ e ≤ N := by
    calc
      2 ^ e ≤ p ^ e := Nat.pow_le_pow_left hp.two_le e
      _ = n := hpow
      _ ≤ N := hn.le
  exact ⟨p, e, hp, he2, hpow, Nat.le_sqrt'.mpr hsq,
    Nat.le_log_of_pow_le (by norm_num : 1 < (2 : ℕ)) htwo⟩

theorem properPrimePowersBelow_subset_image (N : ℕ) :
    properPrimePowersBelow N ⊆ (powerBox N).image (fun pe => pe.1 ^ pe.2) := by
  intro n hn
  rcases mem_filter.mp hn with ⟨hn, hpp, hprime⟩
  rcases proper_prime_power_bounds (mem_range.mp hn) hpp hprime with
    ⟨p, e, hp, he, hpow, hpS, heL⟩
  apply mem_image.mpr
  refine ⟨(p, e), ?_, hpow⟩
  exact mem_product.mpr ⟨mem_Icc.mpr ⟨hp.pos, hpS⟩, mem_Icc.mpr ⟨by omega, heL⟩⟩

theorem properPrimePowersBelow_card_le (N : ℕ) :
    (properPrimePowersBelow N).card ≤ Nat.sqrt N * Nat.log 2 N := by
  calc
    _ ≤ ((powerBox N).image (fun pe => pe.1 ^ pe.2)).card :=
      card_le_card (properPrimePowersBelow_subset_image N)
    _ ≤ (powerBox N).card := card_image_le
    _ = Nat.sqrt N * Nat.log 2 N := by
      unfold powerBox
      have hc := Finset.card_product (Icc (1 : ℕ) (Nat.sqrt N)) (Icc (1 : ℕ) (Nat.log 2 N))
      simpa only [Nat.card_Icc, Nat.add_sub_cancel] using hc

theorem nat_sqrt_cast_le_real_sqrt (N : ℕ) :
    (Nat.sqrt N : ℝ) ≤ Real.sqrt (N : ℝ) := by
  have hnat : (Nat.sqrt N : ℝ) ^ 2 ≤ (N : ℝ) := by exact_mod_cast Nat.sqrt_le' N
  have hs := Real.sq_sqrt (by positivity : 0 ≤ (N : ℝ))
  have hnonneg := Real.sqrt_nonneg (N : ℝ)
  have hnatnonneg : 0 ≤ (Nat.sqrt N : ℝ) := by positivity
  nlinarith

theorem nat_log_two_cast_le {N : ℕ} (hN : 1 ≤ N) :
    (Nat.log 2 N : ℝ) ≤ 2 * Real.log (N : ℝ) := by
  have hN0 : N ≠ 0 := by omega
  have hpow := Nat.pow_log_le_self 2 hN0
  have hreal : (2 : ℝ) ^ Nat.log 2 N ≤ (N : ℝ) := by exact_mod_cast hpow
  have hlog := Real.log_le_log (by positivity : 0 < (2 : ℝ) ^ Nat.log 2 N) hreal
  rw [Real.log_pow] at hlog
  have hhalf := half_le_log_of_two_le (2 : ℝ) (by norm_num)
  have he : 0 ≤ (Nat.log 2 N : ℝ) := by positivity
  nlinarith

theorem properPrimePowersBelow_card_real_le {N : ℕ} (hN : 1 ≤ N) :
    ((properPrimePowersBelow N).card : ℝ) ≤
      2 * Real.sqrt (N : ℝ) * Real.log (N : ℝ) := by
  have hs := nat_sqrt_cast_le_real_sqrt N
  have hl := nat_log_two_cast_le hN
  have hlog : 0 ≤ Real.log (N : ℝ) := Real.log_nonneg (by exact_mod_cast hN)
  calc
    _ ≤ (Nat.sqrt N : ℝ) * (Nat.log 2 N : ℝ) := by
      exact_mod_cast properPrimePowersBelow_card_le N
    _ ≤ Real.sqrt (N : ℝ) * (2 * Real.log (N : ℝ)) :=
      mul_le_mul hs hl (by positivity) (Real.sqrt_nonneg _)
    _ = _ := by ring

theorem properPowerTerm_eq_zero_off_support (N n : ℕ)
    (h : ¬ (IsPrimePow n ∧ ¬n.Prime)) : properPowerTerm N n = 0 := by
  by_cases hp : n.Prime
  · simp [properPowerTerm, hp]
  · have hpp : ¬ IsPrimePow n := fun hpp => h ⟨hpp, hp⟩
    have hzero := ArithmeticFunction.vonMangoldt_eq_zero_iff.mpr hpp
    simp [properPowerTerm, hp, representationTerm, hzero]

theorem properPowerContribution_eq_restricted (N : ℕ) :
    properPowerContribution N = ∑ n ∈ properPrimePowersBelow N, properPowerTerm N n := by
  unfold properPowerContribution
  symm
  apply sum_subset (filter_subset _ _)
  intro n hn hnot
  have hs : ¬(IsPrimePow n ∧ ¬n.Prime) := by
    intro hs
    exact hnot (mem_filter.mpr ⟨hn, hs⟩)
  exact properPowerTerm_eq_zero_off_support N n hs

theorem vonMangoldt_le_log_N {N n : ℕ} (hN : 1 ≤ N) (hn : n ≤ N) :
    ArithmeticFunction.vonMangoldt n ≤ Real.log (N : ℝ) := by
  by_cases hn0 : n = 0
  · subst n
    simpa using Real.log_nonneg (by exact_mod_cast hN : (1 : ℝ) ≤ (N : ℝ))
  · exact ArithmeticFunction.vonMangoldt_le_log.trans
      (Real.log_le_log (by exact_mod_cast Nat.pos_of_ne_zero hn0) (by exact_mod_cast hn))

theorem properPowerTerm_le_log_square {N n : ℕ} (hN : 1 ≤ N) (hn : n ≤ N) :
    properPowerTerm N n ≤ Real.log (N : ℝ) ^ 2 := by
  have hlog : 0 ≤ Real.log (N : ℝ) := Real.log_nonneg (by exact_mod_cast hN)
  unfold properPowerTerm
  split_ifs with hp
  · positivity
  · unfold representationTerm
    rw [squarefreeMangoldt_eq_prime_log]
    split_ifs with hq
    · have hqlog : 0 ≤ Real.log ((N - n : ℕ) : ℝ) :=
        Real.log_nonneg (by exact_mod_cast hq.one_lt.le)
      have hqlogLe : Real.log ((N - n : ℕ) : ℝ) ≤ Real.log (N : ℝ) :=
        Real.log_le_log (by exact_mod_cast hq.pos) (by exact_mod_cast Nat.sub_le N n)
      have hm := vonMangoldt_le_log_N hN hn
      simpa only [pow_two] using mul_le_mul hm hqlogLe hqlog hlog
    · simp
      positivity

theorem properPowerContribution_le_card_log_square {N : ℕ} (hN : 1 ≤ N) :
    properPowerContribution N ≤
      ((properPrimePowersBelow N).card : ℝ) * Real.log (N : ℝ) ^ 2 := by
  rw [properPowerContribution_eq_restricted]
  calc
    _ ≤ ∑ n ∈ properPrimePowersBelow N, Real.log (N : ℝ) ^ 2 := by
      apply sum_le_sum
      intro n hn
      exact properPowerTerm_le_log_square hN (mem_range.mp (mem_filter.mp hn).1).le
    _ = _ := by simp

theorem properPowerContribution_le_sqrt_log_cube {N : ℕ} (hN : 1 ≤ N) :
    properPowerContribution N ≤ 2 * Real.sqrt (N : ℝ) * Real.log (N : ℝ) ^ 3 := by
  calc
    _ ≤ ((properPrimePowersBelow N).card : ℝ) * Real.log (N : ℝ) ^ 2 :=
      properPowerContribution_le_card_log_square hN
    _ ≤ (2 * Real.sqrt (N : ℝ) * Real.log (N : ℝ)) * Real.log (N : ℝ) ^ 2 :=
      mul_le_mul_of_nonneg_right (properPrimePowersBelow_card_real_le hN) (sq_nonneg _)
    _ = _ := by ring

theorem properPowerContribution_le_requested_budget (N : ℕ) :
    properPowerContribution N ≤ 2 * Real.sqrt (N : ℝ) * (1 + Real.log (N : ℝ)) ^ 3 := by
  by_cases hN : 1 ≤ N
  · have hlog : 0 ≤ Real.log (N : ℝ) := Real.log_nonneg (by exact_mod_cast hN)
    refine (properPowerContribution_le_sqrt_log_cube hN).trans ?_
    apply mul_le_mul_of_nonneg_left ?_ (by positivity)
    nlinarith [sq_nonneg (Real.log (N : ℝ))]
  · have hN0 : N = 0 := by omega
    subst N
    simp [properPowerContribution]

/- The contamination input is now discharged. The transfer identity, lower
   reference margin, and remaining error budgets are still explicit inputs. -/
theorem prime_pair_of_actual_signed_budget_with_power_bound (N alpha Q : ℕ)
    (reference remainder lowerReference remainderBudget signedLoss : ℝ)
    (hidentity : squarefreeRepresentation N =
      reference + actualSignedError N alpha Q + remainder)
    (href : lowerReference ≤ reference)
    (hrem : |remainder| ≤ remainderBudget)
    (hsigned : -signedLoss ≤ actualSignedError N alpha Q)
    (hmargin : 2 * Real.sqrt (N : ℝ) * (1 + Real.log (N : ℝ)) ^ 3 +
      signedLoss + remainderBudget < lowerReference) :
    ∃ p q : ℕ, p.Prime ∧ q.Prime ∧ p + q = N :=
  prime_pair_of_actual_signed_budget N alpha Q reference remainder lowerReference
    remainderBudget signedLoss
    (2 * Real.sqrt (N : ℝ) * (1 + Real.log (N : ℝ)) ^ 3)
    hidentity href hrem hsigned (properPowerContribution_le_requested_budget N) hmargin

#print axioms proper_prime_power_bounds
#print axioms properPrimePowersBelow_subset_image
#print axioms properPrimePowersBelow_card_le
#print axioms nat_sqrt_cast_le_real_sqrt
#print axioms nat_log_two_cast_le
#print axioms properPrimePowersBelow_card_real_le
#print axioms properPowerTerm_eq_zero_off_support
#print axioms properPowerContribution_eq_restricted
#print axioms vonMangoldt_le_log_N
#print axioms properPowerTerm_le_log_square
#print axioms properPowerContribution_le_card_log_square
#print axioms properPowerContribution_le_sqrt_log_cube
#print axioms properPowerContribution_le_requested_budget
#print axioms prime_pair_of_actual_signed_budget_with_power_bound

end
end GoldbachResearch.ProperPowerBudget
