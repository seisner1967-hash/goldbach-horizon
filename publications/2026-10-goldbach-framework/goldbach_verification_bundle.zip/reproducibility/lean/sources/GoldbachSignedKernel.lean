import GoldbachArithmetic

/-!
# Cofactor identities retaining the arithmetic Moebius signs

These exact identities expose the signed shifted-prime cofactor sums. They
do not supply a cancellation estimate or prove Goldbach.
-/

namespace GoldbachResearch.SignedKernel

open scoped BigOperators
open ActualArithmetic

noncomputable def complementSequence (N m : ℕ) : ℝ :=
  ArithmeticFunction.vonMangoldt (N - m) * muReal m

noncomputable def complementRow (N alpha k m : ℕ) : ℝ :=
  if 1 ≤ m ∧ m < N ∧ alpha * k < m then
    ((if k ∣ m then (1 : ℝ) else 0) - 1 / (Nat.totient k : ℝ)) *
      Real.log ((k : ℝ) / (m : ℝ))
  else 0

theorem actualSequence_complement {N m : ℕ} (hm : m ≤ N) :
    actualSequence N (N - m) = complementSequence N m := by
  simp [actualSequence, complementSequence, Nat.sub_sub_self hm]

theorem actualRow_complement (N alpha k n : ℕ) :
    actualRow N alpha k n = complementRow N alpha k (N - n) := by
  have hsupport :
      (1 ≤ n ∧ n < N ∧ n < N - alpha * k) ↔
        (1 ≤ N - n ∧ N - n < N ∧ alpha * k < N - n) := by
    omega
  unfold actualRow complementRow
  simp only [hsupport]

/-- Exact reindexing of the actual arithmetic row, not a proxy assumption.
    The complementary endpoint m=N is present but its row is zero. -/
theorem actualEpsilon_complement (N alpha k : ℕ) :
    actualEpsilon N alpha k =
      ∑ m ∈ Finset.Icc 1 N, complementSequence N m * complementRow N alpha k m := by
  unfold actualEpsilon ArithmeticBridge.rowSum
  refine Finset.sum_bij (fun n _ => N - n) ?_ ?_ ?_ ?_
  · intro n hn
    simp only [Finset.mem_range] at hn
    simp only [Finset.mem_Icc]
    omega
  · intro n hn r hr he
    simp only [Finset.mem_range] at hn hr
    change N - n = N - r at he
    omega
  · intro m hm
    simp only [Finset.mem_Icc] at hm
    refine ⟨N - m, ?_, ?_⟩
    · simp only [Finset.mem_range]
      omega
    · exact Nat.sub_sub_self hm.2
  · intro n hn
    have hnN : n ≤ N := (Finset.mem_range.mp hn).le
    rw [actualRow_complement]
    have hs := actualSequence_complement (Nat.sub_le N n)
    rw [Nat.sub_sub_self hnN] at hs
    rw [hs]

noncomputable def cofactorAmplitude (N alpha k m : ℕ) : ℝ :=
  if 1 ≤ m ∧ m < N ∧ alpha * k < m then
    Real.log ((k : ℝ) / (m : ℝ))
  else 0

theorem complementRow_eq_amplitude (N alpha k m : ℕ) :
    complementRow N alpha k m = cofactorAmplitude N alpha k m *
      ((if k ∣ m then (1 : ℝ) else 0) - 1 / (Nat.totient k : ℝ)) := by
  unfold complementRow cofactorAmplitude
  split_ifs <;> ring

/-- The common-divisor term and both signed centering terms remain visible. -/
theorem complementRow_product (N alpha k m r : ℕ) :
    complementRow N alpha k m * complementRow N alpha k r =
      cofactorAmplitude N alpha k m * cofactorAmplitude N alpha k r *
        ((if k ∣ Nat.gcd m r then (1 : ℝ) else 0) -
          ((if k ∣ m then (1 : ℝ) else 0) + (if k ∣ r then (1 : ℝ) else 0)) /
            (Nat.totient k : ℝ) + 1 / (Nat.totient k : ℝ) ^ 2) := by
  rw [complementRow_eq_amplitude, complementRow_eq_amplitude]
  by_cases hm : k ∣ m <;> by_cases hr : k ∣ r
  all_goals simp only [Nat.dvd_gcd_iff, hm, hr, and_self, and_false, false_and,
    if_true, if_false]
  all_goals ring

theorem actualKernel_complement_gcd {N alpha Q m r : ℕ}
    (hm : m ≤ N) (hr : r ≤ N) :
    actualKernel N alpha Q (N - m) (N - r) =
      ∑ k ∈ actualModuli N Q,
        (k : ℝ) * cofactorAmplitude N alpha k m * cofactorAmplitude N alpha k r *
          ((if k ∣ Nat.gcd m r then (1 : ℝ) else 0) -
            ((if k ∣ m then (1 : ℝ) else 0) + (if k ∣ r then (1 : ℝ) else 0)) /
              (Nat.totient k : ℝ) + 1 / (Nat.totient k : ℝ) ^ 2) := by
  unfold actualKernel ArithmeticBridge.gramKernel
  apply Finset.sum_congr rfl
  intro k hk
  rw [actual_modulus_mu_sq_eq_one hk, mul_one, actualRow_complement,
    actualRow_complement, Nat.sub_sub_self hm, Nat.sub_sub_self hr,
    complementRow_product]
  ring

/-- Shared factors force the Moebius coefficient to vanish, rather than giving
    a freely chosen sign. This identity is valid even without squarefreeness. -/
theorem muReal_mul_exact (k l : ℕ) :
    muReal (k * l) = if k.Coprime l then muReal k * muReal l else 0 := by
  by_cases hcop : k.Coprime l
  · rw [if_pos hcop]
    unfold muReal
    exact_mod_cast ArithmeticFunction.isMultiplicative_moebius.map_mul_of_coprime hcop
  · rw [if_neg hcop]
    have hsq : ¬Squarefree (k * l) :=
      fun h => hcop (Nat.coprime_of_squarefree_mul h)
    simp [muReal, ArithmeticFunction.moebius_eq_zero_of_not_squarefree hsq]

/-- The outer modulus sign cancels exactly on the divisibility branch. The
    remaining sign is that of the cofactor, whose shifted-prime average is open. -/
theorem signed_moebius_cofactor {k : ℕ} (hs : Squarefree k) (l : ℕ) :
    muReal k * muReal (k * l) = if k.Coprime l then muReal l else 0 := by
  rw [muReal_mul_exact]
  by_cases hc : k.Coprime l
  · simp only [if_pos hc]
    have hm : muReal k ^ 2 = 1 := by
      unfold muReal
      exact_mod_cast ArithmeticFunction.moebius_sq_eq_one_of_squarefree hs
    calc
      _ = muReal k ^ 2 * muReal l := by ring
      _ = muReal l := by rw [hm, one_mul]
  · simp [hc]

theorem cofactor_log {k l : ℕ} (hk : 0 < k) (hl : 0 < l) :
    Real.log ((k : ℝ) / ((k * l : ℕ) : ℝ)) = -Real.log (l : ℝ) := by
  have hkR : (k : ℝ) ≠ 0 := by exact_mod_cast hk.ne'
  have hlR : (l : ℝ) ≠ 0 := by exact_mod_cast hl.ne'
  have hdiv : (k : ℝ) / ((k * l : ℕ) : ℝ) = 1 / (l : ℝ) := by
    rw [Nat.cast_mul]
    field_simp
  rw [hdiv, one_div, Real.log_inv]

noncomputable def signedDivisorTerm (N k l : ℕ) : ℝ :=
  muReal k * complementSequence N (k * l) *
    Real.log ((k : ℝ) / ((k * l : ℕ) : ℝ))

theorem signedDivisorTerm_eq_shifted_cofactor {N k l : ℕ}
    (hs : Squarefree k) (hk : 0 < k) (hl : 0 < l) :
    signedDivisorTerm N k l =
      if k.Coprime l then
        -ArithmeticFunction.vonMangoldt (N - k * l) * muReal l * Real.log (l : ℝ)
      else 0 := by
  unfold signedDivisorTerm complementSequence
  rw [cofactor_log hk hl]
  have hm := signed_moebius_cofactor hs l
  by_cases hc : k.Coprime l
  · rw [if_pos hc] at hm ⊢
    calc
      _ = -ArithmeticFunction.vonMangoldt (N - k * l) *
          (muReal k * muReal (k * l)) * Real.log (l : ℝ) := by ring
      _ = _ := by rw [hm]
  · rw [if_neg hc] at hm ⊢
    calc
      _ = -ArithmeticFunction.vonMangoldt (N - k * l) *
          (muReal k * muReal (k * l)) * Real.log (l : ℝ) := by ring
      _ = 0 := by rw [hm]; ring

theorem signed_divisor_component {N k m : ℕ} (hs : Squarefree k)
    (hk : 0 < k) (hm : 0 < m) :
    muReal k * complementSequence N m * (if k ∣ m then (1 : ℝ) else 0) *
        Real.log ((k : ℝ) / (m : ℝ)) =
      if k ∣ m ∧ k.Coprime (m / k) then
        -ArithmeticFunction.vonMangoldt (N - m) * muReal (m / k) *
          Real.log (m / k : ℕ)
      else 0 := by
  by_cases hd : k ∣ m
  · have he : k * (m / k) = m := Nat.mul_div_cancel' hd
    have hl : (0 : ℕ) < m / k := by
      by_contra h
      have hz : m / k = 0 := Nat.eq_zero_of_not_pos h
      rw [hz, mul_zero] at he
      omega
    have hterm := signedDivisorTerm_eq_shifted_cofactor (N := N) hs hk hl
    simpa [signedDivisorTerm, complementSequence, he, hd] using hterm
  · simp [hd]

/-- Exact centered row after cancellation of the outer modulus sign. The
    centering component still retains both independent Moebius factors. -/
theorem actual_signed_row_cofactor {N alpha Q k : ℕ}
    (hk : k ∈ actualModuli N Q) :
    muReal k * actualEpsilon N alpha k =
      ∑ m ∈ Finset.Icc 1 N,
        if m < N ∧ alpha * k < m then
          (if k ∣ m ∧ k.Coprime (m / k) then
            -ArithmeticFunction.vonMangoldt (N - m) * muReal (m / k) *
              Real.log (m / k : ℕ)
          else 0) - muReal k * complementSequence N m *
            Real.log ((k : ℝ) / (m : ℝ)) / (Nat.totient k : ℝ)
        else 0 := by
  rw [actualEpsilon_complement, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro m hm
  have hm1 : 1 ≤ m := (Finset.mem_Icc.mp hm).1
  have hk0 : 0 < k := by
    have hh := (actualModuli_membership.mp hk).2.1
    omega
  have hks := (actualModuli_membership.mp hk).2.2.2
  by_cases hcut : m < N ∧ alpha * k < m
  · have hrow : 1 ≤ m ∧ m < N ∧ alpha * k < m := ⟨hm1, hcut⟩
    rw [complementRow, if_pos hrow, if_pos hcut]
    have hdiv := signed_divisor_component (N := N) hks hk0 (by omega : 0 < m)
    calc
      _ = muReal k * complementSequence N m * (if k ∣ m then (1 : ℝ) else 0) *
            Real.log ((k : ℝ) / (m : ℝ)) -
          muReal k * complementSequence N m *
            Real.log ((k : ℝ) / (m : ℝ)) / (Nat.totient k : ℝ) := by ring
      _ = _ := by rw [hdiv]
  · have hrow : ¬(1 ≤ m ∧ m < N ∧ alpha * k < m) := by
      intro h
      exact hcut h.2
    simp [complementRow, hrow, hcut]

theorem actualSignedError_cofactor_decomposition (N alpha Q : ℕ) :
    actualSignedError N alpha Q =
      ∑ k ∈ actualModuli N Q, ∑ m ∈ Finset.Icc 1 N,
        if m < N ∧ alpha * k < m then
          (if k ∣ m ∧ k.Coprime (m / k) then
            -ArithmeticFunction.vonMangoldt (N - m) * muReal (m / k) *
              Real.log (m / k : ℕ)
          else 0) - muReal k * complementSequence N m *
            Real.log ((k : ℝ) / (m : ℝ)) / (Nat.totient k : ℝ)
        else 0 := by
  unfold actualSignedError
  apply Finset.sum_congr rfl
  intro k hk
  exact actual_signed_row_cofactor hk

/-- Coprimality of the modulus with N already enforces coprimality with the
    shifted prime argument; it does not enforce a sign for its cofactor. -/
theorem modulus_coprime_shifted {N k l : ℕ} (hc : k.Coprime N)
    (hkl : k * l ≤ N) : k.Coprime (N - k * l) := by
  have he : N - k * l + k * l = N := Nat.sub_add_cancel hkl
  apply (Nat.coprime_add_mul_left_right k (N - k * l) l).mp
  rw [he]
  exact hc

end GoldbachResearch.SignedKernel

#print axioms GoldbachResearch.SignedKernel.actualSequence_complement
#print axioms GoldbachResearch.SignedKernel.actualRow_complement
#print axioms GoldbachResearch.SignedKernel.actualEpsilon_complement
#print axioms GoldbachResearch.SignedKernel.complementRow_eq_amplitude
#print axioms GoldbachResearch.SignedKernel.complementRow_product
#print axioms GoldbachResearch.SignedKernel.actualKernel_complement_gcd
#print axioms GoldbachResearch.SignedKernel.muReal_mul_exact
#print axioms GoldbachResearch.SignedKernel.signed_moebius_cofactor
#print axioms GoldbachResearch.SignedKernel.cofactor_log
#print axioms GoldbachResearch.SignedKernel.signedDivisorTerm_eq_shifted_cofactor
#print axioms GoldbachResearch.SignedKernel.signed_divisor_component
#print axioms GoldbachResearch.SignedKernel.actual_signed_row_cofactor
#print axioms GoldbachResearch.SignedKernel.actualSignedError_cofactor_decomposition
#print axioms GoldbachResearch.SignedKernel.modulus_coprime_shifted
