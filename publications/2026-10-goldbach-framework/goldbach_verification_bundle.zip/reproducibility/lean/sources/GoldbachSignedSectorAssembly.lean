import Mathlib.Tactic

/-!
Finite signed assembly for an internal partition. The entire main model
is removed exactly once. No complementary signs are dropped. Analytic
budgets and a positive terminal reserve are explicit hypotheses, not axioms.
-/

namespace GoldbachResearch.SignedSectorAssembly

open scoped BigOperators

noncomputable section

variable {Row Cell : Type*} [Fintype Row] [Fintype Cell] [DecidableEq Cell]

def fullCoefficient (t : Row → Cell → ℝ) (i : Row) : ℝ := ∑ j, t i j

def partCoefficient (t : Row → Cell → ℝ) (g : Finset Cell) (i : Row) : ℝ :=
  ∑ j ∈ g, t i j

def contraction (w k h : Row → ℝ) : ℝ := ∑ i, w i * h i * k i

def discrepancy (w c m h : Row → ℝ) : ℝ := ∑ i, w i * h i * (c i - m i)

theorem partition_coefficient (t : Row → Cell → ℝ) (g : Finset Cell) (i : Row) :
    fullCoefficient t i = partCoefficient t g i +
      partCoefficient t (Finset.univ \ g) i := by
  classical
  unfold fullCoefficient partCoefficient
  exact (Finset.sum_add_sum_compl g (t i)).symm

theorem remove_global_model_once (t : Row → Cell → ℝ) (g : Finset Cell)
    (w c m : Row → ℝ) :
    discrepancy w c m (fullCoefficient t) =
      contraction w c (partCoefficient t g) +
      contraction w c (partCoefficient t (Finset.univ \ g)) -
      contraction w m (fullCoefficient t) := by
  classical
  unfold discrepancy contraction
  rw [← Finset.sum_add_distrib, ← Finset.sum_sub_distrib]
  apply Finset.sum_congr rfl
  intro i hi
  rw [partition_coefficient t g i]
  ring

theorem remainder_distance_bound (t : Row → Cell → ℝ) (g : Finset Cell)
    (w c m : Row → ℝ) (goodBudget meanBudget : ℝ)
    (hg : |contraction w c (partCoefficient t g)| ≤ goodBudget)
    (hm : |contraction w m (fullCoefficient t)| ≤ meanBudget) :
    |discrepancy w c m (fullCoefficient t) -
      contraction w c (partCoefficient t (Finset.univ \ g))| ≤
      goodBudget + meanBudget := by
  rw [remove_global_model_once t g w c m]
  have hid : contraction w c (partCoefficient t g) +
      contraction w c (partCoefficient t (Finset.univ \ g)) -
      contraction w m (fullCoefficient t) -
      contraction w c (partCoefficient t (Finset.univ \ g)) =
      contraction w c (partCoefficient t g) -
      contraction w m (fullCoefficient t) := by ring
  rw [hid]
  exact (abs_sub _ _).trans (add_le_add hg hm)

theorem signed_one_sided_transfer (S E error uncovered reserve : ℝ)
    (hidentity : S = -E + error + uncovered)
    (htarget : E - uncovered ≤ reserve - |error|) :
    -reserve ≤ S := by
  have he : -|error| ≤ error := neg_abs_le error
  rw [hidentity]
  linarith

theorem positive_margin_requires_reserved_gap
    (primeMass reference S loss reserve margin : ℝ)
    (hidentity : primeMass = reference + S - loss)
    (hs : -reserve ≤ S)
    (hloss : loss + reserve + margin ≤ reference)
    (hmargin : 0 < margin) :
    margin ≤ primeMass ∧ 0 < primeMass := by
  rw [hidentity]
  constructor <;> linarith

theorem one_sided_budget_alone_has_zero_mass_witness (reference : ℝ) :
    ∃ S reserve : ℝ, -reserve ≤ S ∧ reference + S = 0 := by
  exact ⟨-reference, reference, le_refl _, by ring⟩

#print axioms partition_coefficient
#print axioms remove_global_model_once
#print axioms remainder_distance_bound
#print axioms signed_one_sided_transfer
#print axioms positive_margin_requires_reserved_gap
#print axioms one_sided_budget_alone_has_zero_mass_witness

end
end GoldbachResearch.SignedSectorAssembly
