"""Copy only selected read-only evidence; never compile, download, or create a ZIP."""
from pathlib import Path
import argparse,json,hashlib,re,collections,datetime
O=Path(__file__).resolve().parent;FINAL=O.parent
H=lambda b:hashlib.sha256(b).hexdigest()
ap=argparse.ArgumentParser();ap.add_argument('--materialize',action='store_true');args=ap.parse_args()
J=json.loads((O/'lean_inventory.json').read_text(encoding='utf-8'))
DEST=FINAL/'reproducibility'/'lean'
payload={};origins=collections.defaultdict(list)
def add(source,target,expected=None):
 p=Path(source);b=p.read_bytes()
 if expected:assert H(b)==expected,(str(p),expected,H(b))
 if target in payload:assert payload[target]==b,target
 payload[target]=b;origins[target].append({'path':str(p),'sha256':H(b)})
for s in J['canonical_sprint_modules']:add(s['path'],'sources/'+s['module']+'.lean',s['sha256'])
assert len([p for p in payload if p.startswith('sources/')])==71
for sc in J['compile_scripts']:
 add(sc['path'],'original_compile_scripts/'+sc['sha256'][:16]+'_'+Path(sc['path']).name,sc['sha256'])
receipt_paths=set();log_paths=set()
for s in J['canonical_sprint_modules']:
 for e in s['verified_compile_records']:
  if e['receipt'] not in receipt_paths:
   receipt_paths.add(e['receipt']);add(e['receipt'],'receipts/'+e['receipt_sha256'][:16]+'_'+Path(e['receipt']).name,e['receipt_sha256'])
  if e['log'] not in log_paths:
   log_paths.add(e['log']);add(e['log'],'axiom_logs/'+e['log_sha256'][:16]+'_'+Path(e['log']).name,e['log_sha256'])
 if s['sibling_axiom_log']:
  e=s['sibling_axiom_log']
  if e['path'] not in log_paths:
   log_paths.add(e['path']);add(e['path'],'axiom_logs/'+e['sha256'][:16]+'_'+Path(e['path']).name,e['sha256'])
for n in ['lean_inventory_module_table.tsv','lean_inventory_full_statement_appendix.txt','lean_inventory_sprint21_appendix.txt','lean_inventory_receipt.json']:
 add(O/n,'inventory/'+n)
# Manifests may record the original compiler exit and source binding even
# when a compact record parser did not recover an independent replay node.
R=Path(J['roots'][0])
for sprint in ['sprint3','sprint4','sprint5','sprint6','sprint8','sprint9']:
 for basename in ['manifest.json','verification.json','bundle_receipt.json']:
  p=R/sprint/basename
  if p.exists():add(p,'checkpoint_metadata/'+sprint+'_'+basename)
for p in [Path(J['dependency_pin_provenance']['path']),Path(J['roots'][1])/'lean-toolchain']:
 add(p,'toolchain/'+p.name)
add(Path(__file__),'gather_lean_reproducibility.py')
add(O/'portable_replay.py','portable_replay.py')
module_imports={s['module']:sorted({n for line in s['imports'] for n in line.split() if not n.startswith('Mathlib')}) for s in J['canonical_sprint_modules']}
assert all(n in module_imports for ns in module_imports.values() for n in ns)
seen=set();active=set();order=[]
def visit(n):
 if n in seen:return
 assert n not in active,'Local import cycle: '+n
 active.add(n)
 for dep in module_imports[n]:visit(dep)
 active.remove(n);seen.add(n);order.append(n)
for n in sorted(module_imports):visit(n)
guide='''READ-ONLY LEAN SOURCE AND CERTIFICATE REPRODUCTION FOLDER

This folder contains 71 canonical source files, original retained compile
scripts, successful source-bound receipts/axiom logs and older checkpoint
metadata. It contains no copied olean, dependency cache, PDF or ZIP. The
manifest hashes every payload and binds it to its original read-only path.
Imported local modules form a closed graph; compile_order.json records a
topological order. Dependencies and proof names are not counted again.

TRUST AND SCOPE
Use Lean 4.15.0, commit 11651562caae and Mathlib revision
9837ca9d65d9de6fad1ef4381750ca688774e608. Required cached library roots are
aesop, batteries, importGraph, LeanSearchClient, mathlib, plausible,
proofwidgets and Qq (in that order for portable_replay.py).
The copied lake-manifest.json records pins. An existing .olean is not a
fresh source replay. The current inventory verified prior evidence and
performed no new compilation. The latest 19 finite conclusions are separate
from 658 accumulated explicitly axiom-audited statements; lexical declaration
counts, private helpers, repeated imports and old copies are not new results.

PORTABLE REPLAY (not executed during preparation of this folder)
Run python portable_replay.py --help to inspect its arguments. Supply an
absolute --lean-exe, exactly eight --dependency-lib-dir arguments in the
order above, and a NEW absolute --build-dir. --check-only (also the default)
checks paths, source hashes and the closed topological plan without calling
any process or creating the build directory. Actual compilation requires the
separate explicit --execute option. Dependencies must already be available;
the script neither downloads nor installs them. Library revision identity
must be verified on the replay host; a directory existing is not such a check.
It records compiler argv arrays, version, exit codes, source/log/olean hashes
and printed axiom footprints in FRESH_REPLAY_RECEIPT.json in the new directory.
The included five wrappers/probes are not counted as new theorem declarations.
Their inclusion in this replay plan is not a claim that this new plan ran.

MANUAL FRESH REPLAY PROCEDURE
1. Resolve the pinned Lean executable and the eight matching dependency
   library directories on the replay host. Check actual versions/revisions.
2. Choose a NEW absolute build directory that does not contain an old
   project olean. Copy all sources/*.lean into that directory without edits.
3. Set LEAN_PATH to that new directory followed by only the eight pinned
   dependency library roots; standard Lean system libraries are implicit.
4. In compile_order.json order, invoke the pinned compiler with arguments
   ["-o", "<new>/<Module>.olean", "<new>/<Module>.lean"]. Capture stdout and
   stderr to a per-module fresh log and require compiler exit 0.
5. Parse #print axioms outputs against the retained expected statements;
   permit only propext, Classical.choice and Quot.sound. Hash copied source, log
   and olean. Some source/helper declarations are not individually printed.
   Use inventory headers and old receipts to distinguish that scope.

ORIGINAL SCRIPTS
Original scripts retain exact bytes and often authoring-host absolute
paths or PSScriptRoot-relative source layouts. They are templates/evidence,
not automatically portable commands from this flattened evidence folder.
Use the original source layout or resolve equivalent pinned paths before
invocation. Recent supported examples use -BuildDirectory <newAbsolute>.
No original script is executed, silently modified or wrapped by this
gatherer. No network/update/install command is needed for this inventory.

LIMITATIONS
This artifact does not prove a classical analytic input in Lean, a covered
bridge, an effective global signed deficit, a sufficient prime-pair margin
or Goldbach. Historical Horizon predicates and files with gaps/custom
axioms/native certificates are excluded from these 71 canonical sources.
The complete machine registry remains in review/lean_inventory.json; its
absolute origin paths document provenance rather than a portable URL.
'''
payload['README_REPRODUCTION.txt']=guide.encode('utf-8')
expected_audits=[{'name':d['name'],'statement_sha256':d['statement_sha256'],'module':s['module']}
 for s in J['canonical_sprint_modules'] for d in s['explicitly_audited_theorem_declarations']]
payload['compile_order.json']=(json.dumps({'module_order':order,'local_imports':module_imports,'dependency_pin':J['mathlib_revision'],'expected_audited_statements':expected_audits,'performed':False},indent=2)+'\n').encode()
manifest={'scope':'Read-only source/evidence collection; no build or archive created','generated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'canonical_sources':71,'latest_new_audited_conclusions':19,'accumulated_explicit_audited_statements':658,'files':[{'path':p,'bytes':len(b),'sha256':H(b),'origins':origins.get(p,[])} for p,b in sorted(payload.items())]}
mb=(json.dumps(manifest,indent=2)+'\n').encode()
if args.materialize:
 for rel,b in payload.items():
  p=DEST/rel;p.parent.mkdir(parents=True,exist_ok=True)
  if p.exists():assert p.read_bytes()==b,'Refuse to replace changed file: '+str(p)
  else:
   with p.open('xb') as f:f.write(b)
 p=DEST/'MANIFEST_REPRODUCTION.json'
 if p.exists():raise FileExistsError('Manifest already exists; refuse overwrite '+str(p))
 with p.open('xb') as f:f.write(mb)
 for rel,b in payload.items():assert (DEST/rel).read_bytes()==b
else:(O/'lean_reproducibility_preflight.json').write_bytes(mb)
print(json.dumps({'status':'MATERIALIZED_PASS' if args.materialize else 'PREFLIGHT_PASS','destination':str(DEST),'payload_files':len(payload),'canonical_sources':71,'receipt_objects':len(receipt_paths),'axiom_logs':len(log_paths),'original_scripts':len(J['compile_scripts']),'payload_bytes':sum(map(len,payload.values())),'new_compilation':False,'ZIP_created':False,'frozen_writes':False},indent=2))
