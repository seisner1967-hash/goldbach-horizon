"""Exact integer/rational checks, supplementary to the written proofs."""
from fractions import Fraction as Q
from pathlib import Path
from math import gcd,lcm
import json
count=0
for H in range(1,41):
    for L in range(1,51):
        r=H%L
        for s in range(L):
            direct=sum(Q(H-abs(n-s),H) for n in range(s-H+1,s+H) if n%L==0)
            delta=(Q(max(r-s,0)+max(r+s-L,0))-Q(r*r,L))/H
            assert direct==Q(H,L)+delta,(H,L,s,direct,delta)
            assert abs(delta)<=Q(L,4*H),(H,L,s,delta)
            if r==0:assert delta==0
            count+=1
primes=[n for n in range(2,201) if all(n%d for d in range(2,int(n**.5)+1))]
pairs=[(p,98-p) for p in primes if p<=49 and 98-p in primes]
removed={q for p,q in pairs}
remaining=set(primes)-removed
assert not any(98-p in remaining for p in remaining)
def defect(H,L,s):
    r=H%L
    return (Q(max(r-s%L,0)+max(r+s%L-L,0))-Q(r*r,L))/H
cov_count=0
for H in range(1,13):
    for L in range(1,17):
        for M in range(1,17):
            P=lcm(L,M)
            cov=sum(defect(H,L,s)*defect(H,M,s) for s in range(P))/P
            g=gcd(L,M);d=min(H%g,g-H%g)
            exact=(Q(g*(2*d**3+d),3)-d**4)/(L*M*H*H)
            assert cov==exact,(H,L,M,cov,exact)
            cov_count+=1
result={'fejer_cases':count,'fejer_covariance_cases':cov_count,'fejer_identity':'all exact Fraction checks passed','hole_target':98,'prime_pairs':pairs,'removed':sorted(removed),'remaining_primes_to_200':len(remaining)}
out=Path(__file__).resolve().parents[1]/'data'/'exact_checks.json'
out.write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
