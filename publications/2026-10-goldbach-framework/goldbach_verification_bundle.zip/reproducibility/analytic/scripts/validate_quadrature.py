from pathlib import Path
import json,math
def integral(n,tol=1e-7):
    def f(t): return 1/(math.log(t)*math.log(n-t))
    def rec(a,b,fa,fb,fc,S,eps,depth):
        c=(a+b)/2;d=(a+c)/2;e=(c+b)/2;fd=f(d);fe=f(e)
        left=(c-a)*(fa+4*fd+fc)/6;right=(b-c)*(fc+4*fe+fb)/6
        if depth==0 or abs(left+right-S)<15*eps:return left+right+(left+right-S)/15
        return rec(a,c,fa,fc,fd,left,eps/2,depth-1)+rec(c,b,fc,fb,fe,right,eps/2,depth-1)
    a=2;b=n/2;c=(a+b)/2;fa=f(a);fb=f(b);fc=f(c)
    return 2*rec(a,b,fa,fb,fc,(b-a)*(fa+4*fc+fb)/6,tol/2,40)
def trapezoid(n):
    return math.fsum(1/(math.log(k)*math.log(n-k)) for k in range(2,n-1))-1/(math.log(2)*math.log(n-2))
rows=[]
for n in [120000,240000,480000,1000000,2000000]:
    J=integral(n);T=trapezoid(n);bd=1/(8*math.log(2)**2*math.log(n-2))
    assert -1e-6<=T-J<=bd
    rows.append({'n':n,'adaptive_simpson':J,'unit_trapezoid':T,'difference':T-J,'proved_upper_bound':bd})
factor=math.prod((p-1)/(p-2) for p in [3,5,7,11,13,17])
result={'checks':rows,'max_factor_even_to_2million':factor,'uniform_baseline_quad_error_bound':0.6601618158468696*factor/(8*math.log(2)**2*math.log(119998)),
        'note':'Simpson values are floating numerical checks, while trapezoid error inequality is proved in the article.'}
(Path(__file__).resolve().parents[1]/'data'/'quadrature_checks.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
