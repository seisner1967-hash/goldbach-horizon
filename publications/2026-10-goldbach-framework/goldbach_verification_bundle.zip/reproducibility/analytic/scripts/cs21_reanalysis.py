"""Independent CS21 reimplementation; no training on test windows.
Uses only Python/NumPy. Ordered convolution verified against direct counts.
"""
from pathlib import Path
import csv, json, math, time
import numpy as np

OUT = Path(__file__).resolve().parents[1] / 'data'
OUT.mkdir(parents=True, exist_ok=True)
MAXN = 2_000_000
C2 = 0.6601618158468696
def sieve(n):
    a = np.ones(n+1, dtype=bool); a[:2] = False
    for p in range(2, math.isqrt(n)+1):
        if a[p]: a[p*p::p] = False
    return a
prime = sieve(MAXN)
p_all = np.flatnonzero(prime)
length = 1 << (2*MAXN).bit_length()
f = np.fft.rfft(prime.astype(float), n=length)
conv_float = np.fft.irfft(f*f, n=length)[:MAXN+1]
round_err = float(np.max(np.abs(conv_float - np.rint(conv_float))))
ordered = np.rint(conv_float).astype(np.int64)
even_all = np.arange(4, MAXN+1, 2)
unordered = (ordered[even_all] + prime[even_all//2])//2
factor = np.ones(MAXN+1)
for p in p_all[1:]:
    factor[p::p] *= (p-1)/(p-2)
# Unit-mesh trapezoidal approximation to the classical logarithmic integral.
smooth = np.zeros(MAXN+1)
smooth[2:] = 1/np.log(np.arange(2,MAXN+1))
sf=np.fft.rfft(smooth,n=length)
quad=np.fft.irfft(sf*sf,n=length)[:MAXN+1]
quad[4:] -= smooth[2]*smooth[2:MAXN-1]
def counts(ns):
    return (ordered[ns] + prime[ns//2])//2
checks = [4,6,8,10,100,120000,240000,500000,1000000,2000000]
direct_checks = []
for n in checks:
    p = p_all[p_all <= n//2]
    direct = int(np.count_nonzero(prime[n-p]))
    fft = int(counts(np.array([n]))[0])
    assert direct == fft, (n,direct,fft)
    direct_checks.append({'n':n,'unordered_direct':direct,'ordered_fft':int(ordered[n]),'diagonal':bool(prime[n//2])})
def features(ns, M, weight='sqrt'):
    p = p_all[p_all <= ns[-1]]
    w = 1/np.sqrt(p) if weight=='sqrt' else 1/p
    theta = (p % M)/M; phi = np.log(p)/np.log(ns[-1])
    modes = [(k,l) for k in range(4) for l in range(6) if (k,l)!=(0,0)]
    X = np.empty((len(ns),len(modes)))
    idx = np.searchsorted(p,ns,side='right')-1
    for j,(k,l) in enumerate(modes):
        X[:,j] = np.cumsum(w*np.cos(2*np.pi*(k*theta+l*phi)))[idx]
    return X,modes
def fit_predict(X,y,split):
    mu = X[:split].mean(axis=0); sd=X[:split].std(axis=0)
    sd[sd<1e-14]=1
    Z=(X-mu)/sd
    ym=y[:split].mean()
    coeff=np.linalg.solve(Z[:split].T@Z[:split]+np.eye(X.shape[1]), Z[:split].T@(y[:split]-ym))
    return ym+Z@coeff,coeff
def metrics(y,pred,split):
    yt=y[split:]; pt=pred[split:]
    corr=float(np.corrcoef(yt,pt)[0,1])
    return {'rho_train':float(np.corrcoef(y[:split],pred[:split])[0,1]), 'rho_test':corr,
            'rho_test_squared':corr*corr, 'r2_test':float(1-np.sum((yt-pt)**2)/np.sum((yt-yt.mean())**2)),
            'rmse_test':float(np.sqrt(np.mean((yt-pt)**2))), 'mean_error_test':float(np.mean(pt-yt))}
rows=[]
for lo,hi in [(120000,240000),(240002,480000),(500000,1000000),(1000002,2000000)]:
    ns=np.arange(lo,hi+1,2); G=counts(ns).astype(float)
    split=len(ns)//2
    for M,weight in [(997,'sqrt'),(999,'sqrt'),(995,'sqrt'),(997,'reciprocal')]:
        X,modes=features(ns,M,weight)
        for base_name,base in [('CS21',2*C2*ns/np.log(ns)**2*factor[ns]), ('corrected',C2*ns/np.log(ns)**2*factor[ns]),('classical_integral_quadrature',C2*factor[ns]*quad[ns])]:
            y=G-base
            for model,mask in [('all23',np.ones(len(modes),bool)),('log_only5',np.array([k==0 for k,l in modes])),('mod_only18',np.array([k!=0 for k,l in modes]))]:
                if (M,weight)!=(997,'sqrt') and model!='all23':continue
                pred,co=fit_predict(X[:,mask],y,split)
                row={'lo':lo,'hi':hi,'M':M,'weight':weight,'baseline':base_name,'model':model,**metrics(y,pred,split)}
                rows.append(row)
    # Predictor-free approximation metrics in the entire window.
    for name,base in [('CS21',2*C2*ns/np.log(ns)**2*factor[ns]),('corrected',C2*ns/np.log(ns)**2*factor[ns]),('classical_integral_quadrature',C2*factor[ns]*quad[ns])]:
        rows.append({'lo':lo,'hi':hi,'M':0,'weight':'none','baseline':name,'model':'baseline_only',
                     'rho_train':None,'rho_test':float(np.corrcoef(G,base)[0,1]),'rho_test_squared':None,
                     'r2_test':float(1-np.sum((G-base)**2)/np.sum((G-G.mean())**2)),
                     'rmse_test':float(np.sqrt(np.mean((G-base)**2))), 'mean_error_test':float(np.mean(base-G))})
with (OUT/'cs21_reanalysis.csv').open('w',newline='',encoding='utf-8') as fp:
    writer=csv.DictWriter(fp,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
summary={'maxn':MAXN,'fft_max_rounding_error':round_err,'direct_checks':direct_checks,
         'numpy_version':np.__version__,'counting':'unordered including diagonal','train_fraction':0.5,
         'ridge_lambda':1.0,'note':'Independent reimplementation, original companion script not available; R2 is 1-SSE/SST.'}
(OUT/'cs21_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
print('Reference window, M=997, square-root weights:')
for row in rows:
    if row['lo']==120000 and row['M'] in [0,997] and row['weight']!='reciprocal':print(json.dumps(row))
