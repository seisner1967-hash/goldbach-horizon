Selected analytic provenance, not a complete historical archive.
The final manuscript governs the claimed profiles and onsets.
Older notes and the French first-phase source are historical context.
The adaptive 10^24 onset supersedes looser earlier universal assemblies.
Guard scripts verify arithmetic comparisons, not zero-free regions or sieve density.
Scripts retain original paths/output behavior; inspect before running them and use a new directory.
No retained test report is represented as a current execution.
Third-party primary articles are supplied by bibliography links, not redistributed.
