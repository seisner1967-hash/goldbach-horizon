"""Exact rational guards for the written actual-weight transport.

No sampling of an asymptotic input and no AP theorem is asserted.
"""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json
from math import factorial

ROOT = Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    moment_note = ROOT / 'Actual_Weight_Second_Moment_And_AP_Transport.txt'
    supplied = ROOT / 'inputs/Goldbach_Rmain_Vaughan_Checks_2026-10-01.json'
    replay = ROOT / 'root_user_Rmain_replay.json'
    user_report = json.loads(supplied.read_text(encoding='utf-8-sig'))
    replay_report = json.loads(replay.read_text(encoding='utf-8-sig'))
    guards = {
        'exp1_gt_2_from_first_three_Taylor_terms': sum(F(1, factorial(k)) for k in range(3)) > 2,
        'exp1_lt_3_from_eight_term_Taylor_and_geometric_tail': sum(F(1, factorial(k)) for k in range(8)) + F(9, 8 * factorial(8)) < 3,
        'e4_coefficient': 3 * 3**4 == 243,
        'unweighted_coefficient': 22**3 == 10648,
        'discrepancy_coefficient': 4 * 243 == 972,
        'extra_squared_mass_at_u256': F(10648 * 257**2, 2**160) < 1,
        'squared_mass_ratio_decreases_past_u256': F(2, 257) - F(5, 8) < 0,
        'correction_at_u512': F(6 * 513**5, 2**320) < F(1, 10**40),
        'correction_ratio_decreases_past_u512': F(5, 513) - F(5, 8) < 0,
        'independent_user_replay_matches_parsed_report': user_report == replay_report,
        'user_checker_binds_exact_source': user_report['checker_sha256'] == sha(ROOT / 'inputs/Goldbach_Rmain_Vaughan_Checks_2026-10-01.py'),
    }
    # The e<3 proof is analytic: k! >= 2^(k-1) for k>=2,
    # with strict inequality at k>=3, so sum_{k>=2}1/k! < 1.
    # Its finite inequality is recorded as supporting arithmetic only.
    guards['factorial_geometric_strict_example'] = factorial(3) > 2**2
    if not all(guards.values()):
        raise AssertionError(guards)
    result = {
        'status': 'PASS',
        'scope': 'Exact rational calibration and parsed-result replay comparison only. The AP input remains unproved; no all-N bound follows from sampling.',
        'guards': guards,
        'source_sha256': sha(Path(__file__)),
        'written_transport_sha256': sha(moment_note),
        'supplied_Rmain_report_sha256': sha(supplied),
        'actual_root_Rmain_replay_sha256': sha(replay),
        'user_replay_counts': {key: replay_report[key] for key in ['convolution', 'Vaughan']},
    }
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
