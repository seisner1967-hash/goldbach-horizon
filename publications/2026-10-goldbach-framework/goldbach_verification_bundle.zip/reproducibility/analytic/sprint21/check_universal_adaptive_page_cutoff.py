"""Exact evaluations for the adaptive universal exterior budget; D_N stays open."""
from fractions import Fraction as F
from pathlib import Path
from math import factorial
import json,hashlib
u=10**24;lo=54;hi=56;E=100000
e_upper=sum((F(1,factorial(j)) for j in range(9)),F(0))+F(10,9*factorial(9))
e_7_3_lower=sum((F(7,3)**j/factorial(j) for j in range(13)),F(0))
gap=F(224,10**12*lo**3)+F(28,120*lo**8)+F(28,10**12*lo**4)
retained=F(hi,u**3)+F(648*hi*(1+hi)*(1+8*hi),u**2)+F(486*hi*(1+hi)*(1+8*hi),u**6)
bad=F(486*125,lo**6)
grand=F(54*hi**2*25,10**12)
small=F(2187*hi**8,10000*u)
EJ_other=F(14411*hi,u**3)
exterior=F(8,10**6)+F(2,10**12)
net=F(2541,524288)-exterior
margin=net-F(1,256)
guards={
 'exp_upper_11_over4':e_upper<F(11,4),
 'log10_lower_9_over4':F(11,4)**9<10**4,
 'log10_upper_7_over3':e_7_3_lower>10,
 'sqrt_u0_exact':(10**12)**2==u,
 'u0_below_2pow80':u<2**80,
 'E_lower':F(10**12,hi**4)>E,
 'ordinary_zero_gap':gap<1,
 'nonselected_Page_gap':10**12*lo**3>320,
 'selected_Page_local_gap':F(100,4)>4,
 'mask_delta_condition':10**12*lo**3>2,
 'inverse_norm_padding':F(6+48+14)+F(7,2)<74,
 'box_width_h':E//240>7,
 'A1_fee':6346-(3*E//40)<-3,
 'A2_fee':6331-(11*E//120)<-3,
 'A3_fee':467-(2*E//15)<-3,
 'A4_fee':326-(E//240)<-3,
 'A5_fee':320-10000<-3 and F(u,8)>10000,
 'E_log_derivative':F(1,2)-F(4,lo)>F(2,5),
 'A1_decreases':79-F(3,40)*F(2,5)*E<0,
 'A2_decreases':78-F(11,120)*F(2,5)*E<0,
 'A3_decreases':5-F(2,15)*F(2,5)*E<0,
 'A4_decreases':4-F(1,240)*F(2,5)*E<0,
 'exp5_above112':F(8,3)**5>112,
 'I_retained_full':retained<F(1,10**12),
 'I_one_Page_line':bad<F(1,400000),
 'I_total':bad+retained<F(3,10**6),
 'I_bad_decreases':F(3,lo*1)-F(6,lo)<0,
 'EJ_grand_main':grand<F(9,2000000),
 'EJ_small_alternative':small<F(1,10**10),
 'EJ_other_owners':EJ_other<F(1,10**12),
 'EJ_grand_total':grand+EJ_other<F(5,10**6),
 'EJ_small_total':small+EJ_other<F(5,10**6),
 'EJ_grand_decreases':F(2,lo)+F(2,lo)-F(1,2)<0,
 'EJ_small_decreases':F(8,lo)-1<0,
 'EZ_positive_bits1':4*10**8*u**6*hi<2**516,
 'EZ_positive_bits2':160*u**3*hi<2**254,
 'EZ_positive_bits3':40*(1+u)**4*u*hi<2**416,
 'EZ_square_root':u>60*(10**11)**2,
 'EZ_linear_exponent':F(u,40)>10**11,
 'EZ_quarter_exponent':F(u,4)>10**11,
 'EZ_each_bound':F(1,2**1000)<F(1,10**13),
 'EZ_total_bound':F(3,10**13)<F(1,10**12),
 'powers_positive_bits':u**3*hi<2**246,
 'powers_negative_exponent':F(u,2)>10**11,
 'onset_above_all_reused_inputs':u>10**16 and u>8*10**10,
 'conditional_margin_positive':margin>F(9,10000),
 'margin_relation_to_old':margin==F(120361327741,128000000000000)-F(8,10**6)+F(1,10**12),
}
assert all(guards.values()),{k:v for k,v in guards.items() if not v}
print(json.dumps({'status':'EXACT_GUARDS_PASS_ANALYSIS_REQUIRES_REVIEW_D_OPEN',
 'guard_count':len(guards),'guards':guards,'u_onset':str(u),
 'I_allowance_normalized':str(F(3,10**6)),
 'EJ_allowance_normalized':str(F(5,10**6)),
 'exterior_allowance_normalized':str(exterior),
 'net_reference_coefficient':str(net),'conditional_D_target_coefficient':'1/256',
 'conditional_margin_coefficient':str(margin),
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'scope':'Rational constants and onset comparisons only. No analytic estimate or D_N bound is proved by this script.'},indent=2))
