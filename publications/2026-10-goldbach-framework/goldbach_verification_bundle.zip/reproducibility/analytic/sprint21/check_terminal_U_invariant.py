"""Exact coefficient ledger comparisons across genuine Vaughan U-cutoffs."""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parent
LIB=ROOT/'agents'/'check_exact_terminal_recombination.py'
EXPECTED='e2ec73840bdbf3eba9e7dc760f5d2616a482a6de256ff5045ce1b3e56e02d6c5'
if hashlib.sha256(LIB.read_bytes()).hexdigest()!=EXPECTED:
    raise AssertionError('Pinned polynomial arithmetic changed')
# Reuse definitions only; do not rerun the already archived full audit.
exec(compile(LIB.read_text(encoding='utf-8').split('profiles=0')[0],str(LIB),'exec'))

profiles=rows=defect_pairs=0
for N in [30,42,76,120]:
    for alpha in [1,3,fourth_ceiling(N)]:
        for Q in sorted({7,(N-1)//alpha}):
            for V in [1,5]:
                outcomes=[]
                Tactual={}
                for n in range(1,N):
                    D,W,J=kernel(N,n,alpha,Q)
                    K=scale(sub(D,W),int(gcd(n,N)==1)*mu(N-n))
                    Tactual=add(Tactual,mul(mangoldt(n) if n>V else {},K))
                for U in [1,2,4,8,16]:
                    small=full={}
                    for n in range(1,N):
                        D,W,J=kernel(N,n,alpha,Q)
                        K=scale(sub(D,W),int(gcd(n,N)==1)*mu(N-n))
                        hn=add(*(scale(beta(n//a,V),mu(a)) for a in divisors(n) if a<=U))
                        fII=add(*(scale(beta(n//a,V),mu(a)) for a in divisors(n) if a>U))
                        small=add(small,mul(hn,K))
                        full=add(full,mul(fII,K))
                        rows+=1
                    assert add(small,full)==Tactual
                    defects=[]
                    for e in [-2,-1,0,1,2]:
                        DN=add(scale(full,-1),constant(e+abs(e)))
                        terminal=sub(DN,small)
                        assert terminal==add(scale(Tactual,-1),constant(e+abs(e)))
                        defects.append((e,terminal))
                    outcomes.append(defects)
                for x in outcomes:
                    for y in outcomes:
                        for e,t in x:
                            for f,s in y:
                                assert sub(t,s)==constant(e+abs(e)-f-abs(f))
                                defect_pairs+=1
                profiles+=1
print(json.dumps({'status':'EXACT_TERMINAL_U_INVARIANT_PASS',
    'profiles':profiles,'actual_coefficient_rows':rows,'paired_signed_error_checks':defect_pairs,
    'scope':'Genuine finite Vaughan coefficients and literal capped D-W kernels. Does not estimate D-I, Tactual or positive covered error.',
    'library_sha256':EXPECTED,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'written_source_sha256':hashlib.sha256((ROOT/'Terminal_Vaughan_U_Invariant_And_Selector_Defect.txt').read_bytes()).hexdigest(),
    'Lean_compilation_is_separate':True,'Goldbach_proof':False},indent=2))
