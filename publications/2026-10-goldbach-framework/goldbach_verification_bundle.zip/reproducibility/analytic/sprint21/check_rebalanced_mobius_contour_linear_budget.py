"""Exact rebalanced-contour guards; primary complex analysis remains written."""
from pathlib import Path
from fractions import Fraction as F
from math import factorial
import hashlib,json
ROOT=Path(__file__).resolve().parent
u=10**16
e_upper=sum((F(1,factorial(k)) for k in range(6)),F(0))+F(7,4320)
guards={
 'u_onset_below_old':u<2**128,
 'u_upper_power2':u<2**54,
 'e_upper_11_over4':e_upper<F(11,4),
 'log10_lower9_over4':F(11,4)**9<10**4,
 'log10_upper37_over16':sum((F(37,16)**k/F(factorial(k)) for k in range(14)),F(0))>10,
 'E_onset_lower':F(10**8,37**2)>73000,
 'ordinary_zero_free_discs':F(224,10**8*36)+F(28,120*36**4)+F(28,10**8*36**2)<1,
 'nonselected_Page_gap':F(160,10**8*36)<1,
 'selected_small_gap':100>4,
 'near_one_mask_guard':F(2,10**8*36)<1,
 'norm_padding':F(6+48+14)+F(7,2)<74,
 'h_onset':F(73000,240)>304,
 'vertical_power_bound':F(3*73000,40)==5475,
 'vertical_onset':F(2**4292,2**5475)<F(1,8),
 'horizontal_power_bound':F(11*73000,120)>6600,
 'horizontal_onset':F(2**4303,2**6600)<F(1,8),
 'original_tail_power_bound':F(2*73000,15)>9700,
 'original_tail_onset':F(2**337,2**9700)<F(1,8),
 'smoothing_onset':F(2**222,2**304)<F(1,8),
 'endpoint_height':F(u,8)>10000,
 'endpoint_onset':F(2**216,2**10000)<F(1,8),
 'E_derivative_lower':F(1,2)-F(2,36)==F(4,9),
 'vertical_derivative':79-F(3,40)*F(4,9)*73000<0,
 'horizontal_derivative':78-F(11,120)*F(4,9)*73000<0,
 'original_tail_derivative':5-F(2,15)*F(4,9)*73000<0,
 'smoothing_derivative':4-F(1,240)*F(4,9)*73000<0,
 'endpoint_derivative':4-F(u,8)<0,
 'bridge_all_exponents':u>96*10000**2,
 'bridge_padding_onset':F(5*2**520,2**10000)<1,
 'principal_padding_onset':F(2*2**520,2**10000)<1,
 'proper_short_prefix':F(u,8)>10000,
 'lnl_upper4':F(8,3)**4>37,
 'excluded_line_cost':F(486*37*64,u)<F(2,10**10),
 'excluded_line_monotonicity':F(1,36)+F(3,36)-1<0,
 'head_tail_bridge_cost':F(1,u**4)+F(648*38*297,u**3)+F(486*38*297,u**7)<F(1,10**20),
 'head_monotonicity':F(1,37)+F(8,1+8*36)-3<0,
 'tail_monotonicity':F(1,37)+F(8,1+8*36)-7<0,
 'whole_I_linear_allowance':F(2,10**10)+F(1,10**20)<F(1,10**9),
 'new_net_linear_budget':F(15509,750000000)-F(81,40000000)-F(1,10**7)-F(1,10**6)-F(1,10**9)==F(52658,3000000000),
}
assert all(guards.values()),guards
source=ROOT/'Actual_Mobius_AP_Rebalanced_Contour_Linear_Budget.txt'
print(json.dumps({'status':'EXACT_GUARDS_PASS_ANALYTIC_REVIEW_SEPARATE',
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'guard_count':len(guards),'guards':guards,
 'scope':'Finite rational onset and derivative certificates only; no replacement for primary zero-free input, BC/Mellin proof, actual support ownership, or D_N bound.'},indent=2))
