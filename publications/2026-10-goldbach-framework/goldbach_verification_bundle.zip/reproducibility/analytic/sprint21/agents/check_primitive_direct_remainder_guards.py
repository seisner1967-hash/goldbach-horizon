"""Exact guards for the written primitive signed zero-subtraction proof.

No complex-analysis input is inferred from these finite comparisons.
"""
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import hashlib
import json

u0 = 8_000_000
low_remainder = F(1000*16,u0**2)+F(10,u0)+F(100000*16**2,u0**3)+F(200*16,u0**3)
small_model = F(2187,10000)*F(16**7,u0**2)
large_model = F(4,3)*F(216,350000000)
e_upper = sum((F(1,factorial(k)) for k in range(8)),F(0))+F(9,8*factorial(8))
checks = {
 'e_lower_log_u_below_16': F(163,60)**16 > u0,
 'e_upper_below_11_over_4': e_upper < F(11,4),
 'log_u_above_15': F(11,4)**3 < 21 and 21**5 < u0,
 'u_below_2_power_23': u0 < 2**23,
 'R0_gap_denominator': F(6397,1000)*31 < 200,
 'Page_gap_denominator': 20*F(20452,10000) < 200,
 'zero_exponent_above_2500': F(u0,200*16) >=2500,
 'zero_monotonicity': F(500000)*F(14,15)>8000,
 'zero_power_guard': F(1,2**1571)<F(1,10**100),
 'rational_remainder_below_1e4': low_remainder < F(1,10**4),
 'polynomial_remainder_1': F(4000*2**(23*40),2**2000)<F(1,10**100),
 'polynomial_remainder_2': F(3000*2**(23*25),2**2000)<F(1,10**100),
 'polynomial_onset': F(u0,2)>2000,
 'polynomial_monotonicity': u0>40 and u0>50,
 'primitive_constant_100_slack': F(1,10**4)+3*F(1,10**100)<100,
 'low_conductor_transport_below_one': F(19800*16,u0*2800)<1,
 'sqrt_u_above_2800': u0>2800**2,
 'global_beta_above_three_quarters': 20*F(20452,10000)*15>4,
 'large_fixed_N_model': large_model+F(8,3*10**40)<F(1,10**6),
 'small_fixed_N_model': small_model+F(4,10**40)<F(1,10**6),
}
assert all(checks.values()), checks
source=Path(__file__).with_name('Primitive_Zero_Subtraction_Direct_Remainder_Budget.txt')
print(json.dumps({
 'status':'PRIMITIVE_DIRECT_REMAINDER_EXACT_GUARDS_PASS',
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'checks':checks,
 'primitive_constant':100,
 'rational_remainder_fraction':str(low_remainder),
 'small_fixed_N_model_fraction':str(small_model),
 'large_fixed_N_model_fraction':str(large_model),
 'analytic_Lean_axioms_added':False,
 'full_AP_assembly':False,
 'Goldbach_proof':False,
},indent=2,sort_keys=True))
