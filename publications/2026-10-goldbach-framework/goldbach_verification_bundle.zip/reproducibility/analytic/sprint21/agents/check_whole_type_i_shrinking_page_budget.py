"""Exact arithmetic guards for the genuine whole-I shrinking assembly."""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    terms={
        'bridge':F(90,2**384),
        'retained_head':F(648*90*91*721,2**256),
        'unique_Page_line':F(13122*91*90**4,2**128),
        'whole_divisor_tail':F(486*90*91*721,2**768),
    }
    guards={
        'true_mask_logK':8*90<2**128,
        'large_head_log_cut':1+8*90==721,
        'coefficient_head_constant':81*8==648,
        'coefficient_tail_constant':81*6==486,
        'exceptional_line_constant':81*162==13122,
        'bridge_monotonicity':F(1,64)-3<0,
        'head_monotonicity':F(1,64)+F(1,65)+F(8,513)-2<0,
        'Page_line_monotonicity':F(1,65)+F(4,64)-1<0,
        'tail_monotonicity':F(1,64)+F(1,65)+F(8,513)-6<0,
        'total_shrinking_budget':sum(terms.values(),F(0))<F(1,10**12),
    }
    if not all(guards.values()):
        raise AssertionError(guards)
    p=Path(__file__)
    print(json.dumps({
        'status':'EXACT_ARITHMETIC_PASS',
        'scope':'Exact finite coefficient/onset comparisons. Does not prove analytic inputs, I, D_N or Goldbach by finite checks.',
        'guards':guards,
        'guard_count':len(guards),
        'terms':{k:str(v) for k,v in terms.items()},
        'sum':str(sum(terms.values(),F(0))),
        'script_sha256':sha(p),
        'source_sha256':sha(p.with_name('Whole_Type_I_U1_Shrinking_Budget_With_Page_Projection.txt')),
        'large_head_input_sha256':sha(p.with_name('Mobius_AP_Large_Head_And_Unique_Page_Line.txt')),
    },indent=2))


if __name__=='__main__':
    main()
