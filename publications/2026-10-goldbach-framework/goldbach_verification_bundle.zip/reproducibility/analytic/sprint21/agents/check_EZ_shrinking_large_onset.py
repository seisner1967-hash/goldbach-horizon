"""Exact calibration of existing WHOLE E_Z envelopes; no finite-to-infinite claim."""
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import hashlib,json

u=2**128
l_upper=90
guards={
 'log2_lt_7_over_10':sum((F(7,10)**j/F(factorial(j)) for j in range(5)),F(0))>2,
 'log_u_upper':128*F(7,10)<90,
 'log_u_lower':128*F(1,2)==64,
 'sqrt_u_over_60_gt_10000':u>60*10000**2,
 'u_over_40_gt_10000':u>40*10000,
 'u_over_4_gt_10000':u>4*10000,
 'head_power':4*10**8<2**29 and 90<2**7 and 29+6*128+7==804,
 'tail_power':160<2**8 and 8+3*128+7==399,
 'corner_power':40<2**6 and 6+128+7+4*129==657,
 'head_uniform_decrease':u>60*(2*7)**2,
 'tail_uniform_decrease':u>40*4,
 'corner_uniform_decrease':u>4*6,
 'whole_EZ_shrinking_ratio':F(2**804+2**399+2**657,2**10000)<F(1,10**100),
}
assert all(guards.values()),guards
base=Path(__file__).resolve().parent
out={
 'status':'EXACT_GUARDS_PASS_WRITTEN_PROOF_SEPARATE',
 'guard_count':len(guards),'guards':guards,
 'coefficient_in_N_over_u_logu':'1/10^100',
 'onset_logN':'2^128',
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'source_sha256':hashlib.sha256((base/'EZ_Whole_Shrinking_Budget_Large_Onset.txt').read_bytes()).hexdigest(),
 'frozen_EZ_assembly_sha256':'e7fa54df46e34ee22c9831b54627a89a7c0d0e697f9b5a48b49c2893243cbd45',
 'frozen_endpoint_mask_bridge_sha256':'a58bc9ceb88c417ea74b7d975d538e9d3e340362f3b21219ed9339855bd96b29',
 'frozen_mask_transport_sha256':'32eacfe07c8adbabdac79db0a825f05f9eb29ac7b782c797cd16bbc81ed25be6',
 'scope':'Rational calibration only. Written derivative arguments establish uniformity; frozen exact support and existing analytic inputs establish the whole E_Z envelope. No Lean analytic theorem, Goldbach margin, or D_N bound.'
}
print(json.dumps(out,indent=2))
