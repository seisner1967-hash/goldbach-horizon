from pathlib import Path
from fractions import Fraction as F
from math import gcd, lcm
import hashlib, json

HERE=Path(__file__).resolve().parent
LIB=HERE/'check_exact_terminal_recombination.py'
expected='e2ec73840bdbf3eba9e7dc760f5d2616a482a6de256ff5045ce1b3e56e02d6c5'
assert hashlib.sha256(LIB.read_bytes()).hexdigest()==expected
ns={}
exec(LIB.read_text(encoding='utf-8').split('profiles=0')[0],ns)
mu=ns['mu']; factors=ns['factors']

cells=quadratic_terms=crt_remainders=survivors=local_factors=0
for N in range(2,82,2):
  def omega(d):
    out=1
    for p,_ in factors(d): out*=1 if N%p==0 else 2
    return out
  def g(d):
    out=F(1)
    for p,_ in factors(d):
      w=1 if N%p==0 else 2
      out*=F(w,p-w)
    return out
  for z in (2,3,5,8,12):
    ds=[d for d in range(1,z) if mu(d)]
    G=sum((g(d) for d in ds),F(0))
    weights={}
    for d in ds:
      gd=sum((g(h) for h in ds if h*d<z and gcd(h,d)==1),F(0))
      pre=F(mu(d))
      for p,_ in factors(d):
        w=1 if N%p==0 else 2
        pre*=F(p,p-w)
      weights[d]=pre*gd/G
      assert abs(weights[d])<=1
    assert weights[1]==1
    quad=F(0); full_remainder=F(0)
    for d in ds:
      for e in ds:
        q=lcm(d,e)
        quad+=weights[d]*weights[e]*F(omega(q),q)
        number=sum(n*(N-n)%q==0 for n in range(1,N))
        remainder=F(number)-F((N-1)*omega(q),q)
        assert abs(remainder)<=omega(q)<=q<=d*e
        full_remainder+=abs(weights[d]*weights[e]*remainder)
        quadratic_terms+=1; crt_remainders+=1
    assert quad==1/G
    assert full_remainder<=z**4
    primes=[p for p in range(2,z) if factors(p)==((p,1),)]
    count=0; actual_majorant=F(0)
    for n in range(1,N):
      ok=all(n*(N-n)%p for p in primes)
      count+=ok
      v=sum((weights[d] for d in ds if n*(N-n)%d==0),F(0))
      assert v*v>=int(ok)
      actual_majorant+=v*v
      survivors+=1
    assert count<=actual_majorant<=F(N,G)+z**4
    for p in primes:
      w=1 if N%p==0 else 2
      assert 1+g(p)==F(p,p-w)
      # Exact finite Euler relation, per local factor, after S(N).
      if p!=2:
        c=1-F(1,(p-1)**2)
        ratio=F(p-1,p-2) if N%p==0 else F(1)
        assert F(p,p-w)==F(p,p-1)**2/c/ratio
      local_factors+=1
    cells+=1

guards={
 'main_constant_under_159000':F(402653184,2541)<159000,
 'final_constant_slack':159001<200000,
 'mean_markov_onset':F(8000000,8)>=16,
 'tiny_error_at_u128':F(9*128**2,2**64)<1,
 'log_u0_bound':128*F(7,10)<90,
 'linear_sector_allowance_at_u0':F(200000*81**2*91**2,2**128)<F(1,10**24),
 'linear_allowance_fits_old_linear_reference':F(1,10**24)<F(1,60000),
 'C2_lower_above_half':F(2541,4096)>F(1,2),
 'singular_lower_above_one':F(2541,2048)>1,
}
assert all(guards.values())
print(json.dumps({'status':'PASS','scope':'finite Selberg identities and rational guards; no global D bound',
 'N_values':[2,80,2],'levels':[2,3,5,8,12],
 'cells':cells,'quadratic_terms':quadratic_terms,'crt_remainders':crt_remainders,
 'physical_row_majorants':survivors,'local_euler_factors':local_factors,
 'guards':guards,'library_sha256':expected},indent=2,sort_keys=True))
