from fractions import Fraction as F
import json
g={
 'three_small_above_alpha':F(3,20)>F(1,8),
 'two_small_below_alpha':F(2,18)<F(1,8),
 'individual_small_below_alpha':F(1,18)<F(1,8),
 'max_P':3*F(1,18)==F(1,6),
 's_lower':(F(12,25)-F(1,6))/F(1,8)==F(188,75),
 's_lower_positive_gap':F(188,75)-F(5,2)==F(1,150),
 'P_count_max_primes':F(12,25)/F(1,20)<10,
 'conservative_triplets':10*9*8//6==120,
 'BV_total_below_half':F(12,25)<F(1,2),
 'weighted_BV_power':F(5)-F(40,2)<-1,
 'theta_conversion_power':F(12,25)+F(1,2)==F(49,50)<1,
 'SF_plus_one_power':F(1,2)+F(1,6)-F(3,40)==F(71,120)<1,
 'C2_f_baseline':F(32)*F(2541,4096)*F(2,5)*F(2,5)==F(2541,800)>F(31,10),
 'log_three_halves':F(3,2)**5>F(11,4)**2,
 'log_ten_ninths':F(10,9)**10>F(11,4),
 'harmonic_triples':F(1,10)**3/F(6)==F(1,6000),
 'count_margin':F(31,240000)-F(1,10**6)-F(1,8000)==F(19,6000000)>0,
 'negative_row_coefficient':F(3,20)-F(7,50)==F(1,100)>0,
 'negative_credit':F(7,50)*F(1,8000)==F(7,400000)>F(1,60000),
}
g.update({'fixed_P_exponent':F(47,125)*F(5,6)/F(1,8)==F(188,75),'total_modulus_exponent':F(47,125)+(1-F(47,125))/6==F(12,25),'bad_main_300_saving':100-300==-200})
assert all(g.values()),{k:v for k,v in g.items() if not v}
print(json.dumps({'all_exact_guards_passed':True,'guard_count':len(g),'guards':g,
 'scope':'Rational exponent and coefficient arithmetic only. The classical lower-count onset is not evaluated; no full-profile exterior or Goldbach estimate.'},indent=2,sort_keys=True))
