"""Exact arithmetic guards for the missing-prime square reference.

The primary analytic inputs and infinite inequalities are written separately.
"""
from fractions import Fraction as F
from pathlib import Path
from math import factorial
import hashlib
import json

u0=8_000_000
eupper=sum((F(1,factorial(k)) for k in range(8)),F())+F(9,8*factorial(8))
aperror=F(34*u0**2,2**2240)+F(200,u0**8)+F(17*u0**3,2**2000)
guards={
 'theta_argument_onset':2*u0>3594641,
 'log_u_below_16':F(163,60)**16>u0,
 'log_u_above_15':eupper<F(11,4) and F(11,4)**3<21 and 21**5<u0,
 'log4_below_2':F(8,3)**2>4,
 'one_prime_loss_below_one_percent':F(18,u0)<F(1,100),
 'retained_prime_log_mass':1-F(6,5*15**2)-F(1,100)>F(1,2),
 'square_moduli_within_low_range':16*u0**2<=u0**10,
 'AP_error_below_quarter':aperror<F(1,4),
 'AP_error_monotonicities':u0>F(4*5,4)**2 and u0>3,
 'pair_modulus_onset':F(256*u0**4,2**1024)<1,
 'pair_modulus_monotonicity':F(4,u0)<F(3,8),
 'BT_log_gap_coefficient':F(2,1)/F(5,8)==F(16,5),
 'overlap_density_below_eighth':F(16,5*u0)<F(1,8),
 'proper_power_overlap_below_eighth':F(512*u0**4*16,2**2000)<F(1,8),
 'proper_power_overlap_monotonicity':F(5,u0)<F(1,2),
 'ordinary_PNT_reference_correction':F(8704*u0**3*16,2**2240)<1,
 'ordinary_PNT_correction_monotonicity':u0>100,
 'singular_reference_coefficient':F(2541,2048)*F(1,256)==F(2541,524288),
}
assert all(guards.values()),guards
source=Path(__file__).with_name('Universal_Missing_Prime_Square_Reference.txt')
print(json.dumps({
 'status':'UNIVERSAL_SQUARE_REFERENCE_EXACT_GUARDS_PASS',
 'checks':guards,
 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'gap_coefficient':'1/256',
 'scale':'N/(logN*loglogN)',
 'includes_multiples_of_97_primorial':True,
 'total_Goldbach_margin':False,
 'Goldbach_proof':False,
},indent=2,sort_keys=True))
