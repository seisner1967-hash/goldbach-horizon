Finite Identities and Explicit Error Budgets in a Framework for Binary Goldbach
Durand Serge, Independent researcher, seisner1967@gmail.com
Version 2, 1 October 2026. English research report, 51 pages.

SCOPE
Partial finite identities, explicit error accounting and sector estimates.
Goldbach remains open. The primitive-character input and its dependent
universal/exterior estimates remain conditional. No external peer review,
fresh Lean compilation or journal acceptance is asserted.

SOURCE
One standalone ASCII LaTeX file: goldbach_synthesis.tex.
Compile with a standard LaTeX installation (pdfLaTeX); run until references
settle. No external figures, bibliography processor or shell escape needed.
The delivered PDF was exported with existing Tectonic after the native editor
compiler reported a platform directory configuration failure.

REPRODUCTION SNAPSHOT
https://github.com/seisner1967-hash/goldbach-horizon/tree/8ef89b3cef4cddffd9bf9ca81141280b31ea6af6/publications/2026-10-goldbach-framework
The frozen verification ZIP contains 362 manifest-listed payloads, including
canonical Lean sources, exact dependency pins, retained audit records, the
658-declaration statement registry, 19 latest finite headers and checkers.
SHA256: 310c63cdb09e9a190da5bc01ddd781515a7cc717d73b680c8f30ef8fae7b8625
Historical archived notes are provenance; current manuscript defines scope.

V2 EDITORIAL CHANGES
Four scoped contributions highlighted; internal accounting terminology revised;
reflected real zero described by Re(s)<1/2, not a lower half-plane;
public versioned evidence link added; independent-review priority page added.
The incomplete Bordignon substitution chain has not been upgraded to a theorem.

LICENCE AND DISCLOSURE
Manuscript and TeX: CC BY 4.0, see LICENSE_MANUSCRIPT.txt.
Evidence and software retain their own rights, not blanket relicensed.
Substantial generative-AI assistance is disclosed; Durand Serge is human author.
Archive or repository availability is not journal acceptance or arXiv moderation.
