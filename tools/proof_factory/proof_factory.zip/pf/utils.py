from __future__ import annotations
import json
from pathlib import Path
from typing import Any

def read_json(path, default=None):
    if not path.exists(): return default
    return json.loads(path.read_text(encoding="utf-8"))

def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
